#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#ifdef UNIX
#include <unistd.h>
#include <sys/time.h>
#else
#include <time.h>
#endif

#ifdef CONNBASE

#include "Conn.h"
#define CONNTYPE Conn

#else

#ifdef CONNPROXY

#include "HTTPProxy.h"
#define CONNTYPE HTTPProxy

#else

#include "EDFConn.h"
#define CONNTYPE EDFConn

#endif

#endif

#define CERTFILE "ConnTest.pem"

CONNTYPE *pServer = NULL, *pClient = NULL;

void Panic(int iSignal)
{
   printf("Panic entry %d\n", iSignal);

   /* if(pClient != NULL)
   {
      // pClient->Disconnect();
      printf("Panic deleting client %p\n", pClient);
      delete pClient;
   } */

   if(pServer != NULL)
   {
      // pServer->Disconnect();
      printf("Panic deleting server %p\n", pServer);
      delete pServer;
   }

   printf("Panic exit\n");
   exit(1);
}

#ifdef CONNBASE
bool ConnTime(CONNTYPE *pConn)
{
   long lTime = 0;
   char szTime[100];

   lTime = time(NULL);
   printf("ConnTime %ld\n", lTime);

   sprintf(szTime, "Time is %ld", lTime);

   return pConn->Write((byte *)szTime, strlen(szTime));
}
#endif

int func1(int argc, char **argv)
{
   int iPort = 0, iInterval = 3;
   long lTime = 0;
   bool bSecure = false;
   bool bLoop = true;
   char *szServer = NULL;
#ifdef CONNBASE
   bool bRead = false;
   long lDataLen = 0;
   byte *pData = NULL;
#else
   char *szType = NULL, *szMessage = NULL;
   EDF *pIn = NULL, *pOut = NULL;
#endif

   if(argc == 2)
   {
      iPort = atoi(argv[1]);
   }
   else if(argc == 3 || (argc == 4 && strcmp(argv[3], "-secure") == 0))
   {
      szServer = argv[1];
      iPort = atoi(argv[2]);
      if(argc == 4)
      {
         bSecure = true;
      }
   }
   else
   {
      printf("Usage:\n");
      printf("      ConnTest <port>\n");
      printf("      ConnTest <server> <port> [-secure]\n");

      return 1;
   }

   signal(SIGINT, Panic);

   if(szServer == NULL)
   {
      iInterval++;

      pServer = new CONNTYPE();

      // pServer->Timeout(-1);

      if(pServer->Bind(iPort, CERTFILE) == false)
      {
         printf("Bind failed, %s\n", pServer->Error());

         printf("Deleting server %p\n", pServer);
         delete pServer;

         return 1;
      }

      while(bLoop == true)
      {
         pServer->AcceptReset();
         pClient = (CONNTYPE *)pServer->Accept();
         printf("Accept %ld, %p\n", time(NULL), pClient);

         if(pClient != NULL)
         {
            // pClient->Timeout(-1);

/* #ifdef CONNBASE
#ifdef CONNSECURE
            if(pClient->SetSecure() == false)
            {
               pClient->Disconnect();
            }
#endif
#endif */

            while(pClient->State() == Conn::OPEN)
            {
               printf("Server loop %ld\n", time(NULL));

#ifdef CONNBASE
               if(time(NULL) >= lTime + iInterval)
               {
                  lTime = time(NULL);
                  ConnTime(pClient);
               }

               bRead = pClient->Read();
               // printf("Server read %s\n", BoolStr(bRead));
               // printf("Client read %ld, %s %ld\n", time(NULL), BoolStr(bRead), pClient->Buffer());

               if(pClient->ReadBuffer(&pData) > 0)
               {
                  lDataLen = pClient->ReadBuffer();
                  memprint("From client", pData, lDataLen);

#ifdef CONNSECURE
                  if(strncmp((char *)pData, "secure", 6) == 0)
                  {
                     pClient->Write((byte *)"secure", 6);
                     pClient->FlagSecure();

                     if(pClient->SetSecure() == false)
                     {
                        pClient->Disconnect();
                     }
                  }
#endif

                  pClient->Release(lDataLen);
               }
#else
               pIn = pClient->Read();

               if(pIn != NULL)
               {
                  EDFPrint("From client", pIn);

                  // pClient->Write(pIn);

                  szType = NULL;
                  szMessage = NULL;

                  pOut = new EDF();

                  pIn->Get(&szType, &szMessage);
                  if(szType != NULL && szMessage != NULL)
                  {
                     if(stricmp(szType, "request") == 0)
                     {
                        if(stricmp(szMessage, "time") == 0)
                        {
                           // pIn->GetChild("data", &iData);
                           // printf("Client time %ld\n", iData);

                           // ConnTime(pClient, 1);
                           pOut->Set("reply", "time");
                           pOut->AddChild("data", time(NULL));
                        }
                        else
                        {
                           printf("Bad request %s\n", szMessage);

                           pOut->Set("reply", "rq_invalid");
                           pOut->AddChild("request", szMessage);
                        }
                     }
                     else
                     {
                        printf("Bad message %s", szType);
                        if(szMessage != NULL)
                        {
                           printf(" / %s", szMessage);
                        }
                        printf("\n");

                        pOut->Set("reply", "rq_invalid");
                        pOut->AddChild("type", szType);
                        if(szMessage != NULL)
                        {
                           pOut->AddChild("message", szMessage);
                        }
                     }
                  }
                  else
                  {
                     printf("Bad message %s / %s\n", szType, szMessage);
                     pOut->Set("reply", "rq_invalid");
                     if(szType != NULL)
                     {
                        pOut->AddChild("type", szType);
                     }
                     if(szMessage != NULL)
                     {
                        pOut->AddChild("message", szMessage);
                     }
                  }

                  // printf("Server reply\n");
                  EDFPrint("To client", pOut);
                  pClient->Write(pOut);

                  delete pOut;

                  delete[] szType;
                  delete[] szMessage;

                  delete pIn;
               }
               /* else
               {
                  printf("Server no input\n");
               } */
#endif
            }

            printf("Deleting client %p\n", pClient);
            delete pClient;
         }
      }

      printf("Deleting server %p\n", pServer);
      delete pServer;
   }
   else
   {
      pClient = new CONNTYPE();

#ifdef CONNBASE
      if(pClient->Connect(szServer, iPort, false, CERTFILE) == false)
#else
      if(pClient->Connect(szServer, iPort, bSecure, CERTFILE) == false)
#endif
      {
         printf("Connect failed, %s\n", pClient->Error());

         printf("Deleting client %p\n", pClient);
         delete pClient;

         return 1;
      }

#ifdef CONNBASE
#ifdef CONNSECURE
      if(bSecure == true)
      {
         pClient->Write((byte *)"secure", 6);
         pClient->FlagSecure();
         /* if(pClient->SetSecure() == false)
         {
            pClient->Disconnect();
         } */
      }
#endif
#endif

      while(pClient->State() == Conn::OPEN)
      {
         printf("Client loop %ld\n", time(NULL));

         if(time(NULL) >= lTime + iInterval)
         {
            lTime = time(NULL);
#ifdef CONNBASE
            ConnTime(pClient);
#else
            pOut = new EDF();
            pOut->Set("request", "time");
            EDFPrint("To server", pOut);
            pClient->Write(pOut);
            delete pOut;
#endif
         }

#ifdef CONNBASE
         bRead = pClient->Read();
         // printf("Client read %s\n", BoolStr(bRead));

         if(pClient->ReadBuffer(&pData) > 0)
         {
            lDataLen = pClient->ReadBuffer();
            memprint("From server", pData, lDataLen);

#ifdef CONNSECURE
            if(strncmp((char *)pData, "secure", 6) == 0)
            {
               if(pClient->SetSecure() == false)
               {
                  pClient->Disconnect();
               }
            }
#endif

            pClient->Release(lDataLen);
         }
#else
         pIn = pClient->Read();

         if(pIn != NULL)
         {
            EDFPrint("From server", pIn);

            delete pIn;
         }
#endif
      }

      printf("Deleting client %p\n", pClient);
      delete pClient;
   }

   return 0;
}

int func3()
{
#ifdef CONNBASE
   Conn *pConn = new Conn();
   byte *pFile = NULL;
   size_t lLength = 0;

   printf("func3 connecting\n");
   if(pConn->Connect("localhost", 4040) == false)
   {
      return 1;
   }

   printf("func3 reading\n");
   pFile = FileRead("/home/mike/software/wb3xp_beta6.exe", &lLength);
   if(pFile == NULL)
   {
      return 1;
   }

   printf("func3 writing %p(%d)\n", pFile, lLength);
   pConn->Write(pFile, lLength);

   printf("func3 looping\n");
   while(pConn->State() == Conn::OPEN)
   {
      pConn->Read();

      if(pConn->State() == Conn::OPEN)
      {
         printf("Sleeping %ld...\n", time(NULL));
#ifdef UNIX
         sleep(2);
#else
         Sleep(2000);
#endif
      }
   }
#endif

   return 0;
}

int func4()
{
#ifdef CONNBASE
   int iLoopNum = 0;
   bool bRead = false;
   long lBufferLen = 0;
   byte *pBuffer = NULL;
   Conn *pClient = new Conn();

   pClient->Connect("localhost", 80);

   pClient->Write("GET /localstart.asp HTTP/1.1\r\n\r\n");

   while(pClient->State() == Conn::OPEN)
   {
      printf("func4 loop %d state %d\n", iLoopNum, pClient->State());

      bRead = pClient->Read();
      printf("func4 read %s, %ld\n", BoolStr(bRead), pClient->ReadBuffer());

      if(pClient->ReadBuffer() > 0)
      {
         lBufferLen = pClient->ReadBuffer(&pBuffer);
         memprint("func4 buffer", pBuffer, lBufferLen);
         pClient->Release();
      }
   }
#endif

   return 0;
}

int main(int argc, char **argv)
{
   return func1(argc, argv);
   // return func2(argc, argv);

   // return func3();

   // return func4();
}
