/*
** HTTPConn: HTML connection class based on Conn class
** (c) 2001 Michael Wood (mike@compsoc.man.ac.uk)
**
** Redistribution and use in source and binary forms, with or without
** modification, are permitted provided this copyright message remains
*/

#include "stdafx.h"

// Standard headers
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <ctype.h>

#include "HTTPConn.h"

#define HTTP_PORT 80

// Constructor
HTTPConn::HTTPConn(const char *szProxyServer, int iProxyPort, bool bProxySecure) : Conn()
{
   STACKTRACE
   debug("HTTPConn::HTTPConn %s %d %s\n", szProxyServer, iProxyPort, BoolStr(bProxySecure));

   m_szProxyServer = strmk(szProxyServer);
   m_iProxyPort = iProxyPort;
   m_bProxySecure = bProxySecure;

   m_szServer = NULL;
   m_bSecure = false;
   m_iPort = -1;

   m_bURLSent = false;
   m_szURLType = NULL;
   m_szURLPath = NULL;
   m_fURLProtocol = 1.0;
   m_pURLFields = NULL;
   m_pURLCookie = NULL;
}

HTTPConn::~HTTPConn()
{
   STACKTRACE
   debug("HTTPConn::~HTTPConn\n");

   delete[] m_szProxyServer;

   delete[] m_szServer;

   URLReset();
}

bool HTTPConn::Connect(const char *szServer, int iPort, bool bSecure)
{
   debug("HTTPConn::Connect %s %d %s\n", szServer, iPort, BoolStr(bSecure));

   m_iType = CLIENT;

   m_szServer = strmk(szServer);
   m_iPort = iPort;
   m_bSecure = bSecure;

   return true;
}

bool HTTPConn::SetURL(const char *szType, const char *szPath, float fProtocol)
{
   if(m_iType != CLIENT)
   {
      debug("HTTPConn::SetURL not a client\n");
      return false;
   }

   m_szURLType = strmk(szType);
   m_szURLPath = strmk(szPath);
   m_fURLProtocol = fProtocol;

   return true;
}

bool HTTPConn::SetField(const char *szName, const char *szValue)
{
   debug("HTTPConn::SetField %s %s\n", szName, szValue);
   return SetField(szName, (const byte *)szValue, strlen(szValue));
}

bool HTTPConn::SetField(const char *szName, const byte *pValue, int iValueLen)
{
   STACKTRACE
   int iURLFieldNum = 0;
   URLField *pNew = NULL; //, **pTemp = NULL;

   if(m_iType != CLIENT)
   {
      debug("HTTPConn::SetField not a client\n");
      return false;
   }

   debug("HTTPConn::SetField entry %s %p %d\n", szName, pValue, iValueLen);

   while(iURLFieldNum < m_iNumURLFields && stricmp(m_pURLFields[iURLFieldNum]->m_szName, szName) != 0)
   {
      iURLFieldNum++;
   }

   if(iURLFieldNum < m_iNumURLFields)
   {
      debug("HTTPConn::SetField set field %d\n", iURLFieldNum);
      delete m_pURLFields[iURLFieldNum]->m_pValue;
      m_pURLFields[iURLFieldNum]->m_pValue = new bytes(pValue, iValueLen);
   }
   else
   {
      debug("HTTPConn::SetField new field\n");
      pNew = new URLField;
      pNew->m_szName = strmk(szName);
      pNew->m_pValue = new bytes(pValue, iValueLen);

      debug("HTTPConn::SetField array add\n");
      // ARRAY_INSERT(URLField *, m_pURLFields, m_iNumURLFields, pNew, m_iNumURLFields, pTemp)
   }

   debug("HTTPConn::SetField exit true\n");
   return true;
}

bool HTTPConn::SetCookie(const byte *pCookie, int iCookieLen)
{
   if(m_iType != CLIENT)
   {
      debug("HTTPConn::SetCookie not a client\n");
      return false;
   }

   return true;
}

bytes *HTTPConn::Read()
{
   STACKTRACE
   bool bRead = false;
   long lReadLen = 0;
   byte *pRead = NULL;
   bytes *pReturn = NULL;

   debug("HTTPConn::Read entry, %d\n", State());

   if(m_iType == CLIENT && m_bURLSent == false)
   {
      if(URLSend() == false)
      {
         debug("HTTPConn::Read exit NULL, URLSend failed\n");
         return NULL;
      }
   }

   bRead = Conn::Read();

   lReadLen = ReadBuffer((byte **)&pRead);
   debug("HTTPConn::Read base return %s, %ld %p\n", BoolStr(bRead), lReadLen, pRead);
   if(lReadLen > 0)
   {
      memprint(debugfile(), "HTTPConn::Read buffer", pRead, lReadLen);
   }

   if(m_iType == SERVER)
   {
      if(pRead == NULL || strstr((char *)pRead, "\r\n\r\n") == NULL)
      {
         return NULL;
      }

      Release();
   }

   pReturn = new bytes(pRead, lReadLen);

   debug("HTTPConn::Read exit %p, %ld\n", pReturn, pReturn->Length());
   // return (char *)pRead;
   return pReturn;
}

bool HTTPConn::Write(const char *szData)
{
   if(m_iType != SERVER)
   {
      debug("HTTPConn::Write not a server\n");
      return false;
   }

   return Conn::Write(szData);
}

bool HTTPConn::Write(const byte *pData, long lDataLen)
{
   if(m_iType != SERVER)
   {
      debug("HTTPConn::Write not a server\n");
      return false;
   }

   return Conn::Write(pData, lDataLen);
}

void HTTPConn::Close()
{
   Conn::Close();
}

// Create: Override base class creator for Accept call
Conn *HTTPConn::Create(bool bSecure)
{
   HTTPConn *pConn = NULL;

   debug("HTTPConn::Create\n");

   pConn = new HTTPConn();
   return pConn;
}

bool HTTPConn::URLSend()
{
   STACKTRACE
   int iConnPort = 0;
   bool bConnSecure = false;
   char *szConnServer = NULL;
   bytes *pWrite = NULL;

   debug("HTTPConn::URLSend entry, %s %d %s / %s %s %f\n", m_szServer, m_iPort, BoolStr(m_bSecure), m_szURLType, m_szURLPath, m_fURLProtocol);

   pWrite = new bytes();

   if(m_szProxyServer != NULL)
   {
      debug("HTTPConn::URLSend using proxy settings\n");

      szConnServer = m_szProxyServer;
      iConnPort = m_iProxyPort;
      bConnSecure = m_bProxySecure;
   }
   else
   {
      szConnServer = m_szServer;
      iConnPort = m_iPort;
      bConnSecure = m_bSecure;
   }

   if(iConnPort == -1)
   {
      if(bConnSecure == true)
      {
         iConnPort = 443;
      }
      else
      {
         iConnPort = 80;
      }
   }

   debug("HTTPConn::URLSend connecting to %s %d %s\n", szConnServer, iConnPort, BoolStr(bConnSecure));
   if(Conn::Connect(szConnServer, iConnPort, bConnSecure) == false)
   {
      debug("HTTPConn::URLSend exit false, connect failed\n");
      return false;
   }

   pWrite->Append(m_szURLType);
   pWrite->Append(" ");
   pWrite->Append(m_szURLPath);
   pWrite->Append(" HTTP/");
   if(m_fURLProtocol == 1.1)
   {
      pWrite->Append("1.1");
   }
   else
   {
      pWrite->Append("1.0");
   }
   pWrite->Append("\r\n");

   bytesprint(debugfile(), "HTTPConn::URLSend request", pWrite);

   // bReturn = Conn::Write(pRequest->Data(false), pRequest->Length());

   URLReset();

   debug("HTTPConn::URLSend exit true\n");
   return true;
}

void HTTPConn::URLReset()
{
   STACKTRACE
   // int iURLFieldNum = 0;

   STR_NULL(m_szURLType)
   STR_NULL(m_szURLPath)

   /* for(iURLFieldNum = 0; iURLFieldNum < m_iNumURLFields; iURLFieldNum++)
   {
      STR_NULL(m_pURLFields[iURLFieldNum]->m_szName)
      delete m_pURLFields[iURLFieldNum]->m_pValue;
   }
   STR_NULL(m_pURLFields) */

   delete m_pURLCookie;
   m_pURLCookie = NULL;
}
