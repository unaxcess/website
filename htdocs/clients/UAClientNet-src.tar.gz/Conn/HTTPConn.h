/*
** HTTPConn: HTML connection class based on Conn class
** (c) 2001 Michael Wood (mike@compsoc.man.ac.uk)
**
** Redistribution and use in source and binary forms, with or without
** modification, are permitted provided this copyright message remains
*/

#ifndef _HTTPCONN_H_
#define _HTTPCONN_H_

#include "Conn.h"

class HTTPConn : public Conn
{
public:
   HTTPConn(const char *szProxyServer = NULL, int iProxyPort = 0, bool bProxySecure = false);
   ~HTTPConn();

   bool Connect(const char *szServer, int iPort = -1, bool bSecure = false);

   bool SetURL(const char *szType, const char *szPath, float fProtocol = 1.0);

   bool SetField(const char *szName, const char *szValue);
   bool SetField(const char *szName, const byte *pValue, int iValueLen);
   // bool SetField(const char *szName, bytes *pValue);

   bool SetCookie(const byte *pCookie, int iCookieLen);
   // bool SetCookie(bytes *pCookie);

   // Read / write methods
   bytes *Read();
   bool Write(const char *szData);
   bool Write(const byte *pData, long lDataLen);

   void Close();

protected:
   Conn *Create(bool bSecure = false);

private:
   struct URLField
   {
      char *m_szName;
      bytes *m_pValue;
   };

   char *m_szProxyServer;
   int m_iProxyPort;
   bool m_bProxySecure;

   char *m_szServer;
   int m_iPort;
   bool m_bSecure;

   bool m_bURLSent;
   char *m_szURLType;
   char *m_szURLPath;
   float m_fURLProtocol;

   URLField **m_pURLFields;
   int m_iNumURLFields;

   bytes *m_pURLCookie;

   bool URLSend();
   void URLReset();
};

#endif
