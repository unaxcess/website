#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "HTTPConn.h"

int main(int argc, char **argv)
{
   int iPort = 80, iClientNum = 0, iNumClients = 0;
   bytes *pRequest = NULL;
   HTTPConn *pServer = NULL, **pClients = NULL, **pTemp = NULL, *pAccept = NULL;

   debuglevel(DEBUGLEVEL_DEBUG);

   if(argc >= 2)
   {
      iPort = atoi(argv[1]);
   }

   pServer = new HTTPConn();

   if(pServer->Bind(iPort, "HTTPConnTest.pem") == false)
   {
      printf("Bind failed, %s\n", pServer->Error());

      printf("Deleting server %p\n", pServer);
      delete pServer;

      return 1;
   }

   while(true)
   {
      printf("Accept reset\n");
      pServer->AcceptReset();

      iClientNum = 0;
      while(iClientNum < iNumClients)
      {
         if(pClients[iClientNum]->State() == Conn::OPEN || pClients[iClientNum]->State() == Conn::CLOSING)
         {
            printf("Accepting %d(%p)\n", iClientNum, pClients[iClientNum]);

            pServer->AcceptCheck(pClients[iClientNum]);
            iClientNum++;
         }
         else
         {
            printf("Deleting %d(%p)\n", iClientNum, pClients[iClientNum]);
            delete pClients[iClientNum];

            ARRAY_DELETE(HTTPConn *, pClients, iNumClients, iClientNum, pTemp);
         }
      }

      printf("Accepting (%d clients)\n", iNumClients);
      pAccept = (HTTPConn *)pServer->Accept(true);

      if(pAccept != NULL)
      {
         printf("Accept %p\n", pAccept);

         ARRAY_INSERT(HTTPConn *, pClients, iNumClients, pAccept, 0, pTemp);
      }

      for(iClientNum = 0; iClientNum < iNumClients; iClientNum++)
      {
         pRequest = pClients[iClientNum]->Read();
         if(pRequest != NULL)
         {
            printf("Sending standard response\n");

            pClients[iClientNum]->Write("HTTP/1.1 200 OK\r\n\r\n");

            pClients[iClientNum]->Close();

            delete pRequest;
         }
      }
   }

   return 0;
}
