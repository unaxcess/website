#include <stdio.h>
#include <string.h>

#include "SMTPConn.h"

SMTPConn::SMTPConn() : Conn()
{
   m_szHeaders = NULL;
   m_szValues = NULL;
   m_iNumHeaders = 0;
   
   m_szSubject = NULL;
   m_szText = NULL;
   
   m_bSent = false;
}

SMTPConn::~SMTPConn()
{
   int iHeaderNum = 0;
   
   for(iHeaderNum = 0; iHeaderNum < m_iNumHeaders; iHeaderNum++)
     {
	delete[] m_szHeaders[iHeaderNum];
	delete[] m_szValues[iHeaderNum];
     }
   delete[] m_szHeaders;
   delete[] m_szValues;
   
   delete[] m_szSubject;
   delete [] m_szText;
}

bool SMTPConn::Connect(const char *szServer, int iPort, const char *szHelo)
{
   if(Conn::Connect((char *)szServer, iPort) == false)
     {
	return false;
     }
   
   Write("HELO ");
   Write((char *)szHelo);
   Write("\r\n");
   
   return SMTPRead("Connect");
}

bool SMTPConn::SetFrom(const char *szFrom)
{
   if(m_bSent == true)
     {
	return false;
     }
   
   printf("SMTPConn::SetFrom %s\n", szFrom);
   
   Write("MAIL FROM: ");
   Write((char *)szFrom);
   Write("\r\n");
   
   return SMTPRead("SetFrom");
}

bool SMTPConn::SetTo(const char *szTo)
{
   if(m_bSent == true)
     {
	return false;
     }
   
   printf("SMTPConn::SetTo %s\n", szTo);
   
   Write("RCPT TO: ");
   Write((char *)szTo);
   Write("\r\n");
   
   return SMTPRead("SetTo");
}

bool SMTPConn::SetHeader(const char *szHeader, const char *szValue)
{
   int iNumHeaders = 0;
   char *szString = NULL, **szTemps = NULL;
   
   if(m_bSent == true)
     {
	return false;
     }
   
   printf("SMTPConn::SetHeader %s %s\n", szHeader, szValue);
   
   iNumHeaders = m_iNumHeaders;
   szString = strmk(szHeader);
   ARRAY_INSERT(char *, m_szHeaders, iNumHeaders, szString, iNumHeaders, szTemps);
   
   iNumHeaders = m_iNumHeaders;
   szString = strmk(szValue);
   ARRAY_INSERT(char *, m_szValues, iNumHeaders, szString, iNumHeaders, szTemps);
   
   m_iNumHeaders++;
   
   return true;
}

bool SMTPConn::SetText(const char *szText)
{
   if(m_bSent == true)
     {
	return false;
     }
   
   m_szText = strmk(szText);
   return true;
}

bool SMTPConn::Send()
{
   int iHeaderNum = 0;
   
   Write("DATA\r\n");
   SMTPRead("Send pre-DATA");
   
   for(iHeaderNum = 0; iHeaderNum < m_iNumHeaders; iHeaderNum++)
     {
	Write(m_szHeaders[iHeaderNum]);
	Write(": ");
	Write(m_szValues[iHeaderNum]);
	Write("\r\n");
     }
   if(iHeaderNum > 0)
     {
	Write("\r\n");
     }
   
   if(m_szText != NULL)
     {
	Write(m_szText);
     }
   
   Write("\r\n.\r\n");
   
   m_bSent = true;
   
   return SMTPRead("Send post-DATA");
}

bool SMTPConn::SMTPRead(const char *szMethod)
{
   byte *pBuffer = NULL;
   
   while(ReadBuffer() == 0)
     {
	Read();
     }
   
   ReadBuffer(&pBuffer);
   
   printf("qUAlm::%s buffer:\n", szMethod);
   memprint(pBuffer, ReadBuffer());
   
   Release();
   
   return true;
}
