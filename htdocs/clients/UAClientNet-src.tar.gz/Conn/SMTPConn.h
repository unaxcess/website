#ifndef _SMTPCONN_H_
#define _SMTPCONN_H_

#include "Conn/Conn.h"

class SMTPConn : public Conn
{
public:
   SMTPConn();
   ~SMTPConn();
   
   bool Connect(const char *szServer, int iPort, const char *szHelo);
   
   bool SetFrom(const char *szFrom);
   bool SetTo(const char *szTo);
   
   bool SetHeader(const char *szHeader, const char *szValue);   
   bool SetSubject(const char *szSubject);
   
   bool SetText(const char *szText);
   
   bool Send();
   
private:
   char **m_szHeaders;
   char **m_szValues;
   int m_iNumHeaders;
   
   char *m_szSubject;
   char *m_szText;
   
   bool m_bSent;
   
   bool SMTPRead(const char *szMethod);
};

#endif
