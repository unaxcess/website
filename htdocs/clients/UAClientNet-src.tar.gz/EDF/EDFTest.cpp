#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <stdlib.h>
#include <signal.h>

#include "EDF.h"

#include "XMLParser.h"

void Panic(int iSignal)
{
   debug("Panic entry %d, %d\n", iSignal, errno);
   
   STACKPRINT
   
   debug("Panic exit\n");
   exit(2);
}

int main(int argc, char **argv)
{
	bool bLoop = false;
	double dValue = 0.0;
	EDF *pEDF = NULL, *pXML = NULL;
	
	if(argc != 2)
	{
		printf("Usage: EDFTest <filename>\n");
		return 1;
	}

   signal(SIGINT, Panic);
   signal(SIGILL, Panic);
   signal(SIGSEGV, Panic);

   debuglevel(DEBUGLEVEL_DEBUG);
	
   pEDF = EDFParser::FromFile(argv[1]);

   if(pEDF != NULL)
   {
		bLoop = pEDF->Child();
		while(bLoop == true)
		{
			pEDF->Get(NULL, &dValue);
			printf("Value: %g\n", dValue);
			
			bLoop = pEDF->Iterate();
		}
	
	   /* EDFParser::Print("EDF 1", pEDF);
	   XMLParser::Print("XML 1", pEDF);
      XMLParser::ToFile(pEDF, "EDFTest.xml");

      pXML = XMLParser::FromFile("EDFTest.xml", NULL, -1);
      EDFParser::Print("EDF 2", pXML);
      XMLParser::Print("XML 2", pXML); 
      delete pXML; */
		
		delete pEDF;
   }
   else
   {
      printf("Unable to open %s, %s\n", argv[1], strerror(errno));
   }
		
	return 0;
}
