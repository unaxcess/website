#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdarg.h>

#include <curl/curl.h>

#include "EDF/EDF.h"

#include "EDF/HTMLParser.h"

char *SINGLETONS[] = { "br", "hr", "img", "input", "li", "meta", "option", "p", NULL };

char *m_szCurlCookie = NULL;
bytes *m_pCurlData = NULL;

#define VALID_CHAR \
(pPos < pStop)

#define IS_RETURN \
(*pPos == '\n' || (*pPos == '\r' && *(pPos + 1) == '\n'))

#define INC_RETURN \
/*printf("PageScan inc '\\%c' line num %ld -> %ld\n", *pPos == '\r' ? 'r' : 'n', lLineNum, lLineNum + 1);*/\
if(*pPos == '\r') \
{ \
   pPos++; \
} \
pLine = pPos + 1; \
lLineNum++;

#define CHECK_RETURN \
if(IS_RETURN) \
{ \
   INC_RETURN \
}

#define IS_SPACE \
(*pPos == ' ' || *pPos == '\r' || *pPos == '\n' || *pPos == '\t' || *pPos == '\0')

#define WHITE_SPACE(szParse) \
/*printf("PageScan white space %s %d '%c' [%d]\n", szParse != NULL ? szParse : "", pPos - pData, *pPos, *pPos);*/\
while(VALID_CHAR && IS_SPACE)\
{\
   CHECK_RETURN \
   pPos++;\
}

size_t curlwrite(void *pBuffer, size_t iSize, size_t iMembers, void *pStream)
{
   printf("curlwrite %p %d %d %p\n", pBuffer, iSize, iMembers, pStream);

   // printf("%s", (char *)pBuffer);

   m_pCurlData->Append((byte *)pBuffer, iSize * iMembers);

   return iSize * iMembers;
}

size_t curlheader(void *pBuffer, size_t iSize, size_t iMembers, void *pStream)
{
   char *szBuffer = (char *)pBuffer;

   printf("curlheader %p %d %d %p\n", pBuffer, iSize, iMembers, pStream);
   // printf("%s\n", (char *)pBuffer);

   if(strncmp(szBuffer, "Set-Cookie: ", 12) == 0 && m_szCurlCookie == NULL)
   {
      szBuffer += 12;
      m_szCurlCookie = strmk(szBuffer, 0, strchr(szBuffer, ';') - szBuffer);
   }

   return iSize * iMembers;
}

CURL *curlsetup(const char *szURL)
{
   CURL *pReturn = NULL;

   pReturn = curl_easy_init();

   curl_easy_setopt(pReturn, CURLOPT_WRITEFUNCTION, curlwrite);
   curl_easy_setopt(pReturn, CURLOPT_HEADERFUNCTION, curlheader);

   curl_easy_setopt(pReturn, CURLOPT_URL, szURL);

   m_pCurlData = new bytes();

   return pReturn;
}

bytes *curlperform(CURL *pCurl)
{
   int iCurl = CURLE_OK;
   bytes *pReturn = NULL;

   printf("curlperform entry\n");
   iCurl = curl_easy_perform(pCurl);
   if(iCurl != CURLE_OK)
   {
      delete m_pCurlData;

      printf("curlperform exit NULL, error %d\n", iCurl);
      return NULL;
   }

   curl_easy_cleanup(pCurl);

   pReturn = new bytes(m_pCurlData);

   printf("curlperform exit %p, %ld\n", pReturn, pReturn->Length());
   return pReturn;
}

bool Singleton(const char *szTag)
{
   bool bReturn = false;
   int iSingletonNum = 0;

   while(SINGLETONS[iSingletonNum] != NULL && stricmp(SINGLETONS[iSingletonNum], szTag) != 0)
   {
      iSingletonNum++;
   }

   if(SINGLETONS[iSingletonNum] != NULL)
   {
      bReturn = true;
   }

   return bReturn;
}

bytes *HTMLParser::Get(const char *szURL, const char *szCookie)
{
   CURL *pCurl = NULL;

   printf("HTMLParser::Get entry %s %s\n", szURL, szCookie);

   pCurl = curlsetup(szURL);

   curl_easy_setopt(pCurl, CURLOPT_HTTPGET, 1);
   if(szCookie != NULL)
   {
      curl_easy_setopt(pCurl, CURLOPT_COOKIE, szCookie);
   }

   return curlperform(pCurl);
}

bytes *HTMLParser::Post(const char *szURL, const char *szFields, char **pCookie)
{
   bytes *pReturn = NULL;
   CURL *pCurl = NULL;

   printf("HTMLParser::Post entry %s %s %p\n", szURL, szFields, pCookie);

   pCurl = curlsetup(szURL);

   curl_easy_setopt(pCurl, CURLOPT_POST, 1);
   curl_easy_setopt(pCurl, CURLOPT_POSTFIELDS, szFields);

   pReturn = curlperform(pCurl);

   *pCookie = strmk(m_szCurlCookie);

   return pReturn;
}

int HTMLParser::Read(EDF *pEDF, bytes *pData)
{
   STACKTRACE
   int iSingletonNum = 0, iTagID = 0;
   long lLineNum = 1;
   bool bLoop = true, bParent = false, bLiteral = false;
   char cQuote = '\0';
   char *szName = NULL, *szAttrib = NULL, *szValue = NULL, *szText = NULL, *szComment = NULL, *szTemp = NULL;
   byte *pPos = pData->Data(false), *pStop = pPos + pData->Length(), *pLine = NULL, *pStart = NULL;

   printf("HTMLParser::Read entry %p %p, %p %ld\n", pData, pEDF, pData->Data(false), pData->Length());

   while(bLoop == true)
   {
      /* if(m_bDebug == true)
      {
         printf("PageScan pos %d line %ld col %d\n", pPos - pData, lLineNum, pPos - pLine);
         memprint(pPos, 20);
         printf("\n");
      } */

      pStart = pPos;

      while(VALID_CHAR && *pPos != '<')
      {
         CHECK_RETURN

         pPos++;
      }

      if(pPos > pStart)
      {
         szText = strmk((char *)pStart, 0, pPos - pStart);
         szTemp = szText;
         while(*szTemp != '\0' && (*szTemp == '\r' || *szTemp == '\n'))
         {
            szTemp++;
         }
         if(*szTemp != '\0')
         {
            debug(DEBUGLEVEL_DEBUG, "HTMLParser::Read text add '%s'\n", szText);
            pEDF->AddChild("text", szTemp);
         }
         else
         {
            memprint(DEBUGLEVEL_DEBUG, debugfile(), "HTMLParser::Read text skip", (byte *)szText, strlen(szText));
         }
         delete[] szText;
      }

      if(!VALID_CHAR)
      {
         bLoop = false;
      }
      else
      {
         if(strncmp((char *)pPos, "<!--", 4) == 0)
         {
            pPos += 4;

            pStart = pPos;

            while(strncmp((char *)pPos, "-->", 3) != 0)
            {
               CHECK_RETURN

               pPos++;
            }

            szComment = strmk((char*)pStart, 0, pPos - pStart);
            debug(DEBUGLEVEL_DEBUG, "HTMLParser::Read comment '%s'\n", szComment);
            delete[] szComment;

            pPos += 3;
         }
         else
         {
            // Start of element
            pPos++;

            WHITE_SPACE("before name")

            // Element name
            if(*pPos == '/')
            {
               // Before name
               bParent = true;
               pPos++;
               WHITE_SPACE("before name")
            }
            else
            {
               bParent = false;
            }

            pStart = pPos;
            while(isalnum(*pPos) || *pPos == '-')
            {
               pPos++;
            }
            szName = strmk((char *)pStart, 0, pPos - pStart);

            if(bParent == true)
            {
               debug(DEBUGLEVEL_DEBUG, "HTMLParser::Read close %s\n", szName);

               WHITE_SPACE("after name")

               if(Singleton(szName) == false)
               {
                  pEDF->Parent();
               }
            }
            else
            {
               bParent = Singleton(szName);

               iTagID++;
               pEDF->Add("tag", iTagID);
               pEDF->AddChild("name", szName);

               debug(DEBUGLEVEL_DEBUG, "HTMLParser::Read open %s%s\n", szName, SINGLETONS[iSingletonNum] != NULL ? "(singleton)" : "");
               // EDFParser::Print(m_pEDF);

               while(*pPos != '/' && *pPos != '>')
               {
                  // Before attribute
                  WHITE_SPACE("before attribute")

                  if(isalpha(*pPos))
                  {
                     pStart = pPos;
                     while(isalnum(*pPos) || *pPos == '-')
                     {
                        pPos++;
                     }
                     szAttrib = strmk((char *)pStart, 0, pPos - pStart);
                     debug(DEBUGLEVEL_DEBUG, "HTMLParser::Read attrib %s\n", szAttrib);
                     pEDF->Add("attribute", szAttrib);

                     WHITE_SPACE("before equals")

                     if(*pPos == '=')
                     {
                        pPos++;

                        WHITE_SPACE("after equals")

                        if(*pPos == '"' || *pPos == '\'')
                        {
                           cQuote = *pPos;
                           pPos++;

                           pStart = pPos;
                           bLiteral = false;
                           while(!(bLiteral == false && *pPos == cQuote))
                           {
                              if(bLiteral == true)
                              {
                                 if(*pPos == '\\' || *pPos == cQuote)
                                 {
                                 }
                                 bLiteral = false;
                              }
                              else if(*pPos == '\\')
                              {
                                 bLiteral = true;
                              }
                              CHECK_RETURN

                              pPos++;
                           }
                        }
                        else
                        {
                           pStart = pPos;

                           while(*pPos != '\r' && *pPos != '\n' && *pPos != ' ' && *pPos != '>')
                           {
                              pPos++;
                           }

                           CHECK_RETURN
                        }

                        szValue = strmk((char *)pStart, 0, pPos - pStart);
                        debug(DEBUGLEVEL_DEBUG, "HTMLParser::Read attrib value %s\n", szValue);
                        pEDF->AddChild("value", szValue);
                        delete[] szValue;

                        if(*pPos != '/' && *pPos != '>')
                        {
                           pPos++;
                        }
                     }
                     else
                     {
                        // printf("PageScan attrib '%s'\n", szAttrib);
                     }

                     pEDF->Parent();

                     delete[] szAttrib;
                  }
               }

               // printf("PageScan attrib end '%c'\n", *pPos);

               if(bParent == false)
               {
                  // printf("PageScan singleton %s\n", pCurr->m_szName);

                  if(*pPos == '/')
                  {
                     WHITE_SPACE("after singleton")
                  }

                  WHITE_SPACE("before end of element")
               }
               else
               {
                  // printf("PageScan parent %s\n", pCurr->m_szName);

                  // if(m_pEDF->Children() > 0)
                  {
                     pEDF->Parent();
                  }
                  /* else
                  {
                     m_pEDF->Delete();
                  } */
               }
            }

            pPos++;

            delete[] szName;
         }
      }
   }

   pEDF->Root();

   printf("HTMLParser::Read return %d, line %ld col %d\n", pPos - pData->Data(false), lLineNum, pPos - pLine);
   return pPos - pData->Data(false);
}

void HTMLParser::Print(EDF *pEDF, const char *szTitle)
{
   STACKTRACE
   int iType = 0;
   long lValue = 0;
   bool bLoop = true;
   char *szName = NULL, *szValue = NULL, *szTag = NULL, *szText = NULL;
   EDFElement *pCurr = NULL;

   pCurr = pEDF->GetCurr();

   printf("%s:\n", szTitle != NULL ? szTitle : "TagPrint");

   while(bLoop == true)
   {
      szValue = NULL;
      iType = pEDF->TypeGet(&szName, &szValue, &lValue, NULL);

      printf(" %s", szName);
      if(iType == EDFElement::INT)
      {
         printf(" / %ld", lValue);
      }
      else if(iType == EDFElement::BYTES)
      {
         printf(" / %s", szValue);
      }
      if(stricmp(szName, "tag") == 0)
      {
         if(pEDF->GetChild("name", &szTag) == true)
         {
            printf(" n=%s", szTag);
            delete[] szTag;
         }
         if(pEDF->GetChild("text", &szText) == true)
         {
            printf(" t=%s", szText);
            delete[] szText;
         }
      }
      printf(". %d]\n", pEDF->Position());

      delete[] szValue;
      delete[] szName;

      bLoop = pEDF->Parent();
   }

   pEDF->SetCurr(pCurr);

   printf("\n");
}

void HTMLParser::TagText(EDF *pPage, EDF *pArgs)
{
   STACKTRACE
   int iTagID = 0;
   bool bLoop = false;
   char *szText = NULL, *szArg = NULL;

   printf("TagText entry %p %p\n", pPage, pArgs);
   // EDFParser::Print(pArgs);

   pPage->Get(NULL, &iTagID);

   bLoop = pPage->Child("tag");
   while(bLoop == true)
   {
      bLoop = pPage->Child("text");
      while(bLoop == true)
      {
         pPage->Get(NULL, &szText);
         // printf("TagText %d text %s\n", iTagID, szText);

         bLoop = pArgs->Child("arg");
         while(bLoop == true)
         {
            pArgs->Get(NULL, &szArg);
            // printf("TagText check '%s' '%s' -> %d %p\n", szText, szArg, strnicmp(szText, szArg, strlen(szArg)), strstr(szText, szArg));
            if(strnicmp(szText, szArg, strlen(szArg)) == 0 || strstr(szText, szArg) != NULL)
            {
               // printf("TagText match %s\n", szArg);
               Print(pPage, "TagText match");
               // bLoop = false;
            }
            delete[] szArg;

            if(bLoop == true)
            {
               bLoop = pArgs->Next("arg");
            }
            if(bLoop == false)
            {
               pArgs->Parent();
            }
         }

         delete[] szText;

         bLoop = pPage->Next("text");
         if(bLoop == false)
         {
            pPage->Parent();
         }
      }

      bLoop = pPage->Iterate("tag");
   }

   printf("TagText exit\n");
}


void HTMLParser::TagText(EDF *pPage, char *szArg, ...)
{
   STACKTRACE
   va_list vList;
   EDF *pArgs = NULL;

   printf("HTMLParser::TagText entry %p %s\n", pPage, szArg);

   pArgs = new EDF();

   va_start(vList, szArg);

   while(szArg != NULL)
   {
      pArgs->AddChild("arg", szArg);

      szArg = va_arg(vList, char *);
   }

   TagText(pPage, pArgs);

   delete pArgs;

   printf("HTMLParser::TagText exit\n");
}

void HTMLParser::TagTree(EDF *pPage, EDF *pArgs, TAGFN pFunction, EDF *pData)
{
   char *szArg = NULL, *szName = NULL;
   bool bLoop = true;

   // printf("TagTree entry\n");
   // EDFParser::Print("TagTree entry", pPage, EDFElement::EL_CURR + EDFElement::PR_SPACE);

   if(pArgs->Child("arg") == false)
   {
      bLoop = pArgs->Next("arg");
   }

   if(bLoop == false)
   {
      if(pFunction != NULL)
      {
         pFunction(pPage, pData);
      }
      else
      {
         Print(pPage, "TagTree match");
      }
   }
   else
   {
      pArgs->Get(NULL, &szArg);
      // printf("TagTree arg %s\n", szArg);

      bLoop = pPage->Child("tag");

      while(bLoop == true)
      {
         pPage->GetChild("name", &szName);
         // printf("TagTree tag name %s\n", szName);
         if(stricmp(szArg, szName) == 0)
         {
            TagTree(pPage, pArgs, pFunction, pData);
         }
         /* else
         {
            printf("TagTree fail point\n");
            EDFParser::Print(pPage, false, true);
         } */

         bLoop = pPage->Next("tag");
         if(bLoop == false)
         {
            pPage->Parent();
         }
      }

      pArgs->Prev("arg");
   }

   // printf("TagTree exit\n");
}

void HTMLParser::TagTree(EDF *pPage, TAGFN pFunction, EDF *pData, char *szArg, ...)
{
   STACKTRACE
   va_list vList;
   EDF *pArgs = NULL;

   printf("HTMLParser::TagTree entry %p %p %p %s\n", pPage, pFunction, pData, szArg);

   pArgs = new EDF();

   va_start(vList, szArg);

   while(szArg != NULL)
   {
      pArgs->AddChild("arg", szArg);

      szArg = va_arg(vList, char *);
   }

   TagTree(pPage, pArgs, pFunction, pData);

   delete pArgs;

   printf("HTMLParser::TagTree exit\n");
}
