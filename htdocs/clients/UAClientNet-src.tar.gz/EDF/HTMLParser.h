#ifndef _HTMLPARSER_H_
#define _HTMLPARSER_H_

class EDF;

typedef void (*TAGFN)(EDF *pPage, EDF *pData);

class HTMLParser
{
public:
   static bytes *Get(const char *szURL, const char *szCookie = NULL);
   static bytes *Post(const char *szURL, const char *szFields, char **pCookie = NULL);

   static int Read(EDF *pEDF, bytes *pData);

   static void Print(EDF *pEDF, const char *szTitle = NULL);

   static void TagText(EDF *pPage, EDF *pArgs);
   static void TagText(EDF *pPage, char *szArg, ...);

   static void TagTree(EDF *pPage, EDF *pArgs, TAGFN pFunction = NULL, EDF *pData = NULL);
   static void TagTree(EDF *pPage, TAGFN pFunction, EDF *pData, char *szArg, ...);
};

#endif
