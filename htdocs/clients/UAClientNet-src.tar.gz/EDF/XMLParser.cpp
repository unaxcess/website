#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

#include "EDF.h"

#include "XMLParser.h"

#define VALID_CHAR \
(pPos < pStop)

#define IS_SPACE \
(*pPos == ' ' || *pPos == '\r' || *pPos == '\n' || *pPos == '\t' || *pPos == '\0')

#define PRINT_POS \
isprint(*pPos) || *pPos == ' ' ? *pPos : '\0'

#define WHITE_SPACE(szParse) \
/*printf("XMLParser::Read white space %s %d '%c' [%d]\n", szParse != NULL ? szParse : "", pPos - pData, PRINT_POS, *pPos);*/\
while(VALID_CHAR && IS_SPACE)\
{\
   if(*pPos == '\n')\
   {\
      pLine = pPos + 1;\
      lLineNum++;\
   }\
   pPos++;\
}

#define PARSE_SIZE 10

#define PARSE_ERROR(szError, lError)\
{\
   debug(DEBUGLEVEL_DEBUG, "XMLParser::Read (%d, %ld, %d) '%c' [%d] %s\n", pPos - pData, lLineNum, pPos - pLine, PRINT_POS, *pPos, szError);\
}\
lReturn = lError;\
bLoop = false;\
bValid = false;

#define BYTES_VALUE \
dBytesVal = gettick(); \
pPos++; \
pStart = pPos; \
bLiteral = false; \
lValueLiterals = 0; \
while(VALID_CHAR && !(bLiteral == false && *pPos == '"')) \
{ \
   if(bLiteral == true) \
   { \
      if(*pPos == '\\' || *pPos == '"') \
      { \
         lValueLiterals++; \
      } \
      bLiteral = false; \
   } \
   else if(*pPos == '\\') \
   { \
      bLiteral = true; \
   } \
   if(*pPos == '\n') \
   { \
      pLine = pPos + 1; \
      lLineNum++; \
   } \
   pPos++; \
} \
lBytesVal += tickdiff(dBytesVal);

long XMLParser::Read(EDF *pEDF, const byte *pData, const long lDataLen, const int iProgress, const int iOptions)
{
   STACKTRACE
   long lReturn = 0, lLineNum = 1, lValueLiterals = 0, lValueLen = 0;
   long lNew = 0, lSpace = 0, lSet = 0, lTick = 0, lName = 0, lBytesVal = 0, lValid = 0, lTempLen = 0;
   int iDepth = 0, iNumElements = 0, iType = 0;
   bool bLoop = true, bLiteral = false, bParent = false, bValid = true, bSingleton = false, bDepth = true, bRootSet = false, bXMLType = true, bXML = true;
   double dTick = gettick(), dBytesVal = 0, dNew = 0, dSpace = 0, dName = 0, dValid = 0;
   char *szName = NULL, *szParse = NULL;
   byte *pPos = (byte *)pData, *pStop = pPos + lDataLen, *pStart = pPos, *pLine = pPos, *pParse = NULL, *pProgress = pPos, *pValue = NULL, *pTemp = NULL;
   EDFElement *pElement = NULL, *pEDFRoot = NULL, *pRoot = NULL, *pCurr = NULL;

   // if(m_bDebug == true)
   {
      debug("XMLParser::Read entry %p %ld %d\n", pData, lDataLen, iProgress);
      // memprint("XMLParser::Read data", pData, lDataLen);
   }

   if(pData == NULL || lDataLen < 5)
   {
      // Has to be at least <></>
      return 0;
   }

   memprint(debugfile(), "XMLParser::Read XML parse", pData, lDataLen);

   if(strnicmp((char *)pData, "<?xml", 5) == 0 ||
      (lDataLen >= 6 && strnicmp((char *)pData, "<? xml", 6) == 0))
   {
      pPos = (byte *)pData + 5;
      while(bXML == true)
      {
         if(!VALID_CHAR)
         {
            lReturn = -2;
            bXML = false;
            bLoop = false;
         }
         else
         {
            pPos++;
            if(*pPos == '?')
            {
               pPos++;
               if(*pPos == '>')
               {
                  pPos++;
                  bXML = false;
               }
            }
         }
      }
   }

   memprint("XMLParser::Read parse", pPos, lDataLen - (pPos - pData));

   while(bLoop == true)
   {
      STACKTRACEUPDATE

      if(iProgress != -1 && pPos > pProgress + iProgress)
      {
         debug(DEBUGLEVEL_DEBUG, "XMLParser::Read progress point %d after %ld ms\n", pPos - pData, tickdiff(dTick));
         memprint(DEBUGLEVEL_DEBUG, debugfile(), NULL, pPos, 40, false);
         debug(DEBUGLEVEL_DEBUG, "\n");
         pProgress = pPos;
      }

      dSpace = gettick();

      while(VALID_CHAR && *pPos != '<')
      {
         if(*pPos == '\n')
         {
            pLine = pPos;
            lLineNum++;
         }
         pPos++;
      }

      if(!VALID_CHAR)
      {
         lReturn = -2;
         bLoop = false;
      }
      else
      {
         STACKTRACEUPDATE

         // Start of element
         pPos++;

         WHITE_SPACE("before name")

         if(!VALID_CHAR)
         {
            PARSE_ERROR("EOD before name", -1)
         }
         else if(!(isalpha(*pPos) || *pPos == '=' || *pPos == '>' || *pPos == '/'))
         {
            PARSE_ERROR("before name", 0)
         }
         else
         {
            STACKTRACEUPDATE

            // Element name
            if(*pPos == '/')
            {
               bParent = true;
               pPos++;
            }
            else
            {
               bParent = false;
            }

            lSpace += tickdiff(dSpace);

            dName = gettick();

            pStart = pPos;
            // pPos++; // Skip over first chacter
            while(VALID_CHAR && (isalnum(*pPos) || *pPos == '-'))
            {
               pPos++;
            }

            if(!VALID_CHAR)
            {
               PARSE_ERROR("EOD during name", -1)
            }
            else
            {
               STACKTRACEUPDATE

               lName += tickdiff(dName);

               // Create element
               // szName = (char *)memmk(pStart, pPos - pStart);
               dNew = gettick();
               NEWCOPY(szName, pStart, pPos - pStart, char, byte);
               lNew += tickdiff(dNew);
               // printf("XMLParser::Read name '%s'\n", szName);
               dValid = gettick();
               if(EDFElement::validName(szName) == false)
               {
                  PARSE_ERROR("at invalid name", 0)
               }
               else
               {
                  STACKTRACEUPDATE

                  lValid += tickdiff(dValid);
                  if(bParent == false)
                  {
                     bRootSet = true;

                     iNumElements++;
                     dNew = gettick();
                     STACKTRACEUPDATE
                     // debug(DEBUGLEVEL_DEBUG, "XMLParser::Read new element %p '%s' '%s'\n", m_pCurr, m_pCurr != NULL ? m_pCurr->getName(false) : NULL, szName);
                     pElement = new EDFElement(pCurr, szName);
                     STACKTRACEUPDATE
                     lNew += tickdiff(dNew);
                     // printf("XMLParser::Read new element %p, parent %p\n", pElement, m_pCurr);
                     if(pRoot == NULL)
                     {
                        pRoot = pElement;
                     }
                     pCurr = pElement;
                     // m_pCurr->print("XMLParser::Read element");
                  }

                  STACKTRACEUPDATE

                  dSpace = gettick();

                  if(IS_SPACE)
                  {
                     // After name
                     WHITE_SPACE("after name")
                  }

                  if(!VALID_CHAR)
                  {
                     PARSE_ERROR("EOD after name", -1)
                  }
                  else
                  {
                     STACKTRACEUPDATE

                     lSpace += tickdiff(dSpace);
                     if(bParent == false)
                     {
                        if(pPos + 2 <= pStop)
                        {
                           bXMLType = true;

                           // memprint("XMLParser::Read value type", pPos, 7);

                           if(*pPos == 's' && *(pPos + 1) == 't' && *(pPos + 2) == 'r')
                           {
                              iType = EDFElement::BYTES;
                           }
                           else if(*pPos == 'n' && *(pPos + 1) == 'u' && *(pPos + 2) == 'm')
                           {
                              iType = EDFElement::INT;
                           }
                           else
                           {
                              bXMLType = false;
                           }

                           if(bXMLType == true)
                           {
                              pPos += 3;

                              WHITE_SPACE("before XML value")

                              if(!VALID_CHAR)
                              {
                                 PARSE_ERROR("EOD before XML value", -1)
                              }
                              else
                              {
                                 if(*pPos != '=')
                                 {
                                    PARSE_ERROR("Non-equals before XML value", -1)
                                 }
                                 else
                                 {
                                    STACKTRACEUPDATE

                                    pPos++;

                                    if(!VALID_CHAR)
                                    {
                                       PARSE_ERROR("EOD before XML value", -1)
                                    }
                                    else
                                    {
                                       STACKTRACEUPDATE

                                       if(*pPos != '"')
                                       {
                                          PARSE_ERROR("Non-quote before XML value", -1)
                                       }
                                       else
                                       {
                                          STACKTRACEUPDATE

                                          // Byte value
                                          BYTES_VALUE

                                          if(!VALID_CHAR)
                                          {
                                             PARSE_ERROR("EOD during XML value", -1)
                                          }
                                          /* else if(*pPos != '"')
                                          {
                                             PARSE_ERROR("during XML value", 0)
                                          } */
                                          else
                                          {
                                             STACKTRACEUPDATE

                                             pValue = memmk(pStart, (int)(pPos - pStart));
                                             lValueLen = pPos - pStart;
                                             // if(m_bDebug == true)
                                             {
                                                memprint(DEBUGLEVEL_DEBUG, "XMLParser::Read value", pValue, lValueLen);
                                             }

                                             pPos++;

                                             WHITE_SPACE("before XML value type")

                                             if(!VALID_CHAR)
                                             {
                                                PARSE_ERROR("EOD before XML value type", -1)
                                             }
                                             else if(*pPos == '/' || *pPos == '>')
                                             {
                                                STACKTRACEUPDATE

                                                if(iType == EDFElement::BYTES)
                                                {
                                                   // printf("XMLParser::Read set byte value\n");
                                                   // pCurr->setValue(pValue, lValueLen, true);
                                                   lTempLen = readvalue(&pTemp, pValue, lValueLen);
                                                   pCurr->setValue(pTemp, lTempLen, false);
                                                   delete[] pTemp;
                                                }
                                                else
                                                {
                                                   STACKTRACEUPDATE

                                                   if(strchr((char *)pValue, '.') != NULL)
                                                   {
                                                      pCurr->setValue(atof((char *)pValue));
                                                   }
                                                   else
                                                   {
                                                      pCurr->setValue(atol((char *)pValue));
                                                   }
                                                }
                                             }
                                             delete[] pValue;
                                          }

                                          szParse = "after XML value";
                                       }
                                    }
                                 }
                              }
                           }
                        }
                        else
                        {
                           szParse = "EOD after name";
                        }

                        if(VALID_CHAR)
                        {
                           dSpace = gettick();
                           WHITE_SPACE("before end of element")
                           lSpace += tickdiff(dSpace);

                           if(!VALID_CHAR)
                           {
                              PARSE_ERROR(szParse, -1)
                           }
                        }
                     }
                  }

                  // m_pCurr->print("XMLParser::Read element");

                  if(VALID_CHAR)
                  {
                     if(bParent == false)
                     {
                        if(*pPos == '/')
                        {
                           bSingleton = true;
                           pPos++;
                        }
                        else
                        {
                           bSingleton = false;
                        }

                        dSpace = gettick();
                        WHITE_SPACE("before end of element")
                        lSpace += tickdiff(dSpace);
                     }

                     if(!VALID_CHAR)
                     {
                        PARSE_ERROR("EOD before end of element", -1)
                     }
                     else if(*pPos != '>')
                     {
                        PARSE_ERROR("before end of element", 0)
                     }
                     else
                     {
                        // printf("XMLParser::Read move to parent %s && (%s || %s)\n", BoolStr(bRootSet), BoolStr(bSingleton), BoolStr(bParent));
                        if(bRootSet == true && (bSingleton == true || bParent == true))
                        {
                           if(pCurr->parent() != NULL)
                           {
                              bDepth = true;
                              pCurr = pCurr->parent();
                           }
                           else
                           {
                              bDepth = false;
                           }
                           bLoop = bDepth;
                           /* if(m_bDebug == true)
                           {
                              debug("XMLParser::Read parent l=%s d=%d(%s) n=%s\n", BoolStr(bLoop), m_iDepth, BoolStr(bDepth), m_pCurr != NULL ? m_pCurr->getName(false) : "");
                           } */
                        }
                        else if(bParent == true)
                        {
                           bLoop = false;
                           bValid = false;
                        }
                        pPos++;
                     }
                  }
               }
               delete[] szName;
            }
         }
      }

      /* if(m_bDebug == true)
      {
         debug("XMLParser::Read loop, s='%s' p=%d d=%d\n", pPos, pPos - pData, m_iDepth);
      } */
   }

   // printf("XMLParser::Read %d elements\n", iNumElements);

   /* if(lReturn < 0)
   {
      debug("XMLParser::Read exit %d\n", lReturn);
      return lReturn;
   } */

   // iDepth = Depth();
   debug(DEBUGLEVEL_DEBUG, "XMLParser::Read return %ld, parse v=%s, l=%s, d=%d(%s)\n", lReturn, BoolStr(bValid), BoolStr(bLoop), iDepth, BoolStr(bDepth));
   if(lReturn < 0 || bValid == false || iDepth > 0 || (iDepth <= 0 && bDepth == true))
   {
      // printf(" XMLParser::Read use old root %p\n", pOldRoot);
      // if(m_bDebug == true)
      {
         int iParseLen = 0;

         if(pPos - pData > 200)
         {
            pParse = pPos - 200;
         }
         else
         {
            pParse = pPos;
         }
         if(pStop - pPos > 200)
         {
            iParseLen = 200;
         }
         else
         {
            iParseLen = pStop - pPos;
         }
         memprint(DEBUGLEVEL_DEBUG, "XMLParser::Read parse failed", pParse, pPos - pParse + iParseLen);
         // m_pRoot->print("XMLParser::Read parse failed");
      }

      // dValue = gettick();
      delete pRoot;
      // lDelete = tickdiff(dValue);

      // if(m_bDebug == true)
      lTick = tickdiff(dTick);
      /* if(lTick > 250)
      {
         debug("XMLParser::Read exit %ld, t=%ld ms\n", lReturn, lTick);
      } */
      debug("XMLParser::Read exit %ld, parse failed t=%ld ms\n", lReturn, lTick);
      return lReturn;
   }
   else
   {
      // printf(" XMLParser::Read use new root %p\n", m_pRoot);

      // dValue = gettick();
      // lDelete = tickdiff(dValue);

      // printf("XMLParser::Read delete %ld ms\n", lDelete);

      if(mask(iOptions, EN_EDFROOT) == true)
      {
         pEDFRoot = pRoot->child(0);
         if(pEDFRoot != NULL)
         {
            printf("XMLParser::Read pre-move root %p(%p)\n", pRoot, pRoot->parent());
            pRoot->print();

            pRoot->remove(0);
            delete pRoot;

            pRoot = pEDFRoot;

            printf("XMLParser::Read post-move root %p(%p)\n", pRoot, pRoot->parent());
            pRoot->print();
         }
      }

      // Root();
   }

   // m_pRoot->print("XMLParser::Read");

   // if(m_bDebug == true)
   /* lTick = tickdiff(dTick);
   if(lTick > 250)
   {
      debug("XMLParser::Read exit %ld, t=%ld (new=%ld del=%ld set=%ld sp=%ld nm=%ld bv=%ld nv=%ld vld=%ld rem=%ld) ms\n", (long)(pPos - pData), lTick, lNew, lDelete, lSet, lSpace, lName, lBytesVal, lNumVal, lValid, lTick - lNew - lDelete - lSet - lSpace - lName - lBytesVal - lNumVal - lValid);
   } */

   pEDF->SetRoot(pRoot);

   debug("XMLParser::Read exit %ld, %p parse OK t=%ld (new=%ld set=%ld sp=%ld nm=%ld bv=%ld vld=%ld rem=%ld) ms\n", (long)(pPos - pData), pEDF, lTick, lNew, lSet, lSpace, lName, lBytesVal, lValid, lTick - lNew - lSet - lSpace - lName - lBytesVal - lValid);
   return pPos - pData;
}

bytes *XMLParser::Write(EDF *pEDF, const int iOptions)
{
   STACKTRACE
   // long lReturn = 0;
   double dTick = gettick();
   EDFElement *pElement = NULL;
   bytes *pReturn = NULL;

   // if(m_bDebug == true)
   {
      debug(DEBUGLEVEL_DEBUG, "XMLParser::Write entry %d\n", iOptions);
   }

   if(mask(iOptions, EDFElement::EL_ROOT) == true)
   {
      pElement = pEDF->GetCurr();
      while(pElement->parent() != NULL)
      {
         pElement = pElement->parent();
      }
   }
   else
   {
      pElement = pEDF->GetCurr();
   }

   // STACKTRACE
   long lStorageLen = 0, lWriteLen = 0;
   byte *pWrite = NULL;

   /* if(pWrite == NULL)
   {
      return 0;
   } */

   // printf("EDFElement::write %p, %p '%s' %d\n", this, m_pParent, m_szName, m_iNumChildren);

   /* if(m_pParent == NULL && strcmp(m_szName, "")== 0 && m_iNumChildren == 0)
   {
      NEWCOPY((*pWrite), "<></>", 5, byte, char);
      return 5;
   } */

   /* if(bCurr == false)
   {
      debug("EDFElement::write no curr\n");
   } */

   // debugprint(0);

   lStorageLen = 60;
   lStorageLen += storage(pElement, iOptions, 0);
   debug("EDFElement::write XML storage %ld bytes\n", lStorageLen);
   pWrite = new byte[lStorageLen + 1];
   memcpy(pWrite, "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<edf>\n", 39);
   lWriteLen = 39;
   if(mask(iOptions, EN_EDFROOT) == true)
   {
      memcpy(pWrite + lWriteLen, "<xml>\n", 6);
      lWriteLen += 6;
   }
   lWriteLen = write(pWrite, pElement, lWriteLen, iOptions, 0);
   pWrite[lWriteLen] = '\0';
   while(lWriteLen > 0 && (pWrite[lWriteLen - 1] == '\r' || pWrite[lWriteLen - 1] == '\n'))
   {
      pWrite[--lWriteLen] = '\0';
   }
   if(mask(iOptions, EN_EDFROOT) == true)
   {
      memcpy(pWrite + lWriteLen, "\n</xml>\n", 8);
      lWriteLen += 8;
   }
   pWrite[lWriteLen] = '\0';
   debug("EDFElement::write XML write point %ld bytes\n", lWriteLen);

   /* if(lWriteLen > 200000)
   {
      debug("EDFElement::write written to %ld of %ld bytes\n", lWriteLen, lStorageLen);
   } */

   // printf("EDFElement::write %p %ld\n", pWrite, lWriteLen);
   pReturn = new bytes(pWrite, lWriteLen);

   delete[] pWrite;

   // bytesprint("XMLParser::Write bytes", pReturn);

   // if(m_bDebug == true)
   {
      debug(DEBUGLEVEL_DEBUG, "XMLParser::Write exit %ld, %ld ms\n", pReturn->Length(), tickdiff(dTick));
   }
   return pReturn;
}

EDF *XMLParser::FromFile(const char *szFilename, size_t *lReadLen, const int iProgress, const int iOptions)
{
   STACKTRACE
   long lEDF = 0;
   size_t lDataLen = 0;
   byte *pData = NULL;
   EDF *pEDF = NULL;

   // printf(" FileToEDF entry %s\n", szFilename);

   pData = FileRead(szFilename, &lDataLen);
   if(pData == NULL)
   {
      return NULL;
   }

   pEDF = new EDF();
   lEDF = XMLParser::Read(pEDF, pData, lDataLen, iProgress, iOptions);
   delete[] pData;

   if(lEDF <= 0)
   {
      delete pEDF;
      return NULL;
   }

   // printf(" FileToEDF exit %p\n", pEDF);
   return pEDF;
}

bool XMLParser::ToFile(EDF *pEDF, const char *szFilename, int iOptions)
{
   STACKTRACE
   // long lWriteLen = 0;
   bytes *pWrite = NULL;

   if(iOptions == -1)
   {
      iOptions = EDFElement::EL_ROOT | EDFElement::EL_CURR | EDFElement::PR_SPACE;
   }

   debug("XMLParser::ToFile options %d\n", iOptions);
   // XMLParser::Print(pEDF, true, true);
   pWrite = XMLParser::Write(pEDF, iOptions);
   // memprint("XMLParser::ToFile write", pWrite, lWriteLen);
   if(FileWrite(szFilename, pWrite->Data(false), pWrite->Length()) == -1)
   {
      delete pWrite;
      return false;
   }

   delete pWrite;

   return true;
}

bool XMLParser::Print(EDF *pEDF, int iOptions)
{
   return XMLParser::Print(NULL, NULL, pEDF, iOptions);
}

bool XMLParser::Print(EDF *pEDF, const bool bRoot, const bool bCurr)
{
   int iOptions = EDFElement::PR_SPACE;

   if(bRoot == true)
   {
      iOptions |= EDFElement::EL_ROOT;
   }
   if(bCurr == true)
   {
      iOptions |= EDFElement::EL_CURR;
   }

   return XMLParser::Print(NULL, NULL, pEDF, iOptions);
}

bool XMLParser::Print(const char *szTitle, EDF *pEDF, const int iOptions)
{
   return XMLParser::Print(NULL, szTitle, pEDF, iOptions);
}

/* void XMLParser::Print(const char *szTitle, EDF *pEDF, const bool bRoot, const bool bCurr)
{
   int iOptions = EDFElement::PR_SPACE;

   if(bRoot == true)
   {
      iOptions |= EDFElement::EL_ROOT;
   }
   if(bCurr == true)
   {
      iOptions |= EDFElement::EL_CURR;
   }

   XMLParser::Print(NULL, szTitle, pEDF, iOptions);
} */

bool XMLParser::Print(FILE *fOutput, const char *szTitle, EDF *pEDF, int iOptions)
{
   STACKTRACE
   // long lWriteLen = 0;
   bytes *pWrite = NULL;

   if(fOutput == NULL)
   {
      fOutput = stdout;
   }

   if(iOptions == -1)
   {
      iOptions = EDFElement::EL_ROOT | EDFElement::EL_CURR | EDFElement::PR_SPACE;
   }

   // printf("XMLParser::Print options %d\n", iOptions);

   if(pEDF != NULL)
   {
      pWrite = XMLParser::Write(pEDF, iOptions);
   }
   if(szTitle != NULL)
   {
      fprintf(fOutput, "%s:\n", szTitle);
   }
   if(pWrite != NULL)
   {
      fwrite(pWrite->Data(false), 1, pWrite->Length(), fOutput);
      if(pWrite->Length() > 0)
      {
         fprintf(fOutput, "\n");
      }
   }
   else
   {
      fwrite("NULL\n", 1, 5, fOutput);
   }

   delete pWrite;

   return true;
}

bool XMLParser::Print(FILE *fOutput, const char *szTitle, EDF *pEDF, const bool bRoot, const bool bCurr)
{
   int iOptions = EDFElement::PR_SPACE;

   if(bRoot == true)
   {
      iOptions |= EDFElement::EL_ROOT;
   }
   if(bCurr == true)
   {
      iOptions |= EDFElement::EL_CURR;
   }

   return XMLParser::Print(fOutput, szTitle, pEDF, iOptions);
}

bool XMLParser::debugPrint(EDF *pEDF, const int iOptions)
{
   return XMLParser::debugPrint(0, NULL, pEDF, iOptions);
}

bool XMLParser::debugPrint(EDF *pEDF, const bool bRoot, const bool bCurr)
{
   int iOptions = EDFElement::PR_SPACE;

   if(bRoot == true)
   {
      iOptions |= EDFElement::EL_ROOT;
   }
   if(bCurr == true)
   {
      iOptions |= EDFElement::EL_CURR;
   }

   return XMLParser::debugPrint(0, NULL, pEDF, iOptions);
}

bool XMLParser::debugPrint(int iLevel, EDF *pEDF, const int iOptions)
{
   return XMLParser::debugPrint(iLevel, NULL, pEDF, iOptions);
}

bool XMLParser::debugPrint(const char *szTitle, EDF *pEDF, const int iOptions)
{
   return XMLParser::debugPrint(0, szTitle, pEDF, iOptions);
}

bool XMLParser::debugPrint(int iLevel, const char *szTitle, EDF *pEDF, const int iOptions)
{
   if(iLevel > debuglevel())
   {
      return false;
   }

   return XMLParser::Print(debugfile(), szTitle, pEDF, iOptions);
}

/* void XMLParser::debugPrint(const char *szTitle, EDF *pEDF, const bool bRoot, const bool bCurr)
{
   int iOptions = EDFElement::PR_SPACE;

   if(bRoot == true)
   {
      iOptions |= EDFElement::EL_ROOT;
   }
   if(bCurr == true)
   {
      iOptions |= EDFElement::EL_CURR;
   }

   XMLParser::Print(debugfile(), szTitle, pEDF, iOptions);
} */

long XMLParser::readvalue(byte **pData, byte *pValue, long lValueLen)
{
   STACKTRACE
   int iDataPos = 0, iValuePos = 0;

   (*pData) = new byte[lValueLen];

   for(iValuePos = 0; iValuePos < lValueLen; iValuePos++)
   {
      if(pValue[iValuePos] == '&')
      {
         if(strnicmp((char *)pValue + iValuePos, "&lt;", 4) == 0)
         {
            (*pData)[iDataPos++] = '<';
            iValuePos += 3;
         }
         else if(strnicmp((char *)pValue + iValuePos, "&gt;", 4) == 0)
         {
            (*pData)[iDataPos++] = '>';
            iValuePos += 3;
         }
         else if(strnicmp((char *)pValue + iValuePos, "&amp;", 5) == 0)
         {
            (*pData)[iDataPos++] = '&';
            iValuePos += 4;
         }
         else if(strnicmp((char *)pValue + iValuePos, "&quot;", 6) == 0)
         {
            (*pData)[iDataPos++] = '"';
            iValuePos += 5;
         }
         else if(strnicmp((char *)pValue + iValuePos, "&apos;", 6) == 0)
         {
            (*pData)[iDataPos++] = '\'';
            iValuePos += 5;
         }
      }
      else
      {
         (*pData)[iDataPos++] = pValue[iValuePos];
      }
   }

   return iDataPos;
}

long XMLParser::storage(EDFElement *pElement, const int iOptions, int iDepth)
{
   int iChildNum = 0, iNameLen = strlen(pElement->getName(false));
   long lReturn = 0;

   // printf("EDFElement::storage entry %p %d %d, %s %d\n", this, iPretty, iDepth, m_szName, m_vType);

   if(mask(iOptions, EDFElement::PR_SPACE) == true)
   {
      lReturn += iDepth; // indent
   }
   lReturn += 13; // <,=,",",/,>\r,\n -- \r,\n,<,/,>
   lReturn += iNameLen; // name
   if(pElement->getType() == EDFElement::BYTES && pElement->getValueBytes(false) != NULL)
   {
      if(mask(iOptions, EDFElement::PR_BIN) == true)
      {
         lReturn += 5 * pElement->getValueBytes(false)->Length(); // value in [nnn] format
      }
      else
      {
         lReturn += 2 * pElement->getValueBytes(false)->Length(); // escaped value
      }
      // printf("EDFElement::storage value %ld\n", m_lValueLen);
   }
   else if(pElement->getType() == EDFElement::INT || pElement->getType() == EDFElement::FLOAT)
   {
      if(pElement->getType() == EDFElement::INT)
      {
         lReturn += 10; // value
      }
      else
      {
         lReturn += 20; // value
      }
   }
   if(pElement->children() > 0)
   {
      if(mask(iOptions, EDFElement::PR_SPACE) == true)
      {
         iDepth += 2;
      }
      for(iChildNum = 0; iChildNum < pElement->children(); iChildNum++)
      {
         lReturn += storage(pElement->child(iChildNum), iOptions, iDepth);
      }
      if(mask(iOptions, EDFElement::PR_SPACE) == true)
      {
         iDepth -= 2;

         lReturn += iDepth;
         lReturn += iNameLen; // name
      }
   }

   // printf("EDFElement::storage exit %ld, %p\n", lReturn, this);
   return lReturn;
}

long XMLParser::writevalue(byte **pData, bytes *pBytes)
{
   STACKTRACE
   int iDataPos = 0, iTempPos = 0, iTempLen = 0;
   byte *pTemp = NULL;

   iTempLen = pBytes->Length();
   pTemp = pBytes->Data(false);

   (*pData) = new byte[6 * iTempLen];

   for(iTempPos = 0; iTempPos < iTempLen; iTempPos++)
   {
      if(pTemp[iTempPos] == '<' || pTemp[iTempPos] == '>' || pTemp[iTempPos] == '&' || pTemp[iTempPos] == '\"' || pTemp[iTempPos] == '\'')
      {
         (*pData)[iDataPos++] = '&';

         if(pTemp[iTempPos] == '<')
         {
            (*pData)[iDataPos++] = 'l';
            (*pData)[iDataPos++] = 't';
         }
         else if(pTemp[iTempPos] == '>')
         {
            (*pData)[iDataPos++] = 'g';
            (*pData)[iDataPos++] = 't';
         }
         else if(pTemp[iTempPos] == '&')
         {
            (*pData)[iDataPos++] = 'a';
            (*pData)[iDataPos++] = 'm';
            (*pData)[iDataPos++] = 'p';
         }
         else if(pTemp[iTempPos] == '\"')
         {
            (*pData)[iDataPos++] = 'q';
            (*pData)[iDataPos++] = 'u';
            (*pData)[iDataPos++] = 'o';
            (*pData)[iDataPos++] = 't';
         }
         else if(pTemp[iTempPos] == '\'')
         {
            (*pData)[iDataPos++] = 'a';
            (*pData)[iDataPos++] = 'p';
            (*pData)[iDataPos++] = 'o';
            (*pData)[iDataPos++] = 's';
         }

         (*pData)[iDataPos++] = ';';
      }
      else
      {
         (*pData)[iDataPos++] = pTemp[iTempPos];
      }
   }

   return iDataPos;
}

long XMLParser::write(byte *pWrite, EDFElement *pElement, long lOffset, const int iOptions, int iDepth)
{
   int iChildNum = 0, iNameLen = strlen(pElement->getName(false));
   // int iSourcePos = 0, iSourceLen = 0;
   int iValuePos = 0, iValueLen = 0;
   // long lValueLen = 0;
   char szNumber[20];
   byte *pValue = NULL;

   /* printf("EDFElement::write %ld, '%s' %d", lOffset, m_szName, m_vType);
   if(m_vType == BYTES)
   {
      debug(" %p", m_pValue);
      if(m_pValue != NULL)
      {
         debug("/%ld", m_pValue->Length());
      }
   }
   debug("\n"); */

   if(mask(iOptions, EDFElement::EL_CURR) == true)
   {
      if(mask(iOptions, EDFElement::PR_SPACE) == true)
      {
         memset(pWrite + lOffset, ' ', iDepth);
         lOffset += iDepth;
      }
      pWrite[lOffset++] = '<';
      memcpy(pWrite + lOffset, pElement->getName(false), iNameLen);
      lOffset += iNameLen;
      if(pElement->getType() == EDFElement::BYTES && pElement->getValueBytes(false) != NULL)
      {
         // bytesprint("EDFElement::write byte value", m_pValue);

         // lValueLen = getValueByte(&pValue, true, true);
         iValueLen = writevalue(&pValue, pElement->getValueBytes(false));
         /* if(lValueLen != m_lValueLen && m_lValueLen < 70)
         {
            debug("EDFElement::write literalised %ld -vs- %ld bytes\n", lValueLen, m_lValueLen);
            memprint("EDFElement::write unliteralised value", m_pValue, m_lValueLen);
            memprint("EDFElement::write literalised value", pValue, lValueLen);
         } */

         if(pValue != NULL)
         {
            pWrite[lOffset++] = ' ';
            pWrite[lOffset++] = 's';
            pWrite[lOffset++] = 't';
            pWrite[lOffset++] = 'r';
            pWrite[lOffset++] = '=';
            pWrite[lOffset++] = '"';

            if(mask(iOptions, EDFElement::PR_BIN) == true)
            {
               // pSource = pValue->Data(false);
               // iSourceLen = pValue->Length();
               for(iValuePos = 0; iValuePos < iValueLen; iValuePos++)
               {
                  if(!iscntrl(pValue[iValuePos]))
                  {
                     pWrite[lOffset++] = pValue[iValuePos];
                  }
                  else
                  {
                     pWrite[lOffset++] = '[';
                     lOffset += sprintf((char *)(pWrite + lOffset), "%d", pValue[iValuePos]);
                     pWrite[lOffset++] = ']';
                  }
               }
            }
            else
            {
               memcpy(pWrite + lOffset, pValue, iValueLen);
               lOffset += iValueLen;
            }
            delete pValue;

            pWrite[lOffset++] = '"';
         }
      }
      else if(pElement->getType() == EDFElement::INT || pElement->getType() == EDFElement::FLOAT)
      {
         // printf("EDFElement::write int value %ld\n", m_lValue);

         pWrite[lOffset++] = ' ';
         pWrite[lOffset++] = 'n';
         pWrite[lOffset++] = 'u';
         pWrite[lOffset++] = 'm';
         pWrite[lOffset++] = '=';
         pWrite[lOffset++] = '"';
         if(pElement->getType() == EDFElement::INT)
         {
            sprintf(szNumber, "%ld", pElement->getValueInt());
         }
         else
         {
            sprintf(szNumber, "%g", pElement->getValueFloat());
         }
         memcpy(pWrite + lOffset, szNumber, strlen(szNumber));
         lOffset += strlen(szNumber);
         pWrite[lOffset++] = '"';
         /* if(mask(iOptions, EN_XML) == true)
         {
            memcpy(pWrite + lOffset, "\" t=\"i\"", 7);
            lOffset += 7;
         } */
      }
   }
   /* else
   {
      debug("EDFElement::write no curr %s(%d)\n", m_szName, m_vType);
   } */

   if(pElement->children() > 0)
   {
      if(mask(iOptions, EDFElement::EL_CURR) == true)
      {
         pWrite[lOffset++] = '>';
         if(mask(iOptions, EDFElement::PR_SPACE) == true)
         {
            if(mask(iOptions, EDFElement::PR_CRLF) == true)
            {
               pWrite[lOffset++] = '\r';
            }
            pWrite[lOffset++] = '\n';

            iDepth += 2;
         }
      }
      for(iChildNum = 0; iChildNum < pElement->children(); iChildNum++)
      {
         lOffset = write(pWrite, pElement->child(iChildNum), lOffset, EDFElement::EL_CURR | iOptions, iDepth);
         if(mask(iOptions, EDFElement::PR_SPACE) == true)
         {
            if(mask(iOptions, EDFElement::PR_CRLF) == true)
            {
               pWrite[lOffset++] = '\r';
            }
            pWrite[lOffset++] = '\n';
         }
      }
      if(mask(iOptions, EDFElement::PR_SPACE) == true)
      {
         iDepth -= 2;

         if(mask(iOptions, EDFElement::EL_CURR) == true)
         {
            memset(pWrite + lOffset, ' ', iDepth);
            lOffset += iDepth;
         }
      }
      if(mask(iOptions, EDFElement::EL_CURR) == true)
      {
         pWrite[lOffset++] = '<';
         pWrite[lOffset++] = '/';
         if(mask(iOptions, EDFElement::PR_SPACE) == true)
         {
            memcpy(pWrite + lOffset, pElement->getName(false), iNameLen);
            lOffset += iNameLen;
         }
         pWrite[lOffset++] = '>';
      }
   }
   else if(mask(iOptions, EDFElement::EL_CURR) == true)
   {
      if(pElement->getName(false)[0] == '\0')
      {
         pWrite[lOffset++] = '>';
         pWrite[lOffset++] = '<';
      }
      pWrite[lOffset++] = '/';
      pWrite[lOffset++] = '>';
   }

   return lOffset;
}
