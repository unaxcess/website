// This is the main DLL file.

#include "stdafx.h"

#include <stdio.h>
#include <time.h>

#include "useful/useful.h"

#include "EDF/EDFParser.h"

#include "ua.h"

#include "UAClientNet.h"

char *strmk(String *sString)
{
   int iDataPos = 0;
   char *szReturn = NULL;

   if(sString == NULL)
   {
      return NULL;
   }

   szReturn = new char[sString->Length + 1];
   for(iDataPos = 0; iDataPos < sString->Length; iDataPos++)
   {
      szReturn[iDataPos] = sString->get_Chars(iDataPos);
   }
   szReturn[sString->Length] = '\0';

   // memprint(debugfile(), "strmk", (byte *)szReturn, sString->Length, false);

   return szReturn;
}

bytes *StringToBytes(String *sString)
{
   int iDataPos = 0;
   byte *pData = NULL;
   bytes *pReturn = NULL;

   if(sString == NULL)
   {
      return NULL;
   }
   
   pData = new byte[sString->Length];
   for(iDataPos = 0; iDataPos < sString->Length; iDataPos++)
   {
      pData[iDataPos] = sString->get_Chars(iDataPos);
   }

   pReturn = new bytes(pData, sString->Length);

   // bytesprint(debugfile(), "UAClientNet::StringToBytes", pReturn, true);

   delete[] pData;

   return pReturn;
}

String *BytesToString(byte *pData, long lDataLen)
{
   if(pData == NULL)
   {
      return NULL;
   }

   // bytesprint("UAClientNet::BytesToString", pBytes, true);

   return new String((char *)pData, 0, lDataLen);
}

String *BytesToString(bytes *pBytes)
{
   if(pBytes == NULL)
   {
      return NULL;
   }

   // bytesprint("UAClientNet::BytesToString", pBytes, true);

   return new String((char *)pBytes->Data(false), 0, pBytes->Length());
}

namespace org
{

namespace ua2
{

void debugCEDFPrint(char *szTitle, CEDF *pCEDF)
{
   EDFParser::debugPrint(szTitle, pCEDF->GetEDF());
}

void debugCEDFPrint(CEDF *pCEDF)
{
   EDFParser::debugPrint(pCEDF->GetEDF());
}

void MsgEDFPrint(char *szTitle, EDF *pEDF, int iOptions)
{
   bytes *pWrite = NULL;

   if(iOptions == -1)
   {
      iOptions = EDFElement::EL_ROOT | EDFElement::EL_CURR;
   }
   pWrite = EDFParser::Write(pEDF, iOptions | EDFElement::PR_SPACE | EDFElement::PR_CRLF);

   MessageBox(GetFocus(), (LPSTR)pWrite->Data(false), szTitle, 0);

   delete pWrite;
}

void MsgCEDFPrint(char *szTitle, CEDF *pCEDF, int iOptions)
{
   MsgEDFPrint(szTitle, pCEDF->GetEDF(), iOptions);
}


CEDF::CEDF()
{
   // STACKTRACEMEM
   m_pEDF = new EDF();
   m_pEDF->DataCopy(false);
}

CEDF::CEDF(EDF *pEDF)
{
   // STACKTRACEMEM
   m_pEDF = new EDF(pEDF);
   m_pEDF->DataCopy(false);
}

CEDF::~CEDF()
{
   // STACKTRACEMEM
   delete m_pEDF;
}

bool CEDF::Add(String *sName)
{
   return Add(sName, (String *)NULL);
}

bool CEDF::Add(String *sName, String *sValue)
{
   bool bReturn = false;
   char *szName = NULL, *szValue = NULL;

   szName = strmk(sName);
   szValue = strmk(sValue);
   bReturn = m_pEDF->Add(szName, szValue);
   delete[] szName;
   delete[] szValue;

   return bReturn;
}

bool CEDF::Add(String *sName, int iValue)
{
   bool bReturn = false;
   char *szName = NULL;

   szName = strmk(sName);
   bReturn = m_pEDF->Add(szName, iValue);
   delete[] szName;

   return bReturn;
}

bool CEDF::Delete()
{
   return m_pEDF->Delete();
}

String *CEDF::GetName()
{
   String *sReturn = NULL;

   Get(&sReturn, (String **)NULL);

   return sReturn;
}

String *CEDF::GetStr()
{
   String *sReturn = NULL;

   Get(NULL, &sReturn);

   return sReturn;
}

int CEDF::GetInt()
{
   int iReturn = 0;

   Get(NULL, &iReturn);

   return iReturn;
}

int CEDF::GetValType()
{
   return m_pEDF->GetCurr()->getType();
}

bool CEDF::Set(String *sName, String *sValue)
{
   bool bReturn = false;
   char *szName = NULL;
   bytes *pValue = NULL;

   szName = strmk(sName);
   pValue = StringToBytes(sValue);
   bReturn = m_pEDF->Set(szName, pValue);
   delete[] szName;
   delete pValue;

   return bReturn;
}

bool CEDF::Set(String *sName, int iValue)
{
   bool bReturn = false;
   char *szName = NULL;

   szName = strmk(sName);
   bReturn = m_pEDF->Set(szName, iValue);
   delete[] szName;

   return bReturn;
}

bool CEDF::Set(String *sName)
{
   bool bReturn = false;
   char *szName = NULL;

   szName = strmk(sName);
   bReturn = m_pEDF->Set(szName);
   delete[] szName;

   return bReturn;
}

String *CEDF::GetChildStr(String *sName)
{
   String *sReturn = NULL;

   GetChild(sName, &sReturn);

   return sReturn;
}

int CEDF::GetChildInt(String *sName)
{
   return GetChildInt(sName, CEDF::FIRST);
}

int CEDF::GetChildInt(String *sName, int iPosition)
{
   int iReturn = 0;

   GetChild(sName, &iReturn, iPosition);

   return iReturn;
}

double CEDF::GetChildFloat(String *sName)
{
   return GetChildFloat(sName, CEDF::FIRST);
}

double CEDF::GetChildFloat(String *sName, int iPosition)
{
   double dReturn = 0;

   GetChild(sName, &dReturn, iPosition);

   return dReturn;
}

bool CEDF::GetChildBool(String *sName)
{
   bool bReturn = false;
   char *szName = NULL;

   szName = strmk(sName);
   if(m_pEDF->GetChildBool(szName) == true)
   {
      bReturn = true;
   }
   delete[] szName;

   return bReturn;
}

bool CEDF::SetChild(String *sName, String *sValue)
{
   bool bReturn = false;
   char *szName = NULL;
   bytes *pValue = NULL;

   szName = strmk(sName);
   pValue = StringToBytes(sValue);
   bReturn = m_pEDF->SetChild(szName, pValue);
   delete[] szName;
   delete pValue;

   return bReturn;
}

bool CEDF::SetChild(String *sName, int iValue)
{
   bool bReturn = false;
   char *szName = NULL;

   szName = strmk(sName);
   bReturn = m_pEDF->SetChild(szName, iValue);
   delete[] szName;

   return bReturn;
}

bool CEDF::SetChild(String *sName)
{
   return SetChild(sName, NULL);
}

bool CEDF::AddChild(String *sName)
{
   bool bReturn = false;
   char *szName = NULL;

   szName = strmk(sName);
   bReturn = m_pEDF->AddChild(szName);
   delete[] szName;

   return bReturn;
}

bool CEDF::AddChild(String *sName, String *sValue)
{
   bool bReturn = false;
   char *szName = NULL;
   bytes *pValue = NULL;

   szName = strmk(sName);
   pValue = StringToBytes(sValue);
   // debug("CEDF::AddChild %s / %p(%s, %ld)\n", szName, pValue, pValue->Data(false), pValue->Length());
   bReturn = m_pEDF->AddChild(szName, pValue);
   delete[] szName;
   delete pValue;

   return bReturn;
}

bool CEDF::AddChild(String *sName, Byte pValue[], int iValueLen)
{
   int iValuePos = 0;
   bool bReturn = false;
   char *szName = NULL;
   byte *pTemp = NULL;
   bytes *pBytes = NULL;
   __box Byte *pByte = NULL;

   szName = strmk(sName);
   // pValue = StringToBytes(sValue);
   pTemp = new byte[iValueLen];
   for(iValuePos = 0; iValuePos < iValueLen; iValuePos++)
   {
      pByte = __box(pValue[iValuePos]);
      pTemp[iValuePos] = pByte->ToByte(NULL);
   }
   pBytes = new bytes(pTemp, iValueLen);
   // debug("CEDF::AddChild %s / %p(%s, %ld)\n", szName, pValue, pValue->Data(false), pValue->Length());
   bReturn = m_pEDF->AddChild(szName, pBytes);
   delete[] szName;
   delete[] pTemp;
   delete pBytes;

   return bReturn;
}

bool CEDF::AddChild(String *sName, int iValue)
{
   bool bReturn = false;
   char *szName = NULL;

   szName = strmk(sName);
   // debug("CEDF::AddChild %s / %d\n", szName, iValue);
   bReturn = m_pEDF->AddChild(szName, iValue);
   delete[] szName;

   return bReturn;
}

bool CEDF::AddChild(String *sName, double dValue)
{
   bool bReturn = false;
   char *szName = NULL;

   szName = strmk(sName);
   // debug("CEDF::AddChild %s / %d\n", szName, iValue);
   bReturn = m_pEDF->AddChild(szName, dValue);
   delete[] szName;

   return bReturn;
}

bool CEDF::AddChild(String *sName, bool bValue)
{
   return AddChild(sName, (int)bValue);
}

bool CEDF::DeleteChild(String *sName)
{
   bool bReturn = false;
   char *szName = NULL;

   szName = strmk(sName);
   bReturn = m_pEDF->DeleteChild(szName);
   delete[] szName;

   return bReturn;
}

int CEDF::Children()
{
   return Children(NULL, false);
}

int CEDF::Children(String *sName)
{
   return Children(sName, false);
}

int CEDF::Children(String *sName, bool bRecurse)
{
   int iReturn = 0;
   char *szName = NULL;

   szName = strmk(sName);
   iReturn = m_pEDF->Children(szName, bRecurse);
   delete[] szName;

   return iReturn;
}

bool CEDF::Root()
{
   return m_pEDF->Root();;
}

bool CEDF::Child()
{
   return m_pEDF->Child();
}

bool CEDF::Child(String *sName)
{
   return Child(sName, NULL);
}

bool CEDF::Child(String *sName, String *sValue)
{
   bool bReturn = false;
   char *szName = NULL, *szValue = NULL;

   szName = strmk(sName);
   szValue = strmk(sValue);
   bReturn = m_pEDF->Child(szName, szValue);
   delete[] szName;
   delete[] szValue;

   return bReturn;
}

bool CEDF::IsChild(String *sName)
{
   bool bReturn = false;
   char *szName = NULL;

   szName = strmk(sName);
   bReturn = m_pEDF->IsChild(szName);
   delete[] szName;

   return bReturn;
}

bool CEDF::Next()
{
   return Next(NULL);
}

bool CEDF::Next(String *sName)
{
   bool bReturn = false;
   char *szName = NULL;

   szName = strmk(sName);
   bReturn = m_pEDF->Next(szName);
   delete[] szName;

   return bReturn;
}

bool CEDF::Parent()
{
   return m_pEDF->Parent();
}

bool CEDF::Iterate(String *sIter)
{
   bool bReturn = false;
   char *szIter = NULL;

   szIter = strmk(sIter);
   bReturn = m_pEDF->Iterate(szIter);
   delete[] szIter;

   return bReturn;
}

bool CEDF::SortReset(String *sItems)
{
   return SortReset(sItems, false);
}

bool CEDF::SortReset(String *sItems, bool bRecurse)
{
   bool bReturn = false;
   char *szItems = NULL;

   szItems = strmk(sItems);
   bReturn = m_pEDF->SortReset(szItems, bRecurse);
   delete[] szItems;

   return bReturn;
}

bool CEDF::SortAddSection(String *sName)
{
   bool bReturn = false;
   char *szName = NULL;

   szName = strmk(sName);
   bReturn = m_pEDF->SortAddSection(szName);
   delete[] szName;

   return bReturn;
}

bool CEDF::SortAddKey(String *sName)
{
   return SortAddKey(sName, true);
}

bool CEDF::SortAddKey(String *sName, bool bAscending)
{
   bool bReturn = false;
   char *szName = NULL;

   szName = strmk(sName);
   bReturn = m_pEDF->SortAddKey(szName, bAscending);
   delete[] szName;

   return bReturn;
}

bool CEDF::SortParent()
{
   return m_pEDF->SortParent();
}

bool CEDF::Sort()
{
   return m_pEDF->Sort();
}

bool CEDF::Sort(String *sItems, String *sKey)
{
   return Sort(sItems, sKey, false, true);
}

bool CEDF::Sort(String *sItems, String *sKey, bool bRecurse)
{
   return Sort(sItems, sKey, bRecurse, true);
}

bool CEDF::Sort(String *sItems, String *sKey, bool bRecurse, bool bAscending)
{
   bool bReturn = false;
   char *szItems = NULL, *szKey = NULL;

   szItems = strmk(sItems);
   szKey = strmk(sKey);
   bReturn = m_pEDF->Sort(szItems, szKey, bRecurse, bAscending);

   return bReturn;
}

bool CEDF::Copy(CEDF *pCEDF, bool bSrcCurr, bool bDestSet, bool bRecurse)
{
   return m_pEDF->Copy(pCEDF->GetEDF(), bSrcCurr, bDestSet, bRecurse);
}

bool CEDF::Find(String *sName, int iID, bool bRecurse)
{
   bool bReturn = false;
   char *szName = NULL;

   szName = strmk(sName);
   bReturn = EDFFind(m_pEDF, szName, iID, bRecurse);
   delete[] szName;

   return bReturn;
}

int CEDF::Read(String *sData)
{
   int iReturn = 0;
   char *szData = NULL;

   szData = strmk(sData);
   iReturn = EDFParser::Read(m_pEDF, szData);
   delete[] szData;

   return iReturn;
}

int CEDF::Read(Byte pValue[], int iValueLen)
{
   int iReturn = 0, iValuePos;
   byte *pTemp = NULL;
   bytes *pBytes = NULL;
   __box Byte *pByte = NULL;

   pTemp = new byte[iValueLen];
   for(iValuePos = 0; iValuePos < iValueLen; iValuePos++)
   {
      pByte = __box(pValue[iValuePos]);
      pTemp[iValuePos] = pByte->ToByte(NULL);
   }
   pBytes = new bytes(pTemp, iValueLen);
   iReturn = EDFParser::Read(m_pEDF, pBytes, iValueLen);
   delete[] pTemp;
   delete pBytes;

   return iReturn;
}

String *CEDF::Write(int iOptions)
{
   bytes *pWrite = NULL;
   String *pReturn = NULL;

   pWrite = EDFParser::Write(m_pEDF, iOptions);
   pReturn = BytesToString(pWrite);
   delete pWrite;

   return pReturn;
}

bool CEDF::FileToEDF(String *sFilename)
{
   char *szFilename = NULL;
   EDF *pEDF = NULL;

   if(sFilename == NULL)
   {
      return false;
   }

   szFilename = strmk(sFilename);
   pEDF = EDFParser::FromFile(szFilename);
   delete[] szFilename;

   if(pEDF == NULL)
   {
      return false;
   }

   SetEDF(pEDF);

   return true;
}

bool CEDF::EDFToFile(String *sFilename)
{
   bool bReturn = false;
   char *szFilename = NULL;

   if(sFilename == NULL)
   {
      return false;
   }

   szFilename = strmk(sFilename);
   bReturn = EDFParser::ToFile(m_pEDF, szFilename);
   delete[] szFilename;

   return bReturn;
}

void CEDF::MsgPrint(String *sTitle)
{
   MsgPrint(sTitle, -1);
}

void CEDF::MsgPrint(String *sTitle, int iOptions)
{
   char *szTitle = NULL;

   szTitle = strmk(sTitle);
   MsgEDFPrint(szTitle, GetEDF(), iOptions);
   delete[] szTitle;
}

void CEDF::debugPrint(String *sTitle)
{
   debugPrint(sTitle, -1);
}

void CEDF::debugPrint(String *sTitle, int iOptions)
{
   char *szTitle = NULL;

   szTitle = strmk(sTitle);
   EDFParser::debugPrint(szTitle, m_pEDF, iOptions);
   delete[] szTitle;
}

EDF *CEDF::GetEDF()
{
   return m_pEDF;
}

void CEDF::SetEDF(EDF *pEDF)
{
   // STACKTRACEMEM
   if(m_pEDF != NULL)
   {
      delete m_pEDF;
   }

   m_pEDF = new EDF(pEDF);
   m_pEDF->DataCopy(false);
}

bool CEDF::Get(String **sName, String **sValue)
{
   bool bReturn = false;
   char *szName = NULL;
   bytes *pValue = NULL;

   bReturn = m_pEDF->Get(&szName, &pValue);

   if(sName != NULL)
   {
      (*sName) = new String(szName);
   }
   if(sValue != NULL)
   {
      (*sValue) = BytesToString(pValue);
   }

   return bReturn;
}

bool CEDF::Get(String **sName, int *iValue)
{
   bool bReturn = false;
   char *szName = NULL;

   bReturn = m_pEDF->Get(&szName, iValue);

   if(sName != NULL)
   {
      (*sName) = new String(szName);
   }

   return bReturn;
}

bool CEDF::GetChild(String *sName, String **sValue)
{
   bool bReturn = false;
   char *szName = NULL;
   bytes *pValue = NULL;

   szName = strmk(sName);
   bReturn = m_pEDF->GetChild(szName, &pValue);
   if(sValue != NULL)
   {
      (*sValue) = BytesToString(pValue);
   }

   return bReturn;
}

/* bool CEDF::GetChild(String *sName, int *iValue)
{
   return GetChild(sName, iValue, FIRST);
} */

bool CEDF::GetChild(String *sName, int *iValue, int iPosition)
{
   bool bReturn = false;
   char *szName = NULL;

   szName = strmk(sName);
   bReturn = m_pEDF->GetChild(szName, iValue, iPosition);
   delete[] szName;

   return bReturn;
}

bool CEDF::GetChild(String *sName, double *dValue, int iPosition)
{
   bool bReturn = false;
   char *szName = NULL;

   szName = strmk(sName);
   bReturn = m_pEDF->GetChild(szName, dValue, iPosition);
   delete[] szName;

   return bReturn;
}


CClient::CClient()
{
   STACKTRACELOG
   char *szDebugFile = NULL;

   debuglevel(DEBUGLEVEL_INFO);

   m_pData = new CEDF();
   m_pUser = NULL;

   m_pClient = new EDFConn();

   m_iLoopDepth = 0;

   m_pAnnounces = NULL;
   m_iNumAnnounces = 0;

   m_sProtocol = NULL;

   m_hLoop = CreateMutex(NULL, TRUE, NULL);
}

CClient::~CClient()
{
   STACKTRACELOG
   delete m_pClient;
}

bool CClient::Disconnect()
{
   bool bReturn = false;

   bReturn = m_pClient->Disconnect();

   while(m_pClient->State() == Conn::CLOSING)
   {
      loop();
   }

   return bReturn;
}

bool CClient::startup()
{
   return true;
}

bool CClient::shutdown()
{
   return true;
}

bool CClient::connected()
{
   return true;
}

bool CClient::disconnected()
{
   return true;
}

int CClient::State()
{
   return m_pClient->State();
}

bool CClient::login(CEDF *pRequest)
{
   return true;
}

bool CClient::loggedIn()
{
   return true;
}

bool CClient::notLoggedIn()
{
   return true;
}

bool CClient::reply(String *sReply, CEDF *pReply)
{
   return false;
}

bool CClient::announce(String *sAnnounce, CEDF *pAnnounce)
{
   return true;
}

int CClient::background()
{
   return 0;
}

bool CClient::request1(String *sRequest)
{
   return request3(sRequest, NULL, NULL);
}

bool CClient::request2(String *sRequest, CEDF *pReply)
{
   return request3(sRequest, NULL, pReply);
}

bool CClient::request3(String *sRequest, CEDF *pRequest, CEDF *pReply)
{
   bool bReturn = false;
   double dTick = gettick();
   char *szRequest = NULL;
   EDF *pRequestEDF = NULL, *pReplyEDF = NULL;

   if(pRequest != NULL)
   {
      pRequestEDF = pRequest->GetEDF();
   }

   szRequest = strmk(sRequest);
   if(pReply != NULL)
   {
      bReturn = request(szRequest, pRequestEDF, &pReplyEDF);
   }
   else
   {
      bReturn = request(szRequest, pRequestEDF, NULL);
   }
   delete[] szRequest;

   if(bReturn == false && m_pClient->State() != Conn::OPEN)
   {
      disconnected();

      return false;
   }

   if(pReply != NULL)
   {
      pReply->SetEDF(pReplyEDF);
   }

   return bReturn;
}

bool CClient::edf(String *sValue)
{
   bool bReturn = false;
   char *szValue = NULL;
   EDF *pEDF = NULL;

   szValue = strmk(sValue);

   pEDF = new EDF();
   pEDF->Set("edf", szValue);

   bReturn = m_pClient->Write(pEDF);

   delete[] szValue;

   return bReturn;
}

int CClient::version(String *sVersion)
{
   int iReturn = 0;
   char *szProtocol = NULL, *szVersion = NULL;

   szProtocol = strmk(m_sProtocol);
   szVersion = strmk(sVersion);
   iReturn = ProtocolCompare(szProtocol, szVersion);
   delete[] szVersion;
   delete[] szProtocol;

   return iReturn;
}

bool CClient::write(CEDF *pEDF)
{
   return m_pClient->Write(pEDF->GetEDF());
}

bool CClient::run(CEDF *pConfig)
{
   STACKTRACELOG
   int iPort = 0, iStatus = 0, iTimeout = 1000, iUserID = -1;
   bool bForce = false, bSecure = false, bBusy = false, bSilent = false, bShadow = false, bNoContact = false, bReturn = false;
   char *szServer = NULL, *szUsername = NULL, *szPassword = NULL, *szHostname = NULL, *szAddress = NULL, *szCertFile = NULL, *szClientName = NULL, *szReply = NULL, *szProtocol = NULL;
   String *sReply = NULL;
   EDF *pConfigEDF = NULL, *pReadEDF = NULL, *pRequestEDF = NULL, *pReplyEDF = NULL, *pSystemEDF = NULL;
   CEDF *pRequest = NULL, *pReply = NULL;
   double dTick = 0;

   if(pConfig == NULL)
   {
      return false;
   }

   pConfigEDF = pConfig->GetEDF();

   // debug("CClient::run entry %p\n", pConfigEDF);
   EDFParser::debugPrint("CClient::run entry", pConfigEDF);

   pConfigEDF->GetChild("server", &szServer);
   pConfigEDF->GetChild("port", &iPort);
   pConfigEDF->GetChild("timeout", &iTimeout);
#ifdef CONNSECURE
   bSecure = pConfigEDF->GetChildBool("secure");
   pConfigEDF->GetChild("certificate", &szCertFile);
#endif

   pConfigEDF->GetChild("username", &szUsername);
   pConfigEDF->GetChild("password", &szPassword);

   // pConfigEDF->GetChild("hostname", &szHostname);
   // pConfigEDF->GetChild("address", &szAddress);

   bForce = pConfigEDF->GetChildBool("force");
   bBusy = pConfigEDF->GetChildBool("busy");
   bSilent = pConfigEDF->GetChildBool("silent");
   bShadow = pConfigEDF->GetChildBool("shadow");
   bNoContact = pConfigEDF->GetChildBool("nocontact");

   // debug("CClient::run mem2: %ld bytes\n", memusage());

   m_pData->SetEDF(pConfigEDF);

   // debug("CClient::run mem3: %ld bytes\n", memusage());

   debug("CClient::run server %s, port %d, username %s, password %s", szServer, iPort, szUsername, szPassword != NULL ? "****" : "");
   /* if(szHostname != NULL)
   {
      debug(", hostname %s", szHostname);
   }
   if(szAddress != NULL)
   {
      debug(", address %s", szAddress);
   } */
   if(bBusy == true)
   {
      debug(", busy");
   }
   if(bSilent == true)
   {
      debug(", silent");
   }
   if(bSecure == true)
   {
      debug(", secure");
   }
   if(bShadow == true)
   {
      debug(", shadow");
   }
   if(bNoContact == true)
   {
      debug(", nocontact");
   }
   if(szCertFile != NULL)
   {
      debug(", certificate %s", szCertFile);
   }
   debug("\n");

   // debug("CClient::run mem4: %ld bytes\n", memusage());

   m_pData->Root();
   while(m_pData->DeleteChild("quit") == true);
   if(startup() == false)
   {
      debug("UACLient::run exit false, startup failed\n");
      return false;
   }

   // debug("CClient::run mem5: %ld bytes\n", memusage());

   dTick = gettick();
   if(m_pClient->Connect(szServer, iPort, bSecure, szCertFile) == false)
   {
      debug("CClient::run exit false, Unable to connect to server %s / port %d (%s)\n", szServer, iPort, m_pClient->Error());
      return false;
   }
   debug("CClient::run connected in %ld ms\n", tickdiff(dTick));

   // debug("CClient::run mem6: %ld bytes\n", memusage());

   m_pClient->Timeout(50);

   pReadEDF = NULL;
   dTick = gettick();
   while(m_pClient->State() == Conn::OPEN && m_pClient->Connected() == false)
   {
      pReadEDF = m_pClient->Read();

      // debug("CClient::run state %d connected %s\n", m_pClient->State(), BoolStr(m_pClient->Connected()));
   }
   if(m_pClient->State() != Conn::OPEN)
   {
      disconnected();

      debug("CClient::run exit false, disconnected during EDF mode loop\n");
      return false;
   }
   // debug("CClient::run mem7: %ld bytes\n", memusage());
   debug("CClient::run EDF mode on in %ld ms\n", tickdiff(dTick));
   delete pReadEDF;

   // debug("CClient::run mem8: %ld bytes\n", memusage());

   dTick = gettick();
   m_pData->Root();
   connected();
   debug("CClient::run connect called in %ld ms\n", tickdiff(dTick));

   // debug("CClient::run mem9: %ld bytes\n", memusage());

   request(MSG_SYSTEM_LIST, NULL, &pSystemEDF);
   pSystemEDF->GetChild("protocol", &szProtocol);
   m_sProtocol = new String(szProtocol);
   delete pSystemEDF;

   // debug("CClient::run mem10: %ld bytes\n", memusage());

   // Auto-login if possible
   if(szUsername != NULL)
   {
      debug("CClient::run attempt login as %s\n", szUsername);

      // debug("CClient::run creating login request\n");
      pRequest = new CEDF();
      if(login(pRequest) == true)
      {
         pRequestEDF = pRequest->GetEDF();
         if(pRequestEDF->IsChild("name") == false)
         {
            pRequestEDF->SetChild("name", szUsername);
            // EDFPrint("CClient::run post name add", pRequestEDF);
         }

         if(pRequestEDF->IsChild("password") == false && szPassword != NULL)
         {
            pRequestEDF->SetChild("password", szPassword);
            // EDFPrint("CClient::run post password add", pRequestEDF);
         }

			Conn::GetHostInfo(&szHostname, &szAddress);

         if(szHostname != NULL)
         {
            pRequestEDF->SetChild("hostname", szHostname);
         }
         if(szAddress != NULL)
         {
            pRequestEDF->SetChild("address", szAddress);
         }

         szClientName = strmk(CLIENT_NAME());
         pRequestEDF->SetChild("client", szClientName);
         delete[] szClientName;
         pRequestEDF->SetChild("protocol", PROTOCOL);
         pRequestEDF->SetChild(pConfigEDF, "clientbase");
         pRequestEDF->SetChild(pConfigEDF, "attachmentsize");

         // EDFPrint("CClient::run post client / protocol add", pRequestEDF);
         /* if(m_bClientDebug == true)
         {
            debugEDFPrint("CClient::run login", pRequestEDF);
         } */

         pRequestEDF->GetChild("status", &iStatus);
         if(bForce == true)
         {
            pRequestEDF->AddChild("force", true);
         }
         if(bBusy == true)
         {
            iStatus |= LOGIN_BUSY;
         }
         if(bSilent == true)
         {
            iStatus |= LOGIN_SILENT;
         }
         if(bShadow == true)
         {
            iStatus |= LOGIN_SHADOW;
         }
         if(bNoContact == true)
         {
            iStatus |= LOGIN_NOCONTACT;
         }
         if(iStatus > 0)
         {
            pRequestEDF->SetChild("status", iStatus);
         }

         EDFParser::debugPrint("CClient::run logging in", pRequestEDF);
         if(request(MSG_USER_LOGIN, pRequestEDF, &pReplyEDF) == true)
         {
            // debugEDFPrint("CClient::run logged in", pReplyEDF);
            // debug("CClient::run logged in after %ld ms\n", tickdiff(dTick));

            if(pReplyEDF->GetChild("userid", &iUserID) == true)
            {
               pReplyEDF->DeleteChild("userid");
               pReplyEDF->Set("user", iUserID);
            }
            m_pUser = new CEDF(pReplyEDF);

            dTick = gettick();
            loggedIn();
            debug("CClient::run loggedIn in %ld ms\n", tickdiff(dTick));

            bReturn = true;
         }
         else
         {
            // debugEDFPrint("CClient::run login failed", pReplyEDF);
            // debug("CClient::run login failed after %ld ms\n", tickdiff(dTick));

            pReplyEDF->Get(NULL, &szReply);
            sReply = new String(szReply);
            // delete[] szReply;

            pReply = new CEDF(pReplyEDF);

            if(reply(sReply, pReply) == false)
            {
               defaultreply(sReply, pReply);
            }
         }

         delete pReplyEDF;
      }

      // delete[] szUsername;
      // delete[] szPassword;
      // delete[] szHostname;
      // delete[] szAddress;
   }
   else
   {
      notLoggedIn();
   }

   // debug("CClient::run mem11: %ld bytes\n", memusage());

   m_pClient->Timeout(iTimeout);

   debug("CClient::run exit %s\n", BoolStr(bReturn));
   return bReturn;
}

bool CClient::loop()
{
   // STACKTRACEMEM
   int iAnnounceNum = 0;
   bool bReturn = false;
   double dTick = 0;
   char *szAnnounce = NULL;
   String *sAnnounce = NULL;
   CEDF *pAnnounce = NULL;

   dTick = gettick();
   WaitForSingleObject(m_hLoop, INFINITE);
   if(tickdiff(dTick) > 0)
   {
      debug("CClient::loop waited %ld ms\n", tickdiff(dTick));
   }

   for(iAnnounceNum = 0; iAnnounceNum < m_iNumAnnounces; iAnnounceNum++)
   {
      pAnnounce = new CEDF(m_pAnnounces[iAnnounceNum]);
      m_pAnnounces[iAnnounceNum]->Get(NULL, &szAnnounce);

      debug("CClient::loop announce %d, %p(%s)\n", iAnnounceNum, m_pAnnounces[iAnnounceNum], szAnnounce);

      sAnnounce = strmk(szAnnounce);
      announce(sAnnounce, pAnnounce);

      delete[] szAnnounce;

      // delete m_pAnnounces[iAnnounceNum];
   }

   // delete[] m_pAnnounces;
   m_iNumAnnounces = 0;

   bReturn = singleloop(NULL, false);

   ReleaseMutex(m_hLoop);

   return bReturn;
}

String *CClient::Error()
{
   return new String(m_pClient->Error());
}

bool CClient::debugopen(String *sFilename)
{
   char *szFilename = NULL;

   if(sFilename != NULL)
   {
      szFilename = strmk(sFilename);
      ::debugopen(szFilename);
      delete[] szFilename;
   }

   return true;
}

int CClient::debugline(String *sString)
{
   int iReturn = 0;
   char *szString = NULL;

   szString = strmk(sString);
   iReturn = debug(szString);
   debug("\n");
   delete[] szString;

   return iReturn;
}

String *CClient::FileRead(String *sFilename)
{
   size_t lRead = 0;
   char *szFilename = NULL;
   byte *pRead = NULL;
   String *sReturn = NULL;

   szFilename = strmk(sFilename);
   pRead = ::FileRead(szFilename, &lRead);

   sReturn = BytesToString(pRead, lRead);

   delete[] pRead;
   delete[] szFilename;

   return sReturn;
}

long CClient::FileWrite(String *sFilename, String *sWrite)
{
   long lReturn = 0;
   char *szFilename = NULL;
   bytes *pWrite = NULL;

   szFilename = strmk(sFilename);
   pWrite = StringToBytes(sWrite);

   lReturn = ::FileWrite(szFilename, pWrite->Data(false), pWrite->Length());

   delete pWrite;
   delete[] szFilename;

   return lReturn;
}

double CClient::gettick()
{
   return ::gettick();
}

long CClient::tickdiff(double dTick)
{
   return ::tickdiff(dTick);
}

bool CClient::request(char *szRequest, EDF *pRequest, EDF **pReply)
{
   STACKTRACELOG
   int iTimeout = 0;
   bool bReturn = false;
   long lTick = 0;
   double dTick = 0;
   char *szReply = NULL;
   EDF *pTemp = NULL;

   // debug("CClient::request %s %p %p\n", szRequest, pRequest, pReply);
   if(pRequest != NULL)
   {
      // EDFParser::debugPrint(pRequest);
   }

   if(szRequest == NULL)
   {
      return false;
   }

   if(pRequest == NULL)
   {
      pTemp = new EDF();
   }
   else
   {
      pTemp = pRequest;
   }

   pTemp->Root();
   pTemp->Set("request", szRequest);
   EDFParser::debugPrint("CClient::request", pTemp);

   // Try sending request
   dTick = gettick();
   // debugEDFPrint("CClient::request sending", pTemp);
   /* dTick = gettick();
   WaitForSingleObject(m_pWriteLock, INFINITE);
   lTick = tickdiff(dTick);
   if(lTick > 50)
   {
      debug("CClient::request waited %ld ms on mutex\n", lTick);
   } */
   if(m_pClient->Write(pTemp) == false)
   {
      // Write failed
      m_pData->Root();
      m_pData->SetChild("quit", true);

      // ReleaseMutex(m_pWriteLock);
      return false;
   }
   // ReleaseMutex(m_pWriteLock);

   if(pTemp != pRequest)
   {
      delete pTemp;
   }

   if(pReply == NULL)
   {
      return true;
   }

   iTimeout = m_pClient->Timeout();
   m_pClient->Timeout(100);

   while(singleloop(pReply, true) == false);

   m_pClient->Timeout(iTimeout);

   if(m_pClient->State() != Conn::OPEN)
   {
      disconnected();

      debug("CClient::request exit false, loop failed\n");
      return false;
   }

   (*pReply)->Get(NULL, &szReply);
   if(stricmp(szRequest, szReply) == 0)
   {
      bReturn = true;
   }

   // debugEDFPrint(*pReply);
   // delete[] szReply;
   return bReturn;
}

bool CClient::singleloop(EDF **pReplyEDF, bool bAnnounceBuffer)
{
   // STACKTRACEMEM
   int iBackground = 0, iTime = 0;
   long lTick = 0, lEntry = 0, lExit = 0, lPostRead = 0, lMinus = 0;
   bool bReturn = true, bQuit = false, bLoop = true, bReply = false;
   double dTick = 0, dEntry = 0;
   char *szType = NULL, *szMessage = NULL, *szQuitType = NULL, *szQuitMessage = NULL;
   String *sMessage = NULL;
   EDF *pReadEDF = NULL, *pAnnounceEDF = NULL, **pTempEDF = NULL;
   CEDF *pRead = NULL;

   m_iLoopDepth++;
   if(m_iLoopDepth > 1 || pReplyEDF != NULL)
   {
      debug("CClient::singleloop %p depth %d\n", pReplyEDF, m_iLoopDepth);
   }

   /* dTick = gettick();
   WaitForSingleObject(m_pLoopLock, INFINITE);
   lTick = tickdiff(dTick);
   // if(lTick > 50)
   {
      debug("CClient::singleloop waited %ld ms on entry\n", lTick);
   } */

   dEntry = gettick();
   // debug("UAClient::singleloop entry %p\n", pReplyEDF);

   lEntry = memusage();

   // Check for a message from the server
   dTick = gettick();

   do
   {
      dTick = gettick();
      pReadEDF = m_pClient->Read();
      // debug("UAClient::singleloop read %p in %ld ms\n", pReadEDF, tickdiff(dTick));
      // debug("UAClient::singleloop read loop %s\n", BoolStr(bRead));

      lPostRead = memusage();
      // debug("UAClient::singleloop read difference %ld bytes\n", lDiff);

      /* if(m_iLoopDepth > 1)
      {
         debug("CClient::singleloop read %ld ms, %p\n", tickdiff(dTick), pReadEDF);
      } */

      if(pReadEDF != NULL)
      {
         EDFParser::debugPrint("UAClient::singleloop read", pReadEDF);

         szType = NULL;
         szMessage = NULL;

         pReadEDF->Root();
         pReadEDF->Get(&szType, &szMessage);
         lMinus = memusage() - lPostRead;
         // debug("UAClient::singleloop minus %ld %ld %ld\n", lEntry, lPostRead, lMinus);

         if(szType != NULL)
         {
            if(stricmp(szType, "reply") == 0)
            {
               // Process reply
               if(m_pUser != NULL)
               {
                  m_pUser->Root();
               }

               // debug("UAClient::singleloop reply '%s'\n", szMessage);

               sMessage = new String(szMessage);
               pRead = new CEDF(pReadEDF);
               if(pReplyEDF != NULL)
               {
                  *pReplyEDF = pReadEDF;
                  bReply = true;
               }
               else if(reply(sMessage, pRead) == false)
               {
                  defaultreply(sMessage, pRead);
               }
            }
            else if(stricmp(szType, "announce") == 0)
            {
               if(bAnnounceBuffer == false)
               {
                  // Process asynchronous event
                  if(m_pUser != NULL)
                  {
                     m_pUser->Root();
                  }

                  // debug("UAClient::singleloop announce '%s'\n", szMessage);
                  // debugEDFPrint(pReadEDF, EDFElement::PR_SPACE);

                  sMessage = new String(szMessage);
                  pRead = new CEDF(pReadEDF);
                  // ReleaseMutex(m_pLoopLock);
                  announce(sMessage, pRead);
                  /* dTick = gettick();
                  WaitForSingleObject(m_pLoopLock, INFINITE);
                  lTick = tickdiff(dTick);
                  // if(lTick > 50)
                  {
                     debug("CClient::singleloop waited %ld ms on announce\n", lTick);
                  } */
               }
               else
               {
                  pAnnounceEDF = new EDF(pReadEDF);

                  ARRAY_INSERT(EDF *, m_pAnnounces, m_iNumAnnounces, pAnnounceEDF, m_iNumAnnounces, pTempEDF)
               }
            }
            else
            {
               // debugEDFPrint("UAClient: Unknown message", pReadEDF);
               m_pData->Root();
               m_pData->SetChild("quit", true);
            }
         }
         else if(m_iLoopDepth > 1)
         {
            debug("CClient::singleloop read failed %ld ms\n", tickdiff(dTick));
         }

         if(bReply == false)
         {
            delete pReadEDF;
         }
      }
   }
   while(m_pClient->State() == Conn::OPEN && pReplyEDF != NULL && bReply == false);

   // debug("UAClient::singleloop state %d\n", State());
   if(m_pClient->State() != Conn::OPEN)
   {
      disconnected();

      bQuit = true;
   }
   else if(pReplyEDF == NULL)
   {
      m_pData->Root();
      iBackground = background();

      m_pData->Root();
      bQuit = m_pData->GetChildBool("quit");
   }

   // debug("UAClient::singleloop quit check %d %s\n", iBackground, BoolStr(bQuit));
   if(m_pClient->State() == Conn::OPEN && (mask(iBackground, BG_QUIT) == true || bQuit == true))
   {
      debug("UAClient::singleloop quitting\n");

      if(m_pUser != NULL)
      {
         debug("UAClient::singleloop logging out\n");
         request(MSG_USER_LOGOUT, NULL, NULL);
      }

      iTime = time(NULL);
      m_pClient->Timeout(100);
      while(bLoop == true)
      {
         // if(Read(&pReadEDF) == true)
         pReadEDF = m_pClient->Read();
         if(pReadEDF != NULL)
         {
            szQuitType = NULL;
            szQuitMessage = NULL;

            pReadEDF->Root();
            pReadEDF->Get(&szQuitType, &szQuitMessage);
            if(szQuitType != NULL && szQuitMessage != NULL)
            {
               if(stricmp(szQuitType, "reply") == 0 && stricmp(szQuitMessage, MSG_USER_LOGOUT) == 0)
               {
                  debug("UAClient::singleloop quit got %s reply\n", MSG_USER_LOGOUT);
                  bLoop = false;
               }
            }
            // delete[] szQuitType;
            // delete[] szQuitMessage;

            delete pReadEDF;
         }

         if(m_pClient->State() != Conn::OPEN)
         {
            disconnected();

            debug("UAClient::singleloop quit state not open\n");
            bLoop = false;
         }
         else if(time(NULL) > iTime + 3)
         {
            debug("UAClient::singleloop quit state timeout\n");
            bLoop = false;
         }
      }

      m_pClient->Disconnect();

      // debug("UAClient::singleloop exit false\n");
      bReturn = false;
   }

   lExit = memusage() - lMinus;
   if(lEntry != lExit)
   {
      /* debug("UAClient::singleloop memusage");
      if(szType != NULL || szMessage != NULL)
      {
         debug("(%s/%s)", szType, szMessage);
      }
      debug(" %ld -> %ld (%ld)\n", lEntry, lExit, lExit - lEntry); */
   }

   // delete[] szType;
   // delete[] szMessage;

   // debug("UAClient::singleloop exit return %s, %ld ms\n", BoolStr(bReturn), tickdiff(dEntry));
   // ReleaseMutex(m_pLoopLock);
   m_iLoopDepth--;
   return bReturn;
}

bool CClient::defaultreply(String *sReply, CEDF *pReply)
{
   if(sReply->CompareTo(MSG_USER_LOGIN_INVALID) == 0)
   {
      m_pData->Root();
      m_pData->SetChild("quit", true);
   }

   return true;
}

}

}
