// UAClientNet.h

#pragma once

#include "common/EDFConn.h"

using namespace System;

namespace org
{
   namespace ua2
   {
      public __gc class CEDF
      {
      public:
         static const EL_ROOT = EDFElement::EL_ROOT;
         static const EL_CURR = EDFElement::EL_CURR;
         static const PR_SPACE = EDFElement::PR_SPACE;
         static const PR_CRLF = EDFElement::PR_CRLF;

         static const FIRST = EDFElement::FIRST;
         static const LAST = EDFElement::LAST;

         static const EL_STR = EDFElement::BYTES;
         static const EL_INT = EDFElement::INT;

         CEDF();
         CEDF(EDF *pEDF);
         ~CEDF();

         bool Add(String *sName);
         bool Add(String *sName, int iValue);
         bool Add(String *sName, String *sValue);

         bool Delete();

         String *GetName();
         String *GetStr();
         int GetInt();
         int GetValType();

         bool Set(String *sName, String *sValue);
         bool Set(String *sName, int iValue);
         bool Set(String *sName);

         String *GetChildStr(String *sName);
         int GetChildInt(String *sName);
         int GetChildInt(String *sName, int iPosition);
         double GetChildFloat(String *sName);
         double GetChildFloat(String *sName, int iPosition);
         bool GetChildBool(String *sName);

         bool SetChild(String *sName, String *sValue);
         bool SetChild(String *sName, int iValue);
         bool SetChild(String *sName);

         bool AddChild(String *sName);
         bool AddChild(String *sName, String *sValue);
         bool AddChild(String *sName, Byte pValue[], int iValueLen);
         bool AddChild(String *sName, int iValue);
         bool AddChild(String *sName, double dValue);
         bool AddChild(String *sName, bool bValue);

         bool DeleteChild(String *sName);

         int Children();
         int Children(String *sName);
         int Children(String *sName, bool bRecurse);

         bool Root();

         bool Child();
         bool Child(String *sName);
         bool Child(String *sName, String *sValue);
         bool IsChild(String *sName);
         bool Next();
         bool Next(String *sName);
         bool Parent();

         bool Iterate(String *sIter);

         bool SortReset(String *sItems);
         bool SortReset(String *sItems, bool bRecurse);
         bool SortAddSection(String *sName);
         bool SortAddKey(String *sName);
         bool SortAddKey(String *sName, bool bAscending);
         bool SortParent();
         bool Sort();
         bool Sort(String *sItems, String *sKey);
         bool Sort(String *sItems, String *sKey, bool bRecurse);
         bool Sort(String *sItems, String *sKey, bool bRecurse, bool bAscending);

         bool Copy(CEDF *pCEDF, bool bSrcCurr, bool bDestSet, bool bRecurse);

         bool Find(String *sName, int iID, bool bRecurse);

         int Read(String *sData);
         int Read(Byte pValue[], int iValueLen);
         String *Write(int iOptions);

         bool FileToEDF(String *sFilename);
         bool EDFToFile(String *sFilename);

         // void print(String *sTitle);
         void MsgPrint(String *sTitle);
         void MsgPrint(String *sTitle, int iOptions);
         void debugPrint(String *sTitle);
         void debugPrint(String *sTitle, int iOptions);

      public:
         // These ought to be hidden
         EDF *GetEDF();
         void SetEDF(EDF *pEDF);

      private:
         EDF *m_pEDF;

         bool Get(String **sName, String **sValue);
         bool Get(String **sName, int *iValue);

         bool GetChild(String *sName, String **sValue);
         // bool GetChild(String *sName, int *iValue);
         bool GetChild(String *sName, int *iValue, int iPosition);
			bool GetChild(String *sName, double *dValue, int iPosition);
      };

      public __gc class CClient
	   {
      public:
         static int BG_QUIT = 1, BG_WRITE = 2;
         static int CLOSED = 0, OPEN = 1, CLOSING = 2, LOST = 3;

         // Constructor and destructor
         CClient();
         virtual ~CClient();

         bool Disconnect();

         // Functions to be derived
         virtual bool startup();
         virtual bool shutdown();
         virtual bool connected();
         virtual bool disconnected();
         int State();

         virtual bool login(CEDF *pRequest);
         virtual bool loggedIn();
         virtual bool notLoggedIn();

         virtual bool reply(String *sReply, CEDF *pReply);
         virtual bool announce(String *sAnnounce, CEDF *pAnnounce);

         virtual int background();

         bool request1(String *sRequest);
         bool request2(String *sRequest, CEDF *pReply);
         bool request3(String *sRequest, CEDF *pRequest, CEDF *pReply);

         bool edf(String *sValue);

         int version(String *sVersion);

         bool write(CEDF *pEDF);

         // Main setup and loop function
         bool run(CEDF *pConfig);
         bool loop();

         String *Error();

         static bool debugopen(String *sFilename);
         static int debugline(String *sString);

         static String *FileRead(String *sFilename);
         static long FileWrite(String *sFilename, String *sWrite);

         static double gettick();
         static long tickdiff(double dTick);

      protected:
         CEDF *m_pData;
         CEDF *m_pUser;

         virtual String *CLIENT_NAME() = 0;

      private:
         EDFConn *m_pClient;
         int m_iLoopDepth;

         String *m_sProtocol;

         EDF **m_pAnnounces;
         int m_iNumAnnounces;

         HANDLE m_hLoop;

         bool request(char *szRequest, EDF *pRequest, EDF **pReply);

         bool singleloop(EDF **pReplyEDF, bool bAnnounceBuffer);
         bool defaultreply(String *sReply, CEDF *pReply);
      };
   }
}
