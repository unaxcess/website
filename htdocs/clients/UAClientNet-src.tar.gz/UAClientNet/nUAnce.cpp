#include "stdafx.h"

#include "nUAnce.h"

#include "UACLientNet.h"

nUAnce::nUAnce(CClient *pParent)
{
   m_pParent = pParent;
}

char *nUAnce::CLIENT_NAME()
{
   return NULL;
}
