#ifndef _NUANCE_H_
#define _NUANCE_H_

#include "client/UAClient.h"

using namespace org::ua2;

class CClient;

class nUAnce : public UAClient
{
protected:
   nUAnce(CClient *pParent);

   char *CLIENT_NAME();

private:
   CClient *m_pParent;
};

#endif
