#ifndef _LEAKTRACER_H_
#define _LEAKTRACER_H_
 
void leakSetStack();
void leakSetStack1();
void leakSetStack2();
void leakGetAllocs(long *lNumAllocs, long *lTotalAllocs);
 
#endif
