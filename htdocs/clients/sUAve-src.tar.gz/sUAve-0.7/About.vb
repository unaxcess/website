Public Class frmAbout
   Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

   Public Sub New()
      MyBase.New()

      'This call is required by the Windows Form Designer.
      InitializeComponent()

      'Add any initialization after the InitializeComponent() call
      lblsUAve.Text = sUAveHelper.CLIENT_NAME & vbCrLf & "Protocol " & ua.PROTOCOL
   End Sub

   'Form overrides dispose to clean up the component list.
   Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
      If disposing Then
         If Not (components Is Nothing) Then
            components.Dispose()
         End If
      End If
      MyBase.Dispose(disposing)
   End Sub

   'Required by the Windows Form Designer
   Private components As System.ComponentModel.IContainer

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   Friend WithEvents cmdOK As System.Windows.Forms.Button
   Friend WithEvents picsUAve As System.Windows.Forms.PictureBox
   Friend WithEvents lblsUAve As System.Windows.Forms.Label
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmAbout))
      Me.cmdOK = New System.Windows.Forms.Button()
      Me.picsUAve = New System.Windows.Forms.PictureBox()
      Me.lblsUAve = New System.Windows.Forms.Label()
      Me.SuspendLayout()
      '
      'cmdOK
      '
      Me.cmdOK.DialogResult = System.Windows.Forms.DialogResult.Cancel
      Me.cmdOK.FlatStyle = System.Windows.Forms.FlatStyle.System
      Me.cmdOK.Location = New System.Drawing.Point(208, 240)
      Me.cmdOK.Name = "cmdOK"
      Me.cmdOK.TabIndex = 0
      Me.cmdOK.Text = "OK"
      '
      'picsUAve
      '
      Me.picsUAve.Image = CType(resources.GetObject("picsUAve.Image"), System.Drawing.Bitmap)
      Me.picsUAve.Location = New System.Drawing.Point(8, 8)
      Me.picsUAve.Name = "picsUAve"
      Me.picsUAve.Size = New System.Drawing.Size(156, 250)
      Me.picsUAve.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
      Me.picsUAve.TabIndex = 1
      Me.picsUAve.TabStop = False
      '
      'lblsUAve
      '
      Me.lblsUAve.Location = New System.Drawing.Point(176, 8)
      Me.lblsUAve.Name = "lblsUAve"
      Me.lblsUAve.Size = New System.Drawing.Size(100, 56)
      Me.lblsUAve.TabIndex = 2
      '
      'frmAbout
      '
      Me.AcceptButton = Me.cmdOK
      Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
      Me.CancelButton = Me.cmdOK
      Me.ClientSize = New System.Drawing.Size(292, 273)
      Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.lblsUAve, Me.picsUAve, Me.cmdOK})
      Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
      Me.MaximizeBox = False
      Me.MinimizeBox = False
      Me.Name = "frmAbout"
      Me.ShowInTaskbar = False
      Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
      Me.Text = "About sUAve"
      Me.ResumeLayout(False)

   End Sub

#End Region

End Class
