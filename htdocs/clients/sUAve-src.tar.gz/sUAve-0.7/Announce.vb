Imports RichControl

Public Class Announce
   Implements RichControl.RichImage

   Public m_iType As Integer
   Public m_iID As Integer
   Public m_iValue As Integer
   Private m_sString As String
   Private m_iImageIndex As Integer

   Public Sub New(ByVal iType As Integer, ByVal iID As Integer, ByVal iValue As Integer, ByVal sString As String, ByVal iImageIndex As Integer)
      m_iType = iType
      m_iID = iID
      m_iValue = iValue

      m_sString = sString
      m_iImageIndex = iImageIndex
   End Sub

   Public Sub New(ByVal sString As String)
      m_iType = 0
      m_iID = 0
      m_iValue = 0

      m_sString = sString
      m_iImageIndex = -1
   End Sub

   Public Overrides Function toString() As String
      Return m_sString
   End Function

   Public Property ImageIndex() As Integer Implements RichImage.ImageIndex
      Get
         Return m_iImageIndex
      End Get
      Set(ByVal Value As Integer)
         m_iImageIndex = Value
         'Console.WriteLine("Announce::ImageIndex " & m_iImageIndex)
      End Set
   End Property

   Public Property SelectedImageIndex() As Integer Implements RichImage.SelectedImageIndex
      Get
         Return -1
      End Get
      Set(ByVal Value As Integer)

      End Set
   End Property
End Class
