Public Class frmInput
   Inherits System.Windows.Forms.Form

   Public Shared TXT_INPUT = 1, CMB_INPUT = 2, RCB_INPUT = 4
   Public Shared CMB_TYPE = 8

   Private m_iType As Integer

#Region " Windows Form Designer generated code "

   Public Sub New(ByVal sTitle As String, ByVal iType As Integer, ByVal sInput As String, Optional ByVal iMaxLen As Integer = -1)
      MyBase.New()

      'This call is required by the Windows Form Designer.
      InitializeComponent()

      'Add any initialization after the InitializeComponent() call
      sUAveFont(Me)
      If Not UnicodeFont() Is Nothing Then
         rcbInput.Font = UnicodeFont()
         cmbInput.Font = UnicodeFont()
         txtInput.Font = UnicodeFont()
      End If

      FormAdd(Me)

      Me.Text = sTitle

      m_iType = iType

      lblInput.Text = sInput

      If mask(m_iType, TXT_INPUT) = True Then
         txtInput.Visible = True
      ElseIf mask(m_iType, CMB_INPUT) = True Then
         cmbInput.Visible = True
      ElseIf mask(m_iType, RCB_INPUT) = True Then
         rcbInput.Visible = True
      End If

      If mask(m_iType, CMB_TYPE) = True Then
         lblType.Visible = True
         cmbType.Visible = True
      End If

      If iMaxLen <> -1 Then
         txtInput.MaxLength = iMaxLen
      End If
   End Sub

   'Form overrides dispose to clean up the component list.
   Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
      If disposing Then
         FormRemove(Me)

         If Not (components Is Nothing) Then
            components.Dispose()
         End If
      End If
      MyBase.Dispose(disposing)
   End Sub

   'Required by the Windows Form Designer
   Private components As System.ComponentModel.IContainer

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   Friend WithEvents lblInput As System.Windows.Forms.Label
   Friend WithEvents txtInput As System.Windows.Forms.TextBox
   Friend WithEvents cmbInput As System.Windows.Forms.ComboBox
   Friend WithEvents rcbInput As RichControl.RichComboBox
   Friend WithEvents cmdOK As System.Windows.Forms.Button
   Friend WithEvents cmdCancel As System.Windows.Forms.Button
   Friend WithEvents PageSetupDialog1 As System.Windows.Forms.PageSetupDialog
   Friend WithEvents lblType As System.Windows.Forms.Label
   Friend WithEvents cmbType As System.Windows.Forms.ComboBox
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Me.rcbInput = New RichControl.RichComboBox()
      Me.cmdCancel = New System.Windows.Forms.Button()
      Me.cmdOK = New System.Windows.Forms.Button()
      Me.txtInput = New System.Windows.Forms.TextBox()
      Me.lblInput = New System.Windows.Forms.Label()
      Me.cmbInput = New System.Windows.Forms.ComboBox()
      Me.PageSetupDialog1 = New System.Windows.Forms.PageSetupDialog()
      Me.lblType = New System.Windows.Forms.Label()
      Me.cmbType = New System.Windows.Forms.ComboBox()
      Me.SuspendLayout()
      '
      'rcbInput
      '
      Me.rcbInput.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
      Me.rcbInput.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
      Me.rcbInput.DropDownWidth = 121
      Me.rcbInput.ImageList = Nothing
      Me.rcbInput.Location = New System.Drawing.Point(72, 8)
      Me.rcbInput.Name = "rcbInput"
      Me.rcbInput.Size = New System.Drawing.Size(121, 21)
      Me.rcbInput.Sorted = True
      Me.rcbInput.TabIndex = 3
      Me.rcbInput.Visible = False
      '
      'cmdCancel
      '
      Me.cmdCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
      Me.cmdCancel.FlatStyle = System.Windows.Forms.FlatStyle.System
      Me.cmdCancel.Location = New System.Drawing.Point(136, 64)
      Me.cmdCancel.Name = "cmdCancel"
      Me.cmdCancel.Size = New System.Drawing.Size(56, 23)
      Me.cmdCancel.TabIndex = 7
      Me.cmdCancel.Text = "Cancel"
      '
      'cmdOK
      '
      Me.cmdOK.FlatStyle = System.Windows.Forms.FlatStyle.System
      Me.cmdOK.Location = New System.Drawing.Point(72, 64)
      Me.cmdOK.Name = "cmdOK"
      Me.cmdOK.Size = New System.Drawing.Size(56, 23)
      Me.cmdOK.TabIndex = 6
      Me.cmdOK.Text = "OK"
      '
      'txtInput
      '
      Me.txtInput.Location = New System.Drawing.Point(72, 8)
      Me.txtInput.Name = "txtInput"
      Me.txtInput.Size = New System.Drawing.Size(120, 20)
      Me.txtInput.TabIndex = 1
      Me.txtInput.Text = ""
      Me.txtInput.Visible = False
      '
      'lblInput
      '
      Me.lblInput.Location = New System.Drawing.Point(8, 8)
      Me.lblInput.Name = "lblInput"
      Me.lblInput.Size = New System.Drawing.Size(64, 23)
      Me.lblInput.TabIndex = 0
      Me.lblInput.Text = "Input"
      '
      'cmbInput
      '
      Me.cmbInput.DropDownWidth = 121
      Me.cmbInput.Location = New System.Drawing.Point(72, 8)
      Me.cmbInput.Name = "cmbInput"
      Me.cmbInput.Size = New System.Drawing.Size(121, 21)
      Me.cmbInput.TabIndex = 2
      Me.cmbInput.Visible = False
      '
      'lblType
      '
      Me.lblType.Location = New System.Drawing.Point(8, 32)
      Me.lblType.Name = "lblType"
      Me.lblType.Size = New System.Drawing.Size(48, 23)
      Me.lblType.TabIndex = 4
      Me.lblType.Text = "Type"
      Me.lblType.Visible = False
      '
      'cmbType
      '
      Me.cmbType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
      Me.cmbType.Location = New System.Drawing.Point(72, 32)
      Me.cmbType.Name = "cmbType"
      Me.cmbType.Size = New System.Drawing.Size(121, 21)
      Me.cmbType.TabIndex = 5
      Me.cmbType.Visible = False
      '
      'frmInput
      '
      Me.AcceptButton = Me.cmdOK
      Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
      Me.CancelButton = Me.cmdCancel
      Me.ClientSize = New System.Drawing.Size(202, 95)
      Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.cmbType, Me.lblType, Me.cmdCancel, Me.cmdOK, Me.rcbInput, Me.cmbInput, Me.txtInput, Me.lblInput})
      Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
      Me.MaximizeBox = False
      Me.MinimizeBox = False
      Me.Name = "frmInput"
      Me.ShowInTaskbar = False
      Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
      Me.Text = "Input"
      Me.ResumeLayout(False)

   End Sub

#End Region

   Public Function GetValue() As String
      If mask(m_iType, TXT_INPUT) = True Then
         Return txtInput.Text
      ElseIf mask(m_iType, CMB_INPUT) = True Then
         Return cmbInput.Text
      End If

      Return Nothing
   End Function

   Public Function GetItem() As Lookup
      Return rcbInput.SelectedItem
   End Function

   Public Sub BeginAddItems()
      rcbInput.BeginUpdate()
   End Sub

   Public Function AddItem(ByRef pLookup As Lookup) As Boolean
      If mask(m_iType, RCB_INPUT) = True Then
         rcbInput.Items.Add(pLookup)

         Return True
      End If

      Return False
   End Function

   Public Sub EndAddItems()
      rcbInput.EndUpdate()
   End Sub

   Public Function AddType(ByRef pObject As Object) As Boolean
      If mask(m_iType, CMB_TYPE) = True Then
         cmbType.Items.Add(pObject)

         If cmbType.SelectedItem = Nothing Then
            cmbType.SelectedIndex = 0
         End If

         Return True
      End If

      Return False
   End Function

   Public Function GetTypeIndex() As Integer
      Return cmbType.SelectedIndex
   End Function

   Private Sub cmdOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdOK.Click
      Me.DialogResult = DialogResult.OK
   End Sub

   Private Sub lblType_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lblType.Click

   End Sub
End Class
