Imports org.ua2

Public Class frmLocations
   Inherits System.Windows.Forms.Form

   Private m_pLocationList As CEDF
   Private m_iLocationID As Integer

   Private Shared m_pForm As Form

#Region " Windows Form Designer generated code "

   Public Sub New(ByRef pLocations As CEDF)
      MyBase.New()

      'This call is required by the Windows Form Designer.
      InitializeComponent()

      'Add any initialization after the InitializeComponent() call
      sUAveFont(Me)
      m_pForm = FormAdd(Me)

      m_pLocationList = pLocations

      tvwLocations.Sorted = chkSortByName.Checked

      ShowLocations(m_pLocationList, Nothing)

      tvwLocations.SelectedNode = Nothing
   End Sub

   'Form overrides dispose to clean up the component list.
   Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
      If disposing Then
         FormRemove(Me)
         m_pForm = Nothing

         If Not (components Is Nothing) Then
            components.Dispose()
         End If
      End If
      MyBase.Dispose(disposing)
   End Sub

   Friend WithEvents splLocations As System.Windows.Forms.Splitter
   Friend WithEvents chkSortByName As System.Windows.Forms.CheckBox
   Friend WithEvents pnlLocation As System.Windows.Forms.Panel
   Friend WithEvents tvwLocations As System.Windows.Forms.TreeView
   Friend WithEvents lblName As System.Windows.Forms.Label
   Friend WithEvents txtName As System.Windows.Forms.TextBox
   Friend WithEvents txtMatch As System.Windows.Forms.TextBox
   Friend WithEvents cmdAdd As System.Windows.Forms.Button
   Friend WithEvents lstMatches As System.Windows.Forms.ListBox
   Friend WithEvents cmdRemove As System.Windows.Forms.Button
   Friend WithEvents lbUses As System.Windows.Forms.Label
   Friend WithEvents txtUses As System.Windows.Forms.TextBox
   Friend WithEvents cmdClose As System.Windows.Forms.Button
   Friend WithEvents lblLocation As System.Windows.Forms.Label

   'Required by the Windows Form Designer
   Private components As System.ComponentModel.IContainer

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmLocations))
      Me.lstMatches = New System.Windows.Forms.ListBox()
      Me.txtMatch = New System.Windows.Forms.TextBox()
      Me.txtUses = New System.Windows.Forms.TextBox()
      Me.lblLocation = New System.Windows.Forms.Label()
      Me.lblName = New System.Windows.Forms.Label()
      Me.cmdAdd = New System.Windows.Forms.Button()
      Me.lbUses = New System.Windows.Forms.Label()
      Me.chkSortByName = New System.Windows.Forms.CheckBox()
      Me.splLocations = New System.Windows.Forms.Splitter()
      Me.pnlLocation = New System.Windows.Forms.Panel()
      Me.cmdClose = New System.Windows.Forms.Button()
      Me.cmdRemove = New System.Windows.Forms.Button()
      Me.txtName = New System.Windows.Forms.TextBox()
      Me.tvwLocations = New System.Windows.Forms.TreeView()
      Me.pnlLocation.SuspendLayout()
      Me.SuspendLayout()
      '
      'lstMatches
      '
      Me.lstMatches.Location = New System.Drawing.Point(8, 112)
      Me.lstMatches.Name = "lstMatches"
      Me.lstMatches.Size = New System.Drawing.Size(176, 95)
      Me.lstMatches.TabIndex = 5
      '
      'txtMatch
      '
      Me.txtMatch.Location = New System.Drawing.Point(8, 80)
      Me.txtMatch.Name = "txtMatch"
      Me.txtMatch.Size = New System.Drawing.Size(176, 20)
      Me.txtMatch.TabIndex = 3
      Me.txtMatch.Text = ""
      '
      'txtUses
      '
      Me.txtUses.Location = New System.Drawing.Point(48, 56)
      Me.txtUses.Name = "txtUses"
      Me.txtUses.Size = New System.Drawing.Size(200, 20)
      Me.txtUses.TabIndex = 8
      Me.txtUses.Text = ""
      '
      'lblLocation
      '
      Me.lblLocation.Location = New System.Drawing.Point(8, 0)
      Me.lblLocation.Name = "lblLocation"
      Me.lblLocation.TabIndex = 0
      Me.lblLocation.Text = "Location"
      '
      'lblName
      '
      Me.lblName.Location = New System.Drawing.Point(8, 24)
      Me.lblName.Name = "lblName"
      Me.lblName.Size = New System.Drawing.Size(40, 23)
      Me.lblName.TabIndex = 1
      Me.lblName.Text = "Name"
      '
      'cmdAdd
      '
      Me.cmdAdd.FlatStyle = System.Windows.Forms.FlatStyle.System
      Me.cmdAdd.Location = New System.Drawing.Point(192, 80)
      Me.cmdAdd.Name = "cmdAdd"
      Me.cmdAdd.Size = New System.Drawing.Size(56, 23)
      Me.cmdAdd.TabIndex = 4
      Me.cmdAdd.Text = "Add"
      '
      'lbUses
      '
      Me.lbUses.Location = New System.Drawing.Point(8, 56)
      Me.lbUses.Name = "lbUses"
      Me.lbUses.Size = New System.Drawing.Size(32, 23)
      Me.lbUses.TabIndex = 7
      Me.lbUses.Text = "Uses"
      '
      'chkSortByName
      '
      Me.chkSortByName.Checked = True
      Me.chkSortByName.CheckState = System.Windows.Forms.CheckState.Checked
      Me.chkSortByName.FlatStyle = System.Windows.Forms.FlatStyle.System
      Me.chkSortByName.Location = New System.Drawing.Point(8, 232)
      Me.chkSortByName.Name = "chkSortByName"
      Me.chkSortByName.TabIndex = 10
      Me.chkSortByName.Text = "Sort by name"
      '
      'splLocations
      '
      Me.splLocations.Dock = System.Windows.Forms.DockStyle.Right
      Me.splLocations.Location = New System.Drawing.Point(165, 8)
      Me.splLocations.Name = "splLocations"
      Me.splLocations.Size = New System.Drawing.Size(3, 257)
      Me.splLocations.TabIndex = 2
      Me.splLocations.TabStop = False
      '
      'pnlLocation
      '
      Me.pnlLocation.Controls.AddRange(New System.Windows.Forms.Control() {Me.chkSortByName, Me.cmdClose, Me.txtUses, Me.lbUses, Me.cmdRemove, Me.lstMatches, Me.cmdAdd, Me.txtMatch, Me.txtName, Me.lblName, Me.lblLocation})
      Me.pnlLocation.Dock = System.Windows.Forms.DockStyle.Right
      Me.pnlLocation.Location = New System.Drawing.Point(168, 8)
      Me.pnlLocation.Name = "pnlLocation"
      Me.pnlLocation.Size = New System.Drawing.Size(256, 257)
      Me.pnlLocation.TabIndex = 1
      '
      'cmdClose
      '
      Me.cmdClose.FlatStyle = System.Windows.Forms.FlatStyle.System
      Me.cmdClose.Location = New System.Drawing.Point(192, 232)
      Me.cmdClose.Name = "cmdClose"
      Me.cmdClose.Size = New System.Drawing.Size(56, 23)
      Me.cmdClose.TabIndex = 9
      Me.cmdClose.Text = "Close"
      '
      'cmdRemove
      '
      Me.cmdRemove.FlatStyle = System.Windows.Forms.FlatStyle.System
      Me.cmdRemove.Location = New System.Drawing.Point(192, 112)
      Me.cmdRemove.Name = "cmdRemove"
      Me.cmdRemove.Size = New System.Drawing.Size(56, 23)
      Me.cmdRemove.TabIndex = 6
      Me.cmdRemove.Text = "Remove"
      '
      'txtName
      '
      Me.txtName.Location = New System.Drawing.Point(48, 24)
      Me.txtName.Name = "txtName"
      Me.txtName.Size = New System.Drawing.Size(200, 20)
      Me.txtName.TabIndex = 2
      Me.txtName.Text = ""
      '
      'tvwLocations
      '
      Me.tvwLocations.Dock = System.Windows.Forms.DockStyle.Fill
      Me.tvwLocations.ImageIndex = -1
      Me.tvwLocations.Indent = 15
      Me.tvwLocations.Location = New System.Drawing.Point(8, 8)
      Me.tvwLocations.Name = "tvwLocations"
      Me.tvwLocations.SelectedImageIndex = -1
      Me.tvwLocations.Size = New System.Drawing.Size(157, 257)
      Me.tvwLocations.TabIndex = 0
      '
      'frmLocations
      '
      Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
      Me.ClientSize = New System.Drawing.Size(424, 273)
      Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.tvwLocations, Me.splLocations, Me.pnlLocation})
      Me.DockPadding.Bottom = 8
      Me.DockPadding.Left = 8
      Me.DockPadding.Top = 8
      Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
      Me.MaximizeBox = False
      Me.MinimizeBox = False
      Me.Name = "frmLocations"
      Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
      Me.Text = "Locations"
      Me.pnlLocation.ResumeLayout(False)
      Me.ResumeLayout(False)

   End Sub

#End Region

   Private Sub ShowLocations(ByRef pLocations As CEDF, ByRef pParent As TreeNode)
      Dim iLocationID As Integer
      Dim bLoop As Boolean
      Dim sName As String
      Dim pNode As TreeNode

      tvwLocations.BeginUpdate()

      bLoop = pLocations.Child("location")
      Do While bLoop = True
         iLocationID = pLocations.GetInt()
         sName = pLocations.GetChildStr("name")

         pNode = New TreeNode(sName)
         pNode.Tag = iLocationID

         If Not pParent Is Nothing Then
            pParent.Nodes.Add(pNode)
         Else
            tvwLocations.Nodes.Add(pNode)
         End If

         ShowLocations(pLocations, pNode)

         pNode.Expand()

         bLoop = pLocations.Next("location")
         If bLoop = False Then
            pLocations.Parent()
         End If
      Loop

      tvwLocations.SelectedNode = Nothing

      tvwLocations.EndUpdate()
   End Sub

   Private Sub ShowLocation(ByRef pLocation As CEDF)
      Dim iNumUses As Integer, iLastUse As Integer
      Dim bLoop As Boolean
      Dim sName As String

      m_iLocationID = pLocation.GetInt()
      sName = pLocation.GetChildStr("name")
      iNumUses = pLocation.GetChildInt("totaluses")
      iLastUse = pLocation.GetChildInt("lastuse")

      lblLocation.Text = "Location " & m_iLocationID
      txtName.Text = sName

      txtUses.Text = iNumUses
      If iLastUse > 0 Then
         txtUses.Text &= " (last at " & StrTime(STRTIME_SHORT, iLastUse) & ")"
      End If

      lstMatches.Items.Clear()

      bLoop = pLocation.Child()
      Do While bLoop = True
         If pLocation.GetName() = "address" Or pLocation.GetName() = "hostname" Then
            lstMatches.Items.Add(pLocation.GetStr())
         End If

         bLoop = pLocation.Next()
         If bLoop = False Then
            pLocation.Parent()
         End If
      Loop
   End Sub

   Private Sub cmdClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdClose.Click
      Me.Dispose()
   End Sub

   Private Sub tvwLocations_AfterSelect(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles tvwLocations.AfterSelect
      Dim iLocationID As Integer
      Dim pRequest As CEDF, pReply As CEDF

      iLocationID = tvwLocations.SelectedNode.Tag

      pRequest = New CEDF()
      pRequest.AddChild("locationid", iLocationID)

      pReply = New CEDF()

      Client.request3(ua.MSG_LOCATION_LIST, pRequest, pReply)

      If pReply.Child("location") = True Then
         ShowLocation(pReply)
      Else
         pReply.MsgPrint("frmLocations::tvwLocations error")
      End If

      txtMatch.Text = ""
   End Sub

   Private Sub cmdAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdAdd.Click
      If txtMatch.Text <> "" Then
         If LocationOp(1, txtMatch.Text) = True Then
            lstMatches.Items.Add(txtMatch.Text)
         End If
      End If
   End Sub

   Private Sub cmdRemove_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdRemove.Click
      If lstMatches.SelectedIndex >= 0 Then
         If LocationOp(2, lstMatches.SelectedItem()) = True Then
            lstMatches.Items.Remove(lstMatches.SelectedItem)
         End If
      End If
   End Sub

   Private Function LocationOp(ByVal iOp As Integer, ByVal sText As String) As Boolean
      Dim pRequest As CEDF, pReply As CEDF

      pRequest = New CEDF()

      pRequest.AddChild("locationid", m_iLocationID)

      If iOp = 1 Then
         pRequest.Add("add")
      Else
         pRequest.Add("delete")
      End If

      If Char.IsDigit(sText, 1) = True Then
         pRequest.AddChild("address", sText)
      Else
         pRequest.AddChild("hostname", sText)
      End If

      pReply = New CEDF()

      Return Client.request3(ua.MSG_LOCATION_EDIT, pRequest, pReply)
   End Function

   Public Shared Function getForm() As Form
      Return m_pForm
   End Function
End Class
