Public Class frmLogin
   Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

   Public Sub New()
      MyBase.New()

      'This call is required by the Windows Form Designer.
      InitializeComponent()

      'Add any initialization after the InitializeComponent() call
      sUAveFont(Me)
   End Sub

   'Form overrides dispose to clean up the component list.
   Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
      If disposing Then
         If Not (components Is Nothing) Then
            components.Dispose()
         End If
      End If
      MyBase.Dispose(disposing)
   End Sub

   Friend WithEvents cmdConnect As System.Windows.Forms.Button
   Friend WithEvents cmdCancel As System.Windows.Forms.Button

   'Required by the Windows Form Designer
   Private components As System.ComponentModel.IContainer

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   Friend WithEvents tabLogin As System.Windows.Forms.TabControl
   Friend WithEvents tbpConnect As System.Windows.Forms.TabPage
   Friend WithEvents txtPort As System.Windows.Forms.TextBox
   Friend WithEvents chkSecure As System.Windows.Forms.CheckBox
   Friend WithEvents txtServer As System.Windows.Forms.TextBox
   Friend WithEvents lblServer As System.Windows.Forms.Label
   Friend WithEvents lblPort As System.Windows.Forms.Label
   Friend WithEvents lblUsername As System.Windows.Forms.Label
   Friend WithEvents txtPassword As System.Windows.Forms.TextBox
   Friend WithEvents lblPassword As System.Windows.Forms.Label
   Friend WithEvents txtUsername As System.Windows.Forms.TextBox
   Friend WithEvents chkBusy As System.Windows.Forms.CheckBox
   Friend WithEvents cmbAttachments As System.Windows.Forms.ComboBox
   Friend WithEvents lblAttachments As System.Windows.Forms.Label
   Friend WithEvents chkThinPipe As System.Windows.Forms.CheckBox
   Friend WithEvents txtBusy As System.Windows.Forms.TextBox
   Friend WithEvents tbcServices As System.Windows.Forms.TabPage
   Friend WithEvents txtEDF As System.Windows.Forms.TextBox
   Friend WithEvents tbpSettings As System.Windows.Forms.TabPage
   Friend WithEvents lblSessions As System.Windows.Forms.Label
   Friend WithEvents cmbSessions As System.Windows.Forms.ComboBox
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Me.cmdCancel = New System.Windows.Forms.Button()
      Me.cmdConnect = New System.Windows.Forms.Button()
      Me.tabLogin = New System.Windows.Forms.TabControl()
      Me.tbpConnect = New System.Windows.Forms.TabPage()
      Me.lblUsername = New System.Windows.Forms.Label()
      Me.txtPassword = New System.Windows.Forms.TextBox()
      Me.lblPassword = New System.Windows.Forms.Label()
      Me.txtUsername = New System.Windows.Forms.TextBox()
      Me.txtPort = New System.Windows.Forms.TextBox()
      Me.chkSecure = New System.Windows.Forms.CheckBox()
      Me.txtServer = New System.Windows.Forms.TextBox()
      Me.lblServer = New System.Windows.Forms.Label()
      Me.lblPort = New System.Windows.Forms.Label()
      Me.tbpSettings = New System.Windows.Forms.TabPage()
      Me.txtBusy = New System.Windows.Forms.TextBox()
      Me.chkBusy = New System.Windows.Forms.CheckBox()
      Me.cmbAttachments = New System.Windows.Forms.ComboBox()
      Me.lblAttachments = New System.Windows.Forms.Label()
      Me.chkThinPipe = New System.Windows.Forms.CheckBox()
      Me.tbcServices = New System.Windows.Forms.TabPage()
      Me.txtEDF = New System.Windows.Forms.TextBox()
      Me.lblSessions = New System.Windows.Forms.Label()
      Me.cmbSessions = New System.Windows.Forms.ComboBox()
      Me.tabLogin.SuspendLayout()
      Me.tbpConnect.SuspendLayout()
      Me.tbpSettings.SuspendLayout()
      Me.tbcServices.SuspendLayout()
      Me.SuspendLayout()
      '
      'cmdCancel
      '
      Me.cmdCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
      Me.cmdCancel.FlatStyle = System.Windows.Forms.FlatStyle.System
      Me.cmdCancel.Location = New System.Drawing.Point(128, 208)
      Me.cmdCancel.Name = "cmdCancel"
      Me.cmdCancel.TabIndex = 16
      Me.cmdCancel.Text = "Cancel"
      '
      'cmdConnect
      '
      Me.cmdConnect.FlatStyle = System.Windows.Forms.FlatStyle.System
      Me.cmdConnect.Location = New System.Drawing.Point(48, 208)
      Me.cmdConnect.Name = "cmdConnect"
      Me.cmdConnect.TabIndex = 15
      Me.cmdConnect.Text = "Connect"
      '
      'tabLogin
      '
      Me.tabLogin.Controls.AddRange(New System.Windows.Forms.Control() {Me.tbpConnect, Me.tbpSettings, Me.tbcServices})
      Me.tabLogin.Location = New System.Drawing.Point(8, 32)
      Me.tabLogin.Name = "tabLogin"
      Me.tabLogin.SelectedIndex = 0
      Me.tabLogin.Size = New System.Drawing.Size(192, 168)
      Me.tabLogin.TabIndex = 17
      '
      'tbpConnect
      '
      Me.tbpConnect.Controls.AddRange(New System.Windows.Forms.Control() {Me.lblUsername, Me.txtPassword, Me.lblPassword, Me.txtUsername, Me.txtPort, Me.chkSecure, Me.txtServer, Me.lblServer, Me.lblPort})
      Me.tbpConnect.Location = New System.Drawing.Point(4, 22)
      Me.tbpConnect.Name = "tbpConnect"
      Me.tbpConnect.Size = New System.Drawing.Size(184, 142)
      Me.tbpConnect.TabIndex = 0
      Me.tbpConnect.Text = "Connect"
      '
      'lblUsername
      '
      Me.lblUsername.Location = New System.Drawing.Point(8, 88)
      Me.lblUsername.Name = "lblUsername"
      Me.lblUsername.Size = New System.Drawing.Size(56, 16)
      Me.lblUsername.TabIndex = 10
      Me.lblUsername.Text = "Username"
      '
      'txtPassword
      '
      Me.txtPassword.Location = New System.Drawing.Point(72, 112)
      Me.txtPassword.Name = "txtPassword"
      Me.txtPassword.PasswordChar = Microsoft.VisualBasic.ChrW(42)
      Me.txtPassword.Size = New System.Drawing.Size(104, 20)
      Me.txtPassword.TabIndex = 13
      Me.txtPassword.Text = ""
      '
      'lblPassword
      '
      Me.lblPassword.Location = New System.Drawing.Point(8, 112)
      Me.lblPassword.Name = "lblPassword"
      Me.lblPassword.Size = New System.Drawing.Size(56, 16)
      Me.lblPassword.TabIndex = 12
      Me.lblPassword.Text = "Password"
      '
      'txtUsername
      '
      Me.txtUsername.Location = New System.Drawing.Point(72, 88)
      Me.txtUsername.Name = "txtUsername"
      Me.txtUsername.Size = New System.Drawing.Size(104, 20)
      Me.txtUsername.TabIndex = 11
      Me.txtUsername.Text = ""
      '
      'txtPort
      '
      Me.txtPort.Location = New System.Drawing.Point(72, 32)
      Me.txtPort.Name = "txtPort"
      Me.txtPort.Size = New System.Drawing.Size(104, 20)
      Me.txtPort.TabIndex = 8
      Me.txtPort.Text = ""
      '
      'chkSecure
      '
      Me.chkSecure.FlatStyle = System.Windows.Forms.FlatStyle.System
      Me.chkSecure.Location = New System.Drawing.Point(72, 56)
      Me.chkSecure.Name = "chkSecure"
      Me.chkSecure.Size = New System.Drawing.Size(56, 16)
      Me.chkSecure.TabIndex = 9
      Me.chkSecure.Text = "Secure"
      '
      'txtServer
      '
      Me.txtServer.Location = New System.Drawing.Point(72, 8)
      Me.txtServer.Name = "txtServer"
      Me.txtServer.Size = New System.Drawing.Size(104, 20)
      Me.txtServer.TabIndex = 6
      Me.txtServer.Text = ""
      '
      'lblServer
      '
      Me.lblServer.Location = New System.Drawing.Point(8, 8)
      Me.lblServer.Name = "lblServer"
      Me.lblServer.Size = New System.Drawing.Size(40, 16)
      Me.lblServer.TabIndex = 5
      Me.lblServer.Text = "Server"
      '
      'lblPort
      '
      Me.lblPort.Location = New System.Drawing.Point(8, 32)
      Me.lblPort.Name = "lblPort"
      Me.lblPort.Size = New System.Drawing.Size(32, 16)
      Me.lblPort.TabIndex = 7
      Me.lblPort.Text = "Port"
      '
      'tbpSettings
      '
      Me.tbpSettings.Controls.AddRange(New System.Windows.Forms.Control() {Me.txtBusy, Me.chkBusy, Me.cmbAttachments, Me.lblAttachments, Me.chkThinPipe})
      Me.tbpSettings.Location = New System.Drawing.Point(4, 22)
      Me.tbpSettings.Name = "tbpSettings"
      Me.tbpSettings.Size = New System.Drawing.Size(184, 142)
      Me.tbpSettings.TabIndex = 1
      Me.tbpSettings.Text = "Settings"
      '
      'txtBusy
      '
      Me.txtBusy.Location = New System.Drawing.Point(72, 80)
      Me.txtBusy.Name = "txtBusy"
      Me.txtBusy.Size = New System.Drawing.Size(104, 20)
      Me.txtBusy.TabIndex = 17
      Me.txtBusy.Text = ""
      '
      'chkBusy
      '
      Me.chkBusy.FlatStyle = System.Windows.Forms.FlatStyle.System
      Me.chkBusy.Location = New System.Drawing.Point(72, 64)
      Me.chkBusy.Name = "chkBusy"
      Me.chkBusy.Size = New System.Drawing.Size(48, 16)
      Me.chkBusy.TabIndex = 14
      Me.chkBusy.Text = "Busy"
      '
      'cmbAttachments
      '
      Me.cmbAttachments.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
      Me.cmbAttachments.DropDownWidth = 112
      Me.cmbAttachments.Items.AddRange(New Object() {"None", "Up to 10Kb", "Up to 100Kb", "Up to 1Mb", "Any size"})
      Me.cmbAttachments.Location = New System.Drawing.Point(72, 8)
      Me.cmbAttachments.Name = "cmbAttachments"
      Me.cmbAttachments.Size = New System.Drawing.Size(104, 21)
      Me.cmbAttachments.TabIndex = 16
      '
      'lblAttachments
      '
      Me.lblAttachments.Location = New System.Drawing.Point(8, 8)
      Me.lblAttachments.Name = "lblAttachments"
      Me.lblAttachments.Size = New System.Drawing.Size(72, 23)
      Me.lblAttachments.TabIndex = 15
      Me.lblAttachments.Text = "Attachments"
      '
      'chkThinPipe
      '
      Me.chkThinPipe.FlatStyle = System.Windows.Forms.FlatStyle.System
      Me.chkThinPipe.Location = New System.Drawing.Point(72, 40)
      Me.chkThinPipe.Name = "chkThinPipe"
      Me.chkThinPipe.Size = New System.Drawing.Size(64, 16)
      Me.chkThinPipe.TabIndex = 13
      Me.chkThinPipe.Text = "Thin pipe"
      '
      'tbcServices
      '
      Me.tbcServices.Controls.AddRange(New System.Windows.Forms.Control() {Me.txtEDF})
      Me.tbcServices.Location = New System.Drawing.Point(4, 22)
      Me.tbcServices.Name = "tbcServices"
      Me.tbcServices.Size = New System.Drawing.Size(184, 142)
      Me.tbcServices.TabIndex = 2
      Me.tbcServices.Text = "Services"
      '
      'txtEDF
      '
      Me.txtEDF.Location = New System.Drawing.Point(8, 8)
      Me.txtEDF.Multiline = True
      Me.txtEDF.Name = "txtEDF"
      Me.txtEDF.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
      Me.txtEDF.Size = New System.Drawing.Size(168, 128)
      Me.txtEDF.TabIndex = 14
      Me.txtEDF.Text = ""
      Me.txtEDF.WordWrap = False
      '
      'lblSessions
      '
      Me.lblSessions.Location = New System.Drawing.Point(8, 8)
      Me.lblSessions.Name = "lblSessions"
      Me.lblSessions.Size = New System.Drawing.Size(56, 16)
      Me.lblSessions.TabIndex = 18
      Me.lblSessions.Text = "Sessions"
      '
      'cmbSessions
      '
      Me.cmbSessions.Location = New System.Drawing.Point(64, 8)
      Me.cmbSessions.Name = "cmbSessions"
      Me.cmbSessions.Size = New System.Drawing.Size(136, 21)
      Me.cmbSessions.TabIndex = 19
      '
      'frmLogin
      '
      Me.AcceptButton = Me.cmdConnect
      Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
      Me.CancelButton = Me.cmdCancel
      Me.ClientSize = New System.Drawing.Size(210, 239)
      Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.cmbSessions, Me.lblSessions, Me.tabLogin, Me.cmdConnect, Me.cmdCancel})
      Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
      Me.MaximizeBox = False
      Me.MinimizeBox = False
      Me.Name = "frmLogin"
      Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
      Me.Text = "Login"
      Me.tabLogin.ResumeLayout(False)
      Me.tbpConnect.ResumeLayout(False)
      Me.tbpSettings.ResumeLayout(False)
      Me.tbcServices.ResumeLayout(False)
      Me.ResumeLayout(False)

   End Sub

#End Region

   Private Sub cmdConnect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdConnect.Click
      Me.DialogResult = DialogResult.OK
   End Sub
End Class
