Imports RichControl

Public Class Lookup
   Implements RichControl.RichImage, IComparable

   Public Const ANN_USER = 1, ANN_MESSAGE = 2, ANN_SERVICE = 4, CHANNEL_USER = 3, FOLDER_SUB = 5

   Public m_iType As Integer
   Public m_iID As Integer
   Public m_sValue As String
   Public m_iValue As Integer
   Public m_iImageIndex As Integer

   Public Sub New(ByVal sValue As String)
      m_iType = 0
      m_iID = 0
      m_sValue = sValue
      m_iValue = 0
      m_iImageIndex = -1
   End Sub

   Public Sub New(ByVal iType As Integer, ByVal iID As Integer, ByVal sValue As String)
      m_iType = iType
      m_iID = iID
      m_sValue = sValue
      m_iValue = 0
      m_iImageIndex = -1
   End Sub

   Public Sub New(ByVal iType As Integer, ByVal iID As Integer, ByVal iValue As Integer, ByVal sValue As String, Optional ByVal iImageIndex As Integer = -1)
      m_iType = iType
      m_iID = iID
      m_sValue = sValue
      m_iValue = iValue
      m_iImageIndex = iImageIndex
   End Sub

   Public Sub New(ByRef pLookup As Lookup)
      m_iType = pLookup.m_iType
      m_iID = pLookup.m_iID
      m_sValue = pLookup.m_sValue
      m_iValue = pLookup.m_iValue
      m_iImageIndex = pLookup.m_iImageIndex
   End Sub

   Public Overrides Function toString() As String
      Dim sReturn As String

      Select Case m_iType
         Case CHANNEL_USER
            If m_iValue = 1 Then
               sReturn &= "A "
            End If
            sReturn &= markup(m_sValue)

         Case FOLDER_SUB
            If m_iValue = ua.SUBTYPE_SUB Then
               sReturn = "S"
            ElseIf m_iValue = ua.SUBTYPE_MEMBER Then
               sReturn = "M"
            ElseIf m_iValue = ua.SUBTYPE_EDITOR Then
               sReturn = "E"
            End If

            sReturn &= " " & markup(m_sValue)

         Case Else
            'debugline("Lookup::toString " & m_iType & " -> " & sReturn)
            sReturn = m_sValue
      End Select

      Return sReturn
   End Function

   Public Property ImageIndex() As Integer Implements RichImage.ImageIndex
      Get
         Return m_iImageIndex
      End Get
      Set(ByVal Value As Integer)
         m_iImageIndex = Value
         'Console.WriteLine("Lookup::ImageIndex " & m_iImageIndex)
      End Set
   End Property

   Public Property SelectedImageIndex() As Integer Implements RichImage.SelectedImageIndex
      Get
         Return -1
      End Get
      Set(ByVal Value As Integer)

      End Set
   End Property

   Overridable Function CompareTo(ByVal obj As Object) As Integer Implements IComparable.CompareTo
      Dim pLookup As Lookup

      If m_sValue Is Nothing Then
         Return 0
      End If

      pLookup = obj

      'debugline("Lookup::CompareTo " & m_sValue & ", " & pLookup.m_sValue)

      Return m_sValue.CompareTo(pLookup.m_sValue)
   End Function
End Class
