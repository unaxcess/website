Imports org.ua2

Public Class frmMessage
   Inherits System.Windows.Forms.Form

   Private m_iMessageID As Integer, m_iFolderID As Integer
   Private m_iFromID As Integer
   Private m_sFromName As String
   Private m_sText As String
   Private m_pRequest As CEDF, m_pVote As CEDF

#Region " Windows Form Designer generated code "

   Public Sub New(ByRef pFolder As MessageTreeLookup, ByRef pMessage As CEDF)
      MyBase.New()

      'This call is required by the Windows Form Designer.
      InitializeComponent()

      'Add any initialization after the InitializeComponent() call
      Dim iFolderNum As Integer
      Dim pMessageTreeLookup As MessageTreeLookup, pItem As MessageTreeLookup
      'Dim pLookup As Lookup
      Dim dTick As DateTime

      sUAveFont(Me)
      If Not UnicodeFont() Is Nothing Then
         txtSubject.Font = UnicodeFont()
         txtText.Font = UnicodeFont()
      End If
      FormAdd(Me)

      rcbFolder.ImageList = sUAveHelper.m_pImageList
      tlbMessage.ImageList = sUAveHelper.m_pImageList

      dTick = gettick()
      rcbFolder.BeginUpdate()
      For iFolderNum = 0 To FolderCount() - 1
         pMessageTreeLookup = FolderList(iFolderNum)
         pItem = New MessageTreeLookup(pMessageTreeLookup)
         pItem.m_bMarkup = False

         rcbFolder.Items.Add(pItem)
      Next
      rcbFolder.EndUpdate()
      debugline("frmMessage::frmMessage rcbFolder populated in " & tickdiff(dTick) & " ms")

      SetData(pFolder, pMessage)
   End Sub

   'Form overrides dispose to clean up the component list.
   Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
      If disposing Then
         FormRemove(Me)

         If Not (components Is Nothing) Then
            components.Dispose()
         End If
      End If
      MyBase.Dispose(disposing)
   End Sub

   Friend WithEvents rcbFolder As RichControl.RichComboBox
   Friend WithEvents txtTo As System.Windows.Forms.TextBox
   Friend WithEvents splFromTo As System.Windows.Forms.Splitter
   Friend WithEvents pnlFill As System.Windows.Forms.Panel
   Friend WithEvents pnlTop As System.Windows.Forms.Panel
   Friend WithEvents txtText As System.Windows.Forms.TextBox
   Friend WithEvents lblFolder As System.Windows.Forms.Label
   Friend WithEvents lblCustomTo As System.Windows.Forms.Label
   Friend WithEvents txtSubject As System.Windows.Forms.TextBox
   Friend WithEvents txtCustomTo As System.Windows.Forms.TextBox
   Friend WithEvents lblSubject As System.Windows.Forms.Label
   Friend WithEvents lblTo As System.Windows.Forms.Label

   'Required by the Windows Form Designer
   Private components As System.ComponentModel.IContainer

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   Friend WithEvents pnlValues As System.Windows.Forms.Panel
   Friend WithEvents pnlFolder As System.Windows.Forms.Panel
   Friend WithEvents pnlTo As System.Windows.Forms.Panel
   Friend WithEvents pnlCustomTo As System.Windows.Forms.Panel
   Friend WithEvents pnlSubject As System.Windows.Forms.Panel
   Friend WithEvents pnlLabels As System.Windows.Forms.Panel
   Friend WithEvents mnuMessage As System.Windows.Forms.MainMenu
   Friend WithEvents mnuFile As System.Windows.Forms.MenuItem
   Friend WithEvents mnuFileSend As System.Windows.Forms.MenuItem
   Friend WithEvents mnuFileClose As System.Windows.Forms.MenuItem
   Friend WithEvents mnuView As System.Windows.Forms.MenuItem
   Friend WithEvents mnuViewFixed As System.Windows.Forms.MenuItem
   Friend WithEvents mnuViewUnicode As System.Windows.Forms.MenuItem
   Friend WithEvents mnuInsert As System.Windows.Forms.MenuItem
   Friend WithEvents mnuInsertFile As System.Windows.Forms.MenuItem
   Friend WithEvents mnuTools As System.Windows.Forms.MenuItem
   Friend WithEvents mnuToolsSpelling As System.Windows.Forms.MenuItem
   Friend WithEvents mnuInsertOriginal As System.Windows.Forms.MenuItem
   Friend WithEvents mnuInsertVote As System.Windows.Forms.MenuItem
   Friend WithEvents cmdCancel As System.Windows.Forms.Button
   Friend WithEvents tlbMessage As System.Windows.Forms.ToolBar
   Friend WithEvents tbbSend As System.Windows.Forms.ToolBarButton
   Friend WithEvents imlsUAve As System.Windows.Forms.ImageList
   Friend WithEvents tbbFileAttach As System.Windows.Forms.ToolBarButton
   Friend WithEvents tbbInsertOriginal As System.Windows.Forms.ToolBarButton
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Me.components = New System.ComponentModel.Container()
      Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmMessage))
      Me.rcbFolder = New RichControl.RichComboBox()
      Me.lblCustomTo = New System.Windows.Forms.Label()
      Me.txtText = New System.Windows.Forms.TextBox()
      Me.txtTo = New System.Windows.Forms.TextBox()
      Me.lblTo = New System.Windows.Forms.Label()
      Me.txtCustomTo = New System.Windows.Forms.TextBox()
      Me.lblFolder = New System.Windows.Forms.Label()
      Me.splFromTo = New System.Windows.Forms.Splitter()
      Me.pnlTop = New System.Windows.Forms.Panel()
      Me.pnlValues = New System.Windows.Forms.Panel()
      Me.pnlSubject = New System.Windows.Forms.Panel()
      Me.txtSubject = New System.Windows.Forms.TextBox()
      Me.pnlCustomTo = New System.Windows.Forms.Panel()
      Me.pnlTo = New System.Windows.Forms.Panel()
      Me.pnlFolder = New System.Windows.Forms.Panel()
      Me.pnlLabels = New System.Windows.Forms.Panel()
      Me.lblSubject = New System.Windows.Forms.Label()
      Me.pnlFill = New System.Windows.Forms.Panel()
      Me.mnuMessage = New System.Windows.Forms.MainMenu()
      Me.mnuFile = New System.Windows.Forms.MenuItem()
      Me.mnuFileSend = New System.Windows.Forms.MenuItem()
      Me.mnuFileClose = New System.Windows.Forms.MenuItem()
      Me.mnuView = New System.Windows.Forms.MenuItem()
      Me.mnuViewFixed = New System.Windows.Forms.MenuItem()
      Me.mnuViewUnicode = New System.Windows.Forms.MenuItem()
      Me.mnuInsert = New System.Windows.Forms.MenuItem()
      Me.mnuInsertFile = New System.Windows.Forms.MenuItem()
      Me.mnuInsertOriginal = New System.Windows.Forms.MenuItem()
      Me.mnuInsertVote = New System.Windows.Forms.MenuItem()
      Me.mnuTools = New System.Windows.Forms.MenuItem()
      Me.mnuToolsSpelling = New System.Windows.Forms.MenuItem()
      Me.cmdCancel = New System.Windows.Forms.Button()
      Me.tlbMessage = New System.Windows.Forms.ToolBar()
      Me.tbbSend = New System.Windows.Forms.ToolBarButton()
      Me.tbbFileAttach = New System.Windows.Forms.ToolBarButton()
      Me.tbbInsertOriginal = New System.Windows.Forms.ToolBarButton()
      Me.imlsUAve = New System.Windows.Forms.ImageList(Me.components)
      Me.pnlTop.SuspendLayout()
      Me.pnlValues.SuspendLayout()
      Me.pnlSubject.SuspendLayout()
      Me.pnlCustomTo.SuspendLayout()
      Me.pnlTo.SuspendLayout()
      Me.pnlFolder.SuspendLayout()
      Me.pnlLabels.SuspendLayout()
      Me.pnlFill.SuspendLayout()
      Me.SuspendLayout()
      '
      'rcbFolder
      '
      Me.rcbFolder.Dock = System.Windows.Forms.DockStyle.Fill
      Me.rcbFolder.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
      Me.rcbFolder.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
      Me.rcbFolder.DropDownWidth = 240
      Me.rcbFolder.ImageList = Nothing
      Me.rcbFolder.Name = "rcbFolder"
      Me.rcbFolder.Size = New System.Drawing.Size(238, 21)
      Me.rcbFolder.Sorted = True
      Me.rcbFolder.TabIndex = 0
      '
      'lblCustomTo
      '
      Me.lblCustomTo.Enabled = False
      Me.lblCustomTo.Location = New System.Drawing.Point(8, 60)
      Me.lblCustomTo.Name = "lblCustomTo"
      Me.lblCustomTo.Size = New System.Drawing.Size(64, 23)
      Me.lblCustomTo.TabIndex = 4
      Me.lblCustomTo.Text = "To (custom)"
      '
      'txtText
      '
      Me.txtText.AcceptsReturn = True
      Me.txtText.AcceptsTab = True
      Me.txtText.Dock = System.Windows.Forms.DockStyle.Fill
      Me.txtText.Location = New System.Drawing.Point(8, 8)
      Me.txtText.Multiline = True
      Me.txtText.Name = "txtText"
      Me.txtText.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
      Me.txtText.Size = New System.Drawing.Size(310, 212)
      Me.txtText.TabIndex = 0
      Me.txtText.Text = ""
      '
      'txtTo
      '
      Me.txtTo.Dock = System.Windows.Forms.DockStyle.Fill
      Me.txtTo.Name = "txtTo"
      Me.txtTo.Size = New System.Drawing.Size(238, 20)
      Me.txtTo.TabIndex = 1
      Me.txtTo.Text = ""
      '
      'lblTo
      '
      Me.lblTo.Location = New System.Drawing.Point(8, 36)
      Me.lblTo.Name = "lblTo"
      Me.lblTo.Size = New System.Drawing.Size(24, 23)
      Me.lblTo.TabIndex = 2
      Me.lblTo.Text = "To"
      '
      'txtCustomTo
      '
      Me.txtCustomTo.Dock = System.Windows.Forms.DockStyle.Fill
      Me.txtCustomTo.Enabled = False
      Me.txtCustomTo.Name = "txtCustomTo"
      Me.txtCustomTo.Size = New System.Drawing.Size(238, 20)
      Me.txtCustomTo.TabIndex = 2
      Me.txtCustomTo.Text = ""
      '
      'lblFolder
      '
      Me.lblFolder.Location = New System.Drawing.Point(8, 12)
      Me.lblFolder.Name = "lblFolder"
      Me.lblFolder.Size = New System.Drawing.Size(40, 23)
      Me.lblFolder.TabIndex = 0
      Me.lblFolder.Text = "Folder"
      '
      'splFromTo
      '
      Me.splFromTo.Dock = System.Windows.Forms.DockStyle.Top
      Me.splFromTo.Location = New System.Drawing.Point(3, 3)
      Me.splFromTo.Name = "splFromTo"
      Me.splFromTo.Size = New System.Drawing.Size(298, 3)
      Me.splFromTo.TabIndex = 3
      Me.splFromTo.TabStop = False
      '
      'pnlTop
      '
      Me.pnlTop.Controls.AddRange(New System.Windows.Forms.Control() {Me.pnlValues, Me.pnlLabels})
      Me.pnlTop.Dock = System.Windows.Forms.DockStyle.Top
      Me.pnlTop.Location = New System.Drawing.Point(0, 25)
      Me.pnlTop.Name = "pnlTop"
      Me.pnlTop.Size = New System.Drawing.Size(326, 112)
      Me.pnlTop.TabIndex = 0
      '
      'pnlValues
      '
      Me.pnlValues.Controls.AddRange(New System.Windows.Forms.Control() {Me.pnlSubject, Me.pnlCustomTo, Me.pnlTo, Me.pnlFolder})
      Me.pnlValues.Dock = System.Windows.Forms.DockStyle.Fill
      Me.pnlValues.DockPadding.All = 8
      Me.pnlValues.Location = New System.Drawing.Point(72, 0)
      Me.pnlValues.Name = "pnlValues"
      Me.pnlValues.Size = New System.Drawing.Size(254, 112)
      Me.pnlValues.TabIndex = 7
      '
      'pnlSubject
      '
      Me.pnlSubject.Controls.AddRange(New System.Windows.Forms.Control() {Me.txtSubject})
      Me.pnlSubject.Dock = System.Windows.Forms.DockStyle.Top
      Me.pnlSubject.Location = New System.Drawing.Point(8, 83)
      Me.pnlSubject.Name = "pnlSubject"
      Me.pnlSubject.Size = New System.Drawing.Size(238, 25)
      Me.pnlSubject.TabIndex = 3
      '
      'txtSubject
      '
      Me.txtSubject.Dock = System.Windows.Forms.DockStyle.Fill
      Me.txtSubject.Name = "txtSubject"
      Me.txtSubject.Size = New System.Drawing.Size(238, 20)
      Me.txtSubject.TabIndex = 3
      Me.txtSubject.Text = ""
      '
      'pnlCustomTo
      '
      Me.pnlCustomTo.Controls.AddRange(New System.Windows.Forms.Control() {Me.txtCustomTo})
      Me.pnlCustomTo.Dock = System.Windows.Forms.DockStyle.Top
      Me.pnlCustomTo.DockPadding.Bottom = 4
      Me.pnlCustomTo.Location = New System.Drawing.Point(8, 58)
      Me.pnlCustomTo.Name = "pnlCustomTo"
      Me.pnlCustomTo.Size = New System.Drawing.Size(238, 25)
      Me.pnlCustomTo.TabIndex = 2
      '
      'pnlTo
      '
      Me.pnlTo.Controls.AddRange(New System.Windows.Forms.Control() {Me.txtTo})
      Me.pnlTo.Dock = System.Windows.Forms.DockStyle.Top
      Me.pnlTo.DockPadding.Bottom = 4
      Me.pnlTo.Location = New System.Drawing.Point(8, 33)
      Me.pnlTo.Name = "pnlTo"
      Me.pnlTo.Size = New System.Drawing.Size(238, 25)
      Me.pnlTo.TabIndex = 1
      '
      'pnlFolder
      '
      Me.pnlFolder.Controls.AddRange(New System.Windows.Forms.Control() {Me.rcbFolder})
      Me.pnlFolder.Dock = System.Windows.Forms.DockStyle.Top
      Me.pnlFolder.DockPadding.Bottom = 4
      Me.pnlFolder.Location = New System.Drawing.Point(8, 8)
      Me.pnlFolder.Name = "pnlFolder"
      Me.pnlFolder.Size = New System.Drawing.Size(238, 25)
      Me.pnlFolder.TabIndex = 0
      '
      'pnlLabels
      '
      Me.pnlLabels.Controls.AddRange(New System.Windows.Forms.Control() {Me.lblSubject, Me.lblCustomTo, Me.lblTo, Me.lblFolder})
      Me.pnlLabels.Dock = System.Windows.Forms.DockStyle.Left
      Me.pnlLabels.Name = "pnlLabels"
      Me.pnlLabels.Size = New System.Drawing.Size(72, 112)
      Me.pnlLabels.TabIndex = 8
      '
      'lblSubject
      '
      Me.lblSubject.Location = New System.Drawing.Point(8, 84)
      Me.lblSubject.Name = "lblSubject"
      Me.lblSubject.Size = New System.Drawing.Size(48, 23)
      Me.lblSubject.TabIndex = 6
      Me.lblSubject.Text = "Subject"
      '
      'pnlFill
      '
      Me.pnlFill.Controls.AddRange(New System.Windows.Forms.Control() {Me.txtText})
      Me.pnlFill.Dock = System.Windows.Forms.DockStyle.Fill
      Me.pnlFill.DockPadding.All = 8
      Me.pnlFill.Location = New System.Drawing.Point(0, 137)
      Me.pnlFill.Name = "pnlFill"
      Me.pnlFill.Size = New System.Drawing.Size(326, 228)
      Me.pnlFill.TabIndex = 1
      '
      'mnuMessage
      '
      Me.mnuMessage.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuFile, Me.mnuView, Me.mnuInsert, Me.mnuTools})
      '
      'mnuFile
      '
      Me.mnuFile.Index = 0
      Me.mnuFile.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuFileSend, Me.mnuFileClose})
      Me.mnuFile.Text = "&File"
      '
      'mnuFileSend
      '
      Me.mnuFileSend.Enabled = False
      Me.mnuFileSend.Index = 0
      Me.mnuFileSend.Shortcut = System.Windows.Forms.Shortcut.CtrlS
      Me.mnuFileSend.Text = "&Send"
      '
      'mnuFileClose
      '
      Me.mnuFileClose.Index = 1
      Me.mnuFileClose.Text = "&Close"
      '
      'mnuView
      '
      Me.mnuView.Index = 1
      Me.mnuView.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuViewFixed, Me.mnuViewUnicode})
      Me.mnuView.Text = "&View"
      '
      'mnuViewFixed
      '
      Me.mnuViewFixed.Index = 0
      Me.mnuViewFixed.Text = "&Fixed font"
      '
      'mnuViewUnicode
      '
      Me.mnuViewUnicode.Index = 1
      Me.mnuViewUnicode.Text = "&Unicode"
      '
      'mnuInsert
      '
      Me.mnuInsert.Index = 2
      Me.mnuInsert.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuInsertFile, Me.mnuInsertOriginal, Me.mnuInsertVote})
      Me.mnuInsert.Text = "&Insert"
      '
      'mnuInsertFile
      '
      Me.mnuInsertFile.Index = 0
      Me.mnuInsertFile.Text = "&File attachment..."
      '
      'mnuInsertOriginal
      '
      Me.mnuInsertOriginal.Index = 1
      Me.mnuInsertOriginal.Text = "&Original text"
      Me.mnuInsertOriginal.Visible = False
      '
      'mnuInsertVote
      '
      Me.mnuInsertVote.Index = 2
      Me.mnuInsertVote.Text = "&Vote..."
      Me.mnuInsertVote.Visible = False
      '
      'mnuTools
      '
      Me.mnuTools.Index = 3
      Me.mnuTools.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuToolsSpelling})
      Me.mnuTools.Text = "&Tools"
      '
      'mnuToolsSpelling
      '
      Me.mnuToolsSpelling.Index = 0
      Me.mnuToolsSpelling.Shortcut = System.Windows.Forms.Shortcut.F7
      Me.mnuToolsSpelling.Text = "&Spelling..."
      '
      'cmdCancel
      '
      Me.cmdCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
      Me.cmdCancel.Name = "cmdCancel"
      Me.cmdCancel.Size = New System.Drawing.Size(0, 0)
      Me.cmdCancel.TabIndex = 2
      Me.cmdCancel.Text = "Cancel"
      '
      'tlbMessage
      '
      Me.tlbMessage.Appearance = System.Windows.Forms.ToolBarAppearance.Flat
      Me.tlbMessage.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.tbbSend, Me.tbbFileAttach, Me.tbbInsertOriginal})
      Me.tlbMessage.DropDownArrows = True
      Me.tlbMessage.ImageList = Me.imlsUAve
      Me.tlbMessage.Name = "tlbMessage"
      Me.tlbMessage.ShowToolTips = True
      Me.tlbMessage.Size = New System.Drawing.Size(326, 25)
      Me.tlbMessage.TabIndex = 3
      '
      'tbbSend
      '
      Me.tbbSend.Enabled = False
      Me.tbbSend.ImageIndex = 6
      Me.tbbSend.ToolTipText = "Send"
      '
      'tbbFileAttach
      '
      Me.tbbFileAttach.ImageIndex = 12
      Me.tbbFileAttach.ToolTipText = "File Attachment"
      '
      'tbbInsertOriginal
      '
      Me.tbbInsertOriginal.Enabled = False
      Me.tbbInsertOriginal.ImageIndex = 14
      Me.tbbInsertOriginal.ToolTipText = "Insert original text"
      '
      'imlsUAve
      '
      Me.imlsUAve.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit
      Me.imlsUAve.ImageSize = New System.Drawing.Size(16, 16)
      Me.imlsUAve.ImageStream = CType(resources.GetObject("imlsUAve.ImageStream"), System.Windows.Forms.ImageListStreamer)
      Me.imlsUAve.TransparentColor = System.Drawing.Color.Transparent
      '
      'frmMessage
      '
      Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
      Me.CancelButton = Me.cmdCancel
      Me.ClientSize = New System.Drawing.Size(326, 365)
      Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.pnlFill, Me.pnlTop, Me.tlbMessage, Me.cmdCancel})
      Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
      Me.MaximizeBox = False
      Me.Menu = Me.mnuMessage
      Me.MinimizeBox = False
      Me.Name = "frmMessage"
      Me.ShowInTaskbar = False
      Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
      Me.Text = "Message"
      Me.pnlTop.ResumeLayout(False)
      Me.pnlValues.ResumeLayout(False)
      Me.pnlSubject.ResumeLayout(False)
      Me.pnlCustomTo.ResumeLayout(False)
      Me.pnlTo.ResumeLayout(False)
      Me.pnlFolder.ResumeLayout(False)
      Me.pnlLabels.ResumeLayout(False)
      Me.pnlFill.ResumeLayout(False)
      Me.ResumeLayout(False)

   End Sub

#End Region

   Private Sub SetData(ByRef pFolder As MessageTreeLookup, ByRef pMessage As CEDF)
      Dim iFolderID As Integer, iLookupNum As Integer
      Dim bFound As Boolean
      Dim sSubject As String
      Dim pLookup As Lookup

      If Not pFolder Is Nothing Then
         'MsgBox("frmMessage::SetData " & pFolder.m_iID & " " & pFolder.m_sValue)

         iFolderID = pFolder.m_iID

         SetFolder(pFolder)
      ElseIf Client.GetAccessLevel >= ua.LEVEL_WITNESS Then
         mnuInsertVote.Visible = True
      End If

      If Not pMessage Is Nothing Then
         'pMessage.MsgPrint("frmMessage::SetData")

         m_iMessageID = pMessage.GetInt()
         'iFolderID = pMessage.GetChildInt("folderid")
         m_iFromID = pMessage.GetChildInt("fromid")
         m_sFromName = pMessage.GetChildStr("fromname")
         sSubject = TextDecode(pMessage.GetChildStr("subject"))

         m_sText = TextDecode(pMessage.GetChildStr("text"))
         If Not m_sText Is Nothing Then
            mnuInsertOriginal.Visible = True
            tbbInsertOriginal.Enabled = True
         End If

         txtText.Focus()
      Else
         txtTo.Focus()
      End If

      m_iFolderID = iFolderID

      If iFolderID > 0 Then
         iLookupNum = 0
         bFound = False
         Do While bFound = False And iLookupNum < rcbFolder.Items.Count
            pLookup = rcbFolder.Items(iLookupNum)
            If pLookup.m_iID = iFolderID Then
               rcbFolder.SelectedIndex = iLookupNum
               bFound = True
            Else
               iLookupNum += 1
            End If
         Loop
      End If

      If Not m_sFromName Is Nothing Then
         txtTo.Text = m_sFromName
      End If

      If Not sSubject Is Nothing Then
         txtSubject.Text = sSubject
      End If
   End Sub

   Private Sub SetFolder(ByVal pFolder As MessageTreeLookup)
      mnuFileSend.Enabled = True
      tbbSend.Enabled = True

      If Client.GetAccessLevel() >= ua.LEVEL_WITNESS Or pFolder.m_iSubType = ua.SUBTYPE_EDITOR Then
         mnuInsertVote.Visible = True
      Else
         mnuInsertVote.Visible = False
      End If
   End Sub

   Public Function GetRequest() As CEDF
      Dim iLookupNum As Integer
      Dim bFound As Boolean
      Dim pSubject() As Byte, pText() As Byte
      Dim pLookup As Lookup
      Dim pUser As UserLookup

      If m_pRequest Is Nothing Then
         m_pRequest = New CEDF()
      End If

      If m_iMessageID > 0 Then
         m_pRequest.AddChild("replyid", m_iMessageID)
      End If

      pLookup = rcbFolder.SelectedItem
      If Not pLookup Is Nothing Then
         If pLookup.m_iID <> m_iFolderID Or m_iMessageID = 0 Then
            m_pRequest.AddChild("folderid", pLookup.m_iID)
         End If
      End If

      If m_sFromName = txtTo.Text And m_iFromID > 0 Then
         'm_pRequest.AddChild("toid", m_iFromID)
      End If

      If txtTo.Text <> "" Then
         pUser = UserGet(txtTo.Text)
         If Not pUser Is Nothing Then
            m_pRequest.AddChild("toid", pUser.m_iID)
         Else
            m_pRequest.AddChild("toname", txtTo.Text)
         End If
      End If

      If txtCustomTo.Text <> "" Then
         m_pRequest.AddChild("toname", txtCustomTo.Text)
      End If

      AddTextField(m_pRequest, "subject", txtSubject.Text)

      AddTextField(m_pRequest, "text", txtText.Text)

      If Not m_pVote Is Nothing Then
         m_pVote.MsgPrint("frmMessage::GetRequest vote")
         m_pRequest.Copy(m_pVote, False, False, True)
      End If

      'm_pRequest.MsgPrint("frmMessage::GetRequest")

      Return m_pRequest
   End Function

   Private Sub mnuViewFixed_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuViewFixed.Click
      mnuViewFixed.Checked = Not mnuViewFixed.Checked

      If mnuViewFixed.Checked = True Then
         mnuViewUnicode.Checked = False
         txtText.Font = FixedFont()
      Else
         txtText.Font = Me.Font
      End If
   End Sub

   Private Sub mnuViewUnicode_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuViewUnicode.Click
      mnuViewUnicode.Checked = Not mnuViewUnicode.Checked

      If mnuViewUnicode.Checked = True Then
         mnuViewFixed.Checked = False
         txtText.Font = FixedFont()
      Else
         txtText.Font = Me.Font
      End If
   End Sub

   Private Sub mnuFileClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuFileClose.Click
      Me.Close()
   End Sub

   Private Sub mnuFileSend_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuFileSend.Click
      If mnuFileSend.Enabled = True Then
         Me.DialogResult = DialogResult.OK
      End If
   End Sub

   Private Sub mnuInsertOriginal_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuInsertOriginal.Click
      Dim sText As String

      sText = m_sText
      If sText.Length > 0 Then
         If sText.Chars(0) <> Chr(13) Then
            sText = "> " & sText
         End If

         sText = sText.Replace(CRLF, CRLF & "> ")

         txtText.Text = sText & CRLF & CRLF & txtText.Text
      End If
   End Sub

   Private Sub mnuInsertFile_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuInsertFile.Click
      OpenAttachments(m_pRequest)
   End Sub

   Private Sub mnuToolsSpelling_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuToolsSpelling.Click
      txtText.Text = SpellCheck(txtText.Text)
   End Sub

   Private Sub rcbFolder_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rcbFolder.SelectedIndexChanged
      SetFolder(rcbFolder.SelectedItem)
   End Sub

   Private Sub frmMessage_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
      If Me.DialogResult <> DialogResult.OK Then
         If AbortEdit() = True Then
            Me.DialogResult = DialogResult.Cancel
         Else
            Me.DialogResult = 0
         End If
      End If
   End Sub

   Private Sub tlbMessage_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles tlbMessage.ButtonClick
      If e.Button Is tbbSend Then
         mnuFileSend_Click(sender, e)
      ElseIf e.Button Is tbbFileAttach Then
         mnuInsertFile_Click(sender, e)
      ElseIf e.Button Is tbbInsertOriginal Then
         mnuInsertOriginal_Click(sender, e)
      End If
   End Sub

   Private Sub mnuInsertVote_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuInsertVote.Click
      Dim pVote As frmVote

      pVote = New frmVote(m_pVote)

      If pVote.ShowDialog() = DialogResult.OK Then
         m_pVote = pVote.GetRequest()

         Me.Text = "Poll"
      Else
         If Not m_pVote Is Nothing And MsgBox("Remove voting options", MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2) = MsgBoxResult.Yes Then
            m_pVote = Nothing

            Me.Text = "Message"
         Else
            Me.Text = "Poll"
         End If
      End If
   End Sub
End Class
