Public Class MessageLookup
   Inherits Lookup

   Public m_sFromName As String
   Public m_sSubject As String

   Public Sub New(ByVal iMessageID As Integer, ByVal sFolderName As String, ByVal sFromName As String, ByVal sSubject As String, ByVal iRead As Integer)
      MyBase.New(0, iMessageID, iRead, sFolderName)

      m_sFromName = sFromName
      m_sSubject = sSubject
   End Sub

   Public Overrides Function toString() As String
      Dim sReturn As String

      sReturn = m_sSubject

      Return sReturn
   End Function
End Class
