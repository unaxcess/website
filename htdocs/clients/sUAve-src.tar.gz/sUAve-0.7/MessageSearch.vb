Imports org.ua2

Public Class frmMessageSearch
   Inherits System.Windows.Forms.Form

   Dim m_pMessages As CEDF

   Private Shared m_pForm As Form

#Region " Windows Form Designer generated code "

   Public Sub New(ByVal iFolderID As Integer, ByVal bFreeForm As Boolean)
      MyBase.New()

      'This call is required by the Windows Form Designer.
      InitializeComponent()

      'Add any initialization after the InitializeComponent() call
      sUAveFont(Me)
      m_pForm = FormAdd(Me)

      chkFreeForm.Checked = bFreeForm

      SetData(iFolderID)
   End Sub

   'Form overrides dispose to clean up the component list.
   Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
      If disposing Then
         FormRemove(Me)
         m_pForm = Nothing

         If Not (components Is Nothing) Then
            components.Dispose()
         End If
      End If
      MyBase.Dispose(disposing)
   End Sub

   Friend WithEvents cmdClose As System.Windows.Forms.Button

   'Required by the Windows Form Designer
   Private components As System.ComponentModel.IContainer

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   Friend WithEvents lvwMessages As System.Windows.Forms.ListView
   Friend WithEvents cmdSearch As System.Windows.Forms.Button
   Friend WithEvents lblFrom As System.Windows.Forms.Label
   Friend WithEvents txtKeyword As System.Windows.Forms.TextBox
   Friend WithEvents chkFullHeaders As System.Windows.Forms.CheckBox
   Friend WithEvents pnlTop As System.Windows.Forms.Panel
   Friend WithEvents pnlSearch As System.Windows.Forms.Panel
   Friend WithEvents pnlBottom As System.Windows.Forms.Panel
   Friend WithEvents pnlClose As System.Windows.Forms.Panel
   Friend WithEvents pnlMessages As System.Windows.Forms.Panel
   Friend WithEvents lblFolder As System.Windows.Forms.Label
   Friend WithEvents cmbFolder As System.Windows.Forms.ComboBox
   Friend WithEvents cmbFrom As System.Windows.Forms.ComboBox
   Friend WithEvents lblMessages As System.Windows.Forms.Label
   Friend WithEvents chkMatchAll As System.Windows.Forms.RadioButton
   Friend WithEvents chkMatchAny As System.Windows.Forms.RadioButton
   Friend WithEvents cmbTo As System.Windows.Forms.ComboBox
   Friend WithEvents lblTo As System.Windows.Forms.Label
   Friend WithEvents lblKeywords As System.Windows.Forms.Label
   Friend WithEvents txtFreeForm As System.Windows.Forms.TextBox
   Friend WithEvents chkFreeForm As System.Windows.Forms.CheckBox
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmMessageSearch))
      Me.cmdClose = New System.Windows.Forms.Button
      Me.lvwMessages = New System.Windows.Forms.ListView
      Me.txtKeyword = New System.Windows.Forms.TextBox
      Me.cmdSearch = New System.Windows.Forms.Button
      Me.lblFrom = New System.Windows.Forms.Label
      Me.chkFullHeaders = New System.Windows.Forms.CheckBox
      Me.pnlTop = New System.Windows.Forms.Panel
      Me.cmbTo = New System.Windows.Forms.ComboBox
      Me.lblTo = New System.Windows.Forms.Label
      Me.chkMatchAny = New System.Windows.Forms.RadioButton
      Me.chkMatchAll = New System.Windows.Forms.RadioButton
      Me.cmbFrom = New System.Windows.Forms.ComboBox
      Me.cmbFolder = New System.Windows.Forms.ComboBox
      Me.lblFolder = New System.Windows.Forms.Label
      Me.pnlSearch = New System.Windows.Forms.Panel
      Me.chkFreeForm = New System.Windows.Forms.CheckBox
      Me.lblKeywords = New System.Windows.Forms.Label
      Me.txtFreeForm = New System.Windows.Forms.TextBox
      Me.pnlBottom = New System.Windows.Forms.Panel
      Me.lblMessages = New System.Windows.Forms.Label
      Me.pnlClose = New System.Windows.Forms.Panel
      Me.pnlMessages = New System.Windows.Forms.Panel
      Me.pnlTop.SuspendLayout()
      Me.pnlSearch.SuspendLayout()
      Me.pnlBottom.SuspendLayout()
      Me.pnlClose.SuspendLayout()
      Me.pnlMessages.SuspendLayout()
      Me.SuspendLayout()
      '
      'cmdClose
      '
      Me.cmdClose.DialogResult = System.Windows.Forms.DialogResult.Cancel
      Me.cmdClose.FlatStyle = System.Windows.Forms.FlatStyle.System
      Me.cmdClose.Location = New System.Drawing.Point(8, 8)
      Me.cmdClose.Name = "cmdClose"
      Me.cmdClose.TabIndex = 0
      Me.cmdClose.Text = "Close"
      '
      'lvwMessages
      '
      Me.lvwMessages.Dock = System.Windows.Forms.DockStyle.Fill
      Me.lvwMessages.FullRowSelect = True
      Me.lvwMessages.Location = New System.Drawing.Point(8, 0)
      Me.lvwMessages.MultiSelect = False
      Me.lvwMessages.Name = "lvwMessages"
      Me.lvwMessages.Size = New System.Drawing.Size(392, 121)
      Me.lvwMessages.TabIndex = 0
      Me.lvwMessages.View = System.Windows.Forms.View.Details
      '
      'txtKeyword
      '
      Me.txtKeyword.Location = New System.Drawing.Point(64, 80)
      Me.txtKeyword.Name = "txtKeyword"
      Me.txtKeyword.Size = New System.Drawing.Size(232, 20)
      Me.txtKeyword.TabIndex = 7
      Me.txtKeyword.Text = ""
      '
      'cmdSearch
      '
      Me.cmdSearch.FlatStyle = System.Windows.Forms.FlatStyle.System
      Me.cmdSearch.Location = New System.Drawing.Point(24, 80)
      Me.cmdSearch.Name = "cmdSearch"
      Me.cmdSearch.TabIndex = 2
      Me.cmdSearch.Text = "Search"
      '
      'lblFrom
      '
      Me.lblFrom.Location = New System.Drawing.Point(8, 32)
      Me.lblFrom.Name = "lblFrom"
      Me.lblFrom.Size = New System.Drawing.Size(32, 16)
      Me.lblFrom.TabIndex = 2
      Me.lblFrom.Text = "From"
      '
      'chkFullHeaders
      '
      Me.chkFullHeaders.FlatStyle = System.Windows.Forms.FlatStyle.System
      Me.chkFullHeaders.Location = New System.Drawing.Point(8, 32)
      Me.chkFullHeaders.Name = "chkFullHeaders"
      Me.chkFullHeaders.Size = New System.Drawing.Size(88, 16)
      Me.chkFullHeaders.TabIndex = 1
      Me.chkFullHeaders.Text = "Full headers"
      '
      'pnlTop
      '
      Me.pnlTop.Controls.Add(Me.cmbTo)
      Me.pnlTop.Controls.Add(Me.lblTo)
      Me.pnlTop.Controls.Add(Me.chkMatchAny)
      Me.pnlTop.Controls.Add(Me.chkMatchAll)
      Me.pnlTop.Controls.Add(Me.cmbFrom)
      Me.pnlTop.Controls.Add(Me.cmbFolder)
      Me.pnlTop.Controls.Add(Me.lblFolder)
      Me.pnlTop.Controls.Add(Me.pnlSearch)
      Me.pnlTop.Controls.Add(Me.txtKeyword)
      Me.pnlTop.Controls.Add(Me.lblFrom)
      Me.pnlTop.Controls.Add(Me.lblKeywords)
      Me.pnlTop.Controls.Add(Me.txtFreeForm)
      Me.pnlTop.Dock = System.Windows.Forms.DockStyle.Top
      Me.pnlTop.Location = New System.Drawing.Point(0, 0)
      Me.pnlTop.Name = "pnlTop"
      Me.pnlTop.Size = New System.Drawing.Size(408, 112)
      Me.pnlTop.TabIndex = 0
      '
      'cmbTo
      '
      Me.cmbTo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
      Me.cmbTo.Location = New System.Drawing.Point(64, 56)
      Me.cmbTo.Name = "cmbTo"
      Me.cmbTo.Size = New System.Drawing.Size(121, 21)
      Me.cmbTo.Sorted = True
      Me.cmbTo.TabIndex = 5
      '
      'lblTo
      '
      Me.lblTo.Location = New System.Drawing.Point(8, 56)
      Me.lblTo.Name = "lblTo"
      Me.lblTo.Size = New System.Drawing.Size(32, 16)
      Me.lblTo.TabIndex = 4
      Me.lblTo.Text = "To"
      '
      'chkMatchAny
      '
      Me.chkMatchAny.FlatStyle = System.Windows.Forms.FlatStyle.System
      Me.chkMatchAny.Location = New System.Drawing.Point(216, 24)
      Me.chkMatchAny.Name = "chkMatchAny"
      Me.chkMatchAny.Size = New System.Drawing.Size(80, 16)
      Me.chkMatchAny.TabIndex = 9
      Me.chkMatchAny.Text = "Match any"
      '
      'chkMatchAll
      '
      Me.chkMatchAll.Checked = True
      Me.chkMatchAll.FlatStyle = System.Windows.Forms.FlatStyle.System
      Me.chkMatchAll.Location = New System.Drawing.Point(216, 8)
      Me.chkMatchAll.Name = "chkMatchAll"
      Me.chkMatchAll.Size = New System.Drawing.Size(80, 16)
      Me.chkMatchAll.TabIndex = 8
      Me.chkMatchAll.TabStop = True
      Me.chkMatchAll.Text = "Match all"
      '
      'cmbFrom
      '
      Me.cmbFrom.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
      Me.cmbFrom.Location = New System.Drawing.Point(64, 32)
      Me.cmbFrom.Name = "cmbFrom"
      Me.cmbFrom.Size = New System.Drawing.Size(121, 21)
      Me.cmbFrom.Sorted = True
      Me.cmbFrom.TabIndex = 3
      '
      'cmbFolder
      '
      Me.cmbFolder.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
      Me.cmbFolder.Location = New System.Drawing.Point(64, 8)
      Me.cmbFolder.Name = "cmbFolder"
      Me.cmbFolder.Size = New System.Drawing.Size(121, 21)
      Me.cmbFolder.Sorted = True
      Me.cmbFolder.TabIndex = 1
      '
      'lblFolder
      '
      Me.lblFolder.Location = New System.Drawing.Point(8, 8)
      Me.lblFolder.Name = "lblFolder"
      Me.lblFolder.Size = New System.Drawing.Size(40, 16)
      Me.lblFolder.TabIndex = 0
      Me.lblFolder.Text = "Folder"
      '
      'pnlSearch
      '
      Me.pnlSearch.Controls.Add(Me.chkFullHeaders)
      Me.pnlSearch.Controls.Add(Me.cmdSearch)
      Me.pnlSearch.Controls.Add(Me.chkFreeForm)
      Me.pnlSearch.Dock = System.Windows.Forms.DockStyle.Right
      Me.pnlSearch.Location = New System.Drawing.Point(304, 0)
      Me.pnlSearch.Name = "pnlSearch"
      Me.pnlSearch.Size = New System.Drawing.Size(104, 112)
      Me.pnlSearch.TabIndex = 10
      '
      'chkFreeForm
      '
      Me.chkFreeForm.Location = New System.Drawing.Point(8, 8)
      Me.chkFreeForm.Name = "chkFreeForm"
      Me.chkFreeForm.Size = New System.Drawing.Size(80, 16)
      Me.chkFreeForm.TabIndex = 0
      Me.chkFreeForm.Text = "Free form"
      '
      'lblKeywords
      '
      Me.lblKeywords.Location = New System.Drawing.Point(8, 80)
      Me.lblKeywords.Name = "lblKeywords"
      Me.lblKeywords.Size = New System.Drawing.Size(56, 16)
      Me.lblKeywords.TabIndex = 6
      Me.lblKeywords.Text = "Keywords"
      '
      'txtFreeForm
      '
      Me.txtFreeForm.Location = New System.Drawing.Point(8, 8)
      Me.txtFreeForm.Multiline = True
      Me.txtFreeForm.Name = "txtFreeForm"
      Me.txtFreeForm.Size = New System.Drawing.Size(288, 96)
      Me.txtFreeForm.TabIndex = 0
      Me.txtFreeForm.Text = ""
      Me.txtFreeForm.Visible = False
      '
      'pnlBottom
      '
      Me.pnlBottom.Controls.Add(Me.lblMessages)
      Me.pnlBottom.Controls.Add(Me.pnlClose)
      Me.pnlBottom.Dock = System.Windows.Forms.DockStyle.Bottom
      Me.pnlBottom.Location = New System.Drawing.Point(0, 233)
      Me.pnlBottom.Name = "pnlBottom"
      Me.pnlBottom.Size = New System.Drawing.Size(408, 40)
      Me.pnlBottom.TabIndex = 2
      '
      'lblMessages
      '
      Me.lblMessages.Location = New System.Drawing.Point(8, 8)
      Me.lblMessages.Name = "lblMessages"
      Me.lblMessages.Size = New System.Drawing.Size(176, 23)
      Me.lblMessages.TabIndex = 0
      '
      'pnlClose
      '
      Me.pnlClose.Controls.Add(Me.cmdClose)
      Me.pnlClose.Dock = System.Windows.Forms.DockStyle.Right
      Me.pnlClose.Location = New System.Drawing.Point(320, 0)
      Me.pnlClose.Name = "pnlClose"
      Me.pnlClose.Size = New System.Drawing.Size(88, 40)
      Me.pnlClose.TabIndex = 1
      '
      'pnlMessages
      '
      Me.pnlMessages.Controls.Add(Me.lvwMessages)
      Me.pnlMessages.Dock = System.Windows.Forms.DockStyle.Fill
      Me.pnlMessages.DockPadding.Left = 8
      Me.pnlMessages.DockPadding.Right = 8
      Me.pnlMessages.Location = New System.Drawing.Point(0, 112)
      Me.pnlMessages.Name = "pnlMessages"
      Me.pnlMessages.Size = New System.Drawing.Size(408, 121)
      Me.pnlMessages.TabIndex = 1
      '
      'frmMessageSearch
      '
      Me.AcceptButton = Me.cmdSearch
      Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
      Me.CancelButton = Me.cmdClose
      Me.ClientSize = New System.Drawing.Size(408, 273)
      Me.Controls.Add(Me.pnlMessages)
      Me.Controls.Add(Me.pnlBottom)
      Me.Controls.Add(Me.pnlTop)
      Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
      Me.Name = "frmMessageSearch"
      Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
      Me.Text = "Search"
      Me.pnlTop.ResumeLayout(False)
      Me.pnlSearch.ResumeLayout(False)
      Me.pnlBottom.ResumeLayout(False)
      Me.pnlClose.ResumeLayout(False)
      Me.pnlMessages.ResumeLayout(False)
      Me.ResumeLayout(False)

   End Sub

#End Region

   Private Sub SetData(ByVal iFolderID As Integer)
      Dim iUserNum As Integer, iFolderNum As Integer
      Dim pLookup As Lookup, pSelected As Lookup
      Dim pUser As UserLookup, pFolder As MessageTreeLookup

      cmbFrom.BeginUpdate()
      cmbTo.BeginUpdate()

      pLookup = New Lookup(0, 0, "<All users>")
      cmbFrom.Items.Add(pLookup)
      cmbTo.Items.Add(pLookup)

      For iUserNum = 0 To UserCount() - 1
         pUser = UserList(iUserNum)

         If pUser.m_iAccessLevel >= ua.LEVEL_MESSAGES Then
            pLookup = New Lookup(0, pUser.m_iID, pUser.m_sValue)
            cmbFrom.Items.Add(pLookup)
            cmbTo.Items.Add(pLookup)
         End If
      Next

      cmbFrom.SelectedIndex = 0
      cmbTo.SelectedIndex = 0

      cmbFrom.EndUpdate()
      cmbTo.EndUpdate()


      cmbFolder.BeginUpdate()

      pLookup = New Lookup(0, 0, "<All folders>")
      cmbFolder.Items.Add(pLookup)

      pSelected = Nothing

      For iFolderNum = 0 To FolderCount() - 1
         pFolder = FolderList(iFolderNum)

         pLookup = New Lookup(0, pFolder.m_iID, pFolder.m_sValue)
         cmbFolder.Items.Add(pLookup)

         If pFolder.m_iID = iFolderID Then
            pSelected = pLookup
         End If
      Next

      If Not pSelected Is Nothing Then
         cmbFolder.SelectedItem = pSelected
      Else
         cmbFolder.SelectedIndex = 0
      End If

      cmbFolder.EndUpdate()
   End Sub

   Private Sub cmdClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdClose.Click
      Me.Dispose()
   End Sub

   Private Sub cmdSearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSearch.Click
      Dim bRequest As Boolean, bLoop As Boolean
      Dim iMessageID As Integer
      Dim sFolderName As String, sSubject As String
      Dim pRequest As CEDF, pReply As CEDF, pEDF As CEDF
      Dim pLookup As Lookup
      Dim pItem As ListViewItem

      pRequest = New CEDF()

      If chkFreeForm.Checked = True Then
         pEDF = MatchToEDF(txtFreeForm.Text)
         pRequest.Copy(pEDF, False, False, True)

         pRequest.MsgPrint("frmMessageSearch::cmdSearch")
      Else
         If chkMatchAll.Checked = False Then
            pRequest.Add("or")
         End If

         pLookup = cmbFolder.SelectedItem
         If Not pLookup Is Nothing Then
            If pLookup.m_iID > 0 Then
               pRequest.AddChild("folderid", pLookup.m_iID)
            End If
         End If

         If txtKeyword.Text <> "" Then
            pRequest.AddChild("keyword", txtKeyword.Text)
         End If

         pLookup = cmbFrom.SelectedItem
         If Not pLookup Is Nothing Then
            If pLookup.m_iID > 0 Then
               pRequest.AddChild("fromid", pLookup.m_iID)
            End If
         End If

         pLookup = cmbTo.SelectedItem
         If Not pLookup Is Nothing Then
            If pLookup.m_iID > 0 Then
               pRequest.AddChild("toid", pLookup.m_iID)
            End If
         End If

         If chkMatchAll.Checked = False Then
            pRequest.Parent()
         End If
      End If

      If chkFullHeaders.Checked = True Then
         pRequest.AddChild("searchtype", 1)
      End If

      Me.Cursor = Cursors.WaitCursor
      Application.DoEvents()

      pReply = New CEDF()

      If Client.request3(ua.MSG_MESSAGE_LIST, pRequest, pReply) = True Then
         ShowMessages(pReply)
      End If

      If pReply.Children("message") > 0 Then
         lblMessages.Text = plural(pReply.Children("message"), "message")
      Else
         MsgBox("No messages found", MsgBoxStyle.Exclamation)
      End If

      Me.Cursor = Cursors.Default
   End Sub

   Private Sub ShowMessages(Optional ByVal pMessages As CEDF = Nothing)
      Dim bRequest As Boolean, bLoop As Boolean
      Dim iMessageID As Integer
      Dim sFolderName As String, sFromName As String, sToName As String, sSubject As String
      Dim pItem As ListViewItem
      Dim pLookup As Lookup

      lvwMessages.BeginUpdate()
      lvwMessages.Items.Clear()

      If Not pMessages Is Nothing Then
         m_pMessages = pMessages
         m_pMessages.Sort("message", Nothing)
      End If

      'txtReply.Text = m_pMessages.Write(CEDF.EL_ROOT + CEDF.EL_CURR + CEDF.PR_SPACE + CEDF.PR_CRLF)

      lvwMessages.Columns.Clear()
      lvwMessages.Columns.Add("Message", 60, HorizontalAlignment.Left)
      lvwMessages.Columns.Add("Folder", 100, HorizontalAlignment.Left)
      If chkFullHeaders.Checked = True Then
         lvwMessages.Columns.Add("From", 100, HorizontalAlignment.Left)
         lvwMessages.Columns.Add("To", 100, HorizontalAlignment.Left)
      End If
      lvwMessages.Columns.Add("Subject", 150, HorizontalAlignment.Left)

      bLoop = m_pMessages.Child("message")
      Do While bLoop = True
         iMessageID = m_pMessages.GetInt()
         sFolderName = m_pMessages.GetChildStr("foldername")
         sFromName = m_pMessages.GetChildStr("fromname")
         sToName = m_pMessages.GetChildStr("toname")
         sSubject = m_pMessages.GetChildStr("subject")

         pLookup = New Lookup(0, iMessageID, Nothing)

         pItem = New ListViewItem(iMessageID)
         pItem.SubItems.Add(sFolderName)
         If chkFullHeaders.Checked = True Then
            pItem.SubItems.Add(sFromName)
            pItem.SubItems.Add(sToName)
         End If
         pItem.SubItems.Add(sSubject)
         pItem.Tag = pLookup

         lvwMessages.Items.Add(pItem)

         bLoop = m_pMessages.Next("message")
         If bLoop = False Then
            m_pMessages.Parent()
         End If
      Loop

      lvwMessages.EndUpdate()
   End Sub

   Private Sub lvwMessages_ColumnClick(ByVal sender As Object, ByVal e As System.Windows.Forms.ColumnClickEventArgs) Handles lvwMessages.ColumnClick
      'MsgBox("You clicked col " & e.Column, , "frmMessageSearch::lvwMessages")

      Select Case e.Column
         Case 0
            m_pMessages.Sort("message", Nothing)

         Case 1
            m_pMessages.Sort("message", "foldername")

         Case 2
            If chkFullHeaders.Checked = True Then
               m_pMessages.Sort("message", "fromname")
            Else
               m_pMessages.Sort("message", "subject")
            End If

         Case 3
            m_pMessages.Sort("message", "toname")

         Case 4
            m_pMessages.Sort("message", "subject")

      End Select

      ShowMessages()
   End Sub

   Private Sub lvwMessages_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lvwMessages.SelectedIndexChanged
      Dim pItem As ListViewItem
      Dim pLookup As Lookup

      If lvwMessages.SelectedItems.Count > 0 Then
         pItem = lvwMessages.SelectedItems(0)

         If Not pItem Is Nothing Then
            pLookup = pItem.Tag

            frmsUAve.getForm().MessageGoto(pLookup)
         End If
      End If
   End Sub

   Private Sub chkFullHeaders_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkFullHeaders.CheckedChanged
      If Not m_pMessages Is Nothing Then
         ShowMessages()
      End If
   End Sub

   Public Shared Function getForm() As Form
      Return m_pForm
   End Function

   Private Sub pnlTop_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles pnlTop.Paint

   End Sub

   Private Sub chkFreeForm_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkFreeForm.CheckedChanged
      Dim pControl As Control

      txtFreeForm.Visible = chkFreeForm.Checked

      For Each pControl In pnlTop.Controls
         If Not (pControl Is pnlSearch Or pControl Is txtFreeForm) Then
            pControl.Visible = Not chkFreeForm.Checked
         End If
      Next
   End Sub
End Class
