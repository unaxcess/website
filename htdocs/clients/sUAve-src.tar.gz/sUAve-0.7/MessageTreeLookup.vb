Imports org.ua2

Public Class MessageTreeLookup
   Inherits Lookup

   Public m_iNumMsgs As Integer
   Public m_iSubType As Integer
   Public m_iReplyID As Integer
   Public m_iAccessMode As Integer
   Public m_pTree As TreeNode
   Public m_bDirty As Boolean
   Public m_bMarkup As Boolean

   Public Sub New(ByVal iID As Integer, ByVal sName As String, ByVal iSubType As Integer, ByVal iNumMsgs As Integer, ByVal iNumUnread As Integer, ByVal iReplyID As Integer, ByVal iAccessMode As Integer)
      MyBase.New(0, iID, iNumUnread, sName)

      m_iNumMsgs = iNumMsgs

      m_iSubType = iSubType
      m_iReplyID = iReplyID
      m_iAccessMode = iAccessMode
      m_pTree = Nothing
      m_bDirty = False
      m_bMarkup = True
   End Sub

   Public Sub New(ByRef pLookup As MessageTreeLookup)
      MyBase.New(pLookup)

      m_iNumMsgs = pLookup.m_iNumMsgs
      m_iSubType = pLookup.m_iSubType
      m_iReplyID = pLookup.m_iReplyID
      m_iAccessMode = pLookup.m_iAccessMode
      m_pTree = pLookup.m_pTree
      m_bDirty = pLookup.m_bDirty
      m_bMarkup = pLookup.m_bMarkup
   End Sub

   Public Overrides Function toString() As String
      Dim sReturn As String

      If m_bMarkup = True Then
         sReturn = submarkup(m_sValue)
         If m_iNumMsgs > 0 Or m_iValue > 0 Then
            sReturn &= " ("

            If m_iNumMsgs > 0 Then
               sReturn &= plural(m_iNumMsgs, "message", m_iSubType > 0)
            End If
            If m_iSubType > 0 And m_iValue > 0 Then
               sReturn &= ", " & submarkup(m_iValue) & " unread"
            End If

            sReturn &= ")"
         End If
      Else
         sReturn = MyBase.ToString()
      End If

      Return sReturn
   End Function

   Private Function submarkup(ByVal sString As String) As String
      If m_iSubType > 0 Then
         Return markup(sString)
      Else
         Return sString
      End If
   End Function
End Class
