Imports org.ua2

Public Class frmMessageTrees
   Inherits System.Windows.Forms.Form

   Private m_sType As String

   Private m_pLookup As Lookup
   Private m_pItem As CEDF

   Private m_pRequest As CEDF

   Private m_bUserInput As Boolean = True

   Private m_bUpdate As Boolean

#Region " Windows Form Designer generated code "

   Public Sub New(ByVal sType As String, ByVal iID As Integer)
      MyBase.New()

      'This call is required by the Windows Form Designer.
      InitializeComponent()

      'Add any initialization after the InitializeComponent() call
      Dim iCurrLevel As Integer
      Dim pControl As Control

      iCurrLevel = Client.GetAccessLevel()

      sUAveFont(Me)
      FormAdd(Me)

      m_sType = sType

      Me.Text = m_sType.Substring(0, 1).ToUpper() & m_sType.Substring(1) & "s"

      If iCurrLevel < ua.LEVEL_WITNESS Then
         txtName.ReadOnly = True
         cmbAccessMode.Enabled = False
         cmbAccessLevel.Enabled = False
         txtExpiry.ReadOnly = True

         mnuSubTypeEditor.Enabled = False
      End If

      SetData(iID)
   End Sub

   'Form overrides dispose to clean up the component list.
   Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
      If disposing Then
         FormRemove(Me)

         If Not (components Is Nothing) Then
            components.Dispose()
         End If
      End If
      MyBase.Dispose(disposing)
   End Sub

   Friend WithEvents cmdClose As System.Windows.Forms.Button

   'Required by the Windows Form Designer
   Private components As System.ComponentModel.IContainer

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   Friend WithEvents txtName As System.Windows.Forms.TextBox
   Friend WithEvents lblAccessMode As System.Windows.Forms.Label
   Friend WithEvents cmbAccessMode As System.Windows.Forms.ComboBox
   Friend WithEvents lblMsgStats As System.Windows.Forms.Label
   Friend WithEvents lblCreated As System.Windows.Forms.Label
   Friend WithEvents cmbAccessLevel As System.Windows.Forms.ComboBox
   Friend WithEvents rlbUsers As RichControl.RichListBox
   Friend WithEvents cmdUserAdd As System.Windows.Forms.Button
   Friend WithEvents cmdUserRemove As System.Windows.Forms.Button
   Friend WithEvents lstItems As System.Windows.Forms.ListBox
   Friend WithEvents pnlItems As System.Windows.Forms.Panel
   Friend WithEvents pnlItem As System.Windows.Forms.Panel
   Friend WithEvents pnlBottom As System.Windows.Forms.Panel
   Friend WithEvents tabItem As System.Windows.Forms.TabControl
   Friend WithEvents tbpGeneral As System.Windows.Forms.TabPage
   Friend WithEvents tbpUsers As System.Windows.Forms.TabPage
   Friend WithEvents lblAccessLevel As System.Windows.Forms.Label
   Friend WithEvents tbpInfo As System.Windows.Forms.TabPage
   Friend WithEvents rtbInfo As System.Windows.Forms.RichTextBox
   Friend WithEvents lblInfo As System.Windows.Forms.Label
   Friend WithEvents lblExpiry As System.Windows.Forms.Label
   Friend WithEvents txtExpiry As System.Windows.Forms.TextBox
   Friend WithEvents lblName As System.Windows.Forms.Label
   Friend WithEvents splItems As System.Windows.Forms.Splitter
   Friend WithEvents mnuSubType As System.Windows.Forms.ContextMenu
   Friend WithEvents mnuSubTypeSub As System.Windows.Forms.MenuItem
   Friend WithEvents mnuSubTypeMember As System.Windows.Forms.MenuItem
   Friend WithEvents mnuSubTypeEditor As System.Windows.Forms.MenuItem
   Friend WithEvents tbpEDF As System.Windows.Forms.TabPage
   Friend WithEvents txtEDF As System.Windows.Forms.TextBox
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmMessageTrees))
      Me.lblName = New System.Windows.Forms.Label()
      Me.lstItems = New System.Windows.Forms.ListBox()
      Me.cmdClose = New System.Windows.Forms.Button()
      Me.txtName = New System.Windows.Forms.TextBox()
      Me.lblAccessMode = New System.Windows.Forms.Label()
      Me.cmbAccessMode = New System.Windows.Forms.ComboBox()
      Me.lblMsgStats = New System.Windows.Forms.Label()
      Me.lblCreated = New System.Windows.Forms.Label()
      Me.lblAccessLevel = New System.Windows.Forms.Label()
      Me.cmbAccessLevel = New System.Windows.Forms.ComboBox()
      Me.rlbUsers = New RichControl.RichListBox()
      Me.mnuSubType = New System.Windows.Forms.ContextMenu()
      Me.mnuSubTypeSub = New System.Windows.Forms.MenuItem()
      Me.mnuSubTypeMember = New System.Windows.Forms.MenuItem()
      Me.mnuSubTypeEditor = New System.Windows.Forms.MenuItem()
      Me.cmdUserAdd = New System.Windows.Forms.Button()
      Me.cmdUserRemove = New System.Windows.Forms.Button()
      Me.pnlItems = New System.Windows.Forms.Panel()
      Me.pnlItem = New System.Windows.Forms.Panel()
      Me.tabItem = New System.Windows.Forms.TabControl()
      Me.tbpGeneral = New System.Windows.Forms.TabPage()
      Me.txtExpiry = New System.Windows.Forms.TextBox()
      Me.lblExpiry = New System.Windows.Forms.Label()
      Me.tbpInfo = New System.Windows.Forms.TabPage()
      Me.rtbInfo = New System.Windows.Forms.RichTextBox()
      Me.lblInfo = New System.Windows.Forms.Label()
      Me.tbpUsers = New System.Windows.Forms.TabPage()
      Me.tbpEDF = New System.Windows.Forms.TabPage()
      Me.txtEDF = New System.Windows.Forms.TextBox()
      Me.pnlBottom = New System.Windows.Forms.Panel()
      Me.splItems = New System.Windows.Forms.Splitter()
      Me.pnlItems.SuspendLayout()
      Me.pnlItem.SuspendLayout()
      Me.tabItem.SuspendLayout()
      Me.tbpGeneral.SuspendLayout()
      Me.tbpInfo.SuspendLayout()
      Me.tbpUsers.SuspendLayout()
      Me.tbpEDF.SuspendLayout()
      Me.pnlBottom.SuspendLayout()
      Me.SuspendLayout()
      '
      'lblName
      '
      Me.lblName.Location = New System.Drawing.Point(8, 8)
      Me.lblName.Name = "lblName"
      Me.lblName.Size = New System.Drawing.Size(72, 23)
      Me.lblName.TabIndex = 3
      Me.lblName.Text = "Name"
      '
      'lstItems
      '
      Me.lstItems.Dock = System.Windows.Forms.DockStyle.Fill
      Me.lstItems.Location = New System.Drawing.Point(8, 8)
      Me.lstItems.Name = "lstItems"
      Me.lstItems.Size = New System.Drawing.Size(112, 186)
      Me.lstItems.Sorted = True
      Me.lstItems.TabIndex = 1
      '
      'cmdClose
      '
      Me.cmdClose.DialogResult = System.Windows.Forms.DialogResult.Cancel
      Me.cmdClose.Dock = System.Windows.Forms.DockStyle.Right
      Me.cmdClose.FlatStyle = System.Windows.Forms.FlatStyle.System
      Me.cmdClose.Location = New System.Drawing.Point(269, 8)
      Me.cmdClose.Name = "cmdClose"
      Me.cmdClose.Size = New System.Drawing.Size(75, 24)
      Me.cmdClose.TabIndex = 0
      Me.cmdClose.Text = "Close"
      '
      'txtName
      '
      Me.txtName.Location = New System.Drawing.Point(88, 8)
      Me.txtName.Name = "txtName"
      Me.txtName.Size = New System.Drawing.Size(112, 20)
      Me.txtName.TabIndex = 4
      Me.txtName.Text = ""
      '
      'lblAccessMode
      '
      Me.lblAccessMode.Location = New System.Drawing.Point(8, 32)
      Me.lblAccessMode.Name = "lblAccessMode"
      Me.lblAccessMode.Size = New System.Drawing.Size(72, 23)
      Me.lblAccessMode.TabIndex = 5
      Me.lblAccessMode.Text = "Access mode"
      '
      'cmbAccessMode
      '
      Me.cmbAccessMode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
      Me.cmbAccessMode.Items.AddRange(New Object() {"Normal", "Read-only", "Restricted", "Private", "Custom..."})
      Me.cmbAccessMode.Location = New System.Drawing.Point(88, 32)
      Me.cmbAccessMode.Name = "cmbAccessMode"
      Me.cmbAccessMode.Size = New System.Drawing.Size(112, 21)
      Me.cmbAccessMode.TabIndex = 6
      '
      'lblMsgStats
      '
      Me.lblMsgStats.Location = New System.Drawing.Point(8, 88)
      Me.lblMsgStats.Name = "lblMsgStats"
      Me.lblMsgStats.Size = New System.Drawing.Size(192, 32)
      Me.lblMsgStats.TabIndex = 7
      '
      'lblCreated
      '
      Me.lblCreated.Location = New System.Drawing.Point(8, 120)
      Me.lblCreated.Name = "lblCreated"
      Me.lblCreated.Size = New System.Drawing.Size(192, 23)
      Me.lblCreated.TabIndex = 8
      '
      'lblAccessLevel
      '
      Me.lblAccessLevel.Location = New System.Drawing.Point(8, 56)
      Me.lblAccessLevel.Name = "lblAccessLevel"
      Me.lblAccessLevel.Size = New System.Drawing.Size(72, 23)
      Me.lblAccessLevel.TabIndex = 9
      Me.lblAccessLevel.Text = "Access level"
      '
      'cmbAccessLevel
      '
      Me.cmbAccessLevel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
      Me.cmbAccessLevel.Items.AddRange(New Object() {"None", "Messages", "Editor", "Witness"})
      Me.cmbAccessLevel.Location = New System.Drawing.Point(88, 56)
      Me.cmbAccessLevel.Name = "cmbAccessLevel"
      Me.cmbAccessLevel.Size = New System.Drawing.Size(112, 21)
      Me.cmbAccessLevel.TabIndex = 10
      '
      'rlbUsers
      '
      Me.rlbUsers.ContextMenu = Me.mnuSubType
      Me.rlbUsers.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
      Me.rlbUsers.ImageList = Nothing
      Me.rlbUsers.Location = New System.Drawing.Point(8, 8)
      Me.rlbUsers.Name = "rlbUsers"
      Me.rlbUsers.Size = New System.Drawing.Size(112, 121)
      Me.rlbUsers.Sorted = True
      Me.rlbUsers.TabIndex = 11
      '
      'mnuSubType
      '
      Me.mnuSubType.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuSubTypeSub, Me.mnuSubTypeMember, Me.mnuSubTypeEditor})
      '
      'mnuSubTypeSub
      '
      Me.mnuSubTypeSub.Index = 0
      Me.mnuSubTypeSub.Text = "Subscriber"
      '
      'mnuSubTypeMember
      '
      Me.mnuSubTypeMember.Index = 1
      Me.mnuSubTypeMember.Text = "Member"
      '
      'mnuSubTypeEditor
      '
      Me.mnuSubTypeEditor.Index = 2
      Me.mnuSubTypeEditor.Text = "Editor"
      '
      'cmdUserAdd
      '
      Me.cmdUserAdd.FlatStyle = System.Windows.Forms.FlatStyle.System
      Me.cmdUserAdd.Location = New System.Drawing.Point(128, 8)
      Me.cmdUserAdd.Name = "cmdUserAdd"
      Me.cmdUserAdd.Size = New System.Drawing.Size(72, 23)
      Me.cmdUserAdd.TabIndex = 12
      Me.cmdUserAdd.Text = "Add..."
      '
      'cmdUserRemove
      '
      Me.cmdUserRemove.FlatStyle = System.Windows.Forms.FlatStyle.System
      Me.cmdUserRemove.Location = New System.Drawing.Point(128, 40)
      Me.cmdUserRemove.Name = "cmdUserRemove"
      Me.cmdUserRemove.Size = New System.Drawing.Size(72, 23)
      Me.cmdUserRemove.TabIndex = 13
      Me.cmdUserRemove.Text = "Remove"
      '
      'pnlItems
      '
      Me.pnlItems.Controls.AddRange(New System.Windows.Forms.Control() {Me.lstItems})
      Me.pnlItems.Dock = System.Windows.Forms.DockStyle.Left
      Me.pnlItems.DockPadding.All = 8
      Me.pnlItems.Name = "pnlItems"
      Me.pnlItems.Size = New System.Drawing.Size(128, 213)
      Me.pnlItems.TabIndex = 14
      '
      'pnlItem
      '
      Me.pnlItem.Controls.AddRange(New System.Windows.Forms.Control() {Me.tabItem})
      Me.pnlItem.Dock = System.Windows.Forms.DockStyle.Fill
      Me.pnlItem.DockPadding.Right = 8
      Me.pnlItem.DockPadding.Top = 8
      Me.pnlItem.Location = New System.Drawing.Point(131, 0)
      Me.pnlItem.Name = "pnlItem"
      Me.pnlItem.Size = New System.Drawing.Size(221, 213)
      Me.pnlItem.TabIndex = 15
      '
      'tabItem
      '
      Me.tabItem.Controls.AddRange(New System.Windows.Forms.Control() {Me.tbpGeneral, Me.tbpUsers, Me.tbpInfo, Me.tbpEDF})
      Me.tabItem.Dock = System.Windows.Forms.DockStyle.Fill
      Me.tabItem.Location = New System.Drawing.Point(0, 8)
      Me.tabItem.Name = "tabItem"
      Me.tabItem.SelectedIndex = 0
      Me.tabItem.Size = New System.Drawing.Size(213, 205)
      Me.tabItem.TabIndex = 14
      '
      'tbpGeneral
      '
      Me.tbpGeneral.Controls.AddRange(New System.Windows.Forms.Control() {Me.txtExpiry, Me.lblExpiry, Me.cmbAccessLevel, Me.lblAccessLevel, Me.lblCreated, Me.lblMsgStats, Me.cmbAccessMode, Me.lblAccessMode, Me.txtName, Me.lblName})
      Me.tbpGeneral.Location = New System.Drawing.Point(4, 22)
      Me.tbpGeneral.Name = "tbpGeneral"
      Me.tbpGeneral.Size = New System.Drawing.Size(205, 179)
      Me.tbpGeneral.TabIndex = 0
      Me.tbpGeneral.Text = "General"
      '
      'txtExpiry
      '
      Me.txtExpiry.Location = New System.Drawing.Point(88, 152)
      Me.txtExpiry.Name = "txtExpiry"
      Me.txtExpiry.Size = New System.Drawing.Size(112, 20)
      Me.txtExpiry.TabIndex = 12
      Me.txtExpiry.Text = ""
      '
      'lblExpiry
      '
      Me.lblExpiry.Location = New System.Drawing.Point(8, 152)
      Me.lblExpiry.Name = "lblExpiry"
      Me.lblExpiry.Size = New System.Drawing.Size(72, 23)
      Me.lblExpiry.TabIndex = 11
      Me.lblExpiry.Text = "Expiry (days)"
      '
      'tbpInfo
      '
      Me.tbpInfo.Controls.AddRange(New System.Windows.Forms.Control() {Me.rtbInfo, Me.lblInfo})
      Me.tbpInfo.DockPadding.All = 8
      Me.tbpInfo.Location = New System.Drawing.Point(4, 22)
      Me.tbpInfo.Name = "tbpInfo"
      Me.tbpInfo.Size = New System.Drawing.Size(205, 179)
      Me.tbpInfo.TabIndex = 2
      Me.tbpInfo.Text = "Info"
      '
      'rtbInfo
      '
      Me.rtbInfo.Dock = System.Windows.Forms.DockStyle.Fill
      Me.rtbInfo.Location = New System.Drawing.Point(8, 31)
      Me.rtbInfo.Name = "rtbInfo"
      Me.rtbInfo.Size = New System.Drawing.Size(189, 140)
      Me.rtbInfo.TabIndex = 0
      Me.rtbInfo.Text = ""
      '
      'lblInfo
      '
      Me.lblInfo.Dock = System.Windows.Forms.DockStyle.Top
      Me.lblInfo.Location = New System.Drawing.Point(8, 8)
      Me.lblInfo.Name = "lblInfo"
      Me.lblInfo.Size = New System.Drawing.Size(189, 23)
      Me.lblInfo.TabIndex = 1
      '
      'tbpUsers
      '
      Me.tbpUsers.Controls.AddRange(New System.Windows.Forms.Control() {Me.cmdUserRemove, Me.cmdUserAdd, Me.rlbUsers})
      Me.tbpUsers.Location = New System.Drawing.Point(4, 22)
      Me.tbpUsers.Name = "tbpUsers"
      Me.tbpUsers.Size = New System.Drawing.Size(205, 179)
      Me.tbpUsers.TabIndex = 1
      Me.tbpUsers.Text = "Users"
      '
      'tbpEDF
      '
      Me.tbpEDF.Controls.AddRange(New System.Windows.Forms.Control() {Me.txtEDF})
      Me.tbpEDF.DockPadding.All = 8
      Me.tbpEDF.Location = New System.Drawing.Point(4, 22)
      Me.tbpEDF.Name = "tbpEDF"
      Me.tbpEDF.Size = New System.Drawing.Size(205, 179)
      Me.tbpEDF.TabIndex = 3
      Me.tbpEDF.Text = "EDF"
      '
      'txtEDF
      '
      Me.txtEDF.Dock = System.Windows.Forms.DockStyle.Fill
      Me.txtEDF.Location = New System.Drawing.Point(8, 8)
      Me.txtEDF.Multiline = True
      Me.txtEDF.Name = "txtEDF"
      Me.txtEDF.Size = New System.Drawing.Size(189, 163)
      Me.txtEDF.TabIndex = 0
      Me.txtEDF.Text = ""
      '
      'pnlBottom
      '
      Me.pnlBottom.Controls.AddRange(New System.Windows.Forms.Control() {Me.cmdClose})
      Me.pnlBottom.Dock = System.Windows.Forms.DockStyle.Bottom
      Me.pnlBottom.DockPadding.All = 8
      Me.pnlBottom.Location = New System.Drawing.Point(0, 213)
      Me.pnlBottom.Name = "pnlBottom"
      Me.pnlBottom.Size = New System.Drawing.Size(352, 40)
      Me.pnlBottom.TabIndex = 16
      '
      'splItems
      '
      Me.splItems.Location = New System.Drawing.Point(128, 0)
      Me.splItems.Name = "splItems"
      Me.splItems.Size = New System.Drawing.Size(3, 213)
      Me.splItems.TabIndex = 17
      Me.splItems.TabStop = False
      '
      'frmMessageTrees
      '
      Me.AcceptButton = Me.cmdClose
      Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
      Me.CancelButton = Me.cmdClose
      Me.ClientSize = New System.Drawing.Size(352, 253)
      Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.pnlItem, Me.splItems, Me.pnlItems, Me.pnlBottom})
      Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
      Me.Name = "frmMessageTrees"
      Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
      Me.Text = "Trees"
      Me.pnlItems.ResumeLayout(False)
      Me.pnlItem.ResumeLayout(False)
      Me.tabItem.ResumeLayout(False)
      Me.tbpGeneral.ResumeLayout(False)
      Me.tbpInfo.ResumeLayout(False)
      Me.tbpUsers.ResumeLayout(False)
      Me.tbpEDF.ResumeLayout(False)
      Me.pnlBottom.ResumeLayout(False)
      Me.ResumeLayout(False)

   End Sub

#End Region

   Private Sub SetData(ByVal iID As Integer)
      Dim iTreeNum As Integer, iNumTrees As Integer
      Dim pTree As MessageTreeLookup, pLookup As Lookup, pSelected As Lookup

      If m_sType = "folder" Then
         iNumTrees = FolderCount() - 1
      Else
         iNumTrees = ChannelCount() - 1
      End If

      lstItems.BeginUpdate()
      For iTreeNum = 0 To iNumTrees
         If m_sType = "folder" Then
            pTree = FolderList(iTreeNum)
         Else
            pTree = ChannelList(iTreeNum)
         End If

         pLookup = New Lookup(0, pTree.m_iID, pTree.m_sValue)

         If pTree.m_iID = iID Then
            pSelected = pLookup
         End If

         lstItems.Items.Add(pLookup)
      Next
      lstItems.EndUpdate()

      If Not pSelected Is Nothing Then
         lstItems.SelectedItem = pSelected
      End If
   End Sub

   Private Sub lstItems_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lstItems.SelectedIndexChanged
      Dim pLookup As Lookup
      Dim pRequest As CEDF, pReply As CEDF

      pLookup = lstItems.SelectedItem
      If Not pLookup Is Nothing Then
         RefreshMessageTree(pLookup)
      End If
   End Sub

   Private Sub RefreshMessageTree(ByVal pItem As Lookup)
      Dim iCurrID As Integer, iCurrLevel As Integer
      Dim iSubType As Integer, iAccessLevel As Integer, iAccessMode As Integer, iInfoDate As Integer
      Dim iNumMsgs As Integer, iTotalMsgs As Integer, iLastMsg As Integer, iCreated As Integer, iExpire As Integer
      Dim iUserID As Integer, iUserSub As Integer
      Dim bLoop As Boolean
      Dim sName As String, sWrite As String, sUserName As String, sInfo As String, sInfoName As String
      Dim pControl As Control
      Dim pLookup As Lookup
      Dim pRequest As CEDF, pReply As CEDF

      If m_bUserInput = True Then
         SaveChanges()

         m_bUserInput = False

         pRequest = New CEDF()
         pRequest.AddChild(m_sType & "id", pItem.m_iID)

         pReply = New CEDF()

         If Client.request3(m_sType & "_list", pRequest, pReply) = True Then
            'pReply.MsgPrint("frmMessageTrees::lstItems reply")

            m_pItem = pReply
            m_pLookup = pItem

            If pReply.Child(m_sType) = True Then
               iCurrID = Client.GetID()
               iCurrLevel = Client.GetAccessLevel()

               sName = pReply.GetChildStr("name")
               iSubType = pReply.GetChildInt("subtype")
               iAccessLevel = pReply.GetChildInt("accesslevel")
               iAccessMode = pReply.GetChildInt("accessmode")

               iNumMsgs = pReply.GetChildInt("nummsgs")
               iTotalMsgs = pReply.GetChildInt("totalmsgs")
               iLastMsg = pReply.GetChildInt("lastmsg")

               iCreated = pReply.GetChildInt("created")

               Me.Text = m_pLookup.m_iID & " - " & m_sType.Substring(0, 1).ToUpper() & m_sType.Substring(1) & "s"

               txtName.Text = sName

               If m_sType = "folder" Then
                  If iAccessMode = ua.FOLDERMODE_NORMAL Then
                     cmbAccessMode.SelectedIndex = 0
                  ElseIf iAccessMode = ua.ACCMODE_READONLY Then
                     cmbAccessMode.SelectedIndex = 1
                  ElseIf iAccessMode = ua.FOLDERMODE_RESTRICTED Then
                     cmbAccessMode.SelectedIndex = 2
                  ElseIf iAccessMode = ua.ACCMODE_PRIVATE Then
                     cmbAccessMode.SelectedIndex = 3
                  Else
                     cmbAccessMode.SelectedIndex = 4
                  End If
               End If

               If iAccessLevel = ua.LEVEL_NONE Or iAccessLevel = ua.LEVEL_GUEST Then
                  cmbAccessLevel.SelectedIndex = 0
               ElseIf iAccessLevel = ua.LEVEL_MESSAGES Then
                  cmbAccessLevel.SelectedIndex = 1
               ElseIf iAccessLevel = ua.LEVEL_EDITOR Then
                  cmbAccessLevel.SelectedIndex = 2
               ElseIf iAccessLevel = ua.LEVEL_WITNESS Then
                  cmbAccessLevel.SelectedIndex = 3
               End If

               sWrite = plural(iNumMsgs, "message")
               If iTotalMsgs > 0 Then
                  sWrite &= " of " & plural(iTotalMsgs, "byte")
               End If

               If iLastMsg >= 0 Then
                  sWrite &= vbCrLf & "Last at " & StrTime(STRTIME_DATE, iLastMsg)
               End If

               lblMsgStats.Text = sWrite

               If iCreated >= 0 Then
                  lblCreated.Text = "Created " & StrTime(STRTIME_DATE, iCreated)
               Else
                  lblCreated.Text = ""
               End If

               iExpire = pReply.GetChildInt("expire")
               If iExpire > 0 Then
                  txtExpiry.Text = iExpire / 86400
               Else
                  txtExpiry.Text = ""
               End If

               If pReply.Child("info") = True Then
                  sInfo = TextDecode(pReply.GetChildStr("text"))
                  sInfoName = pReply.GetChildStr("fromname")
                  iInfoDate = pReply.GetChildInt("date")

                  lblInfo.Text = StrTime(STRTIME_SHORT, iInfoDate) & " by " & sInfoName
                  rtbInfo.Text = sInfo

                  pReply.Parent()
               Else
                  lblInfo.Text = ""
                  rtbInfo.Text = ""
               End If

               If iCurrLevel >= ua.LEVEL_WITNESS Or iSubType = ua.SUBTYPE_EDITOR Then
                  tbpUsers.Enabled = True
               Else
                  tbpUsers.Enabled = False
               End If

               rlbUsers.Items.Clear()

               bLoop = pReply.Child()
               Do While bLoop = True
                  iUserID = pReply.GetInt()
                  If pReply.GetName() = "subscriber" Then
                     iUserSub = ua.SUBTYPE_SUB
                  ElseIf pReply.GetName() = "member" Then
                     iUserSub = ua.SUBTYPE_MEMBER
                  ElseIf pReply.GetName() = "editor" Then
                     iUserSub = ua.SUBTYPE_EDITOR
                  Else
                     iUserSub = 0
                  End If

                  If iUserSub > 0 Then
                     iUserID = pReply.GetInt()
                     sUserName = pReply.GetChildStr("name")

                     pLookup = New Lookup(Lookup.FOLDER_SUB, iUserID, iUserSub, sUserName, -1)
                     rlbUsers.Items.Add(pLookup)
                  End If

                  bLoop = pReply.Next()
                  If bLoop = False Then
                     pReply.Parent()
                  End If
               Loop

               If iCurrLevel < ua.LEVEL_WITNESS Then
                  EditorControls(iSubType = ua.SUBTYPE_EDITOR)
               End If

               'MsgBox("Name is " & txtName.Visible)

               'rtbEDF.Text = pReply.Write(CEDF.PR_SPACE + CEDF.PR_CRLF)
               'pReply.MsgPrint("lstItems::lstItems reply", CEDF.PR_SPACE + CEDF.PR_CRLF)

               txtEDF.Text = pReply.Write(CEDF.PR_CRLF + CEDF.PR_SPACE)

               pReply.Parent()
            End If

            m_pRequest = New CEDF()
         Else
            pReply.MsgPrint("frmMessageTrees::ShowMessageTree request failed")
         End If

         m_bUserInput = True
      End If
   End Sub

   Private Sub EditorControls(ByVal bEditable As Boolean)
      rlbUsers.Enabled = bEditable
      cmdUserAdd.Enabled = bEditable
      cmdUserRemove.Enabled = bEditable
      rtbInfo.ReadOnly = Not bEditable
   End Sub

   Private Sub cmdClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdClose.Click
      SaveChanges()

      If m_bUpdate = True Then
         frmsUAve.getForm.RefreshFolders(False)
      End If

      Me.Dispose()
   End Sub

   Private Sub cmdUserAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdUserAdd.Click
      AddSubToList("user", m_sType, m_sType, m_pLookup, rlbUsers)
   End Sub

   Private Sub cmdUserRemove_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdUserRemove.Click
      RemoveSubFromList("user", m_sType, m_sType, m_pLookup, rlbUsers)
   End Sub

   Private Sub mnuSubType_Popup(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnuSubType.Popup
      Dim pLookup As Lookup

      pLookup = rlbUsers.SelectedItem

      If Not pLookup Is Nothing Then
         Select Case pLookup.m_iValue
            Case ua.SUBTYPE_SUB
               mnuSubTypeSub.Checked = True
               mnuSubTypeMember.Checked = False
               mnuSubTypeEditor.Checked = False

            Case ua.SUBTYPE_MEMBER
               mnuSubTypeSub.Checked = False
               mnuSubTypeMember.Checked = True
               mnuSubTypeEditor.Checked = False

            Case ua.SUBTYPE_EDITOR
               mnuSubTypeSub.Checked = False
               mnuSubTypeMember.Checked = False
               mnuSubTypeEditor.Checked = True
         End Select
      End If
   End Sub

   Private Sub txtName_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtName.TextChanged
      If m_bUserInput = True Then
         m_pRequest.SetChild("name", txtName.Text)
      End If
   End Sub

   Private Sub cmbAccessLevel_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbAccessLevel.SelectedIndexChanged
      Dim iAccessLevel As Integer

      If m_bUserInput = True Then
         Select Case cmbAccessLevel.SelectedIndex
            Case 0
               'none
               iAccessLevel = -1

            Case 1
               'messages
               iAccessLevel = ua.LEVEL_MESSAGES

            Case 2
               'editor
               iAccessLevel = ua.LEVEL_EDITOR

            Case 3
               'witness
               iAccessLevel = ua.LEVEL_WITNESS
         End Select

         m_pRequest.SetChild("accesslevel", iAccessLevel)
      End If
   End Sub

   Private Sub txtExpiry_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtExpiry.TextChanged
      If m_bUserInput = True Then
         m_pRequest.SetChild("expire", Integer.Parse(txtExpiry.Text) * 86400)
      End If
   End Sub

   Private Sub rtbInfo_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rtbInfo.TextChanged
      If m_bUserInput = True Then
         If m_pRequest.Child("info") = True Then
            m_pRequest.SetChild("text", rtbInfo.Text)
            m_pRequest.Parent()
         End If
      End If
   End Sub

   Private Sub SaveChanges()
      Dim iTreeNum As Integer
      Dim bLoop As Boolean = True
      Dim sName As String
      Dim pLookup As Lookup
      Dim pTree As MessageTreeLookup
      Dim pReply As CEDF

      m_bUserInput = False

      If Not m_pRequest Is Nothing Then
         If m_pRequest.Children() > 0 Then
            If MsgBox("Save changes?", MsgBoxStyle.Question + MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
               m_pRequest.AddChild(m_sType & "id", m_pLookup.m_iID)

               pReply = New CEDF()

               If Client.request3(m_sType & "_edit", m_pRequest, pReply) = True Then
                  sName = pReply.GetChildStr("foldername")

                  If m_sType = "folder" Then
                     pTree = FolderGet(m_pLookup.m_iID)
                  Else
                     pTree = ChannelGet(m_pLookup.m_iID)
                  End If

                  If pTree.m_sValue <> sName Then
                     bLoop = True
                     Do While bLoop = True And iTreeNum < lstItems.Items.Count
                        pLookup = lstItems.Items.Item(iTreeNum)
                        If pLookup.m_iID = m_pLookup.m_iID Then
                           pLookup.m_sValue = sName

                           lstItems.BeginUpdate()
                           lstItems.Items.RemoveAt(iTreeNum)
                           lstItems.Items.Add(pLookup)
                           lstItems.EndUpdate()

                           bLoop = False
                        Else
                           iTreeNum += 1
                        End If
                     Loop

                     pTree.m_sValue = sName

                     m_bUpdate = True
                  End If
               Else
                  pReply.MsgPrint("frmMessageTrees::SaveChanges request failed")
               End If
            End If
         End If
      End If

      m_bUserInput = True
   End Sub
End Class
