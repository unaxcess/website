Imports Microsoft.Win32
Imports org.ua2

Public Class frmOptions
   Inherits System.Windows.Forms.Form

   Private m_bInit As Boolean = True
   Private m_pFixedFont As Font, m_pUnicodeFont As Font
   Private m_pRequest As CEDF

#Region " Windows Form Designer generated code "

   Public Sub New()
      MyBase.New()

      'This call is required by the Windows Form Designer.
      InitializeComponent()

      'Add any initialization after the InitializeComponent() call
      Dim sClient As String

      sUAveFont(Me)
      FormAdd(Me)

      'pCurr = CurrUser()
      If Not Client Is Nothing Then
         If Client.State() = Client.OPEN Then
            m_pRequest = New CEDF()

            cmbViewType.SelectedIndex = Client.GetClientInt("viewtype")
            cmbExpansion.SelectedIndex = Client.GetClientInt("expansion")
            cmbCaching.SelectedIndex = Client.GetClientInt("caching")

            chkReturnSend.Checked = Client.GetClientBool("returnsend")
            chkSysTray.Checked = Client.GetClientBool("systray")
            chkHide.Checked = Client.GetClientBool("hide")
            chkBusy.Checked = Client.GetClientBool("busy")
            chkFakePage.Checked = Client.GetClientBool("fakepage")

            chkCustomColours.Checked = Client.GetClientBool("customcolours")
            chkCustomPictures.Checked = Client.GetClientBool("custompictures")

            cmbCatchupAction.SelectedIndex = Client.GetClientInt("catchupaction")
         Else
            tabOptions.Controls.Remove(tbpGeneral)
            tabOptions.Controls.Remove(tbpFolders)
            tabOptions.Controls.Remove(tbpWholist)
         End If
      Else
         tabOptions.Controls.Remove(tbpGeneral)
         tabOptions.Controls.Remove(tbpFolders)
         tabOptions.Controls.Remove(tbpWholist)
      End If

      m_pFixedFont = FixedFont()
      m_pUnicodeFont = UnicodeFont()

      FontSettings(lblFont1)

      FontSettings(lblFont2)

      m_bInit = False
   End Sub

   'Form overrides dispose to clean up the component list.
   Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
      If disposing Then
         FormRemove(Me)

         If Not (components Is Nothing) Then
            components.Dispose()
         End If
      End If
      MyBase.Dispose(disposing)
   End Sub

   Friend WithEvents lblExpansion As System.Windows.Forms.Label
   Friend WithEvents cmbExpansion As System.Windows.Forms.ComboBox
   Friend WithEvents tabOptions As System.Windows.Forms.TabControl
   Friend WithEvents cmdOK As System.Windows.Forms.Button
   Friend WithEvents cmdCancel As System.Windows.Forms.Button
   Friend WithEvents lblViewType As System.Windows.Forms.Label
   Friend WithEvents cmbViewType As System.Windows.Forms.ComboBox
   Friend WithEvents lblCaching As System.Windows.Forms.Label
   Friend WithEvents cmbCaching As System.Windows.Forms.ComboBox

   'Required by the Windows Form Designer
   Private components As System.ComponentModel.IContainer

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   Friend WithEvents tbpGeneral As System.Windows.Forms.TabPage
   Friend WithEvents tbpFolders As System.Windows.Forms.TabPage
   Friend WithEvents tbpWholist As System.Windows.Forms.TabPage
   Friend WithEvents chkCustomPictures As System.Windows.Forms.CheckBox
   Friend WithEvents chkHide As System.Windows.Forms.CheckBox
   Friend WithEvents chkBusy As System.Windows.Forms.CheckBox
   Friend WithEvents chkReturnSend As System.Windows.Forms.CheckBox
   Friend WithEvents chkSysTray As System.Windows.Forms.CheckBox
   Friend WithEvents chkFakePage As System.Windows.Forms.CheckBox
   Friend WithEvents chkCustomColours As System.Windows.Forms.CheckBox
   Friend WithEvents tbpLocal As System.Windows.Forms.TabPage
   Friend WithEvents cmdFont1 As System.Windows.Forms.Button
   Friend WithEvents lblFont1 As System.Windows.Forms.Label
   Friend WithEvents cmdFont2 As System.Windows.Forms.Button
   Friend WithEvents lblFont2 As System.Windows.Forms.Label
   Friend WithEvents chkFreeFormSearch As System.Windows.Forms.CheckBox
   Friend WithEvents lblCatchupAction As System.Windows.Forms.Label
   Friend WithEvents cmbCatchupAction As System.Windows.Forms.ComboBox
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Me.cmbExpansion = New System.Windows.Forms.ComboBox()
      Me.tabOptions = New System.Windows.Forms.TabControl()
      Me.tbpLocal = New System.Windows.Forms.TabPage()
      Me.cmdFont1 = New System.Windows.Forms.Button()
      Me.lblFont1 = New System.Windows.Forms.Label()
      Me.cmdFont2 = New System.Windows.Forms.Button()
      Me.lblFont2 = New System.Windows.Forms.Label()
      Me.tbpGeneral = New System.Windows.Forms.TabPage()
      Me.chkHide = New System.Windows.Forms.CheckBox()
      Me.chkBusy = New System.Windows.Forms.CheckBox()
      Me.chkReturnSend = New System.Windows.Forms.CheckBox()
      Me.chkSysTray = New System.Windows.Forms.CheckBox()
      Me.lblViewType = New System.Windows.Forms.Label()
      Me.cmbViewType = New System.Windows.Forms.ComboBox()
      Me.tbpFolders = New System.Windows.Forms.TabPage()
      Me.cmbCatchupAction = New System.Windows.Forms.ComboBox()
      Me.lblCatchupAction = New System.Windows.Forms.Label()
      Me.chkFreeFormSearch = New System.Windows.Forms.CheckBox()
      Me.chkFakePage = New System.Windows.Forms.CheckBox()
      Me.lblCaching = New System.Windows.Forms.Label()
      Me.cmbCaching = New System.Windows.Forms.ComboBox()
      Me.lblExpansion = New System.Windows.Forms.Label()
      Me.tbpWholist = New System.Windows.Forms.TabPage()
      Me.chkCustomColours = New System.Windows.Forms.CheckBox()
      Me.chkCustomPictures = New System.Windows.Forms.CheckBox()
      Me.cmdCancel = New System.Windows.Forms.Button()
      Me.cmdOK = New System.Windows.Forms.Button()
      Me.tabOptions.SuspendLayout()
      Me.tbpLocal.SuspendLayout()
      Me.tbpGeneral.SuspendLayout()
      Me.tbpFolders.SuspendLayout()
      Me.tbpWholist.SuspendLayout()
      Me.SuspendLayout()
      '
      'cmbExpansion
      '
      Me.cmbExpansion.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
      Me.cmbExpansion.DropDownWidth = 144
      Me.cmbExpansion.Items.AddRange(New Object() {"Always", "Only to new messages", "Never"})
      Me.cmbExpansion.Location = New System.Drawing.Point(80, 8)
      Me.cmbExpansion.Name = "cmbExpansion"
      Me.cmbExpansion.Size = New System.Drawing.Size(136, 21)
      Me.cmbExpansion.TabIndex = 1
      '
      'tabOptions
      '
      Me.tabOptions.Controls.AddRange(New System.Windows.Forms.Control() {Me.tbpLocal, Me.tbpGeneral, Me.tbpFolders, Me.tbpWholist})
      Me.tabOptions.Location = New System.Drawing.Point(8, 8)
      Me.tabOptions.Name = "tabOptions"
      Me.tabOptions.SelectedIndex = 0
      Me.tabOptions.Size = New System.Drawing.Size(232, 168)
      Me.tabOptions.TabIndex = 0
      '
      'tbpLocal
      '
      Me.tbpLocal.Controls.AddRange(New System.Windows.Forms.Control() {Me.cmdFont1, Me.lblFont1, Me.cmdFont2, Me.lblFont2})
      Me.tbpLocal.Location = New System.Drawing.Point(4, 22)
      Me.tbpLocal.Name = "tbpLocal"
      Me.tbpLocal.Size = New System.Drawing.Size(224, 142)
      Me.tbpLocal.TabIndex = 3
      Me.tbpLocal.Text = "Local"
      '
      'cmdFont1
      '
      Me.cmdFont1.FlatStyle = System.Windows.Forms.FlatStyle.System
      Me.cmdFont1.Location = New System.Drawing.Point(144, 8)
      Me.cmdFont1.Name = "cmdFont1"
      Me.cmdFont1.Size = New System.Drawing.Size(56, 23)
      Me.cmdFont1.TabIndex = 1
      Me.cmdFont1.Text = "Pick..."
      '
      'lblFont1
      '
      Me.lblFont1.Location = New System.Drawing.Point(8, 8)
      Me.lblFont1.Name = "lblFont1"
      Me.lblFont1.Size = New System.Drawing.Size(144, 23)
      Me.lblFont1.TabIndex = 0
      '
      'cmdFont2
      '
      Me.cmdFont2.FlatStyle = System.Windows.Forms.FlatStyle.System
      Me.cmdFont2.Location = New System.Drawing.Point(144, 40)
      Me.cmdFont2.Name = "cmdFont2"
      Me.cmdFont2.Size = New System.Drawing.Size(56, 23)
      Me.cmdFont2.TabIndex = 3
      Me.cmdFont2.Text = "Pick..."
      '
      'lblFont2
      '
      Me.lblFont2.Location = New System.Drawing.Point(8, 40)
      Me.lblFont2.Name = "lblFont2"
      Me.lblFont2.Size = New System.Drawing.Size(144, 23)
      Me.lblFont2.TabIndex = 2
      '
      'tbpGeneral
      '
      Me.tbpGeneral.Controls.AddRange(New System.Windows.Forms.Control() {Me.chkHide, Me.chkBusy, Me.chkReturnSend, Me.chkSysTray, Me.lblViewType, Me.cmbViewType})
      Me.tbpGeneral.Location = New System.Drawing.Point(4, 22)
      Me.tbpGeneral.Name = "tbpGeneral"
      Me.tbpGeneral.Size = New System.Drawing.Size(224, 142)
      Me.tbpGeneral.TabIndex = 1
      Me.tbpGeneral.Text = "General"
      '
      'chkHide
      '
      Me.chkHide.FlatStyle = System.Windows.Forms.FlatStyle.System
      Me.chkHide.Location = New System.Drawing.Point(72, 80)
      Me.chkHide.Name = "chkHide"
      Me.chkHide.Size = New System.Drawing.Size(136, 24)
      Me.chkHide.TabIndex = 4
      Me.chkHide.Text = "Hide when minimized"
      '
      'chkBusy
      '
      Me.chkBusy.FlatStyle = System.Windows.Forms.FlatStyle.System
      Me.chkBusy.Location = New System.Drawing.Point(72, 104)
      Me.chkBusy.Name = "chkBusy"
      Me.chkBusy.Size = New System.Drawing.Size(136, 24)
      Me.chkBusy.TabIndex = 5
      Me.chkBusy.Text = "Busy when minimized"
      '
      'chkReturnSend
      '
      Me.chkReturnSend.FlatStyle = System.Windows.Forms.FlatStyle.System
      Me.chkReturnSend.Location = New System.Drawing.Point(72, 32)
      Me.chkReturnSend.Name = "chkReturnSend"
      Me.chkReturnSend.Size = New System.Drawing.Size(144, 24)
      Me.chkReturnSend.TabIndex = 2
      Me.chkReturnSend.Text = "Return sends message"
      '
      'chkSysTray
      '
      Me.chkSysTray.FlatStyle = System.Windows.Forms.FlatStyle.System
      Me.chkSysTray.Location = New System.Drawing.Point(72, 56)
      Me.chkSysTray.Name = "chkSysTray"
      Me.chkSysTray.Size = New System.Drawing.Size(112, 24)
      Me.chkSysTray.TabIndex = 3
      Me.chkSysTray.Text = "System tray icon"
      '
      'lblViewType
      '
      Me.lblViewType.Location = New System.Drawing.Point(8, 8)
      Me.lblViewType.Name = "lblViewType"
      Me.lblViewType.Size = New System.Drawing.Size(64, 23)
      Me.lblViewType.TabIndex = 0
      Me.lblViewType.Text = "Dropdowns"
      '
      'cmbViewType
      '
      Me.cmbViewType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
      Me.cmbViewType.DropDownWidth = 144
      Me.cmbViewType.Items.AddRange(New Object() {"User / folder", "User only", "None"})
      Me.cmbViewType.Location = New System.Drawing.Point(72, 8)
      Me.cmbViewType.Name = "cmbViewType"
      Me.cmbViewType.Size = New System.Drawing.Size(136, 21)
      Me.cmbViewType.TabIndex = 1
      '
      'tbpFolders
      '
      Me.tbpFolders.Controls.AddRange(New System.Windows.Forms.Control() {Me.cmbCatchupAction, Me.lblCatchupAction, Me.chkFreeFormSearch, Me.chkFakePage, Me.lblCaching, Me.cmbCaching, Me.lblExpansion, Me.cmbExpansion})
      Me.tbpFolders.Location = New System.Drawing.Point(4, 22)
      Me.tbpFolders.Name = "tbpFolders"
      Me.tbpFolders.Size = New System.Drawing.Size(224, 142)
      Me.tbpFolders.TabIndex = 0
      Me.tbpFolders.Text = "Folders"
      '
      'cmbCatchupAction
      '
      Me.cmbCatchupAction.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
      Me.cmbCatchupAction.Items.AddRange(New Object() {"Message and replies", "Whole thread"})
      Me.cmbCatchupAction.Location = New System.Drawing.Point(88, 112)
      Me.cmbCatchupAction.Name = "cmbCatchupAction"
      Me.cmbCatchupAction.Size = New System.Drawing.Size(128, 21)
      Me.cmbCatchupAction.TabIndex = 7
      '
      'lblCatchupAction
      '
      Me.lblCatchupAction.Location = New System.Drawing.Point(8, 112)
      Me.lblCatchupAction.Name = "lblCatchupAction"
      Me.lblCatchupAction.Size = New System.Drawing.Size(80, 24)
      Me.lblCatchupAction.TabIndex = 6
      Me.lblCatchupAction.Text = "Catchup action"
      '
      'chkFreeFormSearch
      '
      Me.chkFreeFormSearch.Location = New System.Drawing.Point(72, 88)
      Me.chkFreeFormSearch.Name = "chkFreeFormSearch"
      Me.chkFreeFormSearch.Size = New System.Drawing.Size(128, 16)
      Me.chkFreeFormSearch.TabIndex = 5
      Me.chkFreeFormSearch.Text = "Free form searches"
      '
      'chkFakePage
      '
      Me.chkFakePage.FlatStyle = System.Windows.Forms.FlatStyle.System
      Me.chkFakePage.Location = New System.Drawing.Point(72, 64)
      Me.chkFakePage.Name = "chkFakePage"
      Me.chkFakePage.Size = New System.Drawing.Size(144, 24)
      Me.chkFakePage.TabIndex = 54
      Me.chkFakePage.Text = "Instant private messages"
      '
      'lblCaching
      '
      Me.lblCaching.Location = New System.Drawing.Point(8, 32)
      Me.lblCaching.Name = "lblCaching"
      Me.lblCaching.Size = New System.Drawing.Size(48, 23)
      Me.lblCaching.TabIndex = 2
      Me.lblCaching.Text = "Caching"
      '
      'cmbCaching
      '
      Me.cmbCaching.DropDownWidth = 144
      Me.cmbCaching.Items.AddRange(New Object() {"None", "Message lists", "Full"})
      Me.cmbCaching.Location = New System.Drawing.Point(80, 32)
      Me.cmbCaching.Name = "cmbCaching"
      Me.cmbCaching.Size = New System.Drawing.Size(136, 21)
      Me.cmbCaching.TabIndex = 3
      '
      'lblExpansion
      '
      Me.lblExpansion.Location = New System.Drawing.Point(8, 8)
      Me.lblExpansion.Name = "lblExpansion"
      Me.lblExpansion.Size = New System.Drawing.Size(64, 23)
      Me.lblExpansion.TabIndex = 0
      Me.lblExpansion.Text = "Expansion"
      '
      'tbpWholist
      '
      Me.tbpWholist.Controls.AddRange(New System.Windows.Forms.Control() {Me.chkCustomColours, Me.chkCustomPictures})
      Me.tbpWholist.Location = New System.Drawing.Point(4, 22)
      Me.tbpWholist.Name = "tbpWholist"
      Me.tbpWholist.Size = New System.Drawing.Size(224, 142)
      Me.tbpWholist.TabIndex = 2
      Me.tbpWholist.Text = "Wholist"
      '
      'chkCustomColours
      '
      Me.chkCustomColours.Location = New System.Drawing.Point(8, 8)
      Me.chkCustomColours.Name = "chkCustomColours"
      Me.chkCustomColours.TabIndex = 0
      Me.chkCustomColours.Text = "Custom colours"
      '
      'chkCustomPictures
      '
      Me.chkCustomPictures.Location = New System.Drawing.Point(8, 32)
      Me.chkCustomPictures.Name = "chkCustomPictures"
      Me.chkCustomPictures.Size = New System.Drawing.Size(112, 24)
      Me.chkCustomPictures.TabIndex = 1
      Me.chkCustomPictures.Text = "Custom pictures"
      '
      'cmdCancel
      '
      Me.cmdCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
      Me.cmdCancel.FlatStyle = System.Windows.Forms.FlatStyle.System
      Me.cmdCancel.Location = New System.Drawing.Point(168, 184)
      Me.cmdCancel.Name = "cmdCancel"
      Me.cmdCancel.TabIndex = 1
      Me.cmdCancel.Text = "Cancel"
      '
      'cmdOK
      '
      Me.cmdOK.FlatStyle = System.Windows.Forms.FlatStyle.System
      Me.cmdOK.Location = New System.Drawing.Point(88, 184)
      Me.cmdOK.Name = "cmdOK"
      Me.cmdOK.Size = New System.Drawing.Size(72, 23)
      Me.cmdOK.TabIndex = 0
      Me.cmdOK.Text = "OK"
      '
      'frmOptions
      '
      Me.AcceptButton = Me.cmdOK
      Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
      Me.CancelButton = Me.cmdCancel
      Me.ClientSize = New System.Drawing.Size(250, 216)
      Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.tabOptions, Me.cmdCancel, Me.cmdOK})
      Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
      Me.MaximizeBox = False
      Me.MinimizeBox = False
      Me.Name = "frmOptions"
      Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
      Me.Text = "Options"
      Me.tabOptions.ResumeLayout(False)
      Me.tbpLocal.ResumeLayout(False)
      Me.tbpGeneral.ResumeLayout(False)
      Me.tbpFolders.ResumeLayout(False)
      Me.tbpWholist.ResumeLayout(False)
      Me.ResumeLayout(False)

   End Sub

#End Region

   Private Sub cmdOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdOK.Click
      Dim pSettings As RegistryKey

      pSettings = GetRegSection()
      pSettings.SetValue("fixedfontname", m_pFixedFont.Name)
      pSettings.SetValue("fixedfontsize", m_pFixedFont.Size)
      FixedFont(m_pFixedFont)
      If Not m_pUnicodeFont Is Nothing Then
         pSettings.SetValue("unicodefontname", m_pUnicodeFont.Name)
         pSettings.SetValue("unicodefontsize", m_pUnicodeFont.Size)
         UnicodeFont(m_pUnicodeFont)
      End If

      Me.DialogResult = DialogResult.OK
   End Sub

   Public Function GetRequest() As CEDF
      Return m_pRequest
   End Function

   Private Sub chkReturnSend_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkReturnSend.CheckedChanged
      Dim iValue As Integer

      If chkReturnSend.Checked = True Then
         iValue = 1
      End If

      If m_bInit = False Then
         m_pRequest.SetChild("returnsend", iValue)
      End If
   End Sub

   Private Sub cmbViewType_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbViewType.SelectedIndexChanged
      If m_bInit = False Then
         m_pRequest.SetChild("viewtype", cmbViewType.SelectedIndex)
      End If
   End Sub

   Private Sub cmbExpansion_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbExpansion.SelectedIndexChanged
      If m_bInit = False Then
         m_pRequest.SetChild("expansion", cmbExpansion.SelectedIndex)
      End If
   End Sub

   Private Sub cmbCaching_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbCaching.SelectedIndexChanged
      If m_bInit = False Then
         m_pRequest.SetChild("caching", cmbCaching.SelectedIndex)
      End If
   End Sub

   Private Sub chkSysTray_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkSysTray.CheckedChanged
      Dim iValue As Integer

      If chkSysTray.Checked = True Then
         iValue = 1
      End If

      If m_bInit = False Then
         m_pRequest.SetChild("systray", iValue)
      End If
   End Sub

   Private Sub chkHide_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkHide.CheckedChanged
      Dim iValue As Integer

      If chkHide.Checked = True Then
         iValue = 1
      End If

      If m_bInit = False Then
         m_pRequest.SetChild("hide", iValue)
      End If
   End Sub

   Private Sub chkBusy_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkBusy.CheckedChanged
      Dim iValue As Integer

      If chkBusy.Checked = True Then
         iValue = 1
      End If

      If m_bInit = False Then
         m_pRequest.SetChild("busy", iValue)
      End If
   End Sub

   Private Sub cmdFont1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdFont1.Click
      FontSettings(lblFont1, True)
   End Sub

   Private Sub cmdFont2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdFont2.Click
      FontSettings(lblFont2, True)
   End Sub

   Private Function FontSettings(ByRef pLabel As Label, Optional ByVal bSet As Boolean = False) As Boolean
      Dim sTitle As String
      Dim pFont As Font
      Dim pFontPicker As FontDialog

      If pLabel Is lblFont1 Then
         sTitle = "Fixed"
      ElseIf pLabel Is lblFont2 Then
         sTitle = "Unicode"
      Else
         Return False
      End If

      If bSet = True Then
         pFontPicker = New FontDialog()
         pFontPicker.Font = pFont
         If pFontPicker.ShowDialog() = DialogResult.OK Then
            pFont = pFontPicker.Font

            If pLabel Is lblFont1 Then
               m_pFixedFont = pFont
            Else
               m_pUnicodeFont = pFont
            End If
         End If
      Else
         If pLabel Is lblFont1 Then
            pFont = m_pFixedFont
         Else
            pFont = m_pUnicodeFont
         End If
      End If

      If Not pFont Is Nothing Then
         pLabel.Text = sTitle & ": " & pFont.Name & " " & pFont.Size & " point"
      End If

      Return True
   End Function

   Private Sub chkFakePage_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkFakePage.CheckedChanged
      Dim iValue As Integer

      If chkFakePage.Checked = True Then
         iValue = 1
      End If

      If m_bInit = False Then
         m_pRequest.SetChild("fakepage", iValue)
      End If
   End Sub

   Private Sub chkCustomPictures_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkCustomPictures.CheckedChanged
      Dim iValue As Integer

      If chkCustomPictures.Checked = True Then
         iValue = 1
      End If

      If m_bInit = False Then
         m_pRequest.SetChild("custompictures", iValue)
      End If
   End Sub

   Private Sub chkCustomColours_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkCustomColours.CheckedChanged
      Dim iValue As Integer

      If chkCustomColours.Checked = True Then
         iValue = 1
      End If

      If m_bInit = False Then
         m_pRequest.SetChild("customcolours", iValue)
      End If
   End Sub

   Private Sub chkFreeFormSearch_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkFreeFormSearch.CheckedChanged
      Dim iValue As Integer

      If chkFreeFormSearch.Checked = True Then
         iValue = 1
      End If

      If m_bInit = False Then
         m_pRequest.SetChild("freeformsearch", iValue)
      End If
   End Sub

   Private Sub cmbCatchupAction_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbCatchupAction.SelectedIndexChanged
      If m_bInit = False Then
         m_pRequest.SetChild("catchupaction", cmbCatchupAction.SelectedIndex)
      End If
   End Sub
End Class
