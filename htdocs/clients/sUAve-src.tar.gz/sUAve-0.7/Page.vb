Imports org.ua2

Public Class frmPage
   Inherits System.Windows.Forms.Form

   Private m_iFromID As Integer
   Private m_sFromName As String
   Private m_iServiceID As Integer
   Private m_bHandled As Boolean
   Private m_bInit As Boolean = True
   Private m_pRequest As CEDF
   Public m_bReturnSend As Boolean
   Private m_iContactType As Integer = -1
   Private m_bUserInput As Boolean = True

#Region " Windows Form Designer generated code "

   Public Sub New(ByRef pUser As UserLookup, ByRef pPage As CEDF)
      MyBase.New()

      'This call is required by the Windows Form Designer.
      InitializeComponent()

      'Add any initialization after the InitializeComponent() call

      sUAveFont(Me)
      FormAdd(Me)

      cmbContact.SelectedIndex = 0

      chkReturnSend.Checked = Client.GetClientBool("returnsend")

      rcbTo.ImageList = sUAveHelper.m_pImageList

      SetData(pUser, pPage)
   End Sub

   'Form overrides dispose to clean up the component list.
   Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
      If disposing Then
         FormRemove(Me)

         If Not (components Is Nothing) Then
            components.Dispose()
         End If
      End If
      MyBase.Dispose(disposing)
   End Sub

   Friend WithEvents cmdClose As System.Windows.Forms.Button
   Friend WithEvents chkReturnSend As System.Windows.Forms.CheckBox
   Friend WithEvents cmdFiles As System.Windows.Forms.Button
   Friend WithEvents chkKeepOpen As System.Windows.Forms.CheckBox
   Friend WithEvents cmdSend As System.Windows.Forms.Button
   Friend WithEvents txtText As System.Windows.Forms.TextBox
   Friend WithEvents pnlBottom As System.Windows.Forms.Panel
   Friend WithEvents rtbContent As System.Windows.Forms.RichTextBox
   Friend WithEvents pnlText As System.Windows.Forms.Panel
   Friend WithEvents splContent As System.Windows.Forms.Splitter
   Friend WithEvents pnlFrom As System.Windows.Forms.Panel

   'Required by the Windows Form Designer
   Private components As System.ComponentModel.IContainer

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   Friend WithEvents pnlActions As System.Windows.Forms.Panel
   Friend WithEvents pnlTop As System.Windows.Forms.Panel
   Friend WithEvents pnlLabels As System.Windows.Forms.Panel
   Friend WithEvents pnlValues As System.Windows.Forms.Panel
   Friend WithEvents lblSubject As System.Windows.Forms.Label
   Friend WithEvents lblCustomTo As System.Windows.Forms.Label
   Friend WithEvents lblContact As System.Windows.Forms.Label
   Friend WithEvents lblTo As System.Windows.Forms.Label
   Friend WithEvents rcbTo As RichControl.RichComboBox
   Friend WithEvents txtCustomTo As System.Windows.Forms.TextBox
   Friend WithEvents txtSubject As System.Windows.Forms.TextBox
   Friend WithEvents cmbContact As System.Windows.Forms.ComboBox
   Friend WithEvents pnlTo As System.Windows.Forms.Panel
   Friend WithEvents pnlSubject As System.Windows.Forms.Panel
   Friend WithEvents pnlCustomTo As System.Windows.Forms.Panel
   Friend WithEvents pnlContact As System.Windows.Forms.Panel
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmPage))
      Me.cmdClose = New System.Windows.Forms.Button()
      Me.chkKeepOpen = New System.Windows.Forms.CheckBox()
      Me.cmdFiles = New System.Windows.Forms.Button()
      Me.cmdSend = New System.Windows.Forms.Button()
      Me.chkReturnSend = New System.Windows.Forms.CheckBox()
      Me.pnlText = New System.Windows.Forms.Panel()
      Me.txtText = New System.Windows.Forms.TextBox()
      Me.pnlBottom = New System.Windows.Forms.Panel()
      Me.pnlActions = New System.Windows.Forms.Panel()
      Me.rtbContent = New System.Windows.Forms.RichTextBox()
      Me.splContent = New System.Windows.Forms.Splitter()
      Me.pnlFrom = New System.Windows.Forms.Panel()
      Me.pnlTop = New System.Windows.Forms.Panel()
      Me.pnlValues = New System.Windows.Forms.Panel()
      Me.pnlSubject = New System.Windows.Forms.Panel()
      Me.txtSubject = New System.Windows.Forms.TextBox()
      Me.pnlCustomTo = New System.Windows.Forms.Panel()
      Me.txtCustomTo = New System.Windows.Forms.TextBox()
      Me.pnlTo = New System.Windows.Forms.Panel()
      Me.rcbTo = New RichControl.RichComboBox()
      Me.pnlContact = New System.Windows.Forms.Panel()
      Me.cmbContact = New System.Windows.Forms.ComboBox()
      Me.pnlLabels = New System.Windows.Forms.Panel()
      Me.lblSubject = New System.Windows.Forms.Label()
      Me.lblCustomTo = New System.Windows.Forms.Label()
      Me.lblContact = New System.Windows.Forms.Label()
      Me.lblTo = New System.Windows.Forms.Label()
      Me.pnlText.SuspendLayout()
      Me.pnlBottom.SuspendLayout()
      Me.pnlActions.SuspendLayout()
      Me.pnlFrom.SuspendLayout()
      Me.pnlTop.SuspendLayout()
      Me.pnlValues.SuspendLayout()
      Me.pnlSubject.SuspendLayout()
      Me.pnlCustomTo.SuspendLayout()
      Me.pnlTo.SuspendLayout()
      Me.pnlContact.SuspendLayout()
      Me.pnlLabels.SuspendLayout()
      Me.SuspendLayout()
      '
      'cmdClose
      '
      Me.cmdClose.DialogResult = System.Windows.Forms.DialogResult.Cancel
      Me.cmdClose.FlatStyle = System.Windows.Forms.FlatStyle.System
      Me.cmdClose.Location = New System.Drawing.Point(88, 48)
      Me.cmdClose.Name = "cmdClose"
      Me.cmdClose.TabIndex = 1
      Me.cmdClose.Text = "Close"
      '
      'chkKeepOpen
      '
      Me.chkKeepOpen.FlatStyle = System.Windows.Forms.FlatStyle.System
      Me.chkKeepOpen.Location = New System.Drawing.Point(8, 24)
      Me.chkKeepOpen.Name = "chkKeepOpen"
      Me.chkKeepOpen.Size = New System.Drawing.Size(80, 16)
      Me.chkKeepOpen.TabIndex = 1
      Me.chkKeepOpen.Text = "Keep open"
      '
      'cmdFiles
      '
      Me.cmdFiles.FlatStyle = System.Windows.Forms.FlatStyle.System
      Me.cmdFiles.Location = New System.Drawing.Point(8, 48)
      Me.cmdFiles.Name = "cmdFiles"
      Me.cmdFiles.Size = New System.Drawing.Size(56, 23)
      Me.cmdFiles.TabIndex = 2
      Me.cmdFiles.Text = "Files..."
      '
      'cmdSend
      '
      Me.cmdSend.Enabled = False
      Me.cmdSend.FlatStyle = System.Windows.Forms.FlatStyle.System
      Me.cmdSend.Location = New System.Drawing.Point(8, 48)
      Me.cmdSend.Name = "cmdSend"
      Me.cmdSend.TabIndex = 0
      Me.cmdSend.Text = "&Send"
      '
      'chkReturnSend
      '
      Me.chkReturnSend.FlatStyle = System.Windows.Forms.FlatStyle.System
      Me.chkReturnSend.Location = New System.Drawing.Point(8, 8)
      Me.chkReturnSend.Name = "chkReturnSend"
      Me.chkReturnSend.Size = New System.Drawing.Size(152, 16)
      Me.chkReturnSend.TabIndex = 0
      Me.chkReturnSend.Text = "Return sends message"
      '
      'pnlText
      '
      Me.pnlText.Controls.AddRange(New System.Windows.Forms.Control() {Me.txtText})
      Me.pnlText.Dock = System.Windows.Forms.DockStyle.Bottom
      Me.pnlText.DockPadding.Left = 8
      Me.pnlText.DockPadding.Right = 8
      Me.pnlText.DockPadding.Top = 4
      Me.pnlText.Location = New System.Drawing.Point(0, 208)
      Me.pnlText.Name = "pnlText"
      Me.pnlText.Size = New System.Drawing.Size(320, 117)
      Me.pnlText.TabIndex = 2
      '
      'txtText
      '
      Me.txtText.AcceptsTab = True
      Me.txtText.Dock = System.Windows.Forms.DockStyle.Fill
      Me.txtText.Location = New System.Drawing.Point(8, 4)
      Me.txtText.Multiline = True
      Me.txtText.Name = "txtText"
      Me.txtText.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
      Me.txtText.Size = New System.Drawing.Size(304, 113)
      Me.txtText.TabIndex = 0
      Me.txtText.Text = ""
      '
      'pnlBottom
      '
      Me.pnlBottom.Controls.AddRange(New System.Windows.Forms.Control() {Me.pnlActions, Me.cmdFiles, Me.chkReturnSend, Me.chkKeepOpen})
      Me.pnlBottom.Dock = System.Windows.Forms.DockStyle.Bottom
      Me.pnlBottom.Location = New System.Drawing.Point(0, 325)
      Me.pnlBottom.Name = "pnlBottom"
      Me.pnlBottom.Size = New System.Drawing.Size(320, 80)
      Me.pnlBottom.TabIndex = 3
      '
      'pnlActions
      '
      Me.pnlActions.Controls.AddRange(New System.Windows.Forms.Control() {Me.cmdClose, Me.cmdSend})
      Me.pnlActions.Dock = System.Windows.Forms.DockStyle.Right
      Me.pnlActions.Location = New System.Drawing.Point(152, 0)
      Me.pnlActions.Name = "pnlActions"
      Me.pnlActions.Size = New System.Drawing.Size(168, 80)
      Me.pnlActions.TabIndex = 3
      '
      'rtbContent
      '
      Me.rtbContent.Dock = System.Windows.Forms.DockStyle.Fill
      Me.rtbContent.Location = New System.Drawing.Point(8, 4)
      Me.rtbContent.Name = "rtbContent"
      Me.rtbContent.ReadOnly = True
      Me.rtbContent.Size = New System.Drawing.Size(304, 91)
      Me.rtbContent.TabIndex = 0
      Me.rtbContent.Text = ""
      '
      'splContent
      '
      Me.splContent.Dock = System.Windows.Forms.DockStyle.Top
      Me.splContent.Location = New System.Drawing.Point(0, 109)
      Me.splContent.Name = "splContent"
      Me.splContent.Size = New System.Drawing.Size(320, 3)
      Me.splContent.TabIndex = 1
      Me.splContent.TabStop = False
      '
      'pnlFrom
      '
      Me.pnlFrom.Controls.AddRange(New System.Windows.Forms.Control() {Me.rtbContent})
      Me.pnlFrom.Dock = System.Windows.Forms.DockStyle.Fill
      Me.pnlFrom.DockPadding.Bottom = 4
      Me.pnlFrom.DockPadding.Left = 8
      Me.pnlFrom.DockPadding.Right = 8
      Me.pnlFrom.DockPadding.Top = 4
      Me.pnlFrom.Location = New System.Drawing.Point(0, 109)
      Me.pnlFrom.Name = "pnlFrom"
      Me.pnlFrom.Size = New System.Drawing.Size(320, 99)
      Me.pnlFrom.TabIndex = 1
      '
      'pnlTop
      '
      Me.pnlTop.Controls.AddRange(New System.Windows.Forms.Control() {Me.pnlValues, Me.pnlLabels})
      Me.pnlTop.Dock = System.Windows.Forms.DockStyle.Top
      Me.pnlTop.Name = "pnlTop"
      Me.pnlTop.Size = New System.Drawing.Size(320, 109)
      Me.pnlTop.TabIndex = 0
      '
      'pnlValues
      '
      Me.pnlValues.Controls.AddRange(New System.Windows.Forms.Control() {Me.pnlSubject, Me.pnlCustomTo, Me.pnlTo, Me.pnlContact})
      Me.pnlValues.Dock = System.Windows.Forms.DockStyle.Fill
      Me.pnlValues.DockPadding.All = 8
      Me.pnlValues.Location = New System.Drawing.Point(72, 0)
      Me.pnlValues.Name = "pnlValues"
      Me.pnlValues.Size = New System.Drawing.Size(248, 109)
      Me.pnlValues.TabIndex = 1
      '
      'pnlSubject
      '
      Me.pnlSubject.Controls.AddRange(New System.Windows.Forms.Control() {Me.txtSubject})
      Me.pnlSubject.Dock = System.Windows.Forms.DockStyle.Top
      Me.pnlSubject.Location = New System.Drawing.Point(8, 83)
      Me.pnlSubject.Name = "pnlSubject"
      Me.pnlSubject.Size = New System.Drawing.Size(232, 21)
      Me.pnlSubject.TabIndex = 3
      '
      'txtSubject
      '
      Me.txtSubject.Dock = System.Windows.Forms.DockStyle.Fill
      Me.txtSubject.Name = "txtSubject"
      Me.txtSubject.Size = New System.Drawing.Size(232, 20)
      Me.txtSubject.TabIndex = 0
      Me.txtSubject.Text = ""
      '
      'pnlCustomTo
      '
      Me.pnlCustomTo.Controls.AddRange(New System.Windows.Forms.Control() {Me.txtCustomTo})
      Me.pnlCustomTo.Dock = System.Windows.Forms.DockStyle.Top
      Me.pnlCustomTo.DockPadding.Bottom = 4
      Me.pnlCustomTo.Location = New System.Drawing.Point(8, 58)
      Me.pnlCustomTo.Name = "pnlCustomTo"
      Me.pnlCustomTo.Size = New System.Drawing.Size(232, 25)
      Me.pnlCustomTo.TabIndex = 2
      '
      'txtCustomTo
      '
      Me.txtCustomTo.Dock = System.Windows.Forms.DockStyle.Fill
      Me.txtCustomTo.Name = "txtCustomTo"
      Me.txtCustomTo.Size = New System.Drawing.Size(232, 20)
      Me.txtCustomTo.TabIndex = 0
      Me.txtCustomTo.Text = ""
      '
      'pnlTo
      '
      Me.pnlTo.Controls.AddRange(New System.Windows.Forms.Control() {Me.rcbTo})
      Me.pnlTo.Dock = System.Windows.Forms.DockStyle.Top
      Me.pnlTo.DockPadding.Bottom = 4
      Me.pnlTo.Location = New System.Drawing.Point(8, 33)
      Me.pnlTo.Name = "pnlTo"
      Me.pnlTo.Size = New System.Drawing.Size(232, 25)
      Me.pnlTo.TabIndex = 1
      '
      'rcbTo
      '
      Me.rcbTo.Dock = System.Windows.Forms.DockStyle.Fill
      Me.rcbTo.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
      Me.rcbTo.DropDownWidth = 240
      Me.rcbTo.ImageList = Nothing
      Me.rcbTo.Name = "rcbTo"
      Me.rcbTo.Size = New System.Drawing.Size(232, 21)
      Me.rcbTo.TabIndex = 0
      '
      'pnlContact
      '
      Me.pnlContact.Controls.AddRange(New System.Windows.Forms.Control() {Me.cmbContact})
      Me.pnlContact.Dock = System.Windows.Forms.DockStyle.Top
      Me.pnlContact.DockPadding.Bottom = 4
      Me.pnlContact.Location = New System.Drawing.Point(8, 8)
      Me.pnlContact.Name = "pnlContact"
      Me.pnlContact.Size = New System.Drawing.Size(232, 25)
      Me.pnlContact.TabIndex = 0
      '
      'cmbContact
      '
      Me.cmbContact.Dock = System.Windows.Forms.DockStyle.Fill
      Me.cmbContact.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
      Me.cmbContact.DropDownWidth = 232
      Me.cmbContact.Items.AddRange(New Object() {"Page", "Override", "Divert"})
      Me.cmbContact.Name = "cmbContact"
      Me.cmbContact.Size = New System.Drawing.Size(232, 21)
      Me.cmbContact.TabIndex = 0
      '
      'pnlLabels
      '
      Me.pnlLabels.Controls.AddRange(New System.Windows.Forms.Control() {Me.lblSubject, Me.lblCustomTo, Me.lblContact, Me.lblTo})
      Me.pnlLabels.Dock = System.Windows.Forms.DockStyle.Left
      Me.pnlLabels.Name = "pnlLabels"
      Me.pnlLabels.Size = New System.Drawing.Size(72, 109)
      Me.pnlLabels.TabIndex = 0
      '
      'lblSubject
      '
      Me.lblSubject.Location = New System.Drawing.Point(8, 84)
      Me.lblSubject.Name = "lblSubject"
      Me.lblSubject.Size = New System.Drawing.Size(48, 16)
      Me.lblSubject.TabIndex = 5
      Me.lblSubject.Text = "Subject"
      '
      'lblCustomTo
      '
      Me.lblCustomTo.Location = New System.Drawing.Point(8, 60)
      Me.lblCustomTo.Name = "lblCustomTo"
      Me.lblCustomTo.Size = New System.Drawing.Size(64, 16)
      Me.lblCustomTo.TabIndex = 4
      Me.lblCustomTo.Text = "To (custom)"
      '
      'lblContact
      '
      Me.lblContact.Location = New System.Drawing.Point(8, 12)
      Me.lblContact.Name = "lblContact"
      Me.lblContact.Size = New System.Drawing.Size(48, 16)
      Me.lblContact.TabIndex = 6
      Me.lblContact.Text = "Contact"
      '
      'lblTo
      '
      Me.lblTo.Location = New System.Drawing.Point(8, 36)
      Me.lblTo.Name = "lblTo"
      Me.lblTo.Size = New System.Drawing.Size(24, 16)
      Me.lblTo.TabIndex = 3
      Me.lblTo.Text = "To"
      '
      'frmPage
      '
      Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
      Me.CancelButton = Me.cmdClose
      Me.ClientSize = New System.Drawing.Size(320, 405)
      Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.splContent, Me.pnlFrom, Me.pnlText, Me.pnlTop, Me.pnlBottom})
      Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
      Me.Name = "frmPage"
      Me.Text = "Page"
      Me.pnlText.ResumeLayout(False)
      Me.pnlBottom.ResumeLayout(False)
      Me.pnlActions.ResumeLayout(False)
      Me.pnlFrom.ResumeLayout(False)
      Me.pnlTop.ResumeLayout(False)
      Me.pnlValues.ResumeLayout(False)
      Me.pnlSubject.ResumeLayout(False)
      Me.pnlCustomTo.ResumeLayout(False)
      Me.pnlTo.ResumeLayout(False)
      Me.pnlContact.ResumeLayout(False)
      Me.pnlLabels.ResumeLayout(False)
      Me.ResumeLayout(False)

   End Sub

#End Region

   Public Function GetFromID()
      Return m_iFromID
   End Function

   Public Function GetFromName() As String
      Return m_sFromName
   End Function

   Public Function GetServiceID() As Integer
      Return m_iServiceID
   End Function

   Private Sub SetData(ByRef pFrom As UserLookup, ByRef pPage As CEDF)
      Dim iFromID As Integer
      Dim sService As String, sSubject As String, sText As String

      If Not pFrom Is Nothing Then
         m_iFromID = pFrom.m_iID
         m_sFromName = pFrom.m_sValue
         m_iServiceID = pFrom.m_iServiceID
         If m_iServiceID > 0 Then
            sService = pFrom.m_sServiceName
         End If

         lblTo.Enabled = False
         rcbTo.Enabled = False
         lblCustomTo.Enabled = False
         txtCustomTo.Enabled = False
      ElseIf Not pPage Is Nothing Then
         m_iFromID = pPage.GetChildInt("fromid")
         m_sFromName = pPage.GetChildStr("fromname")
         m_iServiceID = pPage.GetChildInt("serviceid")
         sService = pPage.GetChildStr("servicename")

         lblTo.Enabled = False
         rcbTo.Enabled = False
         lblCustomTo.Enabled = False
         txtCustomTo.Enabled = False
      Else
         cmbContact.SelectedIndex = 0

         sUAveHelper.ShowUsers(rcbTo, False, False)
      End If

      debugline("frmPage::SetTo " & m_iFromID & " / " & m_sFromName & " " & m_iServiceID & " / " & sService)

      If m_sFromName <> "" Then
         If sService <> "" Then
            Me.Text = m_sFromName & " (" & sService & ") - Page"
         Else
            Me.Text = m_sFromName & " - Page"
         End If
      End If

      If m_iServiceID > 0 Then
         m_bUserInput = False
         cmbContact.Items.Add(New Lookup(0, m_iServiceID, sService))
         cmbContact.SelectedIndex = cmbContact.Items.Count - 1
         cmbContact.Enabled = False
         m_bUserInput = True
      ElseIf Not pFrom Is Nothing Then
         If isLoggedIn(pFrom) = False Or isActive(pFrom.m_iValue) = False Then
            cmbContact.SelectedIndex = 2
         End If
      End If

      If Not pPage Is Nothing Then
         chkKeepOpen.Checked = True

         sSubject = TextDecode(pPage.GetChildStr("subject"))
         sText = TextDecode(pPage.GetChildStr("text"))

         If Not pFrom Is Nothing Then
            If m_sFromName.ToLower() <> pFrom.m_sValue.ToLower() Then
               txtCustomTo.Text = m_sFromName
            End If
         End If

         AddPage(True, sText, sSubject, pPage)
      Else
         rtbContent.Enabled = False
      End If

      If Not pPage Is Nothing Then
         txtText.Focus()
      Else
         rcbTo.Focus()
      End If
   End Sub

   Public Sub AddPage(ByVal bUseFrom As Boolean, ByVal sSubject As String, ByVal sText As String, Optional ByRef pEDF As CEDF = Nothing)
      Dim cColour As Color
      Dim sFromName As String
      Dim pForm As Form

      pForm = FormFocus()

      SaveAttachments(pEDF)

      If Not pEDF Is Nothing Then
         sSubject = pEDF.GetChildStr("subject")
         sText = TextDecode(pEDF.GetChildStr("text"))
      End If

      If Not sText Is Nothing Then
         If sText.Length > 0 Then
            If rtbContent.Text.Length > 0 Then
               rtbContent.AppendText(CRLF)
            End If

            rtbContent.Enabled = True
            If bUseFrom = True Then
               sFromName = m_sFromName
               cColour = SystemColors.ActiveCaption
            Else
               sFromName = Client.GetName()
               cColour = rtbContent.ForeColor
            End If

            txtSubject.Text = sSubject
            UserEmote(rtbContent, TimeHM() & " " & sFromName, sText, cColour)
         End If
      End If

      txtText.Focus()

      If Not pForm Is Nothing Then
         pForm.Focus()
      End If
   End Sub

   Private Sub SendMessage()
      Dim iPageNum As Integer = 1, iUserNum As Integer, iServiceID As Integer = -1
      Dim bFound As Boolean, bReturn As Boolean
      Dim pSubject() As Byte, pText() As Byte
      Dim pReply As CEDF
      Dim pService As ServiceLookup
      Dim pUser As UserLookup

      If m_pRequest Is Nothing Then
         m_pRequest = New CEDF()
      End If

      If m_iServiceID > 0 Then
         m_pRequest.AddChild("serviceid", m_iServiceID)
         m_pRequest.AddChild("toname", m_sFromName)
      Else
         If txtCustomTo.Text <> "" Then
            m_pRequest.AddChild("toid", m_iFromID)
            m_pRequest.AddChild("toname", txtCustomTo.Text)
            m_sFromName = txtCustomTo.Text
         ElseIf rcbTo.Text <> "" Then
            pUser = UserGet(rcbTo.Text)
            If Not pUser Is Nothing Then
               m_pRequest.AddChild("toid", pUser.m_iID)

               m_iFromID = pUser.m_iID
               m_sFromName = pUser.m_sValue
            End If
         Else
            m_pRequest.AddChild("toid", m_iFromID)
         End If

         Select Case cmbContact.SelectedIndex()
            Case 1
               m_pRequest.AddChild("override", True)

            Case 2
               If Client.version("2.6") >= 0 Then
                  m_pRequest.AddChild("divert", True)
               Else
                  m_pRequest.AddChild("contacttype", ua.CONTACT_POST)
               End If

               AddTextField(m_pRequest, "subject", txtSubject.Text, "Diverted Page")
         End Select
      End If

      If txtSubject.Text <> "" Then
         m_pRequest.AddChild("subject", txtSubject.Text)
      End If

      AddTextField(m_pRequest, "text", txtText.Text)

      pReply = New CEDF()

      bReturn = Client.request3(ua.MSG_USER_CONTACT, m_pRequest, pReply)

      m_pRequest = Nothing

      If bReturn = False Then
         pReply.MsgPrint("frmsUAve::SendMessage failed")
      End If

      If chkKeepOpen.Checked = True Then
         AddPage(False, txtSubject.Text, txtText.Text)

         txtText.Text = ""

         cmdSend.Enabled = False

         m_pRequest = Nothing
      Else
         Me.Dispose()
      End If
   End Sub

   Private Sub cmdSend_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSend.Click
      SendMessage()
   End Sub

   Private Sub cmdClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdClose.Click
      Dim iPageNum As Integer = 1
      Dim bAbort As Boolean = True, bFound As Boolean

      'debugline("frmPage::cmdClose text & '" & txtText.Text & "', " & txtText.Text.Length & " chars")

      If txtText.Text.Trim() <> "" Then
         bAbort = AbortEdit()
      End If

      If bAbort = True Then
         Me.Dispose()
      End If
   End Sub

   Private Sub txtText_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtText.KeyDown
      If e.KeyCode = Keys.Enter And e.Control = False And chkReturnSend.Checked = True And cmdSend.Enabled = True Then
         SendMessage()

         m_bHandled = True
      End If
   End Sub

   Private Sub rtbContent_LinkClicked(ByVal sender As Object, ByVal e As System.Windows.Forms.LinkClickedEventArgs) Handles rtbContent.LinkClicked
      System.Diagnostics.Process.Start(GetBrowser(), e.LinkText)
   End Sub

   Private Sub txtText_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtText.TextChanged
      If m_bHandled = True Then
         txtText.Text = ""

         m_bHandled = False
      End If

      If txtText.Text <> "" Then
         cmdSend.Enabled = True
      Else
         cmdSend.Enabled = False
      End If
   End Sub

   Private Sub frmPage_VisibleChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.VisibleChanged
      If m_bInit = True Then
         If Me.Visible = True And m_iFromID > 0 Then
            txtText.Focus()

            m_bInit = False
         End If
      End If
   End Sub

   Private Sub cmdFiles_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdFiles.Click
      If OpenAttachments(m_pRequest) = True Then
         SendMessage()
      End If
   End Sub

   Private Sub rcbTo_Leave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rcbTo.Leave
      SetContactType()
   End Sub

   Private Sub cmbContact_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbContact.SelectedIndexChanged
      Dim iUserNum As Integer
      Dim bLoop As Boolean
      Dim sUsername As String
      Dim pLookup As Lookup
      Dim pUser As UserLookup
      Dim pService As ServiceLookup
      Dim pEDF As CEDF

      If m_bUserInput = True And m_iContactType <> cmbContact.SelectedIndex Then
         m_iContactType = cmbContact.SelectedIndex

         rcbTo.BeginUpdate()

         rcbTo.Items.Clear()

         If cmbContact.SelectedIndex >= 3 Then
            pService = cmbContact.SelectedItem
            'MsgBox("Service " & pService.m_sValue)

            If Not pService.m_pEDF Is Nothing Then
               pEDF = pService.m_pEDF
               bLoop = pEDF.Child("username")
               Do While bLoop = True

               Loop
            End If
         Else
            For iUserNum = 0 To UserCount() - 1
               pUser = UserList(iUserNum)
               If isLoggedIn(pUser) = True Then
                  pLookup = New Lookup(0, pUser.m_iID, pUser.m_sValue)
                  rcbTo.Items.Add(pLookup)
               End If
            Next
         End If

         rcbTo.EndUpdate()
      End If
   End Sub

   Private Sub rcbTo_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rcbTo.SelectedIndexChanged
      SetContactType()
   End Sub

   Private Sub SetContactType()
      Dim pUser As UserLookup

      pUser = UserGet(rcbTo.Text)
      If Not pUser Is Nothing Then
         If isActive(pUser.m_iValue) = True Then
            cmbContact.SelectedIndex = 0
         Else
            cmbContact.SelectedIndex = 2
         End If
      End If
   End Sub

   Private Sub rtbContent_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles rtbContent.KeyUp
      Dim sText As String

      If e.KeyCode = Keys.C And e.Control = True And e.Shift = True Then
         sText = rtbContent.SelectedText

         sText = sText.Replace(vbCr, "")
         sText = sText.Replace(vbLf, "")

         Clipboard.SetDataObject(sText)
      End If
   End Sub
End Class
