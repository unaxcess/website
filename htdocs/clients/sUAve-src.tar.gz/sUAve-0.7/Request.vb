Imports System.Text

Imports org.ua2

Public Class frmRequest
   Inherits System.Windows.Forms.Form

   Private m_iFromID As Integer
   Private m_sFromName As String
   Private m_bHandled As Boolean
   Private m_bInit As Boolean = True
   Private m_pRequest As CEDF
   Public m_bReturnSend As Boolean

   Private Shared m_pForm As Form

#Region " Windows Form Designer generated code "

   Public Sub New()
      MyBase.New()

      'This call is required by the Windows Form Designer.
      InitializeComponent()

      'Add any initialization after the InitializeComponent() call
      sUAveFont(Me)
      m_pForm = FormAdd(Me)
   End Sub

   'Form overrides dispose to clean up the component list.
   Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
      If disposing Then
         FormRemove(Me)
         m_pForm = Nothing

         If Not (components Is Nothing) Then
            components.Dispose()
         End If
      End If
      MyBase.Dispose(disposing)
   End Sub

   Friend WithEvents lblRequest As System.Windows.Forms.Label
   Friend WithEvents txtRequest As System.Windows.Forms.TextBox
   Friend WithEvents txtFields As System.Windows.Forms.TextBox
   Friend WithEvents cmdSend As System.Windows.Forms.Button
   Friend WithEvents cmdClose As System.Windows.Forms.Button
   Friend WithEvents pnlRequest As System.Windows.Forms.Panel
   Friend WithEvents pnlFields As System.Windows.Forms.Panel
   Friend WithEvents pnlReply As System.Windows.Forms.Panel
   Friend WithEvents pnlButtons As System.Windows.Forms.Panel
   Friend WithEvents rtbReply As System.Windows.Forms.RichTextBox

   'Required by the Windows Form Designer
   Private components As System.ComponentModel.IContainer

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   Friend WithEvents lblTiming As System.Windows.Forms.Label
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmRequest))
      Me.pnlReply = New System.Windows.Forms.Panel()
      Me.rtbReply = New System.Windows.Forms.RichTextBox()
      Me.txtFields = New System.Windows.Forms.TextBox()
      Me.txtRequest = New System.Windows.Forms.TextBox()
      Me.pnlFields = New System.Windows.Forms.Panel()
      Me.pnlButtons = New System.Windows.Forms.Panel()
      Me.cmdClose = New System.Windows.Forms.Button()
      Me.cmdSend = New System.Windows.Forms.Button()
      Me.lblRequest = New System.Windows.Forms.Label()
      Me.pnlRequest = New System.Windows.Forms.Panel()
      Me.lblTiming = New System.Windows.Forms.Label()
      Me.pnlReply.SuspendLayout()
      Me.pnlFields.SuspendLayout()
      Me.pnlButtons.SuspendLayout()
      Me.pnlRequest.SuspendLayout()
      Me.SuspendLayout()
      '
      'pnlReply
      '
      Me.pnlReply.Controls.AddRange(New System.Windows.Forms.Control() {Me.rtbReply})
      Me.pnlReply.Dock = System.Windows.Forms.DockStyle.Fill
      Me.pnlReply.DockPadding.Bottom = 8
      Me.pnlReply.DockPadding.Left = 8
      Me.pnlReply.DockPadding.Right = 8
      Me.pnlReply.DockPadding.Top = 4
      Me.pnlReply.Location = New System.Drawing.Point(0, 140)
      Me.pnlReply.Name = "pnlReply"
      Me.pnlReply.Size = New System.Drawing.Size(408, 257)
      Me.pnlReply.TabIndex = 8
      '
      'rtbReply
      '
      Me.rtbReply.Dock = System.Windows.Forms.DockStyle.Fill
      Me.rtbReply.Location = New System.Drawing.Point(8, 4)
      Me.rtbReply.Name = "rtbReply"
      Me.rtbReply.ReadOnly = True
      Me.rtbReply.Size = New System.Drawing.Size(392, 245)
      Me.rtbReply.TabIndex = 0
      Me.rtbReply.Text = ""
      '
      'txtFields
      '
      Me.txtFields.Dock = System.Windows.Forms.DockStyle.Fill
      Me.txtFields.Location = New System.Drawing.Point(8, 8)
      Me.txtFields.Multiline = True
      Me.txtFields.Name = "txtFields"
      Me.txtFields.ScrollBars = System.Windows.Forms.ScrollBars.Both
      Me.txtFields.Size = New System.Drawing.Size(392, 88)
      Me.txtFields.TabIndex = 2
      Me.txtFields.Text = ""
      '
      'txtRequest
      '
      Me.txtRequest.Location = New System.Drawing.Point(64, 8)
      Me.txtRequest.Name = "txtRequest"
      Me.txtRequest.Size = New System.Drawing.Size(176, 20)
      Me.txtRequest.TabIndex = 1
      Me.txtRequest.Text = ""
      '
      'pnlFields
      '
      Me.pnlFields.Controls.AddRange(New System.Windows.Forms.Control() {Me.txtFields})
      Me.pnlFields.Dock = System.Windows.Forms.DockStyle.Top
      Me.pnlFields.DockPadding.Bottom = 4
      Me.pnlFields.DockPadding.Left = 8
      Me.pnlFields.DockPadding.Right = 8
      Me.pnlFields.DockPadding.Top = 8
      Me.pnlFields.Location = New System.Drawing.Point(0, 40)
      Me.pnlFields.Name = "pnlFields"
      Me.pnlFields.Size = New System.Drawing.Size(408, 100)
      Me.pnlFields.TabIndex = 7
      '
      'pnlButtons
      '
      Me.pnlButtons.Controls.AddRange(New System.Windows.Forms.Control() {Me.lblTiming, Me.cmdClose, Me.cmdSend})
      Me.pnlButtons.Dock = System.Windows.Forms.DockStyle.Bottom
      Me.pnlButtons.Location = New System.Drawing.Point(0, 397)
      Me.pnlButtons.Name = "pnlButtons"
      Me.pnlButtons.Size = New System.Drawing.Size(408, 40)
      Me.pnlButtons.TabIndex = 9
      '
      'cmdClose
      '
      Me.cmdClose.DialogResult = System.Windows.Forms.DialogResult.Cancel
      Me.cmdClose.FlatStyle = System.Windows.Forms.FlatStyle.System
      Me.cmdClose.Location = New System.Drawing.Point(328, 8)
      Me.cmdClose.Name = "cmdClose"
      Me.cmdClose.TabIndex = 5
      Me.cmdClose.Text = "Close"
      '
      'cmdSend
      '
      Me.cmdSend.FlatStyle = System.Windows.Forms.FlatStyle.System
      Me.cmdSend.Location = New System.Drawing.Point(248, 8)
      Me.cmdSend.Name = "cmdSend"
      Me.cmdSend.TabIndex = 4
      Me.cmdSend.Text = "Send"
      '
      'lblRequest
      '
      Me.lblRequest.Location = New System.Drawing.Point(8, 8)
      Me.lblRequest.Name = "lblRequest"
      Me.lblRequest.Size = New System.Drawing.Size(56, 23)
      Me.lblRequest.TabIndex = 0
      Me.lblRequest.Text = "Message"
      '
      'pnlRequest
      '
      Me.pnlRequest.Controls.AddRange(New System.Windows.Forms.Control() {Me.txtRequest, Me.lblRequest})
      Me.pnlRequest.Dock = System.Windows.Forms.DockStyle.Top
      Me.pnlRequest.Name = "pnlRequest"
      Me.pnlRequest.Size = New System.Drawing.Size(408, 40)
      Me.pnlRequest.TabIndex = 6
      '
      'lblTiming
      '
      Me.lblTiming.Location = New System.Drawing.Point(8, 8)
      Me.lblTiming.Name = "lblTiming"
      Me.lblTiming.Size = New System.Drawing.Size(240, 23)
      Me.lblTiming.TabIndex = 6
      '
      'frmRequest
      '
      Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
      Me.CancelButton = Me.cmdClose
      Me.ClientSize = New System.Drawing.Size(408, 437)
      Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.pnlReply, Me.pnlButtons, Me.pnlFields, Me.pnlRequest})
      Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
      Me.MaximizeBox = False
      Me.MinimizeBox = False
      Me.Name = "frmRequest"
      Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
      Me.Text = "Request"
      Me.pnlReply.ResumeLayout(False)
      Me.pnlFields.ResumeLayout(False)
      Me.pnlButtons.ResumeLayout(False)
      Me.pnlRequest.ResumeLayout(False)
      Me.ResumeLayout(False)

   End Sub

#End Region

   Private Sub cmdSend_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSend.Click
      Dim sFields As String
      Dim pFields() As Byte
      Dim pEncoder As UTF8Encoding
      Dim pRequest As CEDF, pReply As CEDF

      pRequest = New CEDF()

      pReply = New CEDF()

      If txtFields.Text <> "" Then
         sFields = txtFields.Text
         If sFields.StartsWith("<>") = False Then
            sFields = "<>" & sFields & "</>"
         End If

         pEncoder = New UTF8Encoding()
         pFields = pEncoder.GetBytes(sFields)

         If pRequest.Read(pFields, pFields.Length) >= 0 Then
            Me.Cursor = Cursors.WaitCursor
            Application.DoEvents()

            'pRequest.MsgPrint("frmRequest::cmdSend")

            Client.request3(txtRequest.Text, pRequest, pReply)

            rtbReply.Text = pReply.Write(CEDF.EL_ROOT + CEDF.EL_CURR + CEDF.PR_SPACE + CEDF.PR_CRLF)
            Me.Cursor = Cursors.Default
         Else
            MsgBox("Cannot parse fields", MsgBoxStyle.Exclamation)
         End If
      Else
         Me.Cursor = Cursors.WaitCursor
         Application.DoEvents()

         Client.request2(txtRequest.Text, pReply)
         rtbReply.Text = pReply.Write(CEDF.EL_ROOT + CEDF.EL_CURR + CEDF.PR_SPACE + CEDF.PR_CRLF)

         Me.Cursor = Cursors.Default
      End If
   End Sub

   Private Sub cmdClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdClose.Click
      Me.Dispose()
   End Sub

   Public Shared Function getForm() As Form
      Return m_pForm
   End Function
End Class
