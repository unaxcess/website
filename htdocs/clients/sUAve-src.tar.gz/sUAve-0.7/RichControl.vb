Public Class RichControl
   Public Shared Function GetImage(ByVal pImageList As ImageList, ByVal pItems As Object, ByVal e As System.Windows.Forms.DrawItemEventArgs) As Image
      Dim iImageNum As Integer
      Dim pReturn As Image

      If Not pImageList Is Nothing Then
         If e.Index <> -1 Then
            'iImageNum = m_pItems(e.Index)
            If Not pItems Is Nothing Then
               If pItems.Count > e.Index Then
                  Try
                     iImageNum = pItems(e.Index).ImageIndex()
                  Catch pEx As System.MissingMethodException
                     iImageNum = -1
                  End Try
               End If
            End If
            'Console.WriteLine("RichControl::GetImage index " & e.Index & " -> " & iImageNum)
         Else
            iImageNum = -1
            'Console.WriteLine("RichControl::GetImage no e.index value")
         End If

         If iImageNum <> -1 Then
            If pImageList.Images.Count() >= iImageNum Then
               'Console.WriteLine("RichControl::GetImage using image " & iImageNum)
               pReturn = pImageList.Images(iImageNum)
               If Not pReturn Is Nothing Then
                  'Console.WriteLine("RichControl::GetImage object is image")
               Else
                  Console.WriteLine("RichControl::GetImage nothing image")
               End If
            Else
               Console.WriteLine("RichControl::GetImage not enough images")
            End If
         Else
            'Console.WriteLine("RichControl::GetImage bad image number")
         End If
      Else
         'Console.WriteLine("RichControl::GetImage no image list")
      End If

      Return pReturn
   End Function

   Public Shared Sub Draw(ByVal e As System.Windows.Forms.DrawItemEventArgs, ByVal sText As String, ByVal pImage As Image, ByVal iXPos As Integer, ByVal iYPos As Integer)
      Dim iMarkup As Integer, iDataPos As Integer, iDataLen As Integer, iMarkupLen As Integer
      Dim pBrush As SolidBrush
      Dim pFont As Font
      Dim pSize As SizeF

      pBrush = New SolidBrush(e.ForeColor)

      pFont = New Font(e.Font, e.Font.Style)

      e.DrawBackground()

      If Not pImage Is Nothing Then
         'Console.WriteLine("RichControl::Draw using image")

         e.Graphics.DrawImage(pImage, iXPos, iYPos)
         iXPos += pImage.Width
      Else
         'Console.WriteLine("RichControl::Draw not using image")
      End If

      iDataPos = 0
      iDataLen = sText.Length()
      iMarkup = sText.IndexOf(Chr(31))

      Do While iDataPos < iDataLen
         If iMarkup >= 0 Then
            If iMarkup > iDataPos Then
               iMarkupLen = iMarkup - iDataPos
               'Console.WriteLine("RichControl::Draw text '" & sText.Substring(iDataPos, iMarkupLen) & "' (" & iMarkupLen & " chars from " & iDataPos & " of " & iDataLen & ")")
               e.Graphics.DrawString(sText.Substring(iDataPos, iMarkupLen), pFont, pBrush, iXPos, iYPos)
               pSize = e.Graphics.MeasureString(sText.Substring(iDataPos, iMarkupLen), pFont)
               iXPos = iXPos + pSize.Width
            End If

            'Console.WriteLine("RichControl markup char '" & sText.Substring(iMarkup + 1, 1) & "'")
            'If iMarkup < iDataLen Then
            Select Case sText.Substring(iMarkup + 1, 1)
               Case "B"
                  pFont = New Font(e.Font, e.Font.Style + FontStyle.Bold)

               Case Else
                  pFont = New Font(e.Font, e.Font.Style)
            End Select
            'End If

            iDataPos = iMarkup + 2
            iMarkup = sText.IndexOf(Chr(31), iDataPos)
            'iMarkup = InStr(iDataPos, sText, Chr(31))
         Else
            e.Graphics.DrawString(sText.Substring(iDataPos), pFont, pBrush, iXPos, iYPos)
            iDataPos = iDataLen + 1
         End If
      Loop

      'e.Graphics.DrawString(sText, e.Font, pBrush, iXPos, iYPos)
   End Sub
End Class
