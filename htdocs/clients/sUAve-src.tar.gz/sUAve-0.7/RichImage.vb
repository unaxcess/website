Public Interface RichImage
   Property ImageIndex() As Integer
   Property SelectedImageIndex() As Integer
End Interface
