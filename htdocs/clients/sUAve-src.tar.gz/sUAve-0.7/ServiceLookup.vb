Imports org.ua2

Public Class ServiceLookup
   Inherits Lookup

   Public m_bActive As Boolean
   Public m_pEDF As CEDF

   Public Sub New(ByVal iID As Integer, ByVal sName As String, ByVal iServiceType As Integer, ByVal bActive As Boolean, ByRef pEDF As CEDF)
      MyBase.New(0, iID, iServiceType, sName)

      m_bActive = bActive
      m_pEDF = pEDF
   End Sub
End Class
