Imports org.ua2

Public Class frmSysView
   Inherits System.Windows.Forms.Form

   Dim m_pSystem As CEDF

#Region " Windows Form Designer generated code "

   Public Sub New(ByRef pSystem As CEDF)
      MyBase.New()

      Dim iAccessLevel As Integer, iBuildNum As Integer, iServerTime As Integer, iUptime As Integer
      Dim iRequests As Integer, iAnnounces As Integer, iSent As Integer, iRecieved As Integer
      Dim sEDF As CEDF
      Dim sBanner As String, sName As String, sVersion As String, sBuildDate As String

      m_pSystem = pSystem

      'This call is required by the Windows Form Designer.
      InitializeComponent()

      'Add any initialization after the InitializeComponent() call
      sUAveFont(Me)

      'txtEDF.Text = m_pSystem.Write(CEDF.EL_ROOT + CEDF.PR_SPACE + CEDF.PR_CRLF)

      iAccessLevel = CurrUser.GetChildInt("accesslevel")
      If iAccessLevel >= ua.LEVEL_WITNESS Then
         cmdReload.Visible = True
      End If

      sBanner = m_pSystem.GetChildStr("banner")
      txtBanner.Text = TextConv(sBanner)

      sName = m_pSystem.GetChildStr("name")
      sVersion = m_pSystem.GetChildStr("version")
      iBuildNum = m_pSystem.GetChildInt("buildnum")
      sBuildDate = m_pSystem.GetChildStr("builddate")
      Me.Text = sName & " v" & sVersion & ", build " & iBuildNum & " (" & sBuildDate & ")"

      iServerTime = m_pSystem.GetChildInt("systemtime")
      iUptime = iServerTime - m_pSystem.GetChildInt("uptime")
      lblTime.Text = "Server time: " & StrTime(STRTIME_TIME, iServerTime, False) & " (up " & iUptime & ")"

      iRequests = m_pSystem.GetChildInt("requests")
      iAnnounces = m_pSystem.GetChildInt("announces")
      iSent = m_pSystem.GetChildInt("sent")
      iRecieved = m_pSystem.GetChildInt("received")
      lblTransfers.Text = "Transfers: " & plural(iRequests, "request / reply", "request / replies", False) & ", " & plural(iAnnounces, "announcement", False) & Chr(13) & Chr(10) & plural(iSent, "bytes sent", " bytes sent", False) & " / " & plural(iRecieved, "bytes recieved", "bytes recieved", False)
   End Sub

   'Form overrides dispose to clean up the component list.
   Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
      If disposing Then
         If Not (components Is Nothing) Then
            components.Dispose()
         End If
      End If
      MyBase.Dispose(disposing)
   End Sub
   Friend WithEvents lblTime As System.Windows.Forms.Label
   Friend WithEvents lblTransfers As System.Windows.Forms.Label
   Friend WithEvents lblMemory As System.Windows.Forms.Label
   Friend WithEvents cmdClose As System.Windows.Forms.Button
   Friend WithEvents txtBanner As System.Windows.Forms.TextBox
   Friend WithEvents Button1 As System.Windows.Forms.Button
   Friend WithEvents cmdReload As System.Windows.Forms.Button

   'Required by the Windows Form Designer
   Private components As System.ComponentModel.Container

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmSysView))
      Me.cmdReload = New System.Windows.Forms.Button()
      Me.txtBanner = New System.Windows.Forms.TextBox()
      Me.lblMemory = New System.Windows.Forms.Label()
      Me.lblTransfers = New System.Windows.Forms.Label()
      Me.lblTime = New System.Windows.Forms.Label()
      Me.cmdClose = New System.Windows.Forms.Button()
      Me.Button1 = New System.Windows.Forms.Button()
      Me.SuspendLayout()
      '
      'cmdReload
      '
      Me.cmdReload.Location = New System.Drawing.Point(368, 272)
      Me.cmdReload.Name = "cmdReload"
      Me.cmdReload.TabIndex = 8
      Me.cmdReload.Text = "Reload"
      Me.cmdReload.Visible = False
      '
      'txtBanner
      '
      Me.txtBanner.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
      Me.txtBanner.Location = New System.Drawing.Point(8, 8)
      Me.txtBanner.Multiline = True
      Me.txtBanner.Name = "txtBanner"
      Me.txtBanner.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
      Me.txtBanner.Size = New System.Drawing.Size(592, 200)
      Me.txtBanner.TabIndex = 6
      Me.txtBanner.Text = ""
      Me.txtBanner.WordWrap = False
      '
      'lblMemory
      '
      Me.lblMemory.Location = New System.Drawing.Point(8, 264)
      Me.lblMemory.Name = "lblMemory"
      Me.lblMemory.Size = New System.Drawing.Size(184, 23)
      Me.lblMemory.TabIndex = 5
      '
      'lblTransfers
      '
      Me.lblTransfers.Location = New System.Drawing.Point(8, 216)
      Me.lblTransfers.Name = "lblTransfers"
      Me.lblTransfers.Size = New System.Drawing.Size(264, 40)
      Me.lblTransfers.TabIndex = 4
      '
      'lblTime
      '
      Me.lblTime.Location = New System.Drawing.Point(336, 240)
      Me.lblTime.Name = "lblTime"
      Me.lblTime.Size = New System.Drawing.Size(264, 23)
      Me.lblTime.TabIndex = 3
      '
      'cmdClose
      '
      Me.cmdClose.FlatStyle = System.Windows.Forms.FlatStyle.System
      Me.cmdClose.Location = New System.Drawing.Point(528, 272)
      Me.cmdClose.Name = "cmdClose"
      Me.cmdClose.TabIndex = 1
      Me.cmdClose.Text = "Close"
      '
      'Button1
      '
      Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.System
      Me.Button1.Location = New System.Drawing.Point(448, 272)
      Me.Button1.Name = "Button1"
      Me.Button1.TabIndex = 7
      Me.Button1.Text = "Button1"
      '
      'frmSysView
      '
      Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
      Me.ClientSize = New System.Drawing.Size(608, 301)
      Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.Button1, Me.txtBanner, Me.lblMemory, Me.lblTransfers, Me.lblTime, Me.cmdClose})
      Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
      Me.Name = "frmSysView"
      Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
      Me.Tag = "Admin"
      Me.Text = "System"
      Me.ResumeLayout(False)

   End Sub

#End Region

   Private Sub cmdClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdClose.Click
      Dispose()
   End Sub

   Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
      m_pSystem.MsgPrint("frmSysView::Button1")
   End Sub

   Private Sub cmdReload_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdReload.Click
      Dim pEDF As CEDF

      If MsgBox("Really reload server library?", MsgBoxStyle.Question + MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
         pEDF = New CEDF()
         pEDF.Set("edf", "reload")

         Client.write(pEDF)
      End If
   End Sub
End Class
