Imports org.ua2

Public Class frmSystem
   Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

   Public Sub New(ByRef pMessage As CEDF)
      MyBase.New()

      'This call is required by the Windows Form Designer.
      InitializeComponent()

      'Add any initialization after the InitializeComponent() call
      Dim iID As Integer, iDate As Integer, iUptime As Integer
      Dim sMessage As String, sName As String, sVersion As String, sText As String, sFromName As String, sDate As String
      Dim dDate As DateTime

      sUAveFont(Me)
      FormAdd(Me)

      sMessage = pMessage.GetStr()
      If sMessage = ua.MSG_SYSTEM_LIST Then
         iDate = pMessage.GetChildInt("systemtime")
         iUptime = pMessage.GetChildInt("uptime")
         sName = pMessage.GetChildStr("name")
         sVersion = pMessage.GetChildStr("version")
         sText = pMessage.GetChildStr("banner")

         sDate = StrTime(STRTIME_TIME, iDate)
         iUptime = iDate - iUptime

         Me.Text = sName & " " & sVersion
         lblField.Text = "Time"
         txtField.Text = sDate & " (up " & StrValue(STRVALUE_TIME, iUptime, 2) & ")"
         chkFixed.Checked = True
         TextShow(rtbContent, sText, False, chkFixed.Checked, True, False)
      ElseIf sMessage = ua.MSG_SYSTEM_MESSAGE Then
         sFromName = pMessage.GetChildStr("fromname")
         sText = TextDecode(pMessage.GetChildStr("text"))

         Me.Text = "System Message"
         lblField.Text = "From"
         txtField.Text = sFromName
         TextShow(rtbContent, sText, False, chkFixed.Checked, True, True)
      ElseIf sMessage = ua.MSG_BULLETIN_LIST Then
         If pMessage.Child("bulletin") = True Then
            iID = pMessage.GetInt()
            sFromName = pMessage.GetChildStr("fromname")
            sText = TextDecode(pMessage.GetChildStr("text"))

            pMessage.Parent()
         End If

         Me.Text = "Bulletin " & iID

         lblField.Text = "From"
         txtField.Text = sFromName

         TextShow(rtbContent, sText, False, chkFixed.Checked, True, True)
      End If
   End Sub

   'Form overrides dispose to clean up the component list.
   Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
      If disposing Then
         FormRemove(Me)

         If Not (components Is Nothing) Then
            components.Dispose()
         End If
      End If
      MyBase.Dispose(disposing)
   End Sub

   Friend WithEvents lblField As System.Windows.Forms.Label
   Friend WithEvents txtField As System.Windows.Forms.TextBox
   Friend WithEvents rtbContent As System.Windows.Forms.RichTextBox
   Friend WithEvents cmdClose As System.Windows.Forms.Button
   Friend WithEvents chkFixed As System.Windows.Forms.CheckBox

   'Required by the Windows Form Designer
   Private components As System.ComponentModel.IContainer

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   Friend WithEvents pnlTop As System.Windows.Forms.Panel
   Friend WithEvents pnlBottom As System.Windows.Forms.Panel
   Friend WithEvents pnlContent As System.Windows.Forms.Panel
   Friend WithEvents pnlField As System.Windows.Forms.Panel
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmSystem))
      Me.rtbContent = New System.Windows.Forms.RichTextBox()
      Me.chkFixed = New System.Windows.Forms.CheckBox()
      Me.txtField = New System.Windows.Forms.TextBox()
      Me.cmdClose = New System.Windows.Forms.Button()
      Me.lblField = New System.Windows.Forms.Label()
      Me.pnlTop = New System.Windows.Forms.Panel()
      Me.pnlField = New System.Windows.Forms.Panel()
      Me.pnlContent = New System.Windows.Forms.Panel()
      Me.pnlBottom = New System.Windows.Forms.Panel()
      Me.pnlTop.SuspendLayout()
      Me.pnlField.SuspendLayout()
      Me.pnlContent.SuspendLayout()
      Me.pnlBottom.SuspendLayout()
      Me.SuspendLayout()
      '
      'rtbContent
      '
      Me.rtbContent.Dock = System.Windows.Forms.DockStyle.Fill
      Me.rtbContent.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
      Me.rtbContent.Location = New System.Drawing.Point(8, 0)
      Me.rtbContent.Name = "rtbContent"
      Me.rtbContent.ReadOnly = True
      Me.rtbContent.Size = New System.Drawing.Size(568, 279)
      Me.rtbContent.TabIndex = 2
      Me.rtbContent.Text = "12345678901234567890123456789012345678901234567890123456789012345678901234567890"
      '
      'chkFixed
      '
      Me.chkFixed.FlatStyle = System.Windows.Forms.FlatStyle.System
      Me.chkFixed.Location = New System.Drawing.Point(8, 8)
      Me.chkFixed.Name = "chkFixed"
      Me.chkFixed.TabIndex = 0
      Me.chkFixed.Text = "Fixed font"
      '
      'txtField
      '
      Me.txtField.Dock = System.Windows.Forms.DockStyle.Fill
      Me.txtField.Name = "txtField"
      Me.txtField.ReadOnly = True
      Me.txtField.Size = New System.Drawing.Size(528, 20)
      Me.txtField.TabIndex = 1
      Me.txtField.Text = ""
      '
      'cmdClose
      '
      Me.cmdClose.DialogResult = System.Windows.Forms.DialogResult.Cancel
      Me.cmdClose.Dock = System.Windows.Forms.DockStyle.Right
      Me.cmdClose.FlatStyle = System.Windows.Forms.FlatStyle.System
      Me.cmdClose.Location = New System.Drawing.Point(501, 8)
      Me.cmdClose.Name = "cmdClose"
      Me.cmdClose.Size = New System.Drawing.Size(75, 24)
      Me.cmdClose.TabIndex = 3
      Me.cmdClose.Text = "Close"
      '
      'lblField
      '
      Me.lblField.Dock = System.Windows.Forms.DockStyle.Left
      Me.lblField.Location = New System.Drawing.Point(8, 8)
      Me.lblField.Name = "lblField"
      Me.lblField.Size = New System.Drawing.Size(40, 24)
      Me.lblField.TabIndex = 0
      Me.lblField.Text = "Field"
      '
      'pnlTop
      '
      Me.pnlTop.Controls.AddRange(New System.Windows.Forms.Control() {Me.pnlField, Me.lblField})
      Me.pnlTop.Dock = System.Windows.Forms.DockStyle.Top
      Me.pnlTop.DockPadding.Bottom = 8
      Me.pnlTop.DockPadding.Left = 8
      Me.pnlTop.DockPadding.Right = 8
      Me.pnlTop.DockPadding.Top = 8
      Me.pnlTop.Name = "pnlTop"
      Me.pnlTop.Size = New System.Drawing.Size(584, 40)
      Me.pnlTop.TabIndex = 4
      '
      'pnlField
      '
      Me.pnlField.Controls.AddRange(New System.Windows.Forms.Control() {Me.txtField})
      Me.pnlField.Dock = System.Windows.Forms.DockStyle.Fill
      Me.pnlField.Location = New System.Drawing.Point(48, 8)
      Me.pnlField.Name = "pnlField"
      Me.pnlField.Size = New System.Drawing.Size(528, 24)
      Me.pnlField.TabIndex = 2
      '
      'pnlContent
      '
      Me.pnlContent.Controls.AddRange(New System.Windows.Forms.Control() {Me.rtbContent})
      Me.pnlContent.Dock = System.Windows.Forms.DockStyle.Fill
      Me.pnlContent.DockPadding.Left = 8
      Me.pnlContent.DockPadding.Right = 8
      Me.pnlContent.Location = New System.Drawing.Point(0, 40)
      Me.pnlContent.Name = "pnlContent"
      Me.pnlContent.Size = New System.Drawing.Size(584, 279)
      Me.pnlContent.TabIndex = 5
      '
      'pnlBottom
      '
      Me.pnlBottom.Controls.AddRange(New System.Windows.Forms.Control() {Me.chkFixed, Me.cmdClose})
      Me.pnlBottom.Dock = System.Windows.Forms.DockStyle.Bottom
      Me.pnlBottom.DockPadding.All = 8
      Me.pnlBottom.Location = New System.Drawing.Point(0, 319)
      Me.pnlBottom.Name = "pnlBottom"
      Me.pnlBottom.Size = New System.Drawing.Size(584, 40)
      Me.pnlBottom.TabIndex = 6
      '
      'frmSystem
      '
      Me.AcceptButton = Me.cmdClose
      Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
      Me.CancelButton = Me.cmdClose
      Me.ClientSize = New System.Drawing.Size(584, 359)
      Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.pnlContent, Me.pnlBottom, Me.pnlTop})
      Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
      Me.MaximizeBox = False
      Me.MinimizeBox = False
      Me.Name = "frmSystem"
      Me.ShowInTaskbar = False
      Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
      Me.Text = "System"
      Me.pnlTop.ResumeLayout(False)
      Me.pnlField.ResumeLayout(False)
      Me.pnlContent.ResumeLayout(False)
      Me.pnlBottom.ResumeLayout(False)
      Me.ResumeLayout(False)

   End Sub

#End Region

   Private Sub chkFixed_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkFixed.CheckedChanged
      If chkFixed.Checked = True Then
         rtbContent.Font = FixedFont()
      Else
         rtbContent.Font = Me.Font
      End If
   End Sub
End Class
