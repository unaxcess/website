Imports org.ua2

Public Class frmTalk
   Inherits System.Windows.Forms.Form

   Private m_iChannelID As Integer
   Private m_sChannelName As String
   Private m_bHandled As Boolean
   Private m_pChannel As CEDF
   Private m_bInit As Boolean = True
   Private m_pRequest As CEDF

#Region " Windows Form Designer generated code "

   Public Sub New(ByRef pChannel As MessageTreeLookup)
      MyBase.New()

      'This call is required by the Windows Form Designer.
      InitializeComponent()

      'Add any initialization after the InitializeComponent() call

      sUAveFont(Me)
      FormAdd(Me)

      SetData(pChannel)

      chkReturnSend.Checked = Client.GetClientBool("returnsend")
   End Sub

   'Form overrides dispose to clean up the component list.
   Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
      If disposing Then
         ChannelSubscribe(m_iChannelID, 0)

         FormRemove(Me)

         If Not (components Is Nothing) Then
            components.Dispose()
         End If
      End If
      MyBase.Dispose(disposing)
   End Sub

   Friend WithEvents chkReturnSend As System.Windows.Forms.CheckBox
   Friend WithEvents cmdFiles As System.Windows.Forms.Button
   Friend WithEvents pnlMessages As System.Windows.Forms.Panel
   Friend WithEvents pnlUsers As System.Windows.Forms.Panel
   Friend WithEvents rlbUsers As RichControl.RichListBox
   Friend WithEvents cmdSend As System.Windows.Forms.Button
   Friend WithEvents txtText As System.Windows.Forms.TextBox
   Friend WithEvents rtbContent As System.Windows.Forms.RichTextBox
   Friend WithEvents cmdClose As System.Windows.Forms.Button
   Friend WithEvents pnlText As System.Windows.Forms.Panel
   Friend WithEvents pnlBottom As System.Windows.Forms.Panel

   'Required by the Windows Form Designer
   Private components As System.ComponentModel.IContainer

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmTalk))
      Me.rlbUsers = New RichControl.RichListBox()
      Me.txtText = New System.Windows.Forms.TextBox()
      Me.pnlUsers = New System.Windows.Forms.Panel()
      Me.cmdSend = New System.Windows.Forms.Button()
      Me.cmdFiles = New System.Windows.Forms.Button()
      Me.rtbContent = New System.Windows.Forms.RichTextBox()
      Me.chkReturnSend = New System.Windows.Forms.CheckBox()
      Me.pnlMessages = New System.Windows.Forms.Panel()
      Me.pnlBottom = New System.Windows.Forms.Panel()
      Me.cmdClose = New System.Windows.Forms.Button()
      Me.pnlText = New System.Windows.Forms.Panel()
      Me.pnlUsers.SuspendLayout()
      Me.pnlMessages.SuspendLayout()
      Me.pnlBottom.SuspendLayout()
      Me.pnlText.SuspendLayout()
      Me.SuspendLayout()
      '
      'rlbUsers
      '
      Me.rlbUsers.Dock = System.Windows.Forms.DockStyle.Fill
      Me.rlbUsers.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
      Me.rlbUsers.ImageList = Nothing
      Me.rlbUsers.Location = New System.Drawing.Point(4, 8)
      Me.rlbUsers.Name = "rlbUsers"
      Me.rlbUsers.Size = New System.Drawing.Size(88, 212)
      Me.rlbUsers.Sorted = True
      Me.rlbUsers.TabIndex = 0
      '
      'txtText
      '
      Me.txtText.AcceptsTab = True
      Me.txtText.Dock = System.Windows.Forms.DockStyle.Fill
      Me.txtText.Location = New System.Drawing.Point(8, 4)
      Me.txtText.Multiline = True
      Me.txtText.Name = "txtText"
      Me.txtText.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
      Me.txtText.Size = New System.Drawing.Size(304, 96)
      Me.txtText.TabIndex = 0
      Me.txtText.Text = ""
      '
      'pnlUsers
      '
      Me.pnlUsers.Controls.AddRange(New System.Windows.Forms.Control() {Me.rlbUsers})
      Me.pnlUsers.Dock = System.Windows.Forms.DockStyle.Right
      Me.pnlUsers.DockPadding.Bottom = 4
      Me.pnlUsers.DockPadding.Left = 4
      Me.pnlUsers.DockPadding.Right = 8
      Me.pnlUsers.DockPadding.Top = 8
      Me.pnlUsers.Location = New System.Drawing.Point(220, 0)
      Me.pnlUsers.Name = "pnlUsers"
      Me.pnlUsers.Size = New System.Drawing.Size(100, 233)
      Me.pnlUsers.TabIndex = 1
      '
      'cmdSend
      '
      Me.cmdSend.Enabled = False
      Me.cmdSend.FlatStyle = System.Windows.Forms.FlatStyle.System
      Me.cmdSend.Location = New System.Drawing.Point(160, 48)
      Me.cmdSend.Name = "cmdSend"
      Me.cmdSend.TabIndex = 2
      Me.cmdSend.Text = "&Send"
      '
      'cmdFiles
      '
      Me.cmdFiles.FlatStyle = System.Windows.Forms.FlatStyle.System
      Me.cmdFiles.Location = New System.Drawing.Point(8, 48)
      Me.cmdFiles.Name = "cmdFiles"
      Me.cmdFiles.TabIndex = 1
      Me.cmdFiles.Text = "Files..."
      '
      'rtbContent
      '
      Me.rtbContent.Dock = System.Windows.Forms.DockStyle.Fill
      Me.rtbContent.Location = New System.Drawing.Point(8, 8)
      Me.rtbContent.Name = "rtbContent"
      Me.rtbContent.ReadOnly = True
      Me.rtbContent.Size = New System.Drawing.Size(208, 221)
      Me.rtbContent.TabIndex = 0
      Me.rtbContent.Text = ""
      '
      'chkReturnSend
      '
      Me.chkReturnSend.FlatStyle = System.Windows.Forms.FlatStyle.System
      Me.chkReturnSend.Location = New System.Drawing.Point(8, 8)
      Me.chkReturnSend.Name = "chkReturnSend"
      Me.chkReturnSend.Size = New System.Drawing.Size(144, 16)
      Me.chkReturnSend.TabIndex = 0
      Me.chkReturnSend.Text = "Return sends message"
      '
      'pnlMessages
      '
      Me.pnlMessages.Controls.AddRange(New System.Windows.Forms.Control() {Me.rtbContent})
      Me.pnlMessages.Dock = System.Windows.Forms.DockStyle.Fill
      Me.pnlMessages.DockPadding.Bottom = 4
      Me.pnlMessages.DockPadding.Left = 8
      Me.pnlMessages.DockPadding.Right = 4
      Me.pnlMessages.DockPadding.Top = 8
      Me.pnlMessages.Name = "pnlMessages"
      Me.pnlMessages.Size = New System.Drawing.Size(220, 233)
      Me.pnlMessages.TabIndex = 0
      '
      'pnlBottom
      '
      Me.pnlBottom.Controls.AddRange(New System.Windows.Forms.Control() {Me.cmdFiles, Me.chkReturnSend, Me.cmdClose, Me.cmdSend})
      Me.pnlBottom.Dock = System.Windows.Forms.DockStyle.Bottom
      Me.pnlBottom.Location = New System.Drawing.Point(0, 333)
      Me.pnlBottom.Name = "pnlBottom"
      Me.pnlBottom.Size = New System.Drawing.Size(320, 80)
      Me.pnlBottom.TabIndex = 3
      '
      'cmdClose
      '
      Me.cmdClose.DialogResult = System.Windows.Forms.DialogResult.Cancel
      Me.cmdClose.FlatStyle = System.Windows.Forms.FlatStyle.System
      Me.cmdClose.Location = New System.Drawing.Point(240, 48)
      Me.cmdClose.Name = "cmdClose"
      Me.cmdClose.TabIndex = 3
      Me.cmdClose.Text = "Close"
      '
      'pnlText
      '
      Me.pnlText.Controls.AddRange(New System.Windows.Forms.Control() {Me.txtText})
      Me.pnlText.Dock = System.Windows.Forms.DockStyle.Bottom
      Me.pnlText.DockPadding.Left = 8
      Me.pnlText.DockPadding.Right = 8
      Me.pnlText.DockPadding.Top = 4
      Me.pnlText.Location = New System.Drawing.Point(0, 233)
      Me.pnlText.Name = "pnlText"
      Me.pnlText.Size = New System.Drawing.Size(320, 100)
      Me.pnlText.TabIndex = 2
      '
      'frmTalk
      '
      Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
      Me.CancelButton = Me.cmdClose
      Me.ClientSize = New System.Drawing.Size(320, 413)
      Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.pnlMessages, Me.pnlUsers, Me.pnlText, Me.pnlBottom})
      Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
      Me.Name = "frmTalk"
      Me.Text = "Talk"
      Me.pnlUsers.ResumeLayout(False)
      Me.pnlMessages.ResumeLayout(False)
      Me.pnlBottom.ResumeLayout(False)
      Me.pnlText.ResumeLayout(False)
      Me.ResumeLayout(False)

   End Sub

#End Region

   Private Sub SetData(ByRef pChannel As MessageTreeLookup)
      Dim iUserID As Integer, iValue As Integer
      Dim bLoop As Boolean
      Dim sUserName As String
      Dim pRequest As CEDF, pReply As CEDF
      Dim pUser As Lookup

      Me.Text = pChannel.m_sValue & " - Talk"
      m_iChannelID = pChannel.m_iID
      m_sChannelName = pChannel.m_sValue

      debugline("frmTalk::SetData " & m_iChannelID & " / " & m_sChannelName)

      pRequest = New CEDF()
      pRequest.AddChild("channelid", m_iChannelID)
      pReply = New CEDF()

      If Client.request3(ua.MSG_CHANNEL_LIST, pRequest, pReply) = True Then
         'pReply.MsgPrint("frmTalk::SetData channel info")

         If pReply.Child("channel") = True Then
            m_pChannel = New CEDF()
            m_pChannel.Copy(pReply, True, True, True)

            bLoop = m_pChannel.Child()
            Do While bLoop = True
               If m_pChannel.GetName() = "subscriber" Or m_pChannel.GetName() = "member" Or m_pChannel.GetName() = "editor" Then
                  iUserID = m_pChannel.GetInt()

                  sUserName = m_pChannel.GetChildStr("name")

                  If m_pChannel.GetChildBool("active") = True Then
                     iValue = 1
                  Else
                     iValue = 0
                  End If

                  pUser = New Lookup(Lookup.CHANNEL_USER, iUserID, iValue, sUserName)

                  rlbUsers.Items.Add(pUser)
               End If

               bLoop = m_pChannel.Next()
               If bLoop = False Then
                  m_pChannel.Parent()
               End If
            Loop

            m_pChannel.Parent()
         Else
            MsgBox("No channel section", MsgBoxStyle.Exclamation, "frmTalk::SetData")
         End If
      Else
         pReply.MsgPrint("frmTalk::SetData request failed")
      End If
   End Sub

   Public Sub AddTalk(ByVal bUseFrom As Boolean, ByVal sText As String, Optional ByRef pEDF As CEDF = Nothing)
      Dim cColour As Color
      Dim sFromName As String
      Dim pForm As Form

      pForm = FormFocus()

      SaveAttachments(pEDF)

      If rtbContent.Text.Length > 0 Then
         rtbContent.AppendText(CRLF)
      End If

      rtbContent.Enabled = True
      If bUseFrom = True Then
         sFromName = pEDF.GetChildStr("fromname")
         If sFromName Is Nothing Then
            sFromName = pEDF.GetChildStr("channelname")
            cColour = rtbContent.ForeColor
         Else
            cColour = SystemColors.ActiveCaption
         End If
      Else
         sFromName = Client.GetName()
         cColour = rtbContent.ForeColor
      End If

      If Not pEDF Is Nothing Then
         sText = TextDecode(pEDF.GetChildStr("text"))
      End If

      UserEmote(rtbContent, sFromName, sText, cColour)

      txtText.Focus()

      If Not pForm Is Nothing Then
         pForm.Focus()
      End If
   End Sub

   Private Sub SendMessage()
      Dim iPageNum As Integer = 1, iUserNum As Integer, iServiceID As Integer = -1
      Dim bFound As Boolean, bReturn As Boolean
      Dim pText() As Byte
      Dim pReply As CEDF
      Dim pUser As UserLookup

      If m_pRequest Is Nothing Then
         m_pRequest = New CEDF()
      End If

      m_pRequest.AddChild("channelid", m_iChannelID)

      AddTextField(m_pRequest, "text", txtText.Text)

      pReply = New CEDF()

      bReturn = Client.request3(ua.MSG_CHANNEL_SEND, m_pRequest, pReply)

      If bReturn = False Then
         pReply.MsgPrint("frmsUAve::SendMessage failed")
      End If

      'AddText(Nothing, txtText.Text)

      txtText.Text = ""

      cmdSend.Enabled = False

      m_pRequest = Nothing
   End Sub

   Private Sub cmdSend_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSend.Click
      SendMessage()
   End Sub

   Private Sub cmdClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdClose.Click
      Dim iPageNum As Integer = 1
      Dim bAbort As Boolean = True, bFound As Boolean

      'debugline("frmPage::cmdClose text & '" & txtText.Text & "', " & txtText.Text.Length & " chars")

      If txtText.Text.Trim() <> "" Then
         bAbort = AbortEdit()
      End If

      If bAbort = True Then
         Me.Dispose()
      End If
   End Sub

   Private Sub txtText_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtText.KeyDown
      If e.KeyCode = Keys.Enter And e.Control = False And chkReturnSend.Checked = True And cmdSend.Enabled = True Then
         SendMessage()

         m_bHandled = True
      End If
   End Sub

   Private Sub rtbContent_LinkClicked(ByVal sender As Object, ByVal e As System.Windows.Forms.LinkClickedEventArgs) Handles rtbContent.LinkClicked
      System.Diagnostics.Process.Start(GetBrowser(), e.LinkText)
   End Sub

   Private Sub txtText_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtText.TextChanged
      If m_bHandled = True Then
         txtText.Text = ""

         m_bHandled = False
      End If

      If txtText.Text <> "" Then
         cmdSend.Enabled = True
      Else
         cmdSend.Enabled = False
      End If
   End Sub

   Public Function GetChannelID() As Integer
      Return m_iChannelID
   End Function

   Public Function UserAdd(ByRef pAnnounce As CEDF) As Boolean
      Return UserChange(pAnnounce, True)
   End Function

   Public Function UserRemove(ByRef pAnnounce As CEDF) As Boolean
      Return UserChange(pAnnounce, False)
   End Function

   Private Function UserChange(ByRef pAnnounce As CEDF, ByVal bAdd As Boolean) As Boolean
      Dim iUserNum As Integer, iUserID As Integer, iValue As Integer
      Dim bFound As Boolean, bReturn As Boolean
      Dim sType As String, sUserName As String
      Dim pForm As Form
      Dim pUser As Lookup

      'pAnnounce.MsgPrint("frmTalk::UserChange " & bAdd)

      iUserID = pAnnounce.GetChildInt("userid")
      sUserName = pAnnounce.GetChildStr("username")

      If bAdd = True Then
         sType = "joined"
      Else
         sType = "left"
      End If

      Do While bFound = False And iUserNum < rlbUsers.Items.Count
         pUser = rlbUsers.Items(iUserNum)

         If pUser.m_iID = iUserID Then
            bFound = True
         Else
            iUserNum += 1
         End If
      Loop

      If bAdd = True Then
         If m_pChannel.GetChildBool("active") = True Then
            iValue = 1
            bReturn = True
         Else
            iValue = 0
         End If

         If bFound = False Then
            pUser = New Lookup(Lookup.CHANNEL_USER, iUserID, iValue, sUserName)

            rlbUsers.Items.Add(pUser)
         Else
            pUser.m_iValue = iValue
         End If
      ElseIf bAdd = False And bFound = True Then
         rlbUsers.Items.RemoveAt(iUserNum)
         bReturn = True
      End If

      If bReturn = True Then
         pForm = FormFocus()

         If rtbContent.Text.Length > 0 Then
            rtbContent.AppendText(CRLF)
         End If

         rtbContent.Select()
         'rtbContent.SelectionColor = Color.Red
         rtbContent.SelectionFont = New Font(rtbContent.Font, FontStyle.Bold)

         rtbContent.AppendText(sUserName)

         rtbContent.Select()
         'rtbContent.SelectionColor = rtbContent.ForeColor
         rtbContent.SelectionFont = rtbContent.Font

         rtbContent.AppendText(" has " & sType & " the channel")

         txtText.Focus()

         If Not pForm Is Nothing Then
            pForm.Focus()
         End If
      End If

      Return bReturn
   End Function

   Private Sub frmTalk_VisibleChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.VisibleChanged
      If m_bInit = True Then
         If Me.Visible = True Then
            txtText.Focus()

            m_bInit = False
         End If
      End If
   End Sub

   Private Sub cmdFiles_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdFiles.Click
      If OpenAttachments(m_pRequest) = True Then
         SendMessage()
      End If
   End Sub
End Class
