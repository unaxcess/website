Public Class frmText
   Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

   Public Sub New(ByVal sTitle As String)
      MyBase.New()

      'This call is required by the Windows Form Designer.
      InitializeComponent()

      'Add any initialization after the InitializeComponent() call
      sUAveFont(Me)
      FormAdd(Me)

      Me.Text = sTitle
   End Sub

   'Form overrides dispose to clean up the component list.
   Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
      If disposing Then
         FormRemove(Me)
         If Not (components Is Nothing) Then
            components.Dispose()
         End If
      End If
      MyBase.Dispose(disposing)
   End Sub
   Friend WithEvents txtText As System.Windows.Forms.TextBox
   Friend WithEvents cmdOK As System.Windows.Forms.Button
   Friend WithEvents cmdCancel As System.Windows.Forms.Button
   Friend WithEvents chkFixed As System.Windows.Forms.CheckBox

   'Required by the Windows Form Designer
   Private components As System.ComponentModel.Container

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   Friend WithEvents pnlText As System.Windows.Forms.Panel
   Friend WithEvents pnlBottom As System.Windows.Forms.Panel
   Friend WithEvents pnlActions As System.Windows.Forms.Panel
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmText))
      Me.cmdCancel = New System.Windows.Forms.Button()
      Me.txtText = New System.Windows.Forms.TextBox()
      Me.cmdOK = New System.Windows.Forms.Button()
      Me.chkFixed = New System.Windows.Forms.CheckBox()
      Me.pnlText = New System.Windows.Forms.Panel()
      Me.pnlBottom = New System.Windows.Forms.Panel()
      Me.pnlActions = New System.Windows.Forms.Panel()
      Me.pnlText.SuspendLayout()
      Me.pnlBottom.SuspendLayout()
      Me.pnlActions.SuspendLayout()
      Me.SuspendLayout()
      '
      'cmdCancel
      '
      Me.cmdCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
      Me.cmdCancel.FlatStyle = System.Windows.Forms.FlatStyle.System
      Me.cmdCancel.Location = New System.Drawing.Point(88, 8)
      Me.cmdCancel.Name = "cmdCancel"
      Me.cmdCancel.TabIndex = 2
      Me.cmdCancel.Text = "Cancel"
      '
      'txtText
      '
      Me.txtText.AcceptsReturn = True
      Me.txtText.Dock = System.Windows.Forms.DockStyle.Fill
      Me.txtText.Location = New System.Drawing.Point(8, 8)
      Me.txtText.Multiline = True
      Me.txtText.Name = "txtText"
      Me.txtText.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
      Me.txtText.Size = New System.Drawing.Size(272, 157)
      Me.txtText.TabIndex = 0
      Me.txtText.Text = ""
      '
      'cmdOK
      '
      Me.cmdOK.FlatStyle = System.Windows.Forms.FlatStyle.System
      Me.cmdOK.Location = New System.Drawing.Point(8, 8)
      Me.cmdOK.Name = "cmdOK"
      Me.cmdOK.TabIndex = 1
      Me.cmdOK.Text = "OK"
      '
      'chkFixed
      '
      Me.chkFixed.FlatStyle = System.Windows.Forms.FlatStyle.System
      Me.chkFixed.Location = New System.Drawing.Point(8, 8)
      Me.chkFixed.Name = "chkFixed"
      Me.chkFixed.Size = New System.Drawing.Size(80, 24)
      Me.chkFixed.TabIndex = 3
      Me.chkFixed.Text = "Fixed font"
      '
      'pnlText
      '
      Me.pnlText.Controls.AddRange(New System.Windows.Forms.Control() {Me.txtText})
      Me.pnlText.Dock = System.Windows.Forms.DockStyle.Fill
      Me.pnlText.DockPadding.All = 8
      Me.pnlText.Name = "pnlText"
      Me.pnlText.Size = New System.Drawing.Size(288, 173)
      Me.pnlText.TabIndex = 4
      '
      'pnlBottom
      '
      Me.pnlBottom.Controls.AddRange(New System.Windows.Forms.Control() {Me.chkFixed, Me.pnlActions})
      Me.pnlBottom.Dock = System.Windows.Forms.DockStyle.Bottom
      Me.pnlBottom.Location = New System.Drawing.Point(0, 173)
      Me.pnlBottom.Name = "pnlBottom"
      Me.pnlBottom.Size = New System.Drawing.Size(288, 40)
      Me.pnlBottom.TabIndex = 5
      '
      'pnlActions
      '
      Me.pnlActions.Controls.AddRange(New System.Windows.Forms.Control() {Me.cmdCancel, Me.cmdOK})
      Me.pnlActions.Dock = System.Windows.Forms.DockStyle.Right
      Me.pnlActions.Location = New System.Drawing.Point(120, 0)
      Me.pnlActions.Name = "pnlActions"
      Me.pnlActions.Size = New System.Drawing.Size(168, 40)
      Me.pnlActions.TabIndex = 0
      '
      'frmText
      '
      Me.AcceptButton = Me.cmdOK
      Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
      Me.CancelButton = Me.cmdCancel
      Me.ClientSize = New System.Drawing.Size(288, 213)
      Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.pnlText, Me.pnlBottom})
      Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
      Me.MaximizeBox = False
      Me.MinimizeBox = False
      Me.Name = "frmText"
      Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
      Me.Text = "Text"
      Me.pnlText.ResumeLayout(False)
      Me.pnlBottom.ResumeLayout(False)
      Me.pnlActions.ResumeLayout(False)
      Me.ResumeLayout(False)

   End Sub

#End Region

   Private Sub chkFixed_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkFixed.CheckedChanged
      If chkFixed.Checked = True Then
         txtText.Font = FixedFont()
      Else
         txtText.Font = Me.Font
      End If
   End Sub

   Private Sub cmdOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdOK.Click
      Me.DialogResult = DialogResult.OK
   End Sub
End Class
