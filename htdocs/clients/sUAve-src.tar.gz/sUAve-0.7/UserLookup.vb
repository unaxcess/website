Public Class UserLookup
   Inherits Lookup

   Public m_iUserType As Integer
   Public m_iAccessLevel As Integer

   Public m_bSecure As Boolean
   Public m_sStatusMsg As String
   Public m_iNumShadows As Integer
   Public m_iServiceID As Integer
   Public m_sServiceName As String

   Public Sub New(ByVal iID As Integer, ByVal iUserType As Integer, ByVal sName As String, ByVal iAccessLevel As Integer, ByVal iStatus As Integer, ByVal bSecure As Boolean, ByVal sStatusMsg As String, ByVal iNumShadows As Integer, ByVal iServiceID As Integer, ByVal sServiceName As String)
      MyBase.New(0, iID, iStatus, sName)

      m_iUserType = iUserType
      m_iAccessLevel = iAccessLevel

      m_bSecure = bSecure
      m_sStatusMsg = sStatusMsg
      m_iNumShadows = iNumShadows
      m_iServiceID = iServiceID
      m_sServiceName = sServiceName
   End Sub

   Public Overrides Function toString() As String
      Dim sReturn As String

      sReturn = ""
      If mask(m_iValue, ua.LOGIN_IDLE) = True Then
         sReturn &= "I"
      End If
      'If mask(m_iValue, ua.LOGIN_BUSY) = True Then
      'sReturn &= "B"
      'End If
      If mask(m_iValue, ua.LOGIN_TALKING) = True Then
         sReturn &= "T"
      End If
      If mask(m_iValue, ua.LOGIN_SILENT) = True Then
         sReturn &= "S"
      End If
      If mask(m_iValue, ua.LOGIN_SHADOW) = True Then
         sReturn &= "H"
      End If
      'If mask(m_iValue, ua.LOGIN_NOCONTACT) = True Then
      'sReturn &= "N"
      'End If
      If m_bSecure = True Then
         sReturn &= "E"
      End If
      If sReturn <> "" Then
         sReturn &= " "
      End If

      sReturn &= markup(m_sValue)

      If Not m_sServiceName Is Nothing Then
         sReturn &= " (" & m_sServiceName & ")"
      End If

      If Not m_sStatusMsg Is Nothing Then
         If m_sStatusMsg.Trim() <> "" Then
            If m_sStatusMsg.StartsWith(":'s") = True Then
               sReturn &= m_sStatusMsg.Substring(1)
            ElseIf m_sStatusMsg.StartsWith(":") = True Then
               sReturn &= " " & m_sStatusMsg.Substring(1)
            Else
               sReturn &= ". " & m_sStatusMsg
            End If
         End If
      End If

      Return sReturn
   End Function

End Class
