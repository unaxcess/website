Imports org.ua2

Public Class frmUsers
   Inherits System.Windows.Forms.Form

   Private Shared m_pForm As Form

   Private m_pLookup As Lookup
   Private m_pItem As CEDF

   Private m_pRequest As CEDF

   Private m_bUserInput As Boolean = True

   Private m_bUpdate As Boolean

#Region " Windows Form Designer generated code "

   Public Sub New()
      MyBase.New()

      'This call is required by the Windows Form Designer.
      InitializeComponent()

      'Add any initialization after the InitializeComponent() call
      sUAveFont(Me)
      m_pForm = FormAdd(Me)

      SetData()
   End Sub

   'Form overrides dispose to clean up the component list.
   Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
      If disposing Then
         FormRemove(Me)
         m_pForm = Nothing

         If Not (components Is Nothing) Then
            components.Dispose()
         End If
      End If
      MyBase.Dispose(disposing)
   End Sub

   Friend WithEvents cmdClose As System.Windows.Forms.Button
   Friend WithEvents lstUsers As System.Windows.Forms.ListBox
   Friend WithEvents lblAccess As System.Windows.Forms.Label
   Friend WithEvents cmbAccessLevel As System.Windows.Forms.ComboBox
   Friend WithEvents txtAccessName As System.Windows.Forms.TextBox

   'Required by the Windows Form Designer
   Private components As System.ComponentModel.IContainer

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   Friend WithEvents pnlItems As System.Windows.Forms.Panel
   Friend WithEvents pnlItem As System.Windows.Forms.Panel
   Friend WithEvents pnlBottom As System.Windows.Forms.Panel
   Friend WithEvents tabItem As System.Windows.Forms.TabControl
   Friend WithEvents lblName As System.Windows.Forms.Label
   Friend WithEvents txtName As System.Windows.Forms.TextBox
   Friend WithEvents txtEDF As System.Windows.Forms.TextBox
   Friend WithEvents txtDescription As System.Windows.Forms.TextBox
   Friend WithEvents chkAccessAgent As System.Windows.Forms.CheckBox
   Friend WithEvents tbpGeneral As System.Windows.Forms.TabPage
   Friend WithEvents tbpEDF As System.Windows.Forms.TabPage
   Friend WithEvents tbpLogin As System.Windows.Forms.TabPage
   Friend WithEvents tbpFolders As System.Windows.Forms.TabPage
   Friend WithEvents tbpStats As System.Windows.Forms.TabPage
   Friend WithEvents rlbFolders As RichControl.RichListBox
   Friend WithEvents cmdFolderRemove As System.Windows.Forms.Button
   Friend WithEvents cmdFolderAdd As System.Windows.Forms.Button
   Friend WithEvents tbpDetails As System.Windows.Forms.TabPage
   Friend WithEvents lblCreatedTitle As System.Windows.Forms.Label
   Friend WithEvents lblCreated As System.Windows.Forms.Label
   Friend WithEvents lblRealName As System.Windows.Forms.Label
   Friend WithEvents txtRealName As System.Windows.Forms.TextBox
   Friend WithEvents lblEmail As System.Windows.Forms.Label
   Friend WithEvents txtEmail As System.Windows.Forms.TextBox
   Friend WithEvents lblHomepage As System.Windows.Forms.Label
   Friend WithEvents txtHomepage As System.Windows.Forms.TextBox
   Friend WithEvents chkRealNamePublic As System.Windows.Forms.CheckBox
   Friend WithEvents chkEmailPublic As System.Windows.Forms.CheckBox
   Friend WithEvents chkHomepagePublic As System.Windows.Forms.CheckBox
   Friend WithEvents txtNumVotes As System.Windows.Forms.TextBox
   Friend WithEvents lblNumVotes As System.Windows.Forms.Label
   Friend WithEvents lblTotalMsgs As System.Windows.Forms.Label
   Friend WithEvents txtTotalMsgs As System.Windows.Forms.TextBox
   Friend WithEvents lblNumMsgs As System.Windows.Forms.Label
   Friend WithEvents txtNumMsgs As System.Windows.Forms.TextBox
   Friend WithEvents lblLongestLogin As System.Windows.Forms.Label
   Friend WithEvents txtTotalLogins As System.Windows.Forms.TextBox
   Friend WithEvents lblTotalLogins As System.Windows.Forms.Label
   Friend WithEvents txtNumLogins As System.Windows.Forms.TextBox
   Friend WithEvents lblNumLogins As System.Windows.Forms.Label
   Friend WithEvents lblLastMsg As System.Windows.Forms.Label
   Friend WithEvents txtLongestLogin As System.Windows.Forms.TextBox
   Friend WithEvents txtLastMsg As System.Windows.Forms.TextBox
   Friend WithEvents lblTime As System.Windows.Forms.Label
   Friend WithEvents lblHostname As System.Windows.Forms.Label
   Friend WithEvents txtLocation As System.Windows.Forms.TextBox
   Friend WithEvents lblProxyHostname As System.Windows.Forms.Label
   Friend WithEvents txtProxyLocation As System.Windows.Forms.TextBox
   Friend WithEvents lblClientProtocol As System.Windows.Forms.Label
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmUsers))
      Me.txtAccessName = New System.Windows.Forms.TextBox()
      Me.cmbAccessLevel = New System.Windows.Forms.ComboBox()
      Me.lblAccess = New System.Windows.Forms.Label()
      Me.lstUsers = New System.Windows.Forms.ListBox()
      Me.cmdClose = New System.Windows.Forms.Button()
      Me.pnlBottom = New System.Windows.Forms.Panel()
      Me.pnlItems = New System.Windows.Forms.Panel()
      Me.pnlItem = New System.Windows.Forms.Panel()
      Me.tabItem = New System.Windows.Forms.TabControl()
      Me.tbpGeneral = New System.Windows.Forms.TabPage()
      Me.chkAccessAgent = New System.Windows.Forms.CheckBox()
      Me.txtDescription = New System.Windows.Forms.TextBox()
      Me.txtName = New System.Windows.Forms.TextBox()
      Me.lblName = New System.Windows.Forms.Label()
      Me.tbpDetails = New System.Windows.Forms.TabPage()
      Me.chkHomepagePublic = New System.Windows.Forms.CheckBox()
      Me.chkEmailPublic = New System.Windows.Forms.CheckBox()
      Me.chkRealNamePublic = New System.Windows.Forms.CheckBox()
      Me.txtHomepage = New System.Windows.Forms.TextBox()
      Me.lblHomepage = New System.Windows.Forms.Label()
      Me.txtEmail = New System.Windows.Forms.TextBox()
      Me.lblEmail = New System.Windows.Forms.Label()
      Me.txtRealName = New System.Windows.Forms.TextBox()
      Me.lblRealName = New System.Windows.Forms.Label()
      Me.lblCreatedTitle = New System.Windows.Forms.Label()
      Me.lblCreated = New System.Windows.Forms.Label()
      Me.tbpLogin = New System.Windows.Forms.TabPage()
      Me.tbpFolders = New System.Windows.Forms.TabPage()
      Me.cmdFolderRemove = New System.Windows.Forms.Button()
      Me.cmdFolderAdd = New System.Windows.Forms.Button()
      Me.rlbFolders = New RichControl.RichListBox()
      Me.tbpStats = New System.Windows.Forms.TabPage()
      Me.txtLastMsg = New System.Windows.Forms.TextBox()
      Me.txtLongestLogin = New System.Windows.Forms.TextBox()
      Me.lblLastMsg = New System.Windows.Forms.Label()
      Me.txtNumVotes = New System.Windows.Forms.TextBox()
      Me.lblNumVotes = New System.Windows.Forms.Label()
      Me.lblTotalMsgs = New System.Windows.Forms.Label()
      Me.txtTotalMsgs = New System.Windows.Forms.TextBox()
      Me.lblNumMsgs = New System.Windows.Forms.Label()
      Me.txtNumMsgs = New System.Windows.Forms.TextBox()
      Me.lblLongestLogin = New System.Windows.Forms.Label()
      Me.txtTotalLogins = New System.Windows.Forms.TextBox()
      Me.lblTotalLogins = New System.Windows.Forms.Label()
      Me.txtNumLogins = New System.Windows.Forms.TextBox()
      Me.lblNumLogins = New System.Windows.Forms.Label()
      Me.tbpEDF = New System.Windows.Forms.TabPage()
      Me.txtEDF = New System.Windows.Forms.TextBox()
      Me.lblTime = New System.Windows.Forms.Label()
      Me.lblHostname = New System.Windows.Forms.Label()
      Me.txtLocation = New System.Windows.Forms.TextBox()
      Me.lblProxyHostname = New System.Windows.Forms.Label()
      Me.txtProxyLocation = New System.Windows.Forms.TextBox()
      Me.lblClientProtocol = New System.Windows.Forms.Label()
      Me.pnlBottom.SuspendLayout()
      Me.pnlItems.SuspendLayout()
      Me.pnlItem.SuspendLayout()
      Me.tabItem.SuspendLayout()
      Me.tbpGeneral.SuspendLayout()
      Me.tbpDetails.SuspendLayout()
      Me.tbpLogin.SuspendLayout()
      Me.tbpFolders.SuspendLayout()
      Me.tbpStats.SuspendLayout()
      Me.tbpEDF.SuspendLayout()
      Me.SuspendLayout()
      '
      'txtAccessName
      '
      Me.txtAccessName.Location = New System.Drawing.Point(56, 56)
      Me.txtAccessName.Name = "txtAccessName"
      Me.txtAccessName.Size = New System.Drawing.Size(208, 20)
      Me.txtAccessName.TabIndex = 5
      Me.txtAccessName.Text = ""
      '
      'cmbAccessLevel
      '
      Me.cmbAccessLevel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
      Me.cmbAccessLevel.DropDownWidth = 120
      Me.cmbAccessLevel.Items.AddRange(New Object() {"None", "Guest", "Messages", "Editor", "Witness", "SysOp"})
      Me.cmbAccessLevel.Location = New System.Drawing.Point(56, 32)
      Me.cmbAccessLevel.Name = "cmbAccessLevel"
      Me.cmbAccessLevel.Size = New System.Drawing.Size(120, 21)
      Me.cmbAccessLevel.TabIndex = 3
      '
      'lblAccess
      '
      Me.lblAccess.Location = New System.Drawing.Point(8, 32)
      Me.lblAccess.Name = "lblAccess"
      Me.lblAccess.Size = New System.Drawing.Size(48, 23)
      Me.lblAccess.TabIndex = 2
      Me.lblAccess.Text = "Access"
      '
      'lstUsers
      '
      Me.lstUsers.Dock = System.Windows.Forms.DockStyle.Fill
      Me.lstUsers.Location = New System.Drawing.Point(8, 8)
      Me.lstUsers.Name = "lstUsers"
      Me.lstUsers.Size = New System.Drawing.Size(104, 212)
      Me.lstUsers.Sorted = True
      Me.lstUsers.TabIndex = 0
      '
      'cmdClose
      '
      Me.cmdClose.DialogResult = System.Windows.Forms.DialogResult.Cancel
      Me.cmdClose.Dock = System.Windows.Forms.DockStyle.Right
      Me.cmdClose.FlatStyle = System.Windows.Forms.FlatStyle.System
      Me.cmdClose.Location = New System.Drawing.Point(325, 8)
      Me.cmdClose.Name = "cmdClose"
      Me.cmdClose.Size = New System.Drawing.Size(75, 24)
      Me.cmdClose.TabIndex = 0
      Me.cmdClose.Text = "Close"
      '
      'pnlBottom
      '
      Me.pnlBottom.Controls.AddRange(New System.Windows.Forms.Control() {Me.cmdClose})
      Me.pnlBottom.Dock = System.Windows.Forms.DockStyle.Bottom
      Me.pnlBottom.DockPadding.All = 8
      Me.pnlBottom.Location = New System.Drawing.Point(0, 233)
      Me.pnlBottom.Name = "pnlBottom"
      Me.pnlBottom.Size = New System.Drawing.Size(408, 40)
      Me.pnlBottom.TabIndex = 3
      '
      'pnlItems
      '
      Me.pnlItems.Controls.AddRange(New System.Windows.Forms.Control() {Me.lstUsers})
      Me.pnlItems.Dock = System.Windows.Forms.DockStyle.Left
      Me.pnlItems.DockPadding.All = 8
      Me.pnlItems.Name = "pnlItems"
      Me.pnlItems.Size = New System.Drawing.Size(120, 233)
      Me.pnlItems.TabIndex = 0
      '
      'pnlItem
      '
      Me.pnlItem.Controls.AddRange(New System.Windows.Forms.Control() {Me.tabItem})
      Me.pnlItem.Dock = System.Windows.Forms.DockStyle.Fill
      Me.pnlItem.DockPadding.Right = 8
      Me.pnlItem.DockPadding.Top = 8
      Me.pnlItem.Location = New System.Drawing.Point(120, 0)
      Me.pnlItem.Name = "pnlItem"
      Me.pnlItem.Size = New System.Drawing.Size(288, 233)
      Me.pnlItem.TabIndex = 1
      '
      'tabItem
      '
      Me.tabItem.Controls.AddRange(New System.Windows.Forms.Control() {Me.tbpGeneral, Me.tbpDetails, Me.tbpLogin, Me.tbpFolders, Me.tbpStats, Me.tbpEDF})
      Me.tabItem.Dock = System.Windows.Forms.DockStyle.Fill
      Me.tabItem.Location = New System.Drawing.Point(0, 8)
      Me.tabItem.Name = "tabItem"
      Me.tabItem.SelectedIndex = 0
      Me.tabItem.Size = New System.Drawing.Size(280, 225)
      Me.tabItem.TabIndex = 9
      '
      'tbpGeneral
      '
      Me.tbpGeneral.Controls.AddRange(New System.Windows.Forms.Control() {Me.chkAccessAgent, Me.txtDescription, Me.txtName, Me.lblName, Me.txtAccessName, Me.lblAccess, Me.cmbAccessLevel})
      Me.tbpGeneral.Location = New System.Drawing.Point(4, 22)
      Me.tbpGeneral.Name = "tbpGeneral"
      Me.tbpGeneral.Size = New System.Drawing.Size(272, 199)
      Me.tbpGeneral.TabIndex = 1
      Me.tbpGeneral.Text = "General"
      '
      'chkAccessAgent
      '
      Me.chkAccessAgent.FlatStyle = System.Windows.Forms.FlatStyle.System
      Me.chkAccessAgent.Location = New System.Drawing.Point(184, 32)
      Me.chkAccessAgent.Name = "chkAccessAgent"
      Me.chkAccessAgent.Size = New System.Drawing.Size(56, 24)
      Me.chkAccessAgent.TabIndex = 4
      Me.chkAccessAgent.Text = "Agent"
      '
      'txtDescription
      '
      Me.txtDescription.Location = New System.Drawing.Point(8, 80)
      Me.txtDescription.Multiline = True
      Me.txtDescription.Name = "txtDescription"
      Me.txtDescription.Size = New System.Drawing.Size(256, 112)
      Me.txtDescription.TabIndex = 6
      Me.txtDescription.Text = ""
      '
      'txtName
      '
      Me.txtName.Location = New System.Drawing.Point(56, 8)
      Me.txtName.Name = "txtName"
      Me.txtName.Size = New System.Drawing.Size(208, 20)
      Me.txtName.TabIndex = 1
      Me.txtName.Text = ""
      '
      'lblName
      '
      Me.lblName.Location = New System.Drawing.Point(8, 8)
      Me.lblName.Name = "lblName"
      Me.lblName.Size = New System.Drawing.Size(40, 23)
      Me.lblName.TabIndex = 0
      Me.lblName.Text = "Name"
      '
      'tbpDetails
      '
      Me.tbpDetails.Controls.AddRange(New System.Windows.Forms.Control() {Me.chkHomepagePublic, Me.chkEmailPublic, Me.chkRealNamePublic, Me.txtHomepage, Me.lblHomepage, Me.txtEmail, Me.lblEmail, Me.txtRealName, Me.lblRealName, Me.lblCreatedTitle, Me.lblCreated})
      Me.tbpDetails.Location = New System.Drawing.Point(4, 22)
      Me.tbpDetails.Name = "tbpDetails"
      Me.tbpDetails.Size = New System.Drawing.Size(272, 199)
      Me.tbpDetails.TabIndex = 5
      Me.tbpDetails.Text = "Details"
      '
      'chkHomepagePublic
      '
      Me.chkHomepagePublic.FlatStyle = System.Windows.Forms.FlatStyle.System
      Me.chkHomepagePublic.Location = New System.Drawing.Point(72, 136)
      Me.chkHomepagePublic.Name = "chkHomepagePublic"
      Me.chkHomepagePublic.Size = New System.Drawing.Size(56, 16)
      Me.chkHomepagePublic.TabIndex = 25
      Me.chkHomepagePublic.Text = "Public"
      '
      'chkEmailPublic
      '
      Me.chkEmailPublic.FlatStyle = System.Windows.Forms.FlatStyle.System
      Me.chkEmailPublic.Location = New System.Drawing.Point(72, 80)
      Me.chkEmailPublic.Name = "chkEmailPublic"
      Me.chkEmailPublic.Size = New System.Drawing.Size(56, 16)
      Me.chkEmailPublic.TabIndex = 24
      Me.chkEmailPublic.Text = "Public"
      '
      'chkRealNamePublic
      '
      Me.chkRealNamePublic.FlatStyle = System.Windows.Forms.FlatStyle.System
      Me.chkRealNamePublic.Location = New System.Drawing.Point(72, 32)
      Me.chkRealNamePublic.Name = "chkRealNamePublic"
      Me.chkRealNamePublic.Size = New System.Drawing.Size(56, 16)
      Me.chkRealNamePublic.TabIndex = 23
      Me.chkRealNamePublic.Text = "Public"
      '
      'txtHomepage
      '
      Me.txtHomepage.Location = New System.Drawing.Point(72, 112)
      Me.txtHomepage.Name = "txtHomepage"
      Me.txtHomepage.Size = New System.Drawing.Size(192, 20)
      Me.txtHomepage.TabIndex = 22
      Me.txtHomepage.Text = ""
      '
      'lblHomepage
      '
      Me.lblHomepage.Location = New System.Drawing.Point(8, 112)
      Me.lblHomepage.Name = "lblHomepage"
      Me.lblHomepage.Size = New System.Drawing.Size(64, 16)
      Me.lblHomepage.TabIndex = 21
      Me.lblHomepage.Text = "Homepage"
      '
      'txtEmail
      '
      Me.txtEmail.Location = New System.Drawing.Point(72, 56)
      Me.txtEmail.Name = "txtEmail"
      Me.txtEmail.Size = New System.Drawing.Size(192, 20)
      Me.txtEmail.TabIndex = 20
      Me.txtEmail.Text = ""
      '
      'lblEmail
      '
      Me.lblEmail.Location = New System.Drawing.Point(8, 56)
      Me.lblEmail.Name = "lblEmail"
      Me.lblEmail.Size = New System.Drawing.Size(40, 16)
      Me.lblEmail.TabIndex = 19
      Me.lblEmail.Text = "Email"
      '
      'txtRealName
      '
      Me.txtRealName.Location = New System.Drawing.Point(72, 8)
      Me.txtRealName.Name = "txtRealName"
      Me.txtRealName.Size = New System.Drawing.Size(192, 20)
      Me.txtRealName.TabIndex = 18
      Me.txtRealName.Text = ""
      '
      'lblRealName
      '
      Me.lblRealName.Location = New System.Drawing.Point(8, 8)
      Me.lblRealName.Name = "lblRealName"
      Me.lblRealName.Size = New System.Drawing.Size(64, 16)
      Me.lblRealName.TabIndex = 17
      Me.lblRealName.Text = "Real name"
      '
      'lblCreatedTitle
      '
      Me.lblCreatedTitle.Location = New System.Drawing.Point(8, 168)
      Me.lblCreatedTitle.Name = "lblCreatedTitle"
      Me.lblCreatedTitle.Size = New System.Drawing.Size(48, 23)
      Me.lblCreatedTitle.TabIndex = 16
      Me.lblCreatedTitle.Text = "Created"
      '
      'lblCreated
      '
      Me.lblCreated.Location = New System.Drawing.Point(56, 168)
      Me.lblCreated.Name = "lblCreated"
      Me.lblCreated.Size = New System.Drawing.Size(208, 23)
      Me.lblCreated.TabIndex = 15
      '
      'tbpLogin
      '
      Me.tbpLogin.Controls.AddRange(New System.Windows.Forms.Control() {Me.lblClientProtocol, Me.txtProxyLocation, Me.lblProxyHostname, Me.txtLocation, Me.lblHostname, Me.lblTime})
      Me.tbpLogin.Location = New System.Drawing.Point(4, 22)
      Me.tbpLogin.Name = "tbpLogin"
      Me.tbpLogin.Size = New System.Drawing.Size(272, 199)
      Me.tbpLogin.TabIndex = 2
      Me.tbpLogin.Text = "Login"
      '
      'tbpFolders
      '
      Me.tbpFolders.Controls.AddRange(New System.Windows.Forms.Control() {Me.cmdFolderRemove, Me.cmdFolderAdd, Me.rlbFolders})
      Me.tbpFolders.Location = New System.Drawing.Point(4, 22)
      Me.tbpFolders.Name = "tbpFolders"
      Me.tbpFolders.Size = New System.Drawing.Size(272, 199)
      Me.tbpFolders.TabIndex = 3
      Me.tbpFolders.Text = "Folders"
      '
      'cmdFolderRemove
      '
      Me.cmdFolderRemove.FlatStyle = System.Windows.Forms.FlatStyle.System
      Me.cmdFolderRemove.Location = New System.Drawing.Point(192, 40)
      Me.cmdFolderRemove.Name = "cmdFolderRemove"
      Me.cmdFolderRemove.Size = New System.Drawing.Size(72, 23)
      Me.cmdFolderRemove.TabIndex = 15
      Me.cmdFolderRemove.Text = "Remove"
      '
      'cmdFolderAdd
      '
      Me.cmdFolderAdd.FlatStyle = System.Windows.Forms.FlatStyle.System
      Me.cmdFolderAdd.Location = New System.Drawing.Point(192, 8)
      Me.cmdFolderAdd.Name = "cmdFolderAdd"
      Me.cmdFolderAdd.Size = New System.Drawing.Size(72, 23)
      Me.cmdFolderAdd.TabIndex = 14
      Me.cmdFolderAdd.Text = "Add..."
      '
      'rlbFolders
      '
      Me.rlbFolders.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
      Me.rlbFolders.ImageList = Nothing
      Me.rlbFolders.Location = New System.Drawing.Point(8, 8)
      Me.rlbFolders.Name = "rlbFolders"
      Me.rlbFolders.Size = New System.Drawing.Size(176, 186)
      Me.rlbFolders.Sorted = True
      Me.rlbFolders.TabIndex = 0
      '
      'tbpStats
      '
      Me.tbpStats.Controls.AddRange(New System.Windows.Forms.Control() {Me.txtLastMsg, Me.txtLongestLogin, Me.lblLastMsg, Me.txtNumVotes, Me.lblNumVotes, Me.lblTotalMsgs, Me.txtTotalMsgs, Me.lblNumMsgs, Me.txtNumMsgs, Me.lblLongestLogin, Me.txtTotalLogins, Me.lblTotalLogins, Me.txtNumLogins, Me.lblNumLogins})
      Me.tbpStats.Location = New System.Drawing.Point(4, 22)
      Me.tbpStats.Name = "tbpStats"
      Me.tbpStats.Size = New System.Drawing.Size(272, 199)
      Me.tbpStats.TabIndex = 4
      Me.tbpStats.Text = "Stats"
      '
      'txtLastMsg
      '
      Me.txtLastMsg.Location = New System.Drawing.Point(88, 144)
      Me.txtLastMsg.Name = "txtLastMsg"
      Me.txtLastMsg.Size = New System.Drawing.Size(176, 20)
      Me.txtLastMsg.TabIndex = 14
      Me.txtLastMsg.Text = ""
      '
      'txtLongestLogin
      '
      Me.txtLongestLogin.Location = New System.Drawing.Point(88, 56)
      Me.txtLongestLogin.Name = "txtLongestLogin"
      Me.txtLongestLogin.Size = New System.Drawing.Size(176, 20)
      Me.txtLongestLogin.TabIndex = 13
      Me.txtLongestLogin.Text = ""
      '
      'lblLastMsg
      '
      Me.lblLastMsg.Location = New System.Drawing.Point(8, 144)
      Me.lblLastMsg.Name = "lblLastMsg"
      Me.lblLastMsg.Size = New System.Drawing.Size(80, 24)
      Me.lblLastMsg.TabIndex = 12
      Me.lblLastMsg.Text = "Last message"
      '
      'txtNumVotes
      '
      Me.txtNumVotes.Location = New System.Drawing.Point(88, 168)
      Me.txtNumVotes.Name = "txtNumVotes"
      Me.txtNumVotes.Size = New System.Drawing.Size(176, 20)
      Me.txtNumVotes.TabIndex = 11
      Me.txtNumVotes.Text = ""
      '
      'lblNumVotes
      '
      Me.lblNumVotes.Location = New System.Drawing.Point(8, 168)
      Me.lblNumVotes.Name = "lblNumVotes"
      Me.lblNumVotes.Size = New System.Drawing.Size(40, 24)
      Me.lblNumVotes.TabIndex = 10
      Me.lblNumVotes.Text = "Votes"
      '
      'lblTotalMsgs
      '
      Me.lblTotalMsgs.Location = New System.Drawing.Point(8, 120)
      Me.lblTotalMsgs.Name = "lblTotalMsgs"
      Me.lblTotalMsgs.Size = New System.Drawing.Size(56, 23)
      Me.lblTotalMsgs.TabIndex = 9
      Me.lblTotalMsgs.Text = "Total size"
      '
      'txtTotalMsgs
      '
      Me.txtTotalMsgs.Location = New System.Drawing.Point(88, 120)
      Me.txtTotalMsgs.Name = "txtTotalMsgs"
      Me.txtTotalMsgs.Size = New System.Drawing.Size(176, 20)
      Me.txtTotalMsgs.TabIndex = 8
      Me.txtTotalMsgs.Text = ""
      '
      'lblNumMsgs
      '
      Me.lblNumMsgs.Location = New System.Drawing.Point(8, 96)
      Me.lblNumMsgs.Name = "lblNumMsgs"
      Me.lblNumMsgs.Size = New System.Drawing.Size(56, 23)
      Me.lblNumMsgs.TabIndex = 7
      Me.lblNumMsgs.Text = "Messages"
      '
      'txtNumMsgs
      '
      Me.txtNumMsgs.Location = New System.Drawing.Point(88, 96)
      Me.txtNumMsgs.Name = "txtNumMsgs"
      Me.txtNumMsgs.Size = New System.Drawing.Size(176, 20)
      Me.txtNumMsgs.TabIndex = 6
      Me.txtNumMsgs.Text = ""
      '
      'lblLongestLogin
      '
      Me.lblLongestLogin.Location = New System.Drawing.Point(8, 56)
      Me.lblLongestLogin.Name = "lblLongestLogin"
      Me.lblLongestLogin.Size = New System.Drawing.Size(72, 24)
      Me.lblLongestLogin.TabIndex = 5
      Me.lblLongestLogin.Text = "Longest login"
      '
      'txtTotalLogins
      '
      Me.txtTotalLogins.Location = New System.Drawing.Point(88, 32)
      Me.txtTotalLogins.Name = "txtTotalLogins"
      Me.txtTotalLogins.Size = New System.Drawing.Size(176, 20)
      Me.txtTotalLogins.TabIndex = 3
      Me.txtTotalLogins.Text = ""
      '
      'lblTotalLogins
      '
      Me.lblTotalLogins.Location = New System.Drawing.Point(8, 32)
      Me.lblTotalLogins.Name = "lblTotalLogins"
      Me.lblTotalLogins.Size = New System.Drawing.Size(56, 23)
      Me.lblTotalLogins.TabIndex = 2
      Me.lblTotalLogins.Text = "Total time"
      '
      'txtNumLogins
      '
      Me.txtNumLogins.Location = New System.Drawing.Point(88, 8)
      Me.txtNumLogins.Name = "txtNumLogins"
      Me.txtNumLogins.Size = New System.Drawing.Size(176, 20)
      Me.txtNumLogins.TabIndex = 1
      Me.txtNumLogins.Text = ""
      '
      'lblNumLogins
      '
      Me.lblNumLogins.Location = New System.Drawing.Point(8, 8)
      Me.lblNumLogins.Name = "lblNumLogins"
      Me.lblNumLogins.Size = New System.Drawing.Size(40, 23)
      Me.lblNumLogins.TabIndex = 0
      Me.lblNumLogins.Text = "Logins"
      '
      'tbpEDF
      '
      Me.tbpEDF.Controls.AddRange(New System.Windows.Forms.Control() {Me.txtEDF})
      Me.tbpEDF.DockPadding.All = 8
      Me.tbpEDF.Location = New System.Drawing.Point(4, 22)
      Me.tbpEDF.Name = "tbpEDF"
      Me.tbpEDF.Size = New System.Drawing.Size(272, 199)
      Me.tbpEDF.TabIndex = 0
      Me.tbpEDF.Text = "EDF"
      '
      'txtEDF
      '
      Me.txtEDF.Dock = System.Windows.Forms.DockStyle.Fill
      Me.txtEDF.Location = New System.Drawing.Point(8, 8)
      Me.txtEDF.Multiline = True
      Me.txtEDF.Name = "txtEDF"
      Me.txtEDF.ReadOnly = True
      Me.txtEDF.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
      Me.txtEDF.Size = New System.Drawing.Size(256, 183)
      Me.txtEDF.TabIndex = 0
      Me.txtEDF.Text = ""
      '
      'lblTime
      '
      Me.lblTime.Location = New System.Drawing.Point(8, 8)
      Me.lblTime.Name = "lblTime"
      Me.lblTime.Size = New System.Drawing.Size(256, 23)
      Me.lblTime.TabIndex = 0
      '
      'lblHostname
      '
      Me.lblHostname.Location = New System.Drawing.Point(8, 32)
      Me.lblHostname.Name = "lblHostname"
      Me.lblHostname.Size = New System.Drawing.Size(100, 16)
      Me.lblHostname.TabIndex = 1
      '
      'txtLocation
      '
      Me.txtLocation.Location = New System.Drawing.Point(112, 32)
      Me.txtLocation.Name = "txtLocation"
      Me.txtLocation.Size = New System.Drawing.Size(152, 20)
      Me.txtLocation.TabIndex = 2
      Me.txtLocation.Text = ""
      '
      'lblProxyHostname
      '
      Me.lblProxyHostname.Location = New System.Drawing.Point(8, 56)
      Me.lblProxyHostname.Name = "lblProxyHostname"
      Me.lblProxyHostname.Size = New System.Drawing.Size(104, 16)
      Me.lblProxyHostname.TabIndex = 3
      '
      'txtProxyLocation
      '
      Me.txtProxyLocation.Location = New System.Drawing.Point(112, 56)
      Me.txtProxyLocation.Name = "txtProxyLocation"
      Me.txtProxyLocation.Size = New System.Drawing.Size(152, 20)
      Me.txtProxyLocation.TabIndex = 4
      Me.txtProxyLocation.Text = ""
      '
      'lblClientProtocol
      '
      Me.lblClientProtocol.Location = New System.Drawing.Point(8, 80)
      Me.lblClientProtocol.Name = "lblClientProtocol"
      Me.lblClientProtocol.Size = New System.Drawing.Size(256, 16)
      Me.lblClientProtocol.TabIndex = 5
      '
      'frmUsers
      '
      Me.AcceptButton = Me.cmdClose
      Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
      Me.CancelButton = Me.cmdClose
      Me.ClientSize = New System.Drawing.Size(408, 273)
      Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.pnlItem, Me.pnlItems, Me.pnlBottom})
      Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
      Me.Name = "frmUsers"
      Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
      Me.Text = "Users"
      Me.pnlBottom.ResumeLayout(False)
      Me.pnlItems.ResumeLayout(False)
      Me.pnlItem.ResumeLayout(False)
      Me.tabItem.ResumeLayout(False)
      Me.tbpGeneral.ResumeLayout(False)
      Me.tbpDetails.ResumeLayout(False)
      Me.tbpLogin.ResumeLayout(False)
      Me.tbpFolders.ResumeLayout(False)
      Me.tbpStats.ResumeLayout(False)
      Me.tbpEDF.ResumeLayout(False)
      Me.ResumeLayout(False)

   End Sub

#End Region

   Private Sub SetData()
      Dim iUserNum As Integer
      Dim pUser As UserLookup
      Dim pLookup As Lookup

      lstUsers.BeginUpdate()
      For iUserNum = 0 To UserCount() - 1
         pUser = UserList(iUserNum)
         pLookup = New Lookup(0, pUser.m_iID, pUser.m_sValue)
         lstUsers.Items.Add(pLookup)
      Next
      lstUsers.EndUpdate()
   End Sub

   Private Sub AdminControls(ByVal bEditable As Boolean)
      txtName.Enabled = bEditable
      cmbAccessLevel.Enabled = bEditable
      chkAccessAgent.Enabled = bEditable
      txtAccessName.Enabled = bEditable
      txtDescription.Enabled = bEditable
   End Sub

   Private Sub RefreshUserDetail(ByRef pEDF As CEDF, ByVal sName As String, ByRef pValue As TextBox, ByRef pPublic As CheckBox)
      Dim iType As Integer

      If pEDF.Child(sName) = True Then
         pValue.Text = TextDecode(pEDF.GetStr())

         iType = pEDF.GetChildInt("type")
         pPublic.Checked = mask(iType, ua.DETAIL_PUBLIC)

         pEDF.Parent()
      End If
   End Sub

   Private Sub RefreshUser(ByVal pItem As Lookup)
      Dim pRequest As CEDF, pReply As CEDF
      Dim iCurrID As Integer, iCurrLevel As Integer
      Dim iID As Integer, iUserType As Integer, iAccessLevel As Integer, iOwnerID As Integer, iTimeOn As Integer, iStatus As Integer, iCreated As Integer
      Dim iFolderID As Integer, iSubType As Integer
      Dim iNumLogins As Integer, iTotalLogins As Integer, iLongestLogin As Integer, iNumMsgs As Integer, iTotalMsgs As Integer, iLastMsg As Integer, iNumVotes As Integer
      Dim bLoop As Boolean
      Dim sName As String, sAccessName As String, sTimeOn As String, sLogin As String, sFolderName As String
      Dim sClient As String, sProtocol As String
      Dim pControl As Control
      Dim pLookup As Lookup

      If m_bUserInput = True Then
         SaveChanges()

         m_bUserInput = False

         pRequest = New CEDF()
         pRequest.AddChild("userid", pItem.m_iID)

         pReply = New CEDF()

         If Client.request3(ua.MSG_USER_LIST, pRequest, pReply) = True Then
            'pReply.MsgPrint("frmUsers::lstUsers reply")

            m_pItem = pReply
            m_pLookup = pItem

            If pReply.Child("user") = True Then
               iCurrID = Client.GetID()
               iCurrLevel = Client.GetAccessLevel()

               iID = pReply.GetInt()
               sName = pReply.GetChildStr("name")
               iAccessLevel = pReply.GetChildInt("accesslevel")
               iUserType = pReply.GetChildInt("usertype")
               sAccessName = pReply.GetChildStr("accessname")
               iOwnerID = pReply.GetChildInt("ownerid")
               iCreated = pReply.GetChildInt("created")

               Me.Text = iID & " - Users"

               txtName.Text = sName
               cmbAccessLevel.SelectedIndex = iAccessLevel
               chkAccessAgent.Checked = mask(iUserType, ua.USERTYPE_AGENT)
               txtAccessName.Text = sAccessName
               If iCreated > 0 Then
                  lblCreated.Text = sUAveHelper.StrTime(sUAveHelper.STRTIME_SHORT, iCreated)
               Else
                  lblCreated.Text = ""
               End If
               txtDescription.Text = TextDecode(pReply.GetChildStr("description"))

               If iCurrLevel < ua.LEVEL_WITNESS Then
                  AdminControls(iCurrID = iOwnerID)
               End If

               If pReply.Child("login") = True Then
                  iTimeOn = pReply.GetChildInt("timeon")
                  iStatus = pReply.GetChildInt("status")

                  If mask(iStatus, ua.LOGIN_ON) = True Then
                     sLogin = "Current"
                  Else
                     sLogin = "Last"
                  End If
                  sTimeOn = StrTime(STRTIME_SHORT, iTimeOn)
                  'lblTimeOn.Text = sLogin & " login: " & sTimeOn

                  lblTime.Text = sTimeOn

                  lblHostname.Text = pReply.GetChildStr("hostname")
                  txtLocation.Text = pReply.GetChildStr("location")
                  lblProxyHostname.Text = pReply.GetChildStr("proxyhostname")
                  txtProxyLocation.Text = pReply.GetChildStr("proxylocation")

                  sClient = pReply.GetChildStr("client")
                  sProtocol = pReply.GetChildStr("protocol")

                  lblClientProtocol.Text = sClient & " (" & sProtocol & ")"

                  pReply.Parent()
               End If

               If pReply.Child("details") = True Then
                  RefreshUserDetail(pReply, "realname", txtRealName, chkRealNamePublic)
                  RefreshUserDetail(pReply, "email", txtEmail, chkEmailPublic)
                  RefreshUserDetail(pReply, "homepage", txtHomepage, chkHomepagePublic)

                  pReply.Parent()
               Else
                  txtRealName.Text = ""
                  chkRealNamePublic.Checked = False

                  txtEmail.Text = ""
                  chkEmailPublic.Checked = False

                  txtHomepage.Text = ""
                  chkHomepagePublic.Checked = False
               End If

               rlbFolders.Items.Clear()
               If pReply.Child("folders") = True Then
                  bLoop = pReply.Child()
                  Do While bLoop = True
                     iFolderID = pReply.GetInt()
                     If pReply.GetName() = "subscriber" Then
                        iSubType = ua.SUBTYPE_SUB
                     ElseIf pReply.GetName() = "member" Then
                        iSubType = ua.SUBTYPE_MEMBER
                     ElseIf pReply.GetName() = "editor" Then
                        iSubType = ua.SUBTYPE_EDITOR
                     Else
                        iSubType = 0
                     End If

                     If iSubType > 0 Then
                        sFolderName = pReply.GetChildStr("name")

                        pLookup = New Lookup(Lookup.FOLDER_SUB, iFolderID, iSubType, sFolderName, -1)
                        rlbFolders.Items.Add(pLookup)
                     End If

                     bLoop = pReply.Next()
                     If bLoop = False Then
                        pReply.Parent()
                     End If
                  Loop

                  pReply.Parent()
               End If

               If pReply.Child("stats") = True Then
                  iNumLogins = pReply.GetChildInt("numlogins")
                  If iNumLogins > 0 Then
                     iTotalLogins = pReply.GetChildInt("totallogins")
                     iLongestLogin = pReply.GetChildInt("longestlogin")

                     txtNumLogins.Text = iNumLogins
                     txtTotalLogins.Text = StrValue(STRVALUE_TIME, iTotalLogins, 2)
                     txtLongestLogin.Text = StrValue(STRVALUE_TIME, iLongestLogin, 2)
                  Else
                     txtNumLogins.Text = ""
                     txtTotalLogins.Text = ""
                     txtLongestLogin.Text = ""
                  End If

                  iNumMsgs = pReply.GetChildInt("nummsgs")
                  If iNumMsgs > 0 Then
                     iTotalMsgs = pReply.GetChildInt("totalmsgs")
                     iLastMsg = pReply.GetChildInt("lastmsg")

                     txtNumMsgs.Text = iNumMsgs
                     txtTotalMsgs.Text = StrValue(STRVALUE_BYTE, iTotalMsgs)
                     txtLastMsg.Text = StrTime(STRTIME_SHORT, iLastMsg)
                  Else
                     txtNumMsgs.Text = ""
                     txtTotalMsgs.Text = ""
                     txtLastMsg.Text = ""
                  End If

                  iNumVotes = pReply.GetChildInt("numvotes")
                  If iNumVotes > 0 Then
                     txtNumVotes.Text = iNumVotes
                  Else
                     txtNumVotes.Text = ""
                  End If

                  pReply.Parent()
               Else
                  txtNumLogins.Text = ""
                  txtTotalLogins.Text = ""
                  txtLongestLogin.Text = ""

                  txtNumMsgs.Text = ""
                  txtTotalMsgs.Text = ""
                  txtLastMsg.Text = ""

                  txtNumVotes.Text = ""
               End If

               txtEDF.Text = pReply.Write(CEDF.PR_SPACE + CEDF.PR_CRLF)

               pReply.Parent()
            End If

            m_pRequest = New CEDF()
         Else
            pReply.MsgPrint("frmUsers::lstUsers request failed")
         End If

         m_bUserInput = True
      End If
   End Sub

   Private Sub lstUsers_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lstUsers.SelectedIndexChanged
      Dim pLookup As Lookup

      pLookup = lstUsers.SelectedItem
      If Not pLookup Is Nothing Then
         RefreshUser(pLookup)
      End If
   End Sub

   Private Sub cmdClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdClose.Click
      SaveChanges()

      If m_bUpdate = True Then
         'Refresh users
      End If

      Me.Dispose()
   End Sub

   Public Shared Function getForm() As Form
      Return m_pForm
   End Function

   Private Sub cmdFolderAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdFolderAdd.Click
      AddSubToList("folder", "folder", "user", m_pLookup, rlbFolders)
   End Sub

   Private Sub cmdFolderRemove_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdFolderRemove.Click
      RemoveSubFromList("folder", "folder", "user", m_pLookup, rlbFolders)
   End Sub

   Private Sub SaveChanges()
      Dim iUserNum As Integer
      Dim bLoop As Boolean = True
      Dim sName As String
      Dim pLookup As Lookup
      Dim pUser As UserLookup
      Dim pReply As CEDF

      m_bUserInput = False

      If Not m_pRequest Is Nothing Then
         If m_pRequest.Children() > 0 Then
            If MsgBox("Save changes?", MsgBoxStyle.Question + MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
               m_pRequest.AddChild("userid", m_pLookup.m_iID)

               pReply = New CEDF()

               If Client.request3("user_edit", m_pRequest, pReply) = True Then
                  sName = pReply.GetChildStr("username")

                  pUser = UserGet(m_pLookup.m_iID)

                  If pUser.m_sValue <> sName Then
                     bLoop = True
                     Do While bLoop = True And iUserNum < lstUsers.Items.Count
                        pLookup = lstUsers.Items.Item(iUserNum)
                        If pLookup.m_iID = m_pLookup.m_iID Then
                           pLookup.m_sValue = sName

                           lstUsers.BeginUpdate()
                           lstUsers.Items.RemoveAt(iUserNum)
                           lstUsers.Items.Add(pLookup)
                           lstUsers.EndUpdate()

                           bLoop = False
                        Else
                           iUserNum += 1
                        End If
                     Loop

                     pUser.m_sValue = sName

                     m_bUpdate = True
                  End If
               Else
                  pReply.MsgPrint("frmUsers::SaveChanges request failed")
               End If
            End If
         End If
      End If

      m_bUserInput = True
   End Sub

   Private Sub txtName_Leave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtName.Leave
      If m_bUserInput = True Then
         m_pRequest.SetChild("name", txtName.Text)
      End If
   End Sub

   Private Sub txtAccessName_Leave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtAccessName.Leave
      If m_bUserInput = True Then
         If txtAccessName.Text <> "" Then
            m_pRequest.SetChild("accessname", txtAccessName.Text)
         Else
            m_pRequest.SetChild("accessname", 0)
         End If
      End If
   End Sub

   Private Sub cmbAccessLevel_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbAccessLevel.SelectedIndexChanged
      If m_bUserInput = True Then
         m_pRequest.SetChild("accesslevel", cmbAccessLevel.SelectedIndex)
      End If
   End Sub

   Private Sub chkAccessAgent_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkAccessAgent.CheckedChanged
      Dim iUserType As Integer

      If m_bUserInput = True Then
         iUserType = m_pItem.GetChildInt("usertype")
         If chkAccessAgent.Checked = True Then
            iUserType += ua.USERTYPE_AGENT
         Else
            iUserType -= ua.USERTYPE_AGENT
         End If
         m_pItem.SetChild("usertype", iUserType)

         m_pRequest.SetChild("usertype", iUserType)
      End If
   End Sub

   Private Sub txtDescription_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtDescription.Leave
      If m_bUserInput = True Then
         m_pRequest.SetChild("description", txtDescription.Text)
      End If
   End Sub

   Private Sub txtRealName_Leave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtRealName.Leave
      SetUserDetail("realname", txtRealName)
   End Sub

   Private Sub SetUserDetail(ByVal sField As String, ByRef pControl As TextBox)
      If m_bUserInput = True Then
         If m_pRequest.Child("details") = False Then
            m_pRequest.Add("details")
         End If

         m_pRequest.SetChild(sField, pControl.Text)

         m_pRequest.Parent()
      End If
   End Sub

   Private Sub SetUserDetail(ByVal sField As String, ByVal bPublic As Boolean)
      Dim iType As Integer

      If m_bUserInput = True Then
         If m_pItem.Child("details") = True Then
            If m_pItem.Child(sField) = True Then
               iType = m_pItem.GetChildInt("type")

               m_pItem.Parent()
            End If

            m_pItem.Parent()
         End If

         If m_pRequest.Child("details") = False Then
            m_pRequest.Add("details")
         End If

         If m_pRequest.Child(sField) = False Then
            m_pRequest.Add(sField)
         End If

         m_pRequest.SetChild("type", iType)

         m_pRequest.Parent()
         m_pRequest.Parent()
      End If
   End Sub

   Private Sub chkRealNamePublic_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkRealNamePublic.CheckedChanged
      SetUserDetail("realname", chkRealNamePublic.Checked)
   End Sub
End Class
