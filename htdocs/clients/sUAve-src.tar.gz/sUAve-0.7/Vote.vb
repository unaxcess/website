Imports org.ua2

Public Class frmVote
   Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

   Public Sub New(ByRef pEDF As CEDF)
      MyBase.New()

      'This call is required by the Windows Form Designer.
      InitializeComponent()

      'Add any initialization after the InitializeComponent() call
      SetData(pEDF)
   End Sub

   'Form overrides dispose to clean up the component list.
   Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
      If disposing Then
         If Not (components Is Nothing) Then
            components.Dispose()
         End If
      End If
      MyBase.Dispose(disposing)
   End Sub

   'Required by the Windows Form Designer
   Private components As System.ComponentModel.IContainer

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   Friend WithEvents lstOptions As System.Windows.Forms.ListBox
   Friend WithEvents txtOption As System.Windows.Forms.TextBox
   Friend WithEvents cmdOptionAdd As System.Windows.Forms.Button
   Friend WithEvents cmdOptionDelete As System.Windows.Forms.Button
   Friend WithEvents lblType As System.Windows.Forms.Label
   Friend WithEvents cmbType As System.Windows.Forms.ComboBox
   Friend WithEvents lblValue As System.Windows.Forms.Label
   Friend WithEvents cmbValue As System.Windows.Forms.ComboBox
   Friend WithEvents lblMinValue As System.Windows.Forms.Label
   Friend WithEvents txtMinValue As System.Windows.Forms.TextBox
   Friend WithEvents lblMaxValue As System.Windows.Forms.Label
   Friend WithEvents txtMaxValue As System.Windows.Forms.TextBox
   Friend WithEvents chkChange As System.Windows.Forms.CheckBox
   Friend WithEvents lblPublic As System.Windows.Forms.Label
   Friend WithEvents cmbPublic As System.Windows.Forms.ComboBox
   Friend WithEvents lblClose As System.Windows.Forms.Label
   Friend WithEvents txtClose As System.Windows.Forms.TextBox
   Friend WithEvents cmbClose As System.Windows.Forms.ComboBox
   Friend WithEvents cmdOK As System.Windows.Forms.Button
   Friend WithEvents cmdCancel As System.Windows.Forms.Button
   Friend WithEvents chkAnonymous As System.Windows.Forms.CheckBox
   Friend WithEvents cmdOptionUp As System.Windows.Forms.Button
   Friend WithEvents cmdOptionDown As System.Windows.Forms.Button
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmVote))
      Me.lstOptions = New System.Windows.Forms.ListBox()
      Me.txtOption = New System.Windows.Forms.TextBox()
      Me.cmdOptionAdd = New System.Windows.Forms.Button()
      Me.cmdOptionDelete = New System.Windows.Forms.Button()
      Me.lblType = New System.Windows.Forms.Label()
      Me.cmbType = New System.Windows.Forms.ComboBox()
      Me.chkAnonymous = New System.Windows.Forms.CheckBox()
      Me.lblValue = New System.Windows.Forms.Label()
      Me.cmbValue = New System.Windows.Forms.ComboBox()
      Me.lblMinValue = New System.Windows.Forms.Label()
      Me.txtMinValue = New System.Windows.Forms.TextBox()
      Me.lblMaxValue = New System.Windows.Forms.Label()
      Me.txtMaxValue = New System.Windows.Forms.TextBox()
      Me.chkChange = New System.Windows.Forms.CheckBox()
      Me.lblPublic = New System.Windows.Forms.Label()
      Me.cmbPublic = New System.Windows.Forms.ComboBox()
      Me.lblClose = New System.Windows.Forms.Label()
      Me.txtClose = New System.Windows.Forms.TextBox()
      Me.cmbClose = New System.Windows.Forms.ComboBox()
      Me.cmdOK = New System.Windows.Forms.Button()
      Me.cmdCancel = New System.Windows.Forms.Button()
      Me.cmdOptionUp = New System.Windows.Forms.Button()
      Me.cmdOptionDown = New System.Windows.Forms.Button()
      Me.SuspendLayout()
      '
      'lstOptions
      '
      Me.lstOptions.Location = New System.Drawing.Point(8, 152)
      Me.lstOptions.Name = "lstOptions"
      Me.lstOptions.Size = New System.Drawing.Size(120, 134)
      Me.lstOptions.TabIndex = 10
      '
      'txtOption
      '
      Me.txtOption.Location = New System.Drawing.Point(136, 152)
      Me.txtOption.Name = "txtOption"
      Me.txtOption.TabIndex = 11
      Me.txtOption.Text = ""
      '
      'cmdOptionAdd
      '
      Me.cmdOptionAdd.Enabled = False
      Me.cmdOptionAdd.FlatStyle = System.Windows.Forms.FlatStyle.System
      Me.cmdOptionAdd.Location = New System.Drawing.Point(136, 176)
      Me.cmdOptionAdd.Name = "cmdOptionAdd"
      Me.cmdOptionAdd.Size = New System.Drawing.Size(56, 23)
      Me.cmdOptionAdd.TabIndex = 12
      Me.cmdOptionAdd.Text = "Add"
      '
      'cmdOptionDelete
      '
      Me.cmdOptionDelete.Enabled = False
      Me.cmdOptionDelete.FlatStyle = System.Windows.Forms.FlatStyle.System
      Me.cmdOptionDelete.Location = New System.Drawing.Point(136, 200)
      Me.cmdOptionDelete.Name = "cmdOptionDelete"
      Me.cmdOptionDelete.Size = New System.Drawing.Size(56, 23)
      Me.cmdOptionDelete.TabIndex = 13
      Me.cmdOptionDelete.Text = "Delete"
      '
      'lblType
      '
      Me.lblType.Location = New System.Drawing.Point(8, 8)
      Me.lblType.Name = "lblType"
      Me.lblType.Size = New System.Drawing.Size(64, 16)
      Me.lblType.TabIndex = 2
      Me.lblType.Text = "Vote type"
      '
      'cmbType
      '
      Me.cmbType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
      Me.cmbType.Items.AddRange(New Object() {"Single option", "Multiple options", "User's own value"})
      Me.cmbType.Location = New System.Drawing.Point(80, 8)
      Me.cmbType.Name = "cmbType"
      Me.cmbType.Size = New System.Drawing.Size(152, 21)
      Me.cmbType.TabIndex = 3
      '
      'chkAnonymous
      '
      Me.chkAnonymous.Checked = True
      Me.chkAnonymous.CheckState = System.Windows.Forms.CheckState.Checked
      Me.chkAnonymous.FlatStyle = System.Windows.Forms.FlatStyle.System
      Me.chkAnonymous.Location = New System.Drawing.Point(80, 32)
      Me.chkAnonymous.Name = "chkAnonymous"
      Me.chkAnonymous.Size = New System.Drawing.Size(80, 16)
      Me.chkAnonymous.TabIndex = 0
      Me.chkAnonymous.Text = "Anonymous"
      '
      'lblValue
      '
      Me.lblValue.Enabled = False
      Me.lblValue.Location = New System.Drawing.Point(8, 72)
      Me.lblValue.Name = "lblValue"
      Me.lblValue.Size = New System.Drawing.Size(64, 16)
      Me.lblValue.TabIndex = 4
      Me.lblValue.Text = "Value type"
      '
      'cmbValue
      '
      Me.cmbValue.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
      Me.cmbValue.Enabled = False
      Me.cmbValue.Items.AddRange(New Object() {"Integer", "Percentage", "Float", "Percent (float)", "String"})
      Me.cmbValue.Location = New System.Drawing.Point(80, 72)
      Me.cmbValue.Name = "cmbValue"
      Me.cmbValue.Size = New System.Drawing.Size(152, 21)
      Me.cmbValue.TabIndex = 5
      '
      'lblMinValue
      '
      Me.lblMinValue.Enabled = False
      Me.lblMinValue.Location = New System.Drawing.Point(8, 96)
      Me.lblMinValue.Name = "lblMinValue"
      Me.lblMinValue.Size = New System.Drawing.Size(56, 16)
      Me.lblMinValue.TabIndex = 6
      Me.lblMinValue.Text = "Minimum"
      '
      'txtMinValue
      '
      Me.txtMinValue.Enabled = False
      Me.txtMinValue.Location = New System.Drawing.Point(80, 96)
      Me.txtMinValue.Name = "txtMinValue"
      Me.txtMinValue.TabIndex = 7
      Me.txtMinValue.Text = ""
      '
      'lblMaxValue
      '
      Me.lblMaxValue.Enabled = False
      Me.lblMaxValue.Location = New System.Drawing.Point(8, 120)
      Me.lblMaxValue.Name = "lblMaxValue"
      Me.lblMaxValue.Size = New System.Drawing.Size(56, 16)
      Me.lblMaxValue.TabIndex = 8
      Me.lblMaxValue.Text = "Maximum"
      '
      'txtMaxValue
      '
      Me.txtMaxValue.Enabled = False
      Me.txtMaxValue.Location = New System.Drawing.Point(80, 120)
      Me.txtMaxValue.Name = "txtMaxValue"
      Me.txtMaxValue.TabIndex = 9
      Me.txtMaxValue.Text = ""
      '
      'chkChange
      '
      Me.chkChange.Enabled = False
      Me.chkChange.FlatStyle = System.Windows.Forms.FlatStyle.System
      Me.chkChange.Location = New System.Drawing.Point(80, 48)
      Me.chkChange.Name = "chkChange"
      Me.chkChange.Size = New System.Drawing.Size(104, 16)
      Me.chkChange.TabIndex = 1
      Me.chkChange.Text = "Allow changing"
      '
      'lblPublic
      '
      Me.lblPublic.Location = New System.Drawing.Point(8, 296)
      Me.lblPublic.Name = "lblPublic"
      Me.lblPublic.Size = New System.Drawing.Size(72, 16)
      Me.lblPublic.TabIndex = 14
      Me.lblPublic.Text = "Public results"
      '
      'cmbPublic
      '
      Me.cmbPublic.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
      Me.cmbPublic.Items.AddRange(New Object() {"Before and after closing", "After closing", "Never"})
      Me.cmbPublic.Location = New System.Drawing.Point(80, 296)
      Me.cmbPublic.Name = "cmbPublic"
      Me.cmbPublic.Size = New System.Drawing.Size(152, 21)
      Me.cmbPublic.TabIndex = 15
      '
      'lblClose
      '
      Me.lblClose.Enabled = False
      Me.lblClose.Location = New System.Drawing.Point(8, 320)
      Me.lblClose.Name = "lblClose"
      Me.lblClose.Size = New System.Drawing.Size(64, 16)
      Me.lblClose.TabIndex = 16
      Me.lblClose.Text = "Close time"
      '
      'txtClose
      '
      Me.txtClose.Enabled = False
      Me.txtClose.Location = New System.Drawing.Point(80, 320)
      Me.txtClose.Name = "txtClose"
      Me.txtClose.Size = New System.Drawing.Size(56, 20)
      Me.txtClose.TabIndex = 17
      Me.txtClose.Text = ""
      '
      'cmbClose
      '
      Me.cmbClose.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
      Me.cmbClose.Enabled = False
      Me.cmbClose.Items.AddRange(New Object() {"Hours", "Days"})
      Me.cmbClose.Location = New System.Drawing.Point(144, 320)
      Me.cmbClose.Name = "cmbClose"
      Me.cmbClose.Size = New System.Drawing.Size(64, 21)
      Me.cmbClose.TabIndex = 18
      '
      'cmdOK
      '
      Me.cmdOK.Enabled = False
      Me.cmdOK.Location = New System.Drawing.Point(96, 352)
      Me.cmdOK.Name = "cmdOK"
      Me.cmdOK.Size = New System.Drawing.Size(64, 23)
      Me.cmdOK.TabIndex = 19
      Me.cmdOK.Text = "OK"
      '
      'cmdCancel
      '
      Me.cmdCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
      Me.cmdCancel.Location = New System.Drawing.Point(168, 352)
      Me.cmdCancel.Name = "cmdCancel"
      Me.cmdCancel.Size = New System.Drawing.Size(64, 23)
      Me.cmdCancel.TabIndex = 20
      Me.cmdCancel.Text = "Cancel"
      '
      'cmdOptionUp
      '
      Me.cmdOptionUp.Enabled = False
      Me.cmdOptionUp.Location = New System.Drawing.Point(136, 240)
      Me.cmdOptionUp.Name = "cmdOptionUp"
      Me.cmdOptionUp.Size = New System.Drawing.Size(56, 23)
      Me.cmdOptionUp.TabIndex = 21
      Me.cmdOptionUp.Text = "Up"
      '
      'cmdOptionDown
      '
      Me.cmdOptionDown.Enabled = False
      Me.cmdOptionDown.Location = New System.Drawing.Point(136, 264)
      Me.cmdOptionDown.Name = "cmdOptionDown"
      Me.cmdOptionDown.Size = New System.Drawing.Size(56, 23)
      Me.cmdOptionDown.TabIndex = 22
      Me.cmdOptionDown.Text = "Down"
      '
      'frmVote
      '
      Me.AcceptButton = Me.cmdOK
      Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
      Me.CancelButton = Me.cmdCancel
      Me.ClientSize = New System.Drawing.Size(240, 381)
      Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.cmdOptionDown, Me.cmdOptionUp, Me.cmdCancel, Me.cmdOK, Me.cmbClose, Me.txtClose, Me.lblClose, Me.cmbPublic, Me.lblPublic, Me.chkChange, Me.txtMaxValue, Me.lblMaxValue, Me.txtMinValue, Me.lblMinValue, Me.cmbValue, Me.lblValue, Me.chkAnonymous, Me.cmbType, Me.lblType, Me.cmdOptionDelete, Me.cmdOptionAdd, Me.txtOption, Me.lstOptions})
      Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
      Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
      Me.MaximizeBox = False
      Me.MinimizeBox = False
      Me.Name = "frmVote"
      Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
      Me.Text = "Vote"
      Me.ResumeLayout(False)

   End Sub

#End Region

   Private Sub SetData(ByRef pEDF As CEDF)
      Dim iVoteType As Integer
      Dim bLoop As Boolean
      Dim sOption As String

      If Not pEDF Is Nothing Then
         iVoteType = pEDF.GetChildInt("votetype")
         If mask(iVoteType, ua.VOTE_NAMED) = True Then
            chkAnonymous.Checked = False
         Else
            chkAnonymous.Checked = True
         End If

         bLoop = pEDF.Child("vote")
         While bLoop = True
            sOption = pEDF.GetStr()
            lstOptions.Items.Add(sOption)
            bLoop = pEDF.Next("vote")
            If bLoop = False Then
               pEDF.Parent()
            End If
         End While

         If mask(iVoteType, ua.VOTE_PUBLIC) = True Then
            cmbPublic.SelectedIndex = 0
         ElseIf mask(iVoteType, ua.VOTE_PUBLIC_CLOSE) = True Then
            cmbPublic.SelectedIndex = 1
         Else
            cmbPublic.SelectedIndex = 2
         End If
      Else
         cmbPublic.SelectedIndex = 1
      End If
   End Sub

   Public Function GetRequest() As CEDF
      Dim iVoteType As Integer
      Dim dValue As Double
      Dim sOption As String
      Dim pReturn As CEDF

      pReturn = New CEDF()

      If cmbType.SelectedIndex = 1 Then
         iVoteType += ua.VOTE_MULTI
      End If

      If chkAnonymous.Checked = False Then
         iVoteType += ua.VOTE_NAMED
      End If

      If cmbValue.SelectedIndex = 0 Then
         iVoteType += ua.VOTE_INTVALUES
      ElseIf cmbValue.SelectedIndex = 1 Then
         iVoteType += ua.VOTE_PERCENT
      ElseIf cmbValue.SelectedIndex = 2 Then
         iVoteType += ua.VOTE_FLOATVALUES
      ElseIf cmbValue.SelectedIndex = 3 Then
         iVoteType += ua.VOTE_FLOATPERCENT
      ElseIf cmbValue.SelectedIndex = 4 Then
         iVoteType += ua.VOTE_STRVALUES
      End If

      If txtMinValue.Text <> "" Then
         dValue = txtMinValue.Text
         pReturn.AddChild("minvalue", dValue)
      End If
      If txtMaxValue.Text <> "" Then
         dValue = txtMaxValue.Text
         pReturn.AddChild("maxvalue", dValue)
      End If

      For Each sOption In lstOptions.Items
         pReturn.AddChild("vote", sOption)
      Next

      If cmbPublic.SelectedIndex = 0 Then
         iVoteType += ua.VOTE_PUBLIC + ua.VOTE_PUBLIC_CLOSE
      ElseIf cmbPublic.SelectedIndex = 1 Then
         iVoteType += ua.VOTE_PUBLIC_CLOSE
      End If

      pReturn.AddChild("msgtype", ua.MSGTYPE_VOTE)
      pReturn.AddChild("votetype", iVoteType)

      'pReturn.MsgPrint("frmVote::GetRequest")

      Return pReturn
   End Function

   Private Sub lstOptions_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lstOptions.SelectedIndexChanged
      cmdOptionDelete.Enabled = True

      If lstOptions.SelectedIndex > 0 Then
         cmdOptionUp.Enabled = True
      Else
         cmdOptionUp.Enabled = False
      End If
      If lstOptions.SelectedIndex < lstOptions.Items.Count - 1 Then
         cmdOptionDown.Enabled = True
      Else
         cmdOptionDown.Enabled = False
      End If
   End Sub

   Private Sub cmdOptionDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdOptionDelete.Click
      lstOptions.Items.Remove(lstOptions.SelectedItem)

      If lstOptions.Items.Count = 0 Then
         cmdOK.Enabled = False
      End If
   End Sub

   Private Sub cmdOptionAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdOptionAdd.Click
      lstOptions.Items.Add(txtOption.Text)

      txtOption.Text = ""

      cmdOK.Enabled = True

      txtOption.Focus()
   End Sub

   Private Sub txtOption_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtOption.TextChanged
      If txtOption.Text <> "" Then
         cmdOptionAdd.Enabled = True
      Else
         cmdOptionAdd.Enabled = False
      End If
   End Sub

   Private Sub chkAnonymous_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkAnonymous.CheckedChanged
      If chkAnonymous.Checked = True Then
         chkChange.Enabled = False
         chkChange.Checked = False
      Else
         chkChange.Enabled = True
      End If
   End Sub

   Private Sub cmbType_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbType.SelectedIndexChanged
      Dim bOption As Boolean

      If cmbType.SelectedIndex = 1 Then
         chkAnonymous.Enabled = False
         chkAnonymous.Checked = False
      Else
         chkAnonymous.Enabled = True
      End If

      If cmbType.SelectedIndex = 2 Then
         If cmbValue.SelectedIndex = -1 Then
            cmbValue.SelectedIndex = 0
         End If

         cmdOK.Enabled = True

         bOption = False
      Else
         bOption = True

         cmdOK.Enabled = False
      End If

      lblValue.Enabled = Not bOption
      cmbValue.Enabled = Not bOption

      lstOptions.Enabled = bOption
      If bOption = False Then
         lstOptions.Items.Clear()
      End If
      txtOption.Enabled = bOption

      cmdOptionAdd.Enabled = bOption
      cmdOptionDelete.Enabled = bOption
      cmdOptionUp.Enabled = bOption
      cmdOptionDown.Enabled = bOption
   End Sub

   Private Sub cmdOptionUp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdOptionUp.Click
      Dim sOption As String

      sOption = lstOptions.Items.Item(lstOptions.SelectedIndex - 1)

      lstOptions.Items.Item(lstOptions.SelectedIndex - 1) = lstOptions.Items.Item(lstOptions.SelectedIndex)
      lstOptions.Items.Item(lstOptions.SelectedIndex) = sOption

      lstOptions.SelectedIndex -= 1
   End Sub

   Private Sub cmdOptionDown_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdOptionDown.Click
      Dim sOption As String

      sOption = lstOptions.Items.Item(lstOptions.SelectedIndex + 1)

      lstOptions.Items.Item(lstOptions.SelectedIndex + 1) = lstOptions.Items.Item(lstOptions.SelectedIndex)
      lstOptions.Items.Item(lstOptions.SelectedIndex) = sOption

      lstOptions.SelectedIndex += 1
   End Sub

   Private Sub cmdOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdOK.Click
      Me.DialogResult = DialogResult.OK
   End Sub

   Private Sub cmbValue_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbValue.SelectedIndexChanged
      Dim bValue As Boolean = False

      If cmbValue.SelectedIndex = 0 Or cmbValue.SelectedIndex = 2 Then
         bValue = True
      Else
         txtMinValue.Text = ""
         txtMaxValue.Text = ""
      End If

      lblMinValue.Enabled = bValue
      txtMinValue.Enabled = bValue
      lblMaxValue.Enabled = bValue
      txtMaxValue.Enabled = bValue
   End Sub
End Class
