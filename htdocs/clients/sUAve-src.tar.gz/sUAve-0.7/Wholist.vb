Imports System.IO
Imports Microsoft.Win32

Imports org.ua2

Public Class frmWholist
   Inherits System.Windows.Forms.Form

   Private Class WholistField
      Public m_sName As String
      Public m_sField As String
      Public m_iWidth As Integer
      Public m_bVisible As Boolean
   End Class

   Private m_pWholist As CEDF
   Private m_bRightButton As Boolean

   Private Shared m_pFields() As WholistField = Nothing
   Private m_pSortField As WholistField
   Private m_iColumn As Integer = -1
   Private m_bAscending As Boolean = True
   Private m_pField As WholistField
   Private m_pTimeMenu As MenuItem
   Private m_bSetData As Boolean
   Private m_bInit As Boolean = True

   Private Shared m_pForm As Form

#Region " Windows Form Designer generated code "

   Public Sub New(ByRef pWholist As CEDF)
      MyBase.New()

      'This call is required by the Windows Form Designer.
      InitializeComponent()

      'Add any initialization after the InitializeComponent() call
      Dim iValue As String
      Dim sValue As String, sValues() As String
      Dim pVersion As OperatingSystem
      Dim pSettings As RegistryKey

      sUAveFont(Me)
      m_pForm = FormAdd(Me)

      pSettings = GetRegSection()
      sValue = pSettings.GetValue("wholistwindow")
      If Not sValue Is Nothing Then
         sValues = sValue.Split(New Char() {","})
         If sValue.Length >= 2 Then
            Me.StartPosition = FormStartPosition.Manual

            Me.Left = sValues(0)
            Me.Top = sValues(1)
         End If
      End If

      CheckFields()

      m_pSortField = FieldFind(Nothing, "timeon")
      m_bAscending = False

      chkCustomColours.Checked = Client.GetClientBool("customcolours")
      chkCustomPictures.Checked = Client.GetClientBool("custompictures")

      debugline("frmWholist::frmWholist setting data")
      SetData(pWholist)

      m_bInit = False
   End Sub

   'Form overrides dispose to clean up the component list.
   Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
      Dim pSettings As RegistryKey

      If disposing Then
         'MsgBox("frmWholist::~frmWholist")

         tmrWholist.Enabled = False

         FormRemove(Me)
         m_pForm = Nothing

         pSettings = GetRegSection()
         pSettings.SetValue("wholistwindow", Me.Left & "," & Me.Top)

         If Not (components Is Nothing) Then
            components.Dispose()
         End If
         If Not (components Is Nothing) Then
            components.Dispose()
         End If
      End If
      MyBase.Dispose(disposing)
   End Sub

   Private WithEvents pMenu As MenuItem
   Friend WithEvents tmrWholist As System.Timers.Timer
   Friend WithEvents chkCustomColours As System.Windows.Forms.CheckBox
   Friend WithEvents mnuWholist As System.Windows.Forms.ContextMenu
   Friend WithEvents lvwWholist As System.Windows.Forms.ListView
   Friend WithEvents cmdClose As System.Windows.Forms.Button
   Friend WithEvents pnlButtons As System.Windows.Forms.Panel

   'Required by the Windows Form Designer
   Private components As System.ComponentModel.IContainer

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   Friend WithEvents imgWholist As System.Windows.Forms.ImageList
   Friend WithEvents chkCustomPictures As System.Windows.Forms.CheckBox
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Me.components = New System.ComponentModel.Container()
      Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmWholist))
      Me.pnlButtons = New System.Windows.Forms.Panel()
      Me.chkCustomPictures = New System.Windows.Forms.CheckBox()
      Me.chkCustomColours = New System.Windows.Forms.CheckBox()
      Me.cmdClose = New System.Windows.Forms.Button()
      Me.lvwWholist = New System.Windows.Forms.ListView()
      Me.mnuWholist = New System.Windows.Forms.ContextMenu()
      Me.tmrWholist = New System.Timers.Timer()
      Me.imgWholist = New System.Windows.Forms.ImageList(Me.components)
      Me.pnlButtons.SuspendLayout()
      CType(Me.tmrWholist, System.ComponentModel.ISupportInitialize).BeginInit()
      Me.SuspendLayout()
      '
      'pnlButtons
      '
      Me.pnlButtons.Controls.AddRange(New System.Windows.Forms.Control() {Me.chkCustomPictures, Me.chkCustomColours, Me.cmdClose})
      Me.pnlButtons.Dock = System.Windows.Forms.DockStyle.Bottom
      Me.pnlButtons.DockPadding.Bottom = 8
      Me.pnlButtons.DockPadding.Top = 8
      Me.pnlButtons.Location = New System.Drawing.Point(8, 217)
      Me.pnlButtons.Name = "pnlButtons"
      Me.pnlButtons.Size = New System.Drawing.Size(276, 48)
      Me.pnlButtons.TabIndex = 1
      '
      'chkCustomPictures
      '
      Me.chkCustomPictures.FlatStyle = System.Windows.Forms.FlatStyle.System
      Me.chkCustomPictures.Location = New System.Drawing.Point(0, 24)
      Me.chkCustomPictures.Name = "chkCustomPictures"
      Me.chkCustomPictures.Size = New System.Drawing.Size(104, 16)
      Me.chkCustomPictures.TabIndex = 2
      Me.chkCustomPictures.Text = "Custom pictures"
      '
      'chkCustomColours
      '
      Me.chkCustomColours.FlatStyle = System.Windows.Forms.FlatStyle.System
      Me.chkCustomColours.Location = New System.Drawing.Point(0, 8)
      Me.chkCustomColours.Name = "chkCustomColours"
      Me.chkCustomColours.Size = New System.Drawing.Size(104, 16)
      Me.chkCustomColours.TabIndex = 1
      Me.chkCustomColours.Text = "Custom colours"
      '
      'cmdClose
      '
      Me.cmdClose.DialogResult = System.Windows.Forms.DialogResult.Cancel
      Me.cmdClose.Dock = System.Windows.Forms.DockStyle.Right
      Me.cmdClose.FlatStyle = System.Windows.Forms.FlatStyle.System
      Me.cmdClose.Location = New System.Drawing.Point(201, 8)
      Me.cmdClose.Name = "cmdClose"
      Me.cmdClose.Size = New System.Drawing.Size(75, 32)
      Me.cmdClose.TabIndex = 0
      Me.cmdClose.Text = "Close"
      '
      'lvwWholist
      '
      Me.lvwWholist.ContextMenu = Me.mnuWholist
      Me.lvwWholist.Dock = System.Windows.Forms.DockStyle.Fill
      Me.lvwWholist.FullRowSelect = True
      Me.lvwWholist.Location = New System.Drawing.Point(8, 8)
      Me.lvwWholist.MultiSelect = False
      Me.lvwWholist.Name = "lvwWholist"
      Me.lvwWholist.Size = New System.Drawing.Size(276, 209)
      Me.lvwWholist.TabIndex = 0
      Me.lvwWholist.View = System.Windows.Forms.View.Details
      '
      'tmrWholist
      '
      Me.tmrWholist.Enabled = True
      Me.tmrWholist.Interval = 30000
      Me.tmrWholist.SynchronizingObject = Me
      '
      'imgWholist
      '
      Me.imgWholist.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit
      Me.imgWholist.ImageSize = New System.Drawing.Size(32, 32)
      Me.imgWholist.TransparentColor = System.Drawing.Color.Transparent
      '
      'frmWholist
      '
      Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
      Me.CancelButton = Me.cmdClose
      Me.ClientSize = New System.Drawing.Size(292, 273)
      Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.lvwWholist, Me.pnlButtons})
      Me.DockPadding.All = 8
      Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
      Me.Name = "frmWholist"
      Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
      Me.Text = "Wholist"
      Me.pnlButtons.ResumeLayout(False)
      CType(Me.tmrWholist, System.ComponentModel.ISupportInitialize).EndInit()
      Me.ResumeLayout(False)

   End Sub

#End Region

   Public Sub SetData(ByRef pWholist As CEDF)
      Dim iAccessLevel As Integer, iUserType As Integer, iValue As Integer, iWidth As Integer
      Dim iUserID As Integer, iStatus As Integer, iNumShadows As Integer, iImageIndex As Integer = 0
      Dim iActiveIcon As Integer, iBusyIcon As Integer
      Dim bLoop As Boolean, bSecure As Boolean, bPicture As Boolean
      Dim sName As String, sAccessName As String, sValue As String, sFlags As String
      Dim pPicture() As Byte
      Dim pItem As ListViewItem
      Dim pField As WholistField
      Dim pUser As UserLookup
      Dim pStream As MemoryStream
      Dim pImage As Bitmap

      If m_bSetData = False Then
         m_bSetData = True

         If Not pWholist Is Nothing Then
            m_pWholist = pWholist
         End If

         If chkCustomPictures.Checked = True Then
            imgWholist.Images.Clear()
         End If

         If chkCustomPictures.Checked = True Then
            imgWholist.Images.Add(sUAveHelper.m_pImageList.Images(ICO_BULB_ON))
            imgWholist.Images.Add(sUAveHelper.m_pImageList.Images(ICO_BULB_OFF))

            lvwWholist.SmallImageList = imgWholist

            iActiveIcon = -1
            iBusyIcon = -1

            iImageIndex = 2
         Else
            lvwWholist.SmallImageList = sUAveHelper.m_pImageList

            iActiveIcon = sUAveHelper.ICO_BULB_ON
            iBusyIcon = sUAveHelper.ICO_BULB_OFF
         End If

         lvwWholist.Visible = False

         CheckFields()

         SortColumns()

         If mnuWholist.MenuItems.Count = 0 Then
            For Each pField In m_pFields
               pMenu = New MenuItem(pField.m_sName)
               If pField.m_bVisible = True Then
                  pMenu.Checked = True
               End If

               AddHandler pMenu.Click, AddressOf Me.mnuFields_Click

               mnuWholist.MenuItems.Add(pMenu)
            Next
         End If

         lvwWholist.Columns.Clear()

         lvwWholist.Items.Clear()

         debugline("frmWholist::SetData " & m_pFields.Length & " fields")
         lvwWholist.Columns.Add("", 70, HorizontalAlignment.Left)
         For Each pField In m_pFields
            If pField.m_bVisible = True Then
               lvwWholist.Columns.Add(pField.m_sName, pField.m_iWidth, HorizontalAlignment.Left)
               iWidth += pField.m_iWidth
            End If
         Next

         Me.Size = New Size(iWidth + 120, Me.Size.Height)

         If chkCustomColours.Checked = True Then
            lvwWholist.BackColor = Color.Black
            lvwWholist.ForeColor = Color.LightGray
         Else
            lvwWholist.BackColor = SystemColors.Window
            lvwWholist.ForeColor = SystemColors.WindowText
         End If

         bLoop = m_pWholist.Child("user")
         Do While bLoop = True
            'm_pWholist.MsgPrint("frmWholist::SetData", CEDF.EL_CURR + CEDF.PR_SPACE)

            bPicture = False
            iUserID = m_pWholist.GetInt()
            sName = m_pWholist.GetChildStr("name")
            iAccessLevel = m_pWholist.GetChildInt("accesslevel")
            sAccessName = m_pWholist.GetChildStr("accessname")
            iUserType = m_pWholist.GetChildInt("usertype")

            If chkCustomPictures.Checked = True Then
               If m_pWholist.Child("details") = True Then
                  If m_pWholist.Child("picture") = True Then
                     pPicture = StringToBytes(m_pWholist.GetChildStr("data"))

                     If Not pPicture Is Nothing Then
                        pStream = New MemoryStream(pPicture)

                        pImage = New Bitmap(pStream)
                        'MsgBox("frmWholist::SetData picture " & pImage.Width & " x " & pImage.Height)
                        'PictureBox1.Image = pImage

                        imgWholist.Images.Add(pImage)

                        bPicture = True
                     End If

                     m_pWholist.Parent()
                  End If

                  m_pWholist.Parent()
               End If
            End If

            If m_pWholist.Child("login") = True Then
               pItem = Nothing

               iStatus = m_pWholist.GetChildInt("status")
               bSecure = m_pWholist.GetChildBool("secure")

               sFlags = ""
               If mask(iStatus, ua.LOGIN_IDLE) = True Then
                  sFlags += "I"
               End If
               If mask(iStatus, ua.LOGIN_BUSY) = True And chkCustomPictures.Checked = True Then
                  sFlags += "B"
               End If
               If mask(iStatus, ua.LOGIN_TALKING) = True Then
                  sFlags += "T"
               End If
               If mask(iStatus, ua.LOGIN_SILENT) = True Then
                  sFlags += "S"
               End If
               If mask(iStatus, ua.LOGIN_SHADOW) = True Then
                  sFlags += "H"
               End If
               If mask(iStatus, ua.LOGIN_NOCONTACT) = True Then
                  sFlags += "N"
               End If
               If bSecure = True Then
                  sFlags += "E"
               End If

               pItem = New ListViewItem(sFlags)

               If bPicture = True Then
                  pItem.ImageIndex = iImageIndex
                  iImageIndex += 1
               Else
                  If isActive(iStatus) = True Then
                     pItem.ImageIndex = iActiveIcon
                  Else
                     pItem.ImageIndex = iBusyIcon
                  End If
               End If

               For Each pField In m_pFields
                  If pField.m_bVisible = True Then
                     If pField.m_sField = "name" Then
                        FieldAdd(pItem, sName, New Font(lvwWholist.Font, AccessStyle(chkCustomColours.Checked, iAccessLevel, iUserType)), AccessColour(chkCustomColours.Checked, iAccessLevel, iUserType))
                     ElseIf pField.m_sField = "accesslevel" Then
                        If sAccessName Is Nothing Then
                           sAccessName = ua.AccessName(iAccessLevel, iUserType)
                        End If
                        FieldAdd(pItem, sAccessName, New Font(lvwWholist.Font, AccessStyle(chkCustomColours.Checked, iAccessLevel, iUserType)), AccessColour(chkCustomColours.Checked, iAccessLevel, iUserType))
                     ElseIf pField.m_sField.StartsWith("time") = True Then
                        If m_pWholist.IsChild(pField.m_sField) = True Then
                           iValue = m_pWholist.GetChildInt(pField.m_sField)
                           FieldAdd(pItem, SecsToHM(GetServerTime() - iValue), lvwWholist.Font, lvwWholist.ForeColor)
                        Else
                           FieldAdd(pItem, "", lvwWholist.Font, lvwWholist.ForeColor)
                        End If
                     Else
                        sValue = m_pWholist.GetChildStr(pField.m_sField)
                        If pField.m_sField = "hostname" And sValue Is Nothing Then
                           'sValue = m_pWholist.GetChildStr("address")
                        End If
                        FieldAdd(pItem, sValue, lvwWholist.Font, lvwWholist.ForeColor)
                     End If
                  End If
               Next

               pUser = New UserLookup(iUserID, iUserType, sName, iAccessLevel, iStatus, False, Nothing, iNumShadows, False, Nothing)
               pItem.Tag = pUser

               lvwWholist.Items.Add(pItem)

               m_pWholist.Parent()
            End If

            bLoop = m_pWholist.Next("user")
            If bLoop = False Then
               m_pWholist.Parent()
            End If
         Loop

         lvwWholist.Visible = True

         m_bSetData = False
      End If
   End Sub

   Private Sub cmdClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdClose.Click
      Me.Dispose()
   End Sub

   Public Shared Function FieldSet(ByVal sField As String, ByVal bVisible As Boolean) As Boolean
      Dim pField As WholistField

      CheckFields()

      pField = FieldFind(Nothing, sField)

      If pField Is Nothing Then
         Return False
      End If

      pField.m_bVisible = bVisible

   End Function

   Private Shared Function FieldSet(ByVal iFieldNum As Integer, ByVal sName As String, ByVal iWidth As Integer, Optional ByVal sField As String = Nothing) As Boolean
      m_pFields(iFieldNum) = New WholistField()
      m_pFields(iFieldNum).m_sName = sName
      If Not sField Is Nothing Then
         m_pFields(iFieldNum).m_sField = sField
      Else
         m_pFields(iFieldNum).m_sField = sName.ToLower().Replace(" ", "")
      End If
      m_pFields(iFieldNum).m_iWidth = iWidth
      m_pFields(iFieldNum).m_bVisible = False
   End Function

   Private Sub FieldAdd(ByRef pItem As ListViewItem, ByVal sString As String, ByRef pFont As Font, ByVal cColour As Color)
      Dim pSubItem As ListViewItem.ListViewSubItem

      pSubItem = New ListViewItem.ListViewSubItem()
      pSubItem.Text = sString
      pSubItem.Font = pFont
      pSubItem.ForeColor = cColour

      pSubItem = pItem.SubItems.Add(pSubItem)
   End Sub

   Private Sub tmrWholist_Elapsed(ByVal sender As System.Object, ByVal e As System.Timers.ElapsedEventArgs) Handles tmrWholist.Elapsed
      debugline("frmWholist::tmrWholist setting data window visible " & Me.Visible)
      SetData(Nothing)
   End Sub

   Private Sub lvwWholist_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lvwWholist.SelectedIndexChanged
      Dim pPage As frmPage
      Dim pUser As UserLookup

      If m_bRightButton = False Then
         If lvwWholist.SelectedItems.Count > 0 Then
            pUser = lvwWholist.SelectedItems(0).Tag
            'sToName = rcbWholist.SelectedItem().m_sValue

            'MsgBox("Selected user " & iUserID)

            pPage = PageFind(pUser)

            If Not pPage Is Nothing Then
               pPage.Focus()
            Else
               pPage = New frmPage(pUser, Nothing)
               pPage.Show()
            End If
         Else
            debugline("frmWholist::lvwWholist no item selected")
         End If
      Else
         m_bRightButton = False
      End If
   End Sub

   Private Sub chkCustomColours_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkCustomColours.CheckedChanged
      If m_bInit = False Then
         'debugline("frmWholist::chkCustomColours setting data")
         SetData(Nothing)
      End If
   End Sub

   Private Shared Function FieldFind(ByVal sName As String, ByVal sField As String) As WholistField
      Dim iFieldNum As Integer
      Dim pReturn As WholistField

      Do While iFieldNum < m_pFields.Length And pReturn Is Nothing
         If Not sName Is Nothing Then
            If m_pFields(iFieldNum).m_sName.ToLower() = sName.ToLower() Then
               pReturn = m_pFields(iFieldNum)
            End If
         ElseIf Not sField Is Nothing Then
            If m_pFields(iFieldNum).m_sField = sField Then
               pReturn = m_pFields(iFieldNum)
            End If
         End If

         If pReturn Is Nothing Then
            iFieldNum += 1
         End If
      Loop

      Return pReturn
   End Function

   Private Sub lvwWholist_ColumnClick(ByVal sender As Object, ByVal e As System.Windows.Forms.ColumnClickEventArgs) Handles lvwWholist.ColumnClick
      Dim bSortable As Boolean = True

      'MsgBox("That would be column " & e.Column)

      m_pSortField = FieldFind(lvwWholist.Columns(e.Column).Text, Nothing)

      m_pWholist.Root()

      If e.Column = m_iColumn Then
         m_bAscending = Not m_bAscending
      Else
         m_bAscending = True
      End If
      m_iColumn = e.Column

      debugline("frmWholist::lvwWholist setting data")
      SetData(Nothing)
   End Sub

   Private Sub SortColumns()
      If m_pSortField.m_sField = "name" Or m_pSortField.m_sField = "accesslevel" Then
         m_pWholist.Sort("user", m_pSortField.m_sField, False, m_bAscending)
      ElseIf m_pSortField.m_sField.StartsWith("time") = True Or m_pSortField.m_sField = "hostname" Or m_pSortField.m_sField = "location" Or m_pSortField.m_sField = "client" Or m_pSortField.m_sField = "protocol" Then
         m_pWholist.SortReset(Nothing)
         m_pWholist.SortAddSection("login")
         m_pWholist.SortAddKey(m_pSortField.m_sField, m_bAscending)
         m_pWholist.SortParent()
         m_pWholist.SortParent()
         m_pWholist.SortAddKey("name")
         m_pWholist.Sort()
      Else
         MsgBox("Cannot sort on this column", MsgBoxStyle.Exclamation, "frmWholist::SortColumns")
         m_pWholist.Sort("user", "name")
      End If
   End Sub

   Private Shared Sub CheckFields()
      If m_pFields Is Nothing Then
         ReDim m_pFields(10)

         FieldSet(0, "Time On", 80)
         FieldSet(1, "Idle", 80, "timeidle")
         FieldSet(2, "Busy", 80, "timebusy")
         FieldSet(3, "Access", 80, "accesslevel")
         FieldSet(4, "Name", 100)

         FieldSet(5, "Hostname", 150)
         FieldSet(6, "Address", 150)
         FieldSet(7, "Location", 150)
         FieldSet(8, "Client", 150)
         FieldSet(9, "Protocol", 80)

         FieldSet(10, "Status Message", 300, "statusmsg")
      End If
   End Sub

   Private Sub WholistMenu(ByRef pMenu As MenuItem)
      Dim pField As WholistField

      pField = FieldFind(pMenu.Text, Nothing)
      pField.m_bVisible = Not pField.m_bVisible
      pMenu.Checked = pField.m_bVisible

      debugline("frmWholist::WholistMenu setting data")
      SetData(Nothing)
   End Sub

   Private Sub mnuFields_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
      Dim pField As WholistField

      pField = FieldFind(sender.text, Nothing)
      pField.m_bVisible = Not pField.m_bVisible
      sender.checked = pField.m_bVisible

      debugline("frmWholist::mnuFields setting data")
      SetData(Nothing)
   End Sub

   Private Sub lvwWholist_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles lvwWholist.MouseDown
      If mask(e.Button, MouseButtons.Right) = True Then
         m_bRightButton = True
      End If
   End Sub

   Private Sub chkCustomPictures_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkCustomPictures.CheckedChanged
      If m_bInit = False Then
         SetData(Nothing)
      End If
   End Sub

   Public Shared Function getForm() As Form
      Return m_pForm
   End Function
End Class
