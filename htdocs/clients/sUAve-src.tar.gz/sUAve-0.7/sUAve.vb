Imports Microsoft.Win32

Imports org.ua2

Public Class frmsUAve
   Inherits System.Windows.Forms.Form

   Private m_bUserInput As Boolean = True, m_bClearing As Boolean, m_bTimer As Boolean, m_bThinPipe As Boolean, m_bSysTray As Boolean, m_bHide As Boolean
   Private m_iAnnounceItems As Integer = -1
   Private m_pTimeOn As DateTime, m_iTimeUpdate As Int64, m_iWholistUpdate As Int64
   Private m_bSupressError As Boolean
   Private m_sServer As String
   Private m_iViewType As Integer = -1, m_iExpansion As Integer, m_iCaching As Integer
   Private m_pMessageContext As MessageLookup
   Private m_iWindowState As Integer = -1
   Private m_pConfig As CEDF
   Private Shared m_pForm As frmsUAve
   Private m_sDebugFile As String
   Private m_bForceLogin As Boolean = False

   Private Const VT_FOLDERUSER = 0, VT_USER = 1, VT_NONE = 2

#Region " Windows Form Designer generated code "

   Public Sub New()
      MyBase.New()

      'This call is required by the Windows Form Designer.
      InitializeComponent()

      'Add any initialization after the InitializeComponent() call
      Dim sValue As String
      Dim sValues() As String
      Dim pSettings As RegistryKey

      CClient.debugopen("sUAve.txt")

      If IsXP() Then
         sUAveHelper.m_pImageList = imlsUAveXP

         Me.rlbAnnounces.ImageList = imlsUAveXP
         Me.rlbReplyTo.ImageList = imlsUAveXP
         Me.rlbReplyBy.ImageList = imlsUAveXP
         Me.rlbHeader.ImageList = imlsUAveXP
         Me.tlbsUAve.ImageList = imlsUAveXP
         Me.rcbWholist.ImageList = imlsUAveXP
         Me.rcbFolders.ImageList = imlsUAveXP
         Me.tvwFolders.ImageList = imlsUAveXP
         Me.tvwMessages.ImageList = imlsUAveXP
      Else
         sUAveHelper.m_pImageList = imlsUAve
      End If

      pSettings = GetRegSection()
      sValue = pSettings.GetValue("mainwindow")
      If Not sValue Is Nothing Then
         sValues = sValue.Split(New Char() {","})
         If sValue.Length >= 4 Then
            Me.StartPosition = FormStartPosition.Manual

            Me.Left = sValues(0)
            Me.Top = sValues(1)
            Me.ClientSize = New Size(sValues(2), sValues(3))
         End If
      End If

      'MsgBox("Setting font", , "frmSuave::frmsUAve")
      sUAveFont(Me)
      If Not UnicodeFont() Is Nothing Then
         rcbWholist.Font = UnicodeFont()
         rlbAnnounces.Font = UnicodeFont()
      End If

      SetBrowser()

      m_pForm = Me

      sValue = pSettings.GetValue("announceitems")
      If Not sValue Is Nothing Then
         pnlAnnounces.Height = (sValue + 1) * rlbAnnounces.ItemHeight
      End If

      Me.Text = CLIENT_NAME

      'rlbAnnounces.Items.Add("iiiiiiiiii" & markup("iiiii") & "iiiiiiiiii")
      'rlbAnnounces.Items.Add("wwwwwwwwww" & markup("wwwww") & "wwwwwwwwww")
   End Sub

   'Form overrides dispose to clean up the component list.
   Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
      If disposing Then
         nfisUAve.Visible = False

         disconnect(False, Nothing)
         If Not (components Is Nothing) Then
            components.Dispose()
         End If
      End If
      MyBase.Dispose(disposing)
   End Sub

   Friend WithEvents mnuToolsSystem As System.Windows.Forms.MenuItem
   Friend WithEvents mnuMsgCatchAll As System.Windows.Forms.MenuItem
   Friend WithEvents mnuMsgHoldAll As System.Windows.Forms.MenuItem
   Friend WithEvents pnlAttachments As System.Windows.Forms.Panel
   Friend WithEvents rtbAttachments As System.Windows.Forms.RichTextBox
   Friend WithEvents nfisUAve As System.Windows.Forms.NotifyIcon
   Friend WithEvents mnuFolderRefreshMessages As System.Windows.Forms.MenuItem
   Friend WithEvents mnuFolderRefreshFolders As System.Windows.Forms.MenuItem
   Friend WithEvents mnuFolder As System.Windows.Forms.MenuItem
   Friend WithEvents mnuFolderUnsubscribe As System.Windows.Forms.MenuItem
   Friend WithEvents mnuFolderJump As System.Windows.Forms.MenuItem
   Friend WithEvents mnuTray As System.Windows.Forms.ContextMenu
   Friend WithEvents mnuTrayExit As System.Windows.Forms.MenuItem
   Friend WithEvents mnuTrayClose As System.Windows.Forms.MenuItem
   Friend WithEvents mnuTraySep1 As System.Windows.Forms.MenuItem
   Friend WithEvents mnuTrayShow As System.Windows.Forms.MenuItem
   Friend WithEvents tbbTalk As System.Windows.Forms.ToolBarButton
   Friend WithEvents mnuTrayPage As System.Windows.Forms.MenuItem
   Friend WithEvents mnuTraySep2 As System.Windows.Forms.MenuItem
   Friend WithEvents mnuToolsUsers As System.Windows.Forms.MenuItem
   Friend WithEvents mnuViewFixed As System.Windows.Forms.MenuItem
   Friend WithEvents tbbWholist As System.Windows.Forms.ToolBarButton
   Friend WithEvents mnuViewUnicode As System.Windows.Forms.MenuItem
   Friend WithEvents mnuToolsRefreshAll As System.Windows.Forms.MenuItem
   Friend WithEvents mnuAdmin As System.Windows.Forms.MenuItem
   Friend WithEvents mnuAdminBanner As System.Windows.Forms.MenuItem
   Friend WithEvents mnuAdminLocations As System.Windows.Forms.MenuItem
   Friend WithEvents mnuAdminReload As System.Windows.Forms.MenuItem
   Friend WithEvents mnuAdminSysMsg As System.Windows.Forms.MenuItem
   Friend WithEvents tbbPage As System.Windows.Forms.ToolBarButton
   Friend WithEvents tbbSep2 As System.Windows.Forms.ToolBarButton
   Friend WithEvents pnlFolders As System.Windows.Forms.Panel
   Friend WithEvents splFolders As System.Windows.Forms.Splitter
   Friend WithEvents tvwFolders As System.Windows.Forms.TreeView
   Friend WithEvents mnuViewRaw As System.Windows.Forms.MenuItem
   Friend WithEvents tbbOpen As System.Windows.Forms.ToolBarButton
   Friend WithEvents tbbClose As System.Windows.Forms.ToolBarButton
   Friend WithEvents tbbSep1 As System.Windows.Forms.ToolBarButton
   Friend WithEvents rcbFolders As RichControl.RichComboBox
   Friend WithEvents rcbWholist As RichControl.RichComboBox
   Friend WithEvents pnlItem As System.Windows.Forms.Panel
   Friend WithEvents pnlTop As System.Windows.Forms.Panel
   Friend WithEvents pnlAnnounces As System.Windows.Forms.Panel
   Friend WithEvents pnlSelect As System.Windows.Forms.Panel
   Friend WithEvents pnlHeader As System.Windows.Forms.Panel
   Friend WithEvents pnlContent As System.Windows.Forms.Panel
   Friend WithEvents rtbContent As System.Windows.Forms.RichTextBox
   Friend WithEvents pnlMessage As System.Windows.Forms.Panel
   Friend WithEvents pnlMessages As System.Windows.Forms.Panel
   Friend WithEvents tvwMessages As System.Windows.Forms.TreeView
   Friend WithEvents splMessages As System.Windows.Forms.Splitter
   Friend WithEvents splAnnounces As System.Windows.Forms.Splitter
   Friend WithEvents splSelect As System.Windows.Forms.Splitter
   Friend WithEvents mnuFileClose As System.Windows.Forms.MenuItem
   Friend WithEvents mnuHelpAbout As System.Windows.Forms.MenuItem
   Friend WithEvents mnuHelp As System.Windows.Forms.MenuItem
   Friend WithEvents mnuFileOpen As System.Windows.Forms.MenuItem
   Friend WithEvents tmrsUAve As System.Windows.Forms.Timer
   Friend WithEvents mnuFileExit As System.Windows.Forms.MenuItem
   Friend WithEvents mnusUAve As System.Windows.Forms.MainMenu
   Friend WithEvents mnuFile As System.Windows.Forms.MenuItem
   Friend WithEvents mnuFileSep1 As System.Windows.Forms.MenuItem
   Friend WithEvents mnuView As System.Windows.Forms.MenuItem
   Friend WithEvents stbsUAve As System.Windows.Forms.StatusBar
   Friend WithEvents tlbsUAve As System.Windows.Forms.ToolBar
   Friend WithEvents stpTimeOn As System.Windows.Forms.StatusBarPanel
   Friend WithEvents stpUser As System.Windows.Forms.StatusBarPanel
   Friend WithEvents pnlReply As System.Windows.Forms.Panel
   Friend WithEvents lblReplyTo As System.Windows.Forms.Label
   Friend WithEvents lblReplyBy As System.Windows.Forms.Label
   Friend WithEvents rlbAnnounces As RichControl.RichListBox
   Friend WithEvents stpSummary As System.Windows.Forms.StatusBarPanel
   Friend WithEvents mnuMsgCatch As System.Windows.Forms.MenuItem
   Friend WithEvents mnuMsgCatchMsgChild As System.Windows.Forms.MenuItem
   Friend WithEvents mnuMsgCatchWhole As System.Windows.Forms.MenuItem
   Friend WithEvents mnuMsgHold As System.Windows.Forms.MenuItem
   Friend WithEvents mnuMsgHoldMsg As System.Windows.Forms.MenuItem
   Friend WithEvents mnuMsgHoldMsgChild As System.Windows.Forms.MenuItem
   Friend WithEvents mnuMsgHoldChild As System.Windows.Forms.MenuItem
   Friend WithEvents mnuMsgHoldWhole As System.Windows.Forms.MenuItem
   Friend WithEvents mnuMsgCatchChild As System.Windows.Forms.MenuItem
   Friend WithEvents mnuMsgMove As System.Windows.Forms.MenuItem
   Friend WithEvents mnuMsgMoveMsg As System.Windows.Forms.MenuItem
   Friend WithEvents mnuMsgMoveMsgChild As System.Windows.Forms.MenuItem
   Friend WithEvents mnuMsgMoveWhole As System.Windows.Forms.MenuItem
   Friend WithEvents mnuMsgMoveChild As System.Windows.Forms.MenuItem
   Friend WithEvents mnuMsgDel As System.Windows.Forms.MenuItem
   Friend WithEvents mnuMsgDelMsg As System.Windows.Forms.MenuItem
   Friend WithEvents mnuMsgDelMsgChild As System.Windows.Forms.MenuItem
   Friend WithEvents mnuMsgDelChild As System.Windows.Forms.MenuItem
   Friend WithEvents mnuMsgDelWhole As System.Windows.Forms.MenuItem
   Friend WithEvents rlbReplyTo As RichControl.RichListBox
   Friend WithEvents rlbHeader As RichControl.RichListBox
   Friend WithEvents imlsUAve As System.Windows.Forms.ImageList
   Friend WithEvents mnuKeys As System.Windows.Forms.MenuItem
   Friend WithEvents mnuKeysAdd As System.Windows.Forms.MenuItem
   Friend WithEvents mnuKeysReply As System.Windows.Forms.MenuItem
   Friend WithEvents mnuFolderNextUnread As System.Windows.Forms.MenuItem
   Friend WithEvents mnuToolsRequest As System.Windows.Forms.MenuItem
   Friend WithEvents mnuViewRefresh As System.Windows.Forms.MenuItem
   Friend WithEvents mnuToolsOptions As System.Windows.Forms.MenuItem
   Friend WithEvents mnuToolsPager As System.Windows.Forms.MenuItem
   Friend WithEvents mnuTools As System.Windows.Forms.MenuItem
   Friend WithEvents mnuToolsSep1 As System.Windows.Forms.MenuItem
   Friend WithEvents mnuToolsWholist As System.Windows.Forms.MenuItem
   Friend WithEvents imlsUAveXP As System.Windows.Forms.ImageList
   Friend WithEvents rlbVotes As RichControl.RichListBox
   Friend WithEvents pnlVotes As System.Windows.Forms.Panel
   Friend WithEvents mnuToolsRefreshServices As System.Windows.Forms.MenuItem
   Friend WithEvents mnuViewEmphasis As System.Windows.Forms.MenuItem
   Friend WithEvents mnuViewSep As System.Windows.Forms.MenuItem
   Friend WithEvents lblVotes As System.Windows.Forms.Label
   Friend WithEvents tbbMsgAnnotate As System.Windows.Forms.ToolBarButton
   Friend WithEvents tbbMsgReply As System.Windows.Forms.ToolBarButton
   Friend WithEvents tbbMsgAdd As System.Windows.Forms.ToolBarButton
   Friend WithEvents tbbMsgNextUnread As System.Windows.Forms.ToolBarButton
   Friend WithEvents tbbMsgVoteClose As System.Windows.Forms.ToolBarButton
   Friend WithEvents mnuMsgThread As System.Windows.Forms.ContextMenu
   Friend WithEvents tbbMsgThread As System.Windows.Forms.ToolBarButton

   'Required by the Windows Form Designer
   Private components As System.ComponentModel.IContainer

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   Friend WithEvents mnuFolderList As System.Windows.Forms.MenuItem
   Friend WithEvents rlbReplyBy As RichControl.RichListBox
   Friend WithEvents picVotes As System.Windows.Forms.PictureBox
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Me.components = New System.ComponentModel.Container
      Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmsUAve))
      Me.mnuKeys = New System.Windows.Forms.MenuItem
      Me.mnuKeysAdd = New System.Windows.Forms.MenuItem
      Me.mnuKeysReply = New System.Windows.Forms.MenuItem
      Me.mnuFolderNextUnread = New System.Windows.Forms.MenuItem
      Me.rlbAnnounces = New RichControl.RichListBox
      Me.imlsUAve = New System.Windows.Forms.ImageList(Me.components)
      Me.mnuMsgMoveWhole = New System.Windows.Forms.MenuItem
      Me.mnuViewRefresh = New System.Windows.Forms.MenuItem
      Me.splSelect = New System.Windows.Forms.Splitter
      Me.tmrsUAve = New System.Windows.Forms.Timer(Me.components)
      Me.pnlContent = New System.Windows.Forms.Panel
      Me.rtbContent = New System.Windows.Forms.RichTextBox
      Me.splVotes = New System.Windows.Forms.Splitter
      Me.pnlVotes = New System.Windows.Forms.Panel
      Me.picVotes = New System.Windows.Forms.PictureBox
      Me.lblVotes = New System.Windows.Forms.Label
      Me.rlbVotes = New RichControl.RichListBox
      Me.tbbOpen = New System.Windows.Forms.ToolBarButton
      Me.mnuFolderJump = New System.Windows.Forms.MenuItem
      Me.mnuMsgDelMsg = New System.Windows.Forms.MenuItem
      Me.mnuMsgHoldMsg = New System.Windows.Forms.MenuItem
      Me.stpUser = New System.Windows.Forms.StatusBarPanel
      Me.mnuFileOpen = New System.Windows.Forms.MenuItem
      Me.lblReplyTo = New System.Windows.Forms.Label
      Me.stpTimeOn = New System.Windows.Forms.StatusBarPanel
      Me.tbbSep1 = New System.Windows.Forms.ToolBarButton
      Me.tbbSep2 = New System.Windows.Forms.ToolBarButton
      Me.splFolders = New System.Windows.Forms.Splitter
      Me.mnuTraySep2 = New System.Windows.Forms.MenuItem
      Me.pnlHeader = New System.Windows.Forms.Panel
      Me.pnlReply = New System.Windows.Forms.Panel
      Me.rlbReplyTo = New RichControl.RichListBox
      Me.rlbReplyBy = New RichControl.RichListBox
      Me.lblReplyBy = New System.Windows.Forms.Label
      Me.rlbHeader = New RichControl.RichListBox
      Me.mnuMsgMoveChild = New System.Windows.Forms.MenuItem
      Me.rtbAttachments = New System.Windows.Forms.RichTextBox
      Me.mnuFileExit = New System.Windows.Forms.MenuItem
      Me.mnuToolsPager = New System.Windows.Forms.MenuItem
      Me.tbbWholist = New System.Windows.Forms.ToolBarButton
      Me.mnuFolderRefreshMessages = New System.Windows.Forms.MenuItem
      Me.mnuToolsRequest = New System.Windows.Forms.MenuItem
      Me.mnuFolderUnsubscribe = New System.Windows.Forms.MenuItem
      Me.tbbMsgNextUnread = New System.Windows.Forms.ToolBarButton
      Me.rcbFolders = New RichControl.RichComboBox
      Me.pnlSelect = New System.Windows.Forms.Panel
      Me.rcbWholist = New RichControl.RichComboBox
      Me.tbbClose = New System.Windows.Forms.ToolBarButton
      Me.mnuTrayExit = New System.Windows.Forms.MenuItem
      Me.tvwFolders = New System.Windows.Forms.TreeView
      Me.pnlFolders = New System.Windows.Forms.Panel
      Me.pnlMessage = New System.Windows.Forms.Panel
      Me.pnlItem = New System.Windows.Forms.Panel
      Me.pnlAttachments = New System.Windows.Forms.Panel
      Me.pnlAnnounces = New System.Windows.Forms.Panel
      Me.tbbPage = New System.Windows.Forms.ToolBarButton
      Me.stpSummary = New System.Windows.Forms.StatusBarPanel
      Me.mnuMsgDelWhole = New System.Windows.Forms.MenuItem
      Me.mnuMsgHoldAll = New System.Windows.Forms.MenuItem
      Me.mnuMsgMove = New System.Windows.Forms.MenuItem
      Me.mnuMsgMoveMsg = New System.Windows.Forms.MenuItem
      Me.mnuMsgMoveMsgChild = New System.Windows.Forms.MenuItem
      Me.mnuTrayClose = New System.Windows.Forms.MenuItem
      Me.mnuFolderRefreshFolders = New System.Windows.Forms.MenuItem
      Me.tbbTalk = New System.Windows.Forms.ToolBarButton
      Me.mnuView = New System.Windows.Forms.MenuItem
      Me.mnuViewSep = New System.Windows.Forms.MenuItem
      Me.mnuViewEmphasis = New System.Windows.Forms.MenuItem
      Me.mnuViewFixed = New System.Windows.Forms.MenuItem
      Me.mnuViewUnicode = New System.Windows.Forms.MenuItem
      Me.mnuViewRaw = New System.Windows.Forms.MenuItem
      Me.mnuMsgCatchMsgChild = New System.Windows.Forms.MenuItem
      Me.mnuHelpAbout = New System.Windows.Forms.MenuItem
      Me.mnuAdminLocations = New System.Windows.Forms.MenuItem
      Me.mnuTools = New System.Windows.Forms.MenuItem
      Me.mnuToolsRefreshServices = New System.Windows.Forms.MenuItem
      Me.mnuToolsRefreshAll = New System.Windows.Forms.MenuItem
      Me.mnuToolsWholist = New System.Windows.Forms.MenuItem
      Me.mnuToolsSystem = New System.Windows.Forms.MenuItem
      Me.mnuToolsUsers = New System.Windows.Forms.MenuItem
      Me.mnuToolsSep1 = New System.Windows.Forms.MenuItem
      Me.mnuToolsStatus = New System.Windows.Forms.MenuItem
      Me.mnuToolsOptions = New System.Windows.Forms.MenuItem
      Me.mnuFolderList = New System.Windows.Forms.MenuItem
      Me.mnuAdminReload = New System.Windows.Forms.MenuItem
      Me.mnuFileClose = New System.Windows.Forms.MenuItem
      Me.mnuMsgDelMsgChild = New System.Windows.Forms.MenuItem
      Me.mnuFolder = New System.Windows.Forms.MenuItem
      Me.mnuFolderSearch = New System.Windows.Forms.MenuItem
      Me.mnuHelp = New System.Windows.Forms.MenuItem
      Me.pnlTop = New System.Windows.Forms.Panel
      Me.pnlMessages = New System.Windows.Forms.Panel
      Me.tvwMessages = New System.Windows.Forms.TreeView
      Me.tbbMsgAdd = New System.Windows.Forms.ToolBarButton
      Me.mnuTraySep1 = New System.Windows.Forms.MenuItem
      Me.mnuMsgDelChild = New System.Windows.Forms.MenuItem
      Me.splAnnounces = New System.Windows.Forms.Splitter
      Me.tbbMsgThread = New System.Windows.Forms.ToolBarButton
      Me.mnuMsgThread = New System.Windows.Forms.ContextMenu
      Me.mnuMsgDel = New System.Windows.Forms.MenuItem
      Me.mnuMsgCatch = New System.Windows.Forms.MenuItem
      Me.mnuMsgCatchChild = New System.Windows.Forms.MenuItem
      Me.mnuMsgCatchWhole = New System.Windows.Forms.MenuItem
      Me.mnuMsgCatchAll = New System.Windows.Forms.MenuItem
      Me.mnuMsgHold = New System.Windows.Forms.MenuItem
      Me.mnuMsgHoldMsgChild = New System.Windows.Forms.MenuItem
      Me.mnuMsgHoldChild = New System.Windows.Forms.MenuItem
      Me.mnuMsgHoldWhole = New System.Windows.Forms.MenuItem
      Me.tlbsUAve = New System.Windows.Forms.ToolBar
      Me.tbbMsgReply = New System.Windows.Forms.ToolBarButton
      Me.tbbMsgAnnotate = New System.Windows.Forms.ToolBarButton
      Me.tbbMsgVoteClose = New System.Windows.Forms.ToolBarButton
      Me.mnuTrayShow = New System.Windows.Forms.MenuItem
      Me.mnuTray = New System.Windows.Forms.ContextMenu
      Me.mnuTrayPage = New System.Windows.Forms.MenuItem
      Me.mnuFileSep1 = New System.Windows.Forms.MenuItem
      Me.mnusUAve = New System.Windows.Forms.MainMenu
      Me.mnuFile = New System.Windows.Forms.MenuItem
      Me.mnuAdmin = New System.Windows.Forms.MenuItem
      Me.mnuAdminBanner = New System.Windows.Forms.MenuItem
      Me.mnuAdminSysMsg = New System.Windows.Forms.MenuItem
      Me.nfisUAve = New System.Windows.Forms.NotifyIcon(Me.components)
      Me.stbsUAve = New System.Windows.Forms.StatusBar
      Me.imlsUAveXP = New System.Windows.Forms.ImageList(Me.components)
      Me.splMessages = New System.Windows.Forms.Splitter
      Me.pnlContent.SuspendLayout()
      Me.pnlVotes.SuspendLayout()
      CType(Me.stpUser, System.ComponentModel.ISupportInitialize).BeginInit()
      CType(Me.stpTimeOn, System.ComponentModel.ISupportInitialize).BeginInit()
      Me.pnlHeader.SuspendLayout()
      Me.pnlReply.SuspendLayout()
      Me.pnlSelect.SuspendLayout()
      Me.pnlFolders.SuspendLayout()
      Me.pnlMessage.SuspendLayout()
      Me.pnlItem.SuspendLayout()
      Me.pnlAttachments.SuspendLayout()
      Me.pnlAnnounces.SuspendLayout()
      CType(Me.stpSummary, System.ComponentModel.ISupportInitialize).BeginInit()
      Me.pnlTop.SuspendLayout()
      Me.pnlMessages.SuspendLayout()
      Me.SuspendLayout()
      '
      'mnuKeys
      '
      Me.mnuKeys.Index = 6
      Me.mnuKeys.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuKeysAdd, Me.mnuKeysReply})
      Me.mnuKeys.Text = "Keys"
      Me.mnuKeys.Visible = False
      '
      'mnuKeysAdd
      '
      Me.mnuKeysAdd.Enabled = False
      Me.mnuKeysAdd.Index = 0
      Me.mnuKeysAdd.Shortcut = System.Windows.Forms.Shortcut.CtrlE
      Me.mnuKeysAdd.Text = "Add"
      '
      'mnuKeysReply
      '
      Me.mnuKeysReply.Enabled = False
      Me.mnuKeysReply.Index = 1
      Me.mnuKeysReply.Shortcut = System.Windows.Forms.Shortcut.CtrlR
      Me.mnuKeysReply.Text = "Reply"
      '
      'mnuFolderNextUnread
      '
      Me.mnuFolderNextUnread.Enabled = False
      Me.mnuFolderNextUnread.Index = 6
      Me.mnuFolderNextUnread.Shortcut = System.Windows.Forms.Shortcut.CtrlG
      Me.mnuFolderNextUnread.Text = "Next Unread"
      '
      'rlbAnnounces
      '
      Me.rlbAnnounces.Dock = System.Windows.Forms.DockStyle.Fill
      Me.rlbAnnounces.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
      Me.rlbAnnounces.ImageList = Me.imlsUAve
      Me.rlbAnnounces.Location = New System.Drawing.Point(8, 4)
      Me.rlbAnnounces.Name = "rlbAnnounces"
      Me.rlbAnnounces.Size = New System.Drawing.Size(568, 56)
      Me.rlbAnnounces.TabIndex = 0
      '
      'imlsUAve
      '
      Me.imlsUAve.ImageSize = New System.Drawing.Size(16, 16)
      Me.imlsUAve.ImageStream = CType(resources.GetObject("imlsUAve.ImageStream"), System.Windows.Forms.ImageListStreamer)
      Me.imlsUAve.TransparentColor = System.Drawing.Color.Transparent
      '
      'mnuMsgMoveWhole
      '
      Me.mnuMsgMoveWhole.Index = 3
      Me.mnuMsgMoveWhole.Text = "Whole thread"
      '
      'mnuViewRefresh
      '
      Me.mnuViewRefresh.Index = 0
      Me.mnuViewRefresh.Shortcut = System.Windows.Forms.Shortcut.F5
      Me.mnuViewRefresh.Text = "Refresh"
      Me.mnuViewRefresh.Visible = False
      '
      'splSelect
      '
      Me.splSelect.Location = New System.Drawing.Point(208, 8)
      Me.splSelect.Name = "splSelect"
      Me.splSelect.Size = New System.Drawing.Size(3, 25)
      Me.splSelect.TabIndex = 2
      Me.splSelect.TabStop = False
      '
      'tmrsUAve
      '
      Me.tmrsUAve.Interval = 200
      '
      'pnlContent
      '
      Me.pnlContent.Controls.Add(Me.rtbContent)
      Me.pnlContent.Controls.Add(Me.splVotes)
      Me.pnlContent.Controls.Add(Me.pnlVotes)
      Me.pnlContent.Dock = System.Windows.Forms.DockStyle.Fill
      Me.pnlContent.DockPadding.Bottom = 4
      Me.pnlContent.DockPadding.Top = 4
      Me.pnlContent.Location = New System.Drawing.Point(0, 96)
      Me.pnlContent.Name = "pnlContent"
      Me.pnlContent.Size = New System.Drawing.Size(568, 63)
      Me.pnlContent.TabIndex = 1
      '
      'rtbContent
      '
      Me.rtbContent.Dock = System.Windows.Forms.DockStyle.Fill
      Me.rtbContent.Enabled = False
      Me.rtbContent.Location = New System.Drawing.Point(0, 4)
      Me.rtbContent.Name = "rtbContent"
      Me.rtbContent.ReadOnly = True
      Me.rtbContent.Size = New System.Drawing.Size(365, 55)
      Me.rtbContent.TabIndex = 0
      Me.rtbContent.Text = ""
      '
      'splVotes
      '
      Me.splVotes.Dock = System.Windows.Forms.DockStyle.Right
      Me.splVotes.Location = New System.Drawing.Point(365, 4)
      Me.splVotes.Name = "splVotes"
      Me.splVotes.Size = New System.Drawing.Size(3, 55)
      Me.splVotes.TabIndex = 2
      Me.splVotes.TabStop = False
      '
      'pnlVotes
      '
      Me.pnlVotes.Controls.Add(Me.picVotes)
      Me.pnlVotes.Controls.Add(Me.lblVotes)
      Me.pnlVotes.Controls.Add(Me.rlbVotes)
      Me.pnlVotes.Dock = System.Windows.Forms.DockStyle.Right
      Me.pnlVotes.DockPadding.Left = 4
      Me.pnlVotes.Location = New System.Drawing.Point(368, 4)
      Me.pnlVotes.Name = "pnlVotes"
      Me.pnlVotes.Size = New System.Drawing.Size(200, 55)
      Me.pnlVotes.TabIndex = 1
      Me.pnlVotes.Visible = False
      '
      'picVotes
      '
      Me.picVotes.BackColor = System.Drawing.SystemColors.ActiveBorder
      Me.picVotes.Dock = System.Windows.Forms.DockStyle.Fill
      Me.picVotes.Location = New System.Drawing.Point(4, 40)
      Me.picVotes.Name = "picVotes"
      Me.picVotes.Size = New System.Drawing.Size(196, 0)
      Me.picVotes.TabIndex = 0
      Me.picVotes.TabStop = False
      '
      'lblVotes
      '
      Me.lblVotes.Dock = System.Windows.Forms.DockStyle.Top
      Me.lblVotes.Location = New System.Drawing.Point(4, 0)
      Me.lblVotes.Name = "lblVotes"
      Me.lblVotes.Size = New System.Drawing.Size(196, 40)
      Me.lblVotes.TabIndex = 2
      '
      'rlbVotes
      '
      Me.rlbVotes.Dock = System.Windows.Forms.DockStyle.Bottom
      Me.rlbVotes.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
      Me.rlbVotes.ImageList = Nothing
      Me.rlbVotes.Location = New System.Drawing.Point(4, 25)
      Me.rlbVotes.Name = "rlbVotes"
      Me.rlbVotes.ScrollAlwaysVisible = True
      Me.rlbVotes.Size = New System.Drawing.Size(196, 30)
      Me.rlbVotes.TabIndex = 1
      '
      'tbbOpen
      '
      Me.tbbOpen.ImageIndex = 3
      Me.tbbOpen.ToolTipText = "Open"
      '
      'mnuFolderJump
      '
      Me.mnuFolderJump.Enabled = False
      Me.mnuFolderJump.Index = 4
      Me.mnuFolderJump.Shortcut = System.Windows.Forms.Shortcut.CtrlJ
      Me.mnuFolderJump.Text = "&Jump to message..."
      '
      'mnuMsgDelMsg
      '
      Me.mnuMsgDelMsg.Index = 0
      Me.mnuMsgDelMsg.Text = "Message"
      '
      'mnuMsgHoldMsg
      '
      Me.mnuMsgHoldMsg.Index = 0
      Me.mnuMsgHoldMsg.Text = "Message"
      '
      'stpUser
      '
      Me.stpUser.AutoSize = System.Windows.Forms.StatusBarPanelAutoSize.Contents
      Me.stpUser.Width = 10
      '
      'mnuFileOpen
      '
      Me.mnuFileOpen.Index = 0
      Me.mnuFileOpen.Shortcut = System.Windows.Forms.Shortcut.CtrlO
      Me.mnuFileOpen.Text = "&Open..."
      '
      'lblReplyTo
      '
      Me.lblReplyTo.Enabled = False
      Me.lblReplyTo.Location = New System.Drawing.Point(8, 0)
      Me.lblReplyTo.Name = "lblReplyTo"
      Me.lblReplyTo.Size = New System.Drawing.Size(64, 23)
      Me.lblReplyTo.TabIndex = 0
      Me.lblReplyTo.Text = "In-Reply-To"
      '
      'stpTimeOn
      '
      Me.stpTimeOn.Width = 80
      '
      'tbbSep1
      '
      Me.tbbSep1.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
      '
      'tbbSep2
      '
      Me.tbbSep2.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
      '
      'splFolders
      '
      Me.splFolders.Location = New System.Drawing.Point(208, 4)
      Me.splFolders.Name = "splFolders"
      Me.splFolders.Size = New System.Drawing.Size(3, 115)
      Me.splFolders.TabIndex = 2
      Me.splFolders.TabStop = False
      '
      'mnuTraySep2
      '
      Me.mnuTraySep2.Index = 3
      Me.mnuTraySep2.Text = "-"
      Me.mnuTraySep2.Visible = False
      '
      'pnlHeader
      '
      Me.pnlHeader.Controls.Add(Me.pnlReply)
      Me.pnlHeader.Controls.Add(Me.rlbHeader)
      Me.pnlHeader.Dock = System.Windows.Forms.DockStyle.Top
      Me.pnlHeader.DockPadding.Bottom = 4
      Me.pnlHeader.DockPadding.Top = 4
      Me.pnlHeader.Location = New System.Drawing.Point(0, 0)
      Me.pnlHeader.Name = "pnlHeader"
      Me.pnlHeader.Size = New System.Drawing.Size(568, 96)
      Me.pnlHeader.TabIndex = 0
      '
      'pnlReply
      '
      Me.pnlReply.BackColor = System.Drawing.SystemColors.Control
      Me.pnlReply.Controls.Add(Me.rlbReplyTo)
      Me.pnlReply.Controls.Add(Me.lblReplyTo)
      Me.pnlReply.Controls.Add(Me.rlbReplyBy)
      Me.pnlReply.Controls.Add(Me.lblReplyBy)
      Me.pnlReply.Dock = System.Windows.Forms.DockStyle.Right
      Me.pnlReply.Location = New System.Drawing.Point(304, 4)
      Me.pnlReply.Name = "pnlReply"
      Me.pnlReply.Size = New System.Drawing.Size(264, 88)
      Me.pnlReply.TabIndex = 1
      '
      'rlbReplyTo
      '
      Me.rlbReplyTo.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
      Me.rlbReplyTo.ImageList = Me.imlsUAve
      Me.rlbReplyTo.Location = New System.Drawing.Point(80, 0)
      Me.rlbReplyTo.Name = "rlbReplyTo"
      Me.rlbReplyTo.Size = New System.Drawing.Size(184, 43)
      Me.rlbReplyTo.TabIndex = 1
      '
      'rlbReplyBy
      '
      Me.rlbReplyBy.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
      Me.rlbReplyBy.ImageList = Me.imlsUAve
      Me.rlbReplyBy.Location = New System.Drawing.Point(80, 48)
      Me.rlbReplyBy.Name = "rlbReplyBy"
      Me.rlbReplyBy.Size = New System.Drawing.Size(184, 43)
      Me.rlbReplyBy.TabIndex = 3
      '
      'lblReplyBy
      '
      Me.lblReplyBy.Enabled = False
      Me.lblReplyBy.Location = New System.Drawing.Point(8, 48)
      Me.lblReplyBy.Name = "lblReplyBy"
      Me.lblReplyBy.Size = New System.Drawing.Size(80, 23)
      Me.lblReplyBy.TabIndex = 2
      Me.lblReplyBy.Text = "Replied-To-By"
      '
      'rlbHeader
      '
      Me.rlbHeader.Dock = System.Windows.Forms.DockStyle.Fill
      Me.rlbHeader.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
      Me.rlbHeader.Enabled = False
      Me.rlbHeader.ImageList = Nothing
      Me.rlbHeader.Location = New System.Drawing.Point(0, 4)
      Me.rlbHeader.Name = "rlbHeader"
      Me.rlbHeader.ScrollAlwaysVisible = True
      Me.rlbHeader.Size = New System.Drawing.Size(568, 82)
      Me.rlbHeader.TabIndex = 0
      '
      'mnuMsgMoveChild
      '
      Me.mnuMsgMoveChild.Index = 2
      Me.mnuMsgMoveChild.Text = "Replies only"
      '
      'rtbAttachments
      '
      Me.rtbAttachments.Dock = System.Windows.Forms.DockStyle.Fill
      Me.rtbAttachments.Location = New System.Drawing.Point(0, 4)
      Me.rtbAttachments.Name = "rtbAttachments"
      Me.rtbAttachments.Size = New System.Drawing.Size(568, 30)
      Me.rtbAttachments.TabIndex = 0
      Me.rtbAttachments.Multiline = True
      Me.rtbAttachments.ScrollBars = RichTextBoxScrollBars.ForcedVertical
      '
      'mnuFileExit
      '
      Me.mnuFileExit.Index = 3
      Me.mnuFileExit.Text = "E&xit"
      '
      'mnuToolsPager
      '
      Me.mnuToolsPager.Index = 7
      Me.mnuToolsPager.Shortcut = System.Windows.Forms.Shortcut.CtrlB
      Me.mnuToolsPager.Text = "Pager..."
      Me.mnuToolsPager.Visible = False
      '
      'tbbWholist
      '
      Me.tbbWholist.Enabled = False
      Me.tbbWholist.ImageIndex = 7
      Me.tbbWholist.ToolTipText = "Wholist"
      '
      'mnuFolderRefreshMessages
      '
      Me.mnuFolderRefreshMessages.Index = 1
      Me.mnuFolderRefreshMessages.Shortcut = System.Windows.Forms.Shortcut.ShiftF5
      Me.mnuFolderRefreshMessages.Text = "Refresh &messages"
      Me.mnuFolderRefreshMessages.Visible = False
      '
      'mnuToolsRequest
      '
      Me.mnuToolsRequest.Index = 5
      Me.mnuToolsRequest.Text = "Re&quest..."
      Me.mnuToolsRequest.Visible = False
      '
      'mnuFolderUnsubscribe
      '
      Me.mnuFolderUnsubscribe.Index = 3
      Me.mnuFolderUnsubscribe.Text = "&Unsubscribe"
      Me.mnuFolderUnsubscribe.Visible = False
      '
      'tbbMsgNextUnread
      '
      Me.tbbMsgNextUnread.Enabled = False
      Me.tbbMsgNextUnread.ImageIndex = 4
      Me.tbbMsgNextUnread.ToolTipText = "Next Unread"
      '
      'rcbFolders
      '
      Me.rcbFolders.Dock = System.Windows.Forms.DockStyle.Fill
      Me.rcbFolders.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
      Me.rcbFolders.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
      Me.rcbFolders.DropDownWidth = 383
      Me.rcbFolders.Enabled = False
      Me.rcbFolders.ImageList = Me.imlsUAve
      Me.rcbFolders.Location = New System.Drawing.Point(208, 8)
      Me.rcbFolders.Name = "rcbFolders"
      Me.rcbFolders.Size = New System.Drawing.Size(368, 21)
      Me.rcbFolders.TabIndex = 1
      '
      'pnlSelect
      '
      Me.pnlSelect.Controls.Add(Me.splSelect)
      Me.pnlSelect.Controls.Add(Me.rcbFolders)
      Me.pnlSelect.Controls.Add(Me.rcbWholist)
      Me.pnlSelect.Dock = System.Windows.Forms.DockStyle.Top
      Me.pnlSelect.DockPadding.Bottom = 4
      Me.pnlSelect.DockPadding.Left = 8
      Me.pnlSelect.DockPadding.Right = 8
      Me.pnlSelect.DockPadding.Top = 8
      Me.pnlSelect.Location = New System.Drawing.Point(0, 0)
      Me.pnlSelect.Name = "pnlSelect"
      Me.pnlSelect.Size = New System.Drawing.Size(584, 37)
      Me.pnlSelect.TabIndex = 0
      '
      'rcbWholist
      '
      Me.rcbWholist.Dock = System.Windows.Forms.DockStyle.Left
      Me.rcbWholist.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
      Me.rcbWholist.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
      Me.rcbWholist.DropDownWidth = 121
      Me.rcbWholist.Enabled = False
      Me.rcbWholist.ImageList = Me.imlsUAve
      Me.rcbWholist.Location = New System.Drawing.Point(8, 8)
      Me.rcbWholist.Name = "rcbWholist"
      Me.rcbWholist.Size = New System.Drawing.Size(200, 21)
      Me.rcbWholist.TabIndex = 0
      '
      'tbbClose
      '
      Me.tbbClose.Enabled = False
      Me.tbbClose.ImageIndex = 2
      Me.tbbClose.ToolTipText = "Close"
      '
      'mnuTrayExit
      '
      Me.mnuTrayExit.Index = 5
      Me.mnuTrayExit.Text = "E&xit"
      '
      'tvwFolders
      '
      Me.tvwFolders.Dock = System.Windows.Forms.DockStyle.Fill
      Me.tvwFolders.Enabled = False
      Me.tvwFolders.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
      Me.tvwFolders.ImageIndex = 2
      Me.tvwFolders.ImageList = Me.imlsUAve
      Me.tvwFolders.Indent = 19
      Me.tvwFolders.Location = New System.Drawing.Point(0, 0)
      Me.tvwFolders.Name = "tvwFolders"
      Me.tvwFolders.SelectedImageIndex = 3
      Me.tvwFolders.Size = New System.Drawing.Size(195, 115)
      Me.tvwFolders.TabIndex = 0
      '
      'pnlFolders
      '
      Me.pnlFolders.Controls.Add(Me.tvwFolders)
      Me.pnlFolders.Dock = System.Windows.Forms.DockStyle.Left
      Me.pnlFolders.DockPadding.Right = 5
      Me.pnlFolders.Location = New System.Drawing.Point(8, 4)
      Me.pnlFolders.Name = "pnlFolders"
      Me.pnlFolders.Size = New System.Drawing.Size(200, 115)
      Me.pnlFolders.TabIndex = 1
      '
      'pnlMessage
      '
      Me.pnlMessage.Controls.Add(Me.pnlItem)
      Me.pnlMessage.Dock = System.Windows.Forms.DockStyle.Fill
      Me.pnlMessage.DockPadding.Left = 8
      Me.pnlMessage.DockPadding.Right = 8
      Me.pnlMessage.Location = New System.Drawing.Point(0, 186)
      Me.pnlMessage.Name = "pnlMessage"
      Me.pnlMessage.Size = New System.Drawing.Size(584, 199)
      Me.pnlMessage.TabIndex = 1
      '
      'pnlItem
      '
      Me.pnlItem.Controls.Add(Me.pnlContent)
      Me.pnlItem.Controls.Add(Me.pnlHeader)
      Me.pnlItem.Controls.Add(Me.pnlAttachments)
      Me.pnlItem.Dock = System.Windows.Forms.DockStyle.Fill
      Me.pnlItem.Location = New System.Drawing.Point(8, 0)
      Me.pnlItem.Name = "pnlItem"
      Me.pnlItem.Size = New System.Drawing.Size(568, 199)
      Me.pnlItem.TabIndex = 0
      '
      'pnlAttachments
      '
      Me.pnlAttachments.Controls.Add(Me.rtbAttachments)
      Me.pnlAttachments.Dock = System.Windows.Forms.DockStyle.Bottom
      Me.pnlAttachments.DockPadding.Bottom = 4
      Me.pnlAttachments.DockPadding.Top = 4
      Me.pnlAttachments.Location = New System.Drawing.Point(0, 159)
      Me.pnlAttachments.Name = "pnlAttachments"
      Me.pnlAttachments.Size = New System.Drawing.Size(568, 40)
      Me.pnlAttachments.TabIndex = 1
      Me.pnlAttachments.Visible = False
      '
      'pnlAnnounces
      '
      Me.pnlAnnounces.Controls.Add(Me.rlbAnnounces)
      Me.pnlAnnounces.Dock = System.Windows.Forms.DockStyle.Bottom
      Me.pnlAnnounces.DockPadding.Left = 8
      Me.pnlAnnounces.DockPadding.Right = 8
      Me.pnlAnnounces.DockPadding.Top = 4
      Me.pnlAnnounces.Location = New System.Drawing.Point(0, 385)
      Me.pnlAnnounces.Name = "pnlAnnounces"
      Me.pnlAnnounces.Size = New System.Drawing.Size(584, 68)
      Me.pnlAnnounces.TabIndex = 0
      '
      'tbbPage
      '
      Me.tbbPage.Enabled = False
      Me.tbbPage.ImageIndex = 13
      Me.tbbPage.ToolTipText = "Page"
      '
      'stpSummary
      '
      Me.stpSummary.AutoSize = System.Windows.Forms.StatusBarPanelAutoSize.Spring
      '
      'mnuMsgDelWhole
      '
      Me.mnuMsgDelWhole.Index = 3
      Me.mnuMsgDelWhole.Text = "Whole thread"
      '
      'mnuMsgHoldAll
      '
      Me.mnuMsgHoldAll.Index = 4
      Me.mnuMsgHoldAll.Text = "All"
      '
      'mnuMsgMove
      '
      Me.mnuMsgMove.Index = 3
      Me.mnuMsgMove.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuMsgMoveMsg, Me.mnuMsgMoveMsgChild, Me.mnuMsgMoveChild, Me.mnuMsgMoveWhole})
      Me.mnuMsgMove.Text = "Move"
      '
      'mnuMsgMoveMsg
      '
      Me.mnuMsgMoveMsg.Index = 0
      Me.mnuMsgMoveMsg.Text = "Message"
      '
      'mnuMsgMoveMsgChild
      '
      Me.mnuMsgMoveMsgChild.Index = 1
      Me.mnuMsgMoveMsgChild.Text = "Message and replies"
      '
      'mnuTrayClose
      '
      Me.mnuTrayClose.Enabled = False
      Me.mnuTrayClose.Index = 4
      Me.mnuTrayClose.Text = "Close..."
      '
      'mnuFolderRefreshFolders
      '
      Me.mnuFolderRefreshFolders.Enabled = False
      Me.mnuFolderRefreshFolders.Index = 2
      Me.mnuFolderRefreshFolders.Shortcut = System.Windows.Forms.Shortcut.CtrlShiftF5
      Me.mnuFolderRefreshFolders.Text = "Refresh &folders"
      '
      'tbbTalk
      '
      Me.tbbTalk.Enabled = False
      Me.tbbTalk.ImageIndex = 7
      Me.tbbTalk.ToolTipText = "Talk"
      '
      'mnuView
      '
      Me.mnuView.Index = 1
      Me.mnuView.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuViewRefresh, Me.mnuViewSep, Me.mnuViewEmphasis, Me.mnuViewFixed, Me.mnuViewUnicode, Me.mnuViewRaw})
      Me.mnuView.Text = "&View"
      Me.mnuView.Visible = False
      '
      'mnuViewSep
      '
      Me.mnuViewSep.Index = 1
      Me.mnuViewSep.Text = "-"
      '
      'mnuViewEmphasis
      '
      Me.mnuViewEmphasis.Index = 2
      Me.mnuViewEmphasis.Text = "&Emphasis"
      Me.mnuViewEmphasis.Visible = False
      '
      'mnuViewFixed
      '
      Me.mnuViewFixed.Index = 3
      Me.mnuViewFixed.Text = "&Fixed font"
      Me.mnuViewFixed.Visible = False
      '
      'mnuViewUnicode
      '
      Me.mnuViewUnicode.Index = 4
      Me.mnuViewUnicode.Text = "&Unicode"
      Me.mnuViewUnicode.Visible = False
      '
      'mnuViewRaw
      '
      Me.mnuViewRaw.Index = 5
      Me.mnuViewRaw.Shortcut = System.Windows.Forms.Shortcut.CtrlShiftL
      Me.mnuViewRaw.Text = "&Raw"
      Me.mnuViewRaw.Visible = False
      '
      'mnuMsgCatchMsgChild
      '
      Me.mnuMsgCatchMsgChild.Index = 0
      Me.mnuMsgCatchMsgChild.Shortcut = System.Windows.Forms.Shortcut.CtrlD
      Me.mnuMsgCatchMsgChild.Text = "Message and replies"
      '
      'mnuHelpAbout
      '
      Me.mnuHelpAbout.Index = 0
      Me.mnuHelpAbout.Text = "About..."
      '
      'mnuAdminLocations
      '
      Me.mnuAdminLocations.Index = 1
      Me.mnuAdminLocations.Text = "Locations..."
      '
      'mnuTools
      '
      Me.mnuTools.Index = 4
      Me.mnuTools.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuToolsRefreshServices, Me.mnuToolsRefreshAll, Me.mnuToolsWholist, Me.mnuToolsSystem, Me.mnuToolsUsers, Me.mnuToolsRequest, Me.mnuToolsSep1, Me.mnuToolsPager, Me.mnuToolsStatus, Me.mnuToolsOptions})
      Me.mnuTools.Text = "Tools"
      '
      'mnuToolsRefreshServices
      '
      Me.mnuToolsRefreshServices.Index = 0
      Me.mnuToolsRefreshServices.Text = "Refresh services"
      '
      'mnuToolsRefreshAll
      '
      Me.mnuToolsRefreshAll.Index = 1
      Me.mnuToolsRefreshAll.Text = "Refresh &All"
      Me.mnuToolsRefreshAll.Visible = False
      '
      'mnuToolsWholist
      '
      Me.mnuToolsWholist.Enabled = False
      Me.mnuToolsWholist.Index = 2
      Me.mnuToolsWholist.Shortcut = System.Windows.Forms.Shortcut.CtrlW
      Me.mnuToolsWholist.Text = "Wholist..."
      Me.mnuToolsWholist.Visible = False
      '
      'mnuToolsSystem
      '
      Me.mnuToolsSystem.Index = 3
      Me.mnuToolsSystem.Text = "&System..."
      Me.mnuToolsSystem.Visible = False
      '
      'mnuToolsUsers
      '
      Me.mnuToolsUsers.Index = 4
      Me.mnuToolsUsers.Shortcut = System.Windows.Forms.Shortcut.CtrlU
      Me.mnuToolsUsers.Text = "Users..."
      Me.mnuToolsUsers.Visible = False
      '
      'mnuToolsSep1
      '
      Me.mnuToolsSep1.Index = 6
      Me.mnuToolsSep1.Text = "-"
      Me.mnuToolsSep1.Visible = False
      '
      'mnuToolsStatus
      '
      Me.mnuToolsStatus.Index = 8
      Me.mnuToolsStatus.Text = "Status..."
      Me.mnuToolsStatus.Visible = False
      '
      'mnuToolsOptions
      '
      Me.mnuToolsOptions.Index = 9
      Me.mnuToolsOptions.Text = "Options..."
      '
      'mnuFolderList
      '
      Me.mnuFolderList.Index = 0
      Me.mnuFolderList.Text = "&List..."
      '
      'mnuAdminReload
      '
      Me.mnuAdminReload.Index = 2
      Me.mnuAdminReload.Text = "Reload..."
      '
      'mnuFileClose
      '
      Me.mnuFileClose.Enabled = False
      Me.mnuFileClose.Index = 1
      Me.mnuFileClose.Text = "&Close..."
      '
      'mnuMsgDelMsgChild
      '
      Me.mnuMsgDelMsgChild.Index = 1
      Me.mnuMsgDelMsgChild.Text = "Message and replies"
      '
      'mnuFolder
      '
      Me.mnuFolder.Index = 2
      Me.mnuFolder.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuFolderList, Me.mnuFolderRefreshMessages, Me.mnuFolderRefreshFolders, Me.mnuFolderUnsubscribe, Me.mnuFolderJump, Me.mnuFolderSearch, Me.mnuFolderNextUnread})
      Me.mnuFolder.Text = "F&older"
      Me.mnuFolder.Visible = False
      '
      'mnuFolderSearch
      '
      Me.mnuFolderSearch.Enabled = False
      Me.mnuFolderSearch.Index = 5
      Me.mnuFolderSearch.Shortcut = System.Windows.Forms.Shortcut.CtrlS
      Me.mnuFolderSearch.Text = "&Search..."
      '
      'mnuHelp
      '
      Me.mnuHelp.Index = 5
      Me.mnuHelp.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuHelpAbout})
      Me.mnuHelp.Text = "&Help"
      '
      'pnlTop
      '
      Me.pnlTop.Controls.Add(Me.pnlMessages)
      Me.pnlTop.Controls.Add(Me.pnlSelect)
      Me.pnlTop.Dock = System.Windows.Forms.DockStyle.Top
      Me.pnlTop.Location = New System.Drawing.Point(0, 26)
      Me.pnlTop.Name = "pnlTop"
      Me.pnlTop.Size = New System.Drawing.Size(584, 160)
      Me.pnlTop.TabIndex = 1
      '
      'pnlMessages
      '
      Me.pnlMessages.Controls.Add(Me.tvwMessages)
      Me.pnlMessages.Controls.Add(Me.splFolders)
      Me.pnlMessages.Controls.Add(Me.pnlFolders)
      Me.pnlMessages.Dock = System.Windows.Forms.DockStyle.Fill
      Me.pnlMessages.DockPadding.Bottom = 4
      Me.pnlMessages.DockPadding.Left = 8
      Me.pnlMessages.DockPadding.Right = 8
      Me.pnlMessages.DockPadding.Top = 4
      Me.pnlMessages.Location = New System.Drawing.Point(0, 37)
      Me.pnlMessages.Name = "pnlMessages"
      Me.pnlMessages.Size = New System.Drawing.Size(584, 123)
      Me.pnlMessages.TabIndex = 1
      '
      'tvwMessages
      '
      Me.tvwMessages.Dock = System.Windows.Forms.DockStyle.Fill
      Me.tvwMessages.Enabled = False
      Me.tvwMessages.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
      Me.tvwMessages.ImageIndex = 4
      Me.tvwMessages.ImageList = Me.imlsUAve
      Me.tvwMessages.Indent = 19
      Me.tvwMessages.Location = New System.Drawing.Point(211, 4)
      Me.tvwMessages.Name = "tvwMessages"
      Me.tvwMessages.SelectedImageIndex = 5
      Me.tvwMessages.Size = New System.Drawing.Size(365, 115)
      Me.tvwMessages.TabIndex = 0
      '
      'tbbMsgAdd
      '
      Me.tbbMsgAdd.Enabled = False
      Me.tbbMsgAdd.ImageIndex = 6
      Me.tbbMsgAdd.ToolTipText = "Add"
      '
      'mnuTraySep1
      '
      Me.mnuTraySep1.Index = 1
      Me.mnuTraySep1.Text = "-"
      Me.mnuTraySep1.Visible = False
      '
      'mnuMsgDelChild
      '
      Me.mnuMsgDelChild.Index = 2
      Me.mnuMsgDelChild.Text = "Replies only"
      '
      'splAnnounces
      '
      Me.splAnnounces.Dock = System.Windows.Forms.DockStyle.Bottom
      Me.splAnnounces.Location = New System.Drawing.Point(0, 382)
      Me.splAnnounces.Name = "splAnnounces"
      Me.splAnnounces.Size = New System.Drawing.Size(584, 3)
      Me.splAnnounces.TabIndex = 3
      Me.splAnnounces.TabStop = False
      '
      'tbbMsgThread
      '
      Me.tbbMsgThread.DropDownMenu = Me.mnuMsgThread
      Me.tbbMsgThread.Enabled = False
      Me.tbbMsgThread.ImageIndex = 4
      Me.tbbMsgThread.Style = System.Windows.Forms.ToolBarButtonStyle.DropDownButton
      Me.tbbMsgThread.ToolTipText = "Thread"
      '
      'mnuMsgThread
      '
      Me.mnuMsgThread.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuMsgDel, Me.mnuMsgCatch, Me.mnuMsgHold, Me.mnuMsgMove})
      '
      'mnuMsgDel
      '
      Me.mnuMsgDel.Index = 0
      Me.mnuMsgDel.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuMsgDelMsg, Me.mnuMsgDelMsgChild, Me.mnuMsgDelChild, Me.mnuMsgDelWhole})
      Me.mnuMsgDel.Text = "Delete"
      '
      'mnuMsgCatch
      '
      Me.mnuMsgCatch.Index = 1
      Me.mnuMsgCatch.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuMsgCatchMsgChild, Me.mnuMsgCatchChild, Me.mnuMsgCatchWhole, Me.mnuMsgCatchAll})
      Me.mnuMsgCatch.Text = "Catchup"
      '
      'mnuMsgCatchChild
      '
      Me.mnuMsgCatchChild.Index = 1
      Me.mnuMsgCatchChild.Text = "Replies only"
      '
      'mnuMsgCatchWhole
      '
      Me.mnuMsgCatchWhole.Index = 2
      Me.mnuMsgCatchWhole.Shortcut = System.Windows.Forms.Shortcut.CtrlShiftD
      Me.mnuMsgCatchWhole.Text = "Whole thread"
      '
      'mnuMsgCatchAll
      '
      Me.mnuMsgCatchAll.Index = 3
      Me.mnuMsgCatchAll.Text = "All"
      '
      'mnuMsgHold
      '
      Me.mnuMsgHold.Index = 2
      Me.mnuMsgHold.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuMsgHoldMsg, Me.mnuMsgHoldMsgChild, Me.mnuMsgHoldChild, Me.mnuMsgHoldWhole, Me.mnuMsgHoldAll})
      Me.mnuMsgHold.Text = "Hold"
      '
      'mnuMsgHoldMsgChild
      '
      Me.mnuMsgHoldMsgChild.Index = 1
      Me.mnuMsgHoldMsgChild.Text = "Message and replies"
      '
      'mnuMsgHoldChild
      '
      Me.mnuMsgHoldChild.Index = 2
      Me.mnuMsgHoldChild.Text = "Replies only"
      '
      'mnuMsgHoldWhole
      '
      Me.mnuMsgHoldWhole.Index = 3
      Me.mnuMsgHoldWhole.Text = "Whole thread"
      '
      'tlbsUAve
      '
      Me.tlbsUAve.Appearance = System.Windows.Forms.ToolBarAppearance.Flat
      Me.tlbsUAve.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.tbbOpen, Me.tbbClose, Me.tbbSep1, Me.tbbPage, Me.tbbWholist, Me.tbbTalk, Me.tbbSep2, Me.tbbMsgAdd, Me.tbbMsgReply, Me.tbbMsgNextUnread, Me.tbbMsgThread, Me.tbbMsgAnnotate, Me.tbbMsgVoteClose})
      Me.tlbsUAve.Divider = False
      Me.tlbsUAve.DropDownArrows = True
      Me.tlbsUAve.ImageList = Me.imlsUAve
      Me.tlbsUAve.Location = New System.Drawing.Point(0, 0)
      Me.tlbsUAve.Name = "tlbsUAve"
      Me.tlbsUAve.ShowToolTips = True
      Me.tlbsUAve.Size = New System.Drawing.Size(584, 26)
      Me.tlbsUAve.TabIndex = 5
      '
      'tbbMsgReply
      '
      Me.tbbMsgReply.Enabled = False
      Me.tbbMsgReply.ImageIndex = 6
      Me.tbbMsgReply.ToolTipText = "Reply"
      '
      'tbbMsgAnnotate
      '
      Me.tbbMsgAnnotate.Enabled = False
      Me.tbbMsgAnnotate.ImageIndex = 6
      Me.tbbMsgAnnotate.ToolTipText = "Annotate"
      '
      'tbbMsgVoteClose
      '
      Me.tbbMsgVoteClose.Enabled = False
      Me.tbbMsgVoteClose.ImageIndex = 11
      Me.tbbMsgVoteClose.ToolTipText = "Close vote"
      '
      'mnuTrayShow
      '
      Me.mnuTrayShow.DefaultItem = True
      Me.mnuTrayShow.Index = 0
      Me.mnuTrayShow.Text = "Show"
      Me.mnuTrayShow.Visible = False
      '
      'mnuTray
      '
      Me.mnuTray.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuTrayShow, Me.mnuTraySep1, Me.mnuTrayPage, Me.mnuTraySep2, Me.mnuTrayClose, Me.mnuTrayExit})
      '
      'mnuTrayPage
      '
      Me.mnuTrayPage.Index = 2
      Me.mnuTrayPage.Text = "Page..."
      Me.mnuTrayPage.Visible = False
      '
      'mnuFileSep1
      '
      Me.mnuFileSep1.Index = 2
      Me.mnuFileSep1.Text = "-"
      '
      'mnusUAve
      '
      Me.mnusUAve.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuFile, Me.mnuView, Me.mnuFolder, Me.mnuAdmin, Me.mnuTools, Me.mnuHelp, Me.mnuKeys})
      '
      'mnuFile
      '
      Me.mnuFile.Index = 0
      Me.mnuFile.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuFileOpen, Me.mnuFileClose, Me.mnuFileSep1, Me.mnuFileExit})
      Me.mnuFile.Text = "&File"
      '
      'mnuAdmin
      '
      Me.mnuAdmin.Index = 3
      Me.mnuAdmin.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuAdminBanner, Me.mnuAdminLocations, Me.mnuAdminReload, Me.mnuAdminSysMsg})
      Me.mnuAdmin.Text = "Admin"
      Me.mnuAdmin.Visible = False
      '
      'mnuAdminBanner
      '
      Me.mnuAdminBanner.Index = 0
      Me.mnuAdminBanner.Text = "Banner..."
      '
      'mnuAdminSysMsg
      '
      Me.mnuAdminSysMsg.Index = 3
      Me.mnuAdminSysMsg.Text = "System message..."
      '
      'nfisUAve
      '
      Me.nfisUAve.ContextMenu = Me.mnuTray
      Me.nfisUAve.Icon = CType(resources.GetObject("nfisUAve.Icon"), System.Drawing.Icon)
      Me.nfisUAve.Text = "sUAve"
      '
      'stbsUAve
      '
      Me.stbsUAve.Location = New System.Drawing.Point(0, 453)
      Me.stbsUAve.Name = "stbsUAve"
      Me.stbsUAve.Panels.AddRange(New System.Windows.Forms.StatusBarPanel() {Me.stpTimeOn, Me.stpUser, Me.stpSummary})
      Me.stbsUAve.Size = New System.Drawing.Size(584, 20)
      Me.stbsUAve.TabIndex = 4
      Me.stbsUAve.Text = "Not connected"
      '
      'imlsUAveXP
      '
      Me.imlsUAveXP.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit
      Me.imlsUAveXP.ImageSize = New System.Drawing.Size(16, 16)
      Me.imlsUAveXP.ImageStream = CType(resources.GetObject("imlsUAveXP.ImageStream"), System.Windows.Forms.ImageListStreamer)
      Me.imlsUAveXP.TransparentColor = System.Drawing.Color.Transparent
      '
      'splMessages
      '
      Me.splMessages.Dock = System.Windows.Forms.DockStyle.Top
      Me.splMessages.Location = New System.Drawing.Point(0, 186)
      Me.splMessages.Name = "splMessages"
      Me.splMessages.Size = New System.Drawing.Size(584, 3)
      Me.splMessages.TabIndex = 2
      Me.splMessages.TabStop = False
      '
      'frmsUAve
      '
      Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
      Me.ClientSize = New System.Drawing.Size(584, 473)
      Me.Controls.Add(Me.splAnnounces)
      Me.Controls.Add(Me.splMessages)
      Me.Controls.Add(Me.pnlMessage)
      Me.Controls.Add(Me.pnlTop)
      Me.Controls.Add(Me.pnlAnnounces)
      Me.Controls.Add(Me.tlbsUAve)
      Me.Controls.Add(Me.stbsUAve)
      Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
      Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
      Me.Menu = Me.mnusUAve
      Me.Name = "frmsUAve"
      Me.Tag = ""
      Me.Text = "sUAve"
      Me.pnlContent.ResumeLayout(False)
      Me.pnlVotes.ResumeLayout(False)
      CType(Me.stpUser, System.ComponentModel.ISupportInitialize).EndInit()
      CType(Me.stpTimeOn, System.ComponentModel.ISupportInitialize).EndInit()
      Me.pnlHeader.ResumeLayout(False)
      Me.pnlReply.ResumeLayout(False)
      Me.pnlSelect.ResumeLayout(False)
      Me.pnlFolders.ResumeLayout(False)
      Me.pnlMessage.ResumeLayout(False)
      Me.pnlItem.ResumeLayout(False)
      Me.pnlAttachments.ResumeLayout(False)
      Me.pnlAnnounces.ResumeLayout(False)
      CType(Me.stpSummary, System.ComponentModel.ISupportInitialize).EndInit()
      Me.pnlTop.ResumeLayout(False)
      Me.pnlMessages.ResumeLayout(False)
      Me.ResumeLayout(False)

   End Sub

#End Region

   Public Sub connected()
      Me.Text = m_sServer & " - " & CLIENT_NAME

      stbsUAve.Text = "Logging in..."

      Application.DoEvents()
   End Sub

   Public Sub disconnected()
      Dim sError As String

      If m_bSupressError = False Then
         If Not Client Is Nothing Then
            sError = Client.Error()
            If sError Is Nothing Then
               sError = "Connection to host lost"
            End If
            MsgBox(sError, MsgBoxStyle.Critical)
         End If

         disconnect(False, Nothing)
      End If
   End Sub

   Public Sub loggedIn()
      Dim iAccessLevel As Integer, iServiceID As Integer
      Dim bLoop As Boolean
      Dim sServiceName As String
      Dim pRequest As CEDF, pReply As CEDF

      m_pTimeOn = Now()

      sUAveHelper.LoggedIn()

      FormAdd(Me)

      Me.Cursor = Cursors.Default

      iAccessLevel = Client.GetAccessLevel()

      'RefreshSettings()
      'Application.DoEvents()

      RefreshAll()

      mnuFileOpen.Enabled = False
      mnuFileClose.Enabled = True

      mnuView.Visible = True

      mnuFolder.Visible = True
      mnuFolderRefreshFolders.Enabled = True
      mnuFolderJump.Enabled = True
      mnuFolderSearch.Enabled = True

      If iAccessLevel >= ua.LEVEL_WITNESS Then
         mnuAdmin.Visible = True
      End If

      mnuToolsRefreshAll.Visible = True
      mnuToolsWholist.Enabled = True
      mnuToolsWholist.Visible = True
      mnuToolsSystem.Visible = True
      mnuToolsUsers.Visible = True
      mnuToolsRequest.Visible = True
      mnuToolsSep1.Visible = True
      mnuToolsPager.Visible = True
      mnuToolsStatus.Visible = True

      mnuKeysAdd.Enabled = True
      mnuFolderNextUnread.Enabled = True

      tbbOpen.Enabled = False
      tbbClose.Enabled = True
      tbbMsgAdd.Enabled = True
      tbbPage.Enabled = True
      tbbWholist.Enabled = True
      If Client.version("2.6") >= 0 Then
         tbbTalk.Enabled = True
      End If

      rlbAnnounces.Enabled = True

      rcbWholist.Enabled = True
      rcbFolders.Enabled = True
      tvwFolders.Enabled = True

      stbsUAve.ShowPanels = True

      tmrsUAve.Enabled = True

      mnuTrayClose.Enabled = True
      mnuTrayPage.Visible = True
      mnuTraySep2.Visible = True

      frmWholist.FieldSet("timeon", True)
      frmWholist.FieldSet("accesslevel", True)
      frmWholist.FieldSet("name", True)
      If iAccessLevel >= ua.LEVEL_WITNESS Then
         frmWholist.FieldSet("hostname", True)
      End If
      frmWholist.FieldSet("location", True)
      If iAccessLevel >= ua.LEVEL_WITNESS Then
         frmWholist.FieldSet("client", True)
      End If

      pReply = New CEDF
      Client.request2(ua.MSG_SYSTEM_LIST, pReply)
      SetServerTime(pReply)
      rtbContent.Enabled = True
      TextShow(rtbContent, pReply.GetChildStr("banner"), False, True, True, False)
   End Sub

   Private Sub disconnect(ByVal bUserInput As Boolean, ByVal sMessage As String)
      Dim sUsername As Boolean
      Dim pMessage() As Byte
      Dim pPage As frmPage
      Dim pRequest As CEDF, pReply As CEDF
      Dim pNode As TreeNode

      debugline("frmsUAve::disconnect " & bUserInput & " " & sMessage)

      FormDispose(Me)

      tmrsUAve.Enabled = False

      m_bSupressError = True

      If Not Client Is Nothing Then
         pReply = New CEDF

         If Not sMessage Is Nothing Then
            pRequest = New CEDF
            AddTextField(pRequest, "text", sMessage)
            Client.request3(ua.MSG_USER_LOGOUT, pRequest, pReply)
         Else
            Client.request3(ua.MSG_USER_LOGOUT, Nothing, pReply)
         End If

         If bUserInput = True Then
            sUsername = Client.GetName()
            MsgBox("Goodbye " & sUsername & ". Call again soon")
         End If
      End If

      sUAveHelper.Disconnect()

      Me.Text = CLIENT_NAME

      Me.WindowState = FormWindowState.Normal
      nfisUAve.Visible = False

      m_bUserInput = False

      mnuFileOpen.Enabled = True
      mnuFileClose.Enabled = False

      mnuView.Visible = False

      mnuFolder.Visible = False
      mnuFolderRefreshFolders.Enabled = False
      mnuFolderJump.Enabled = False
      mnuFolderSearch.Enabled = False

      mnuAdmin.Visible = False

      mnuToolsRefreshAll.Visible = False
      mnuToolsWholist.Visible = False
      mnuToolsWholist.Enabled = False
      mnuToolsSystem.Visible = False
      mnuToolsUsers.Visible = False
      mnuToolsRequest.Visible = False
      mnuToolsSep1.Visible = False
      mnuToolsPager.Visible = False
      mnuToolsStatus.Visible = False

      tbbOpen.Enabled = True
      tbbClose.Enabled = False
      tbbMsgAdd.Enabled = False
      tbbMsgReply.Enabled = False
      tbbMsgNextUnread.Enabled = False
      tbbMsgThread.Enabled = False
      tbbMsgAnnotate.Enabled = False
      tbbMsgVoteClose.Enabled = False
      tbbPage.Enabled = False
      tbbWholist.Enabled = False
      tbbTalk.Enabled = False

      rcbWholist.Items.Clear()
      rcbWholist.Enabled = False
      rcbFolders.Items.Clear()
      rcbFolders.Enabled = False
      tvwFolders.BeginUpdate()
      tvwFolders.Nodes.Clear()
      tvwFolders.EndUpdate()
      tvwFolders.Enabled = False

      rlbHeader.Items.Clear()
      rlbHeader.Enabled = False

      lblReplyTo.Enabled = False
      rlbReplyTo.Items.Clear()
      rlbReplyTo.Enabled = False
      lblReplyBy.Enabled = False
      rlbReplyBy.Items.Clear()
      rlbReplyBy.Enabled = False

      rtbContent.Text = ""
      rtbContent.Enabled = False

      m_bClearing = True
      rlbAnnounces.BeginUpdate()
      rlbAnnounces.Items.Clear()
      rlbAnnounces.EndUpdate()
      m_bClearing = False
      rlbAnnounces.Enabled = False

      m_bClearing = True
      tvwMessages.BeginUpdate()
      tvwMessages.Nodes.Clear()
      tvwMessages.EndUpdate()
      m_bClearing = False

      tvwMessages.Enabled = False

      m_bUserInput = True

      stbsUAve.Text = "Not connected"
      stbsUAve.ShowPanels = False

      mnuTrayClose.Enabled = False
      mnuTrayPage.Visible = False
      mnuTraySep2.Visible = False
      nfisUAve.Visible = False

      m_bSupressError = False

      m_iViewType = -1
   End Sub

   Public Function reply(ByVal sReply As String, ByRef pReply As CEDF) As Boolean
      If sReply = ua.MSG_USER_LOGIN_INVALID Then
         MsgBox("Login failed", MsgBoxStyle.Critical)

         disconnect(False, Nothing)
      ElseIf sReply = ua.MSG_USER_LOGIN_ALREADY_ON Then
         If MsgBox("You are already logged on. Do you wish to stop the other session?", MsgBoxStyle.YesNo + MsgBoxStyle.Question) = MsgBoxResult.Yes Then
            m_bForceLogin = True

            m_pConfig.AddChild("force", True)

            DoConnect(m_sDebugFile)

            m_bForceLogin = False
         End If
      Else
         pReply.MsgPrint("frmsUAve::reply")
      End If

      Return True
   End Function

   Public Function announce(ByVal sAnnounce As String, ByRef pAnnounce As CEDF) As Boolean
      Dim iItemNum As Integer, iImageIndex As Integer = -1, iTemp As Integer, iToID As Integer, iConnID As Integer
      Dim iFolderID As Integer, iReplyID As Integer, iMessageID As Integer, iMarked As Integer, iRead As Integer, iLStatus As Integer
      Dim iUserID As Integer, iStatus As Integer, iGender As Integer, iFromID As Integer = -1, iIncRead As Integer, iAccessMode As Integer
      Dim iConnectionID As Integer, iWriteTime As Integer, iPageNum As Integer = 1, iMoveID As Integer, iValue As Integer, iMarkType As Integer
      Dim iIcon As Integer
      Dim iMsgType As Integer, iID As Integer, iNumUnread As Integer, iNumChecks As Integer, iAnnounceTime As Integer
      Dim bFound As Boolean, bTemp As Boolean, bLoop As Boolean, bFakePage As Boolean, bAnnounce As Boolean = True, bUpdate As Boolean
      Dim sFromName As String, sUserName As String, sHostname As String, sLocation As String, sClient As String, sText As String
      Dim sFolderName As String, sByName As String, sSubject As String, sMoveName As String, sTitle As String, sService As String
      Dim sWrite As String = "", sTimeOn As String, sStatus1 As String, sStatus2 As String, sAction As String, sShadow As String, sMsgType As String
      Dim pNode As TreeNode, pParent As TreeNode
      Dim pRequest As CEDF, pReply As CEDF
      Dim pMessage As MessageLookup, pLookup As Lookup
      Dim pUser As UserLookup
      Dim pFolder As MessageTreeLookup, pFolder2 As MessageTreeLookup
      Dim pPage As frmPage
      Dim pSysMsg As frmSystem
      Dim pChannel As frmTalk

      iAnnounceTime = pAnnounce.GetChildInt("announcetime")

      If sAnnounce = ua.MSG_SYSTEM_WRITE Then
         iWriteTime = pAnnounce.GetChildInt("writetime")

         sWrite = "System write complete (" & markup(iWriteTime) & " ms)"

         iImageIndex = ICO_LOCK
      ElseIf sAnnounce = ua.MSG_SYSTEM_MESSAGE Then
         pSysMsg = New frmSystem(pAnnounce)
         pSysMsg.ShowDialog()
      ElseIf sAnnounce = ua.MSG_CONNECTION_OPEN Or sAnnounce = ua.MSG_CONNECTION_CLOSE Then
         sHostname = pAnnounce.GetChildStr("hostname")
         If sHostname Is Nothing Then
            sHostname = pAnnounce.GetChildStr("address")
         End If
         sLocation = pAnnounce.GetChildStr("location")
         sClient = pAnnounce.GetChildStr("client")

         iConnectionID = pAnnounce.GetChildInt("connectionid")
         sWrite = "Connection " & markup(iConnectionID) & " "
         If sAnnounce = ua.MSG_CONNECTION_OPEN Then
            sWrite &= "opened"
         Else
            sWrite &= "closed"
         End If

         If Not sHostname Is Nothing Or Not sLocation Is Nothing Then
            sWrite &= " from"
            If Not sHostname Is Nothing Then
               sWrite &= " " & markup(sHostname)
               If Not sLocation Is Nothing Then
                  sWrite &= " (" & markup(sLocation) & ")"
               End If
            Else
               sWrite &= " " & markup(sLocation)
            End If
         End If

         iImageIndex = ICO_LOCK
      ElseIf sAnnounce = ua.MSG_FOLDER_ADD Then
         iFolderID = pAnnounce.GetChildInt("folderid")
         sFolderName = pAnnounce.GetChildStr("foldername")

         pRequest = New CEDF
         pRequest.AddChild("folderid", iFolderID)
         pReply = New CEDF

         Client.request3(ua.MSG_FOLDER_LIST, pRequest, pReply)

         FolderAdd(pReply)
         RefreshFolders(False)

         sWrite = markup(sFolderName) & " has been created"

         iImageIndex = ICO_FOLDER_CLOSE
      ElseIf sAnnounce = ua.MSG_FOLDER_EDIT Then
         iFolderID = pAnnounce.GetChildInt("folderid")
         sFolderName = pAnnounce.GetChildStr("foldername")

         pFolder = FolderGet(iFolderID)
         If pFolder.m_sValue <> sFolderName Then
            pFolder.m_sValue = sFolderName

            RefreshFolders(False)
         End If

         sWrite = markup(sFolderName) & " has been edited"

         sByName = pAnnounce.GetChildStr("byname")
         If sByName <> "" Then
            sWrite &= " by " & markup(sByName)
         End If

         iImageIndex = ICO_FOLDER_CLOSE
      ElseIf sAnnounce = ua.MSG_MESSAGE_ADD Then
         iMessageID = pAnnounce.GetChildInt("messageid")
         iReplyID = pAnnounce.GetChildInt("replyto")
         iFolderID = pAnnounce.GetChildInt("folderid")
         sFromName = pAnnounce.GetChildStr("fromname")
         sSubject = TextDecode(pAnnounce.GetChildStr("subject"))

         'pAnnounce.MsgPrint("frmsUAve::announce message_add")

         iMarked = pAnnounce.GetChildInt("marked")
         debugline("frmsUAve::announce " & iMessageID & " marked " & iMarked)
         If iMarked = ua.MARKED_READ Then
            iRead = 1
         Else
            iIncRead = 1
            'iRead = 0
         End If

         iMarkType = pAnnounce.GetChildInt("marktype")

         If m_iViewType = VT_FOLDERUSER Then
            pFolder = FolderGet(iFolderID)
         Else
            pNode = FolderFind(iFolderID)
            pFolder = pNode.Tag
         End If

         If Not pFolder Is Nothing Then
            iAccessMode = pFolder.m_iAccessMode

            iUserID = Client.GetID()

            iLStatus = Client.GetStatus()

            bFakePage = Client.GetClientBool("fakepage")

            iToID = pAnnounce.GetChildInt("toid")
         Else
            MsgBox("Cannot find folder " & iFolderID, MsgBoxStyle.Exclamation, "frmsUAve::announce")
         End If

         If mask(iLStatus, ua.LOGIN_BUSY) = False And bFakePage = True And mask(iAccessMode, ua.ACCMODE_PRIVATE) = True And iToID = iUserID Then
            'CurrUser().MsgPrint("frmsUAve::announce IPM")

            pRequest = New CEDF
            pReply = New CEDF

            pRequest.AddChild("messageid", iMessageID)
            If Client.request3(ua.MSG_MESSAGE_LIST, pRequest, pReply) = True Then
               iRead = 1
               iIncRead = 0

               If pReply.Child("message") = True Then
                  PageRecieve(iAnnounceTime, pReply)
                  pReply.Parent()
               End If
            End If

            bAnnounce = False
         Else
            sFolderName = pAnnounce.GetChildStr("foldername")
            iMsgType = pAnnounce.GetChildInt("msgtype")

            If mask(iMsgType, ua.MSGTYPE_VOTE) = True Then
               sMsgType = "poll"
               iIcon = ICO_BALLOT
            Else
               sMsgType = "message"
               iIcon = ICO_MSG_CLOSE
            End If
            sWrite = "A new " & sMsgType & " has been posted in " & markup(sFolderName) & " by " & markup(sFromName)
            If iMarkType > 0 Then
               sWrite &= " [Caught-Up]"
            ElseIf iMarked = ua.MARKED_READ Then
               sWrite &= " [Read]"
            End If

            pLookup = New Lookup(Lookup.ANN_MESSAGE, iMessageID, iFolderID, sWrite, iIcon)
         End If

         If Not pFolder Is Nothing Then
            ResetFolder(pFolder, pFolder.m_iValue + iIncRead, pFolder.m_iNumMsgs + 1)

            If iRead = 0 Then
               ShowSystem()
            End If

            If iFolderID = m_iCurrFolder Or m_iCaching >= 1 Then
               pMessage = New MessageLookup(iMessageID, Nothing, sFromName, sSubject, iRead)
               If mask(iMsgType, ua.MSGTYPE_VOTE) = True Then
                  pMessage.ImageIndex = ICO_BALLOT
               End If
               sWrite = pMessage.ToString()

               'iReplyID = pAnnounce.GetChildInt("replyto")
               If iReplyID > 0 Then
                  If Not pFolder.m_pTree Is Nothing Then
                     pParent = NodeFind(pFolder.m_pTree.Nodes, pFolder.m_pTree.GetNodeCount(False), 0, iReplyID)
                  ElseIf iFolderID = m_iCurrFolder Then
                     pParent = MessageFind(0, iReplyID)
                  End If
               End If

               pNode = New TreeNode(sWrite)
               pNode.Tag = pMessage
               If pMessage.m_iValue = 1 Then
                  pNode.NodeFont = New Font(tvwMessages.Font, FontStyle.Regular)
               End If

               If Not pParent Is Nothing Then
                  pParent.Nodes.Add(pNode)
               Else
                  If m_iCaching >= 1 And Not pFolder.m_pTree Is Nothing Then
                     pFolder.m_pTree.Nodes.Add(pNode)
                  End If

                  If iFolderID = m_iCurrFolder Then
                     tvwMessages.Nodes.Add(pNode)
                  End If
               End If

               If Not pParent Is Nothing And (m_iExpansion = 0 Or (m_iExpansion = 1 And pMessage.m_iValue = 0)) Then
                  pParent.Expand()
               End If
            End If
         End If
      ElseIf sAnnounce = ua.MSG_MESSAGE_DELETE Or sAnnounce = ua.MSG_MESSAGE_EDIT Then
         iMessageID = pAnnounce.GetChildInt("messageid")
         iFolderID = pAnnounce.GetChildInt("folderid")
         sFolderName = pAnnounce.GetChildStr("foldername")
         sByName = pAnnounce.GetChildStr("byname")

         sWrite = "Message " & markup(iMessageID) & " in " & markup(sFolderName) & " has been "
         If sAnnounce = ua.MSG_MESSAGE_DELETE Then
            sWrite &= "deleted"
         ElseIf sAnnounce = ua.MSG_MESSAGE_EDIT Then
            sWrite &= "edited"
         End If
         If Not sByName Is Nothing Then
            sWrite &= " by " & markup(sByName)
         End If

         If sAnnounce = ua.MSG_MESSAGE_EDIT Then
            If iMarkType > 0 Then
               sWrite &= " [Caught-Up]"
            ElseIf iMarked = ua.MARKED_READ Then
               sWrite &= " [Read]"
            End If

            If iMessageID = m_iCurrMessage Then
               RefreshMessage(m_iCurrMessage)
            Else
               iMarked = pAnnounce.GetChildInt("marked")
               If iMarked = ua.MARKED_UNREAD Then
                  pFolder = FolderGet(iFolderID)
                  'pFolder.m_iValue += 1
                  ResetFolder(pFolder, pFolder.m_iValue + 1)

                  If m_iCaching >= 1 And Not pFolder.m_pTree Is Nothing Then
                     debugline("frmsUAve::RefreshMessages editing " & iMessageID & " in cached folder " & pFolder.m_iID & " (" & pFolder.m_sValue & ")")

                     pNode = NodeFind(pFolder.m_pTree.Nodes, pFolder.m_pTree.GetNodeCount(False), 0, iMessageID)
                     If Not pNode Is Nothing Then
                        pMessage = pNode.Tag
                        pMessage.m_iValue = 0
                        pNode.NodeFont = New Font(tvwMessages.Font, tvwMessages.Font.Style)
                     End If
                  End If

                  ShowSystem()
               End If
            End If
         End If

         If sAnnounce = ua.MSG_MESSAGE_EDIT Then
            pLookup = New Lookup(Lookup.ANN_MESSAGE, iMessageID, iFolderID, sWrite, ICO_MSG_CLOSE)
         Else
            iImageIndex = ICO_MSG_CLOSE
         End If
      ElseIf sAnnounce = ua.MSG_MESSAGE_MOVE Then
         iFolderID = pAnnounce.GetChildInt("folderid")
         iMessageID = pAnnounce.GetChildInt("messageid")
         iMoveID = pAnnounce.GetChildInt("moveid")
         sFolderName = pAnnounce.GetChildStr("foldername")
         sMoveName = pAnnounce.GetChildStr("movename")
         sByName = pAnnounce.GetChildStr("byname")

         sWrite = "Message " & markup(iMessageID) & " in " & markup(sFolderName)
         If pAnnounce.Children("messageid") - 1 > 0 Then
            sWrite &= " and " & plural(pAnnounce.Children("messageid") - 1, "reply", "replies", True)
         End If
         sWrite &= " moved to " & markup(sMoveName)
         If Not sByName Is Nothing Then
            sWrite &= " by " & markup(sByName)
         End If

         iImageIndex = ICO_MSG_CLOSE

         'debugline("frmsUAve::announce folder " & iFolderID & ", move " & iMoveID)

         pFolder = FolderGet(iFolderID)
         If pFolder.m_iID = m_iCurrFolder Then
            RefreshMessages(pFolder, False)
         Else
            pFolder.m_bDirty = True
         End If

         pFolder = FolderGet(iMoveID)
         If pFolder.m_iID = m_iCurrFolder Then
            RefreshMessages(pFolder, False)
         Else
            pFolder.m_bDirty = True
         End If

         ' RefreshFolders()
         pReply = New CEDF
         Client.request3(ua.MSG_FOLDER_LIST, Nothing, pReply)

         bLoop = pReply.Child("folder")
         Do While bLoop = True
            iID = pReply.GetInt()
            'debugline("frmsUAve::announce folder list ID " & iID)
            If iID = iFolderID Or iID = iMoveID Then
               pFolder = FolderGet(iID)
               iNumUnread = pReply.GetChildInt("unread")
               debugline("frmsUAve::announce " & pFolder.m_iID & "(" & pFolder.m_sValue & ". unread " & iNumUnread & ", lookup " & pFolder.m_iValue)
               If pFolder.m_iValue <> iNumUnread Then
                  debugline("frmsUAve::announce updating folder " & iID)
                  pFolder.m_iValue = iNumUnread
                  bUpdate = True
               End If

               iNumChecks += 1
               If iNumChecks = 2 Then
                  bLoop = False
               Else
                  bLoop = pReply.Iterate("folder")
               End If
            Else
               bLoop = pReply.Iterate("folder")
            End If
         Loop

         If bUpdate = True Then
            debugline("frmsUAve::announce updating system")
            ShowSystem()
         End If
      ElseIf sAnnounce = ua.MSG_CHANNEL_SUBSCRIBE Or sAnnounce = ua.MSG_CHANNEL_UNSUBSCRIBE Or sAnnounce = ua.MSG_CHANNEL_SEND Then
         pChannel = ChannelFind(0, pAnnounce)

         If Not pChannel Is Nothing Then
            If sAnnounce = ua.MSG_CHANNEL_SUBSCRIBE Then
               pChannel.UserAdd(pAnnounce)
            ElseIf sAnnounce = ua.MSG_CHANNEL_UNSUBSCRIBE Then
               pChannel.UserRemove(pAnnounce)
            ElseIf sAnnounce = ua.MSG_CHANNEL_SEND Then
               pChannel.AddTalk(True, Nothing, pAnnounce)
            End If

            ShowSystem()
         Else
            pAnnounce.MsgPrint("Unexpected channel message")
         End If
      ElseIf sAnnounce = ua.MSG_USER_ADD Then
         iUserID = pAnnounce.GetChildInt("userid")
         sUserName = pAnnounce.GetChildStr("username")

         pRequest = New CEDF
         pRequest.AddChild("userid", iUserID)
         pReply = New CEDF

         Client.request3(ua.MSG_USER_LIST, pRequest, pReply)

         UserAdd(pReply)

         sWrite = markup(sUserName) & " has been created"
      ElseIf sAnnounce = ua.MSG_USER_PAGE Then
         PageRecieve(iAnnounceTime, pAnnounce)
      ElseIf sAnnounce = ua.MSG_USER_LOGIN Then
         iUserID = pAnnounce.GetChildInt("userid")
         sUserName = pAnnounce.GetChildStr("username")
         sHostname = pAnnounce.GetChildStr("hostname")
         If sHostname Is Nothing Then
            sHostname = pAnnounce.GetChildStr("address")
         End If
         sLocation = pAnnounce.GetChildStr("location")
         sClient = pAnnounce.GetChildStr("client")
         If pAnnounce.IsChild("status") Then
            iStatus = pAnnounce.GetChildInt("status")
            If mask(iStatus, ua.LOGIN_SHADOW) = True Then
               sShadow = "(" & markup("H") & ")"
            End If
         Else
            iStatus = ua.LOGIN_ON
         End If
         sText = TextDecode(pAnnounce.GetChildStr("statusmsg"))

         UserLogin(iUserID, iStatus, sText)
         ShowWholist()
         ShowSystem()

         sWrite = markup(sUserName) & sShadow
         sWrite &= " has logged in"

         If Not sHostname Is Nothing Or Not sLocation Is Nothing Then
            sWrite &= " from "
            If Not sHostname Is Nothing Then
               sWrite &= markup(sHostname)
               If Not sLocation Is Nothing Then
                  sWrite &= "(" & markup(sLocation) & ")"
               End If
            Else
               sWrite &= markup(sLocation)
            End If
         End If
         If Not sClient Is Nothing Then
            sWrite &= " using " & markup(sClient)
         End If

         pLookup = New Lookup(Lookup.ANN_USER, iUserID, sWrite)
         pLookup.ImageIndex = ICO_USERS
      ElseIf sAnnounce = ua.MSG_USER_LOGOUT Then
         iUserID = pAnnounce.GetChildInt("userid")
         sUserName = pAnnounce.GetChildStr("username")
         iStatus = pAnnounce.GetChildInt("status")
         If mask(iStatus, ua.LOGIN_SHADOW) = True Then
            sShadow = "(" & markup("H") & ")"
         End If
         sText = TextDecode(pAnnounce.GetChildStr("text"))

         UserLogout(iUserID, iStatus, sText)
         ShowWholist()
         ShowSystem()

         sStatus1 = markup(sUserName) & sShadow & " has logged out"
         sStatus2 = "LOGOUT: " & markup(sUserName) & sShadow

         sWrite = UserEmote(sStatus1, sStatus2, sText, True, True)

         pLookup = New Lookup(Lookup.ANN_USER, iUserID, sWrite)
         pLookup.ImageIndex = ICO_USERS
      ElseIf sAnnounce = ua.MSG_USER_STATUS Then
         iUserID = pAnnounce.GetChildInt("userid")
         sUserName = pAnnounce.GetChildStr("username")
         iGender = pAnnounce.GetChildInt("gender")
         If pAnnounce.IsChild("status") = True Then
            iStatus = pAnnounce.GetChildInt("status")
         Else
            iStatus = -1
         End If
         sText = TextDecode(pAnnounce.GetChildStr("statusmsg"))
         iConnID = pAnnounce.GetChildInt("connectionid")

         UserStatus(iUserID, pAnnounce.IsChild("status"), iStatus, sText, iConnID)
         ShowWholist()
         ShowSystem()

         If iStatus <> -1 Then
            If mask(iStatus, ua.LOGIN_BUSY) = True Then
               sAction = markup("off")
               iImageIndex = ICO_BULB_OFF
            Else
               sAction = markup("on")
               iImageIndex = ICO_BULB_ON
            End If

            sStatus1 = markup(sUserName) & " has turned " & ua.gender(iGender) & " pager " & sAction
            sStatus2 = "Pager " & markup(sAction) & ": " & markup(sUserName)
         Else
            sStatus1 = markup(sUserName)
            sStatus2 = sStatus1
            iImageIndex = ICO_USERS
         End If

         sWrite = UserEmote(sStatus1, sStatus2, sText, True, True)

         pLookup = New Lookup(Lookup.ANN_USER, iUserID, sWrite)
         pLookup.ImageIndex = iImageIndex
      Else
         pAnnounce.MsgPrint("frmsUAve::announce " & sAnnounce, 0)
      End If

      If pLookup Is Nothing Then
         If bAnnounce = True And sWrite <> "" Then
            pLookup = New Lookup(sWrite)
            pLookup.ImageIndex = iImageIndex
         End If
      End If

      If Not pLookup Is Nothing Then
         announce(iAnnounceTime, pLookup)
      End If

      Return True
   End Function

   Private Sub announce(ByVal iTime As Integer, ByRef pLookup As Lookup)
      Dim bTemp As Boolean = m_bUserInput

      pLookup.m_sValue = StrTime(STRTIME_HM, iTime, True) & "  " & pLookup.m_sValue

      m_bUserInput = False

      If rlbAnnounces.Items.Count = 50 Then
         rlbAnnounces.Items.RemoveAt(0)
      End If

      rlbAnnounces.Items.Add(pLookup)
      rlbAnnounces.SelectedIndex = rlbAnnounces.Items.Count - 1

      m_bUserInput = bTemp
   End Sub

   Private Sub DoConnect(ByVal sDebugFile As String)
      If sDebugFile Is Nothing Then
         sDebugFile = "sUAve.txt"
      End If

      Client = Nothing

      Client = New sUAveClient(sDebugFile)

      stbsUAve.Text = "Connecting..."

      Me.Cursor = Cursors.WaitCursor
      Application.DoEvents()

      If Client.run(m_pConfig) = False Then
         If Not Client Is Nothing Then
            If m_bForceLogin = False Then
               MsgBox("Could not connect to " & m_sServer & ": " & Client.Error(), MsgBoxStyle.Critical)
            End If
         End If

         stbsUAve.Text = "Not connected"

         Me.Cursor = Cursors.Default
      End If
   End Sub

   Private Sub mnuFileOpen_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuFileOpen.Click
      Dim iPort As Integer, iAttachmentSize As Integer
      Dim bSettings As Boolean, bSecure As Boolean, bBusy As Boolean
      Dim sUsername As String, sPassword As String, sEDF As String
      Dim pSettings As RegistryKey
      Dim pLogin As frmLogin
      Dim pEDF As CEDF

      pSettings = GetRegSection()

      If pSettings.ValueCount > 0 Then
         m_sServer = pSettings.GetValue("server")
         iPort = pSettings.GetValue("port")
         bSecure = pSettings.GetValue("secure")
         sUsername = pSettings.GetValue("username")
         sPassword = pSettings.GetValue("password")
         m_bThinPipe = pSettings.GetValue("thinpipe")
         m_sDebugFile = pSettings.GetValue("debugfile")
         iAttachmentSize = pSettings.GetValue("attachmentsize")
         sEDF = pSettings.GetValue("edf")
      End If

      pLogin = New frmLogin

      pLogin.txtServer.Text = m_sServer
      pLogin.txtPort.Text = iPort
      If bSecure = True Then
         pLogin.chkSecure.Checked = True
      End If
      pLogin.txtUsername.Text = sUsername
      pLogin.txtPassword.Text = sPassword
      If m_bThinPipe = True Then
         pLogin.chkThinPipe.Checked = True
      End If
      pLogin.cmbAttachments.SelectedIndex = iAttachmentSize
      If sEDF <> "" Then
         pEDF = New CEDF
         pEDF.Read(sEDF)
         pLogin.txtEDF.Text = pEDF.Write(CEDF.EL_ROOT + CEDF.EL_CURR + CEDF.PR_SPACE + CEDF.PR_CRLF)
      End If

      If pLogin.ShowDialog() = DialogResult.OK Then
         'MsgBox("sUAve save settings" & pLogin.chkSaveSettings.Checked)

         m_sServer = pLogin.txtServer.Text
         iPort = pLogin.txtPort.Text
         If pLogin.chkSecure.Checked = True Then
            bSecure = True
         Else
            bSecure = False
         End If
         sUsername = pLogin.txtUsername.Text
         sPassword = pLogin.txtPassword.Text
         m_bThinPipe = pLogin.chkThinPipe.Checked
         bBusy = pLogin.chkBusy.Checked
         iAttachmentSize = pLogin.cmbAttachments.SelectedIndex
         sEDF = pLogin.txtEDF.Text

         pSettings.SetValue("server", m_sServer)
         pSettings.SetValue("port", iPort)
         pSettings.SetValue("secure", bSecure)
         pSettings.SetValue("username", sUsername)
         pSettings.SetValue("password", sPassword)
         pSettings.SetValue("thinpipe", m_bThinPipe)
         pSettings.SetValue("attachmentsize", iAttachmentSize)
         pSettings.SetValue("edf", sEDF)

         m_pConfig = New CEDF

         m_pConfig.AddChild("server", m_sServer)
         m_pConfig.AddChild("port", iPort)
         If bSecure = True Then
            m_pConfig.AddChild("secure", True)
         End If
         m_pConfig.AddChild("username", sUsername)
         m_pConfig.AddChild("password", sPassword)
         If bBusy = True Then
            m_pConfig.AddChild("busy", True)
         End If

         m_pConfig.AddChild("timeout", 0)

         m_pConfig.AddChild("clientbase", "sUAve")

         Select Case iAttachmentSize
            Case 1
               m_pConfig.AddChild("attachmentsize", 10000)

            Case 2
               m_pConfig.AddChild("attachmentsize", 100000)

            Case 3
               m_pConfig.AddChild("attachmentsize", 1000000)

            Case 4
               m_pConfig.AddChild("attachmentsize", -1)
         End Select

         pEDF = New CEDF
         pEDF.Read(sEDF)
         m_pConfig.Copy(pEDF, False, False, True)

         'm_pConfig.MsgPrint("sUAve config")

         DoConnect(m_sDebugFile)
      End If
   End Sub

   Private Sub rcbWholist_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rcbWholist.SelectedIndexChanged
      Dim bTemp As Boolean
      Dim pPage As frmPage
      Dim pUser As UserLookup

      If m_bUserInput = True Then
         pUser = rcbWholist.SelectedItem()
         If Not pUser Is Nothing Then
            pPage = PageFind(pUser)

            If Not pPage Is Nothing Then
               pPage.Focus()
            Else
               pPage = New frmPage(pUser, Nothing)
               pPage.Show()
            End If

            bTemp = m_bUserInput
            m_bUserInput = False
            rcbWholist.SelectedIndex = -1
            m_bUserInput = bTemp
         End If
      End If
   End Sub

   Private Sub MessageSelect(ByRef pNode As TreeNode)
      Dim pMessage As MessageLookup
      Dim pFolder As MessageTreeLookup

      pMessage = pNode.Tag
      If pMessage.m_iValue = 0 Then
         pMessage.m_iValue = 1
         tvwMessages.SelectedNode.NodeFont = New Font(tvwMessages.Font, FontStyle.Regular)

         If m_iViewType = VT_FOLDERUSER Then
            pFolder = rcbFolders.SelectedItem()
         Else
            pFolder = tvwFolders.SelectedNode().Tag
         End If

         ResetFolder(pFolder, pFolder.m_iValue - 1)

         ShowSystem()
      End If
   End Sub

   Private Sub tvwMessages_AfterSelect(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles tvwMessages.AfterSelect
      Dim iMessageID As Integer, iItemNum As Integer
      Dim bTemp As Boolean

      If m_bClearing = False Then
         If Not tvwMessages.SelectedNode Is Nothing Then
            If Not tvwMessages.SelectedNode.Tag Is Nothing Then
               If m_bUserInput = True Then
                  iMessageID = tvwMessages.SelectedNode.Tag.m_iID

                  If RefreshMessage(iMessageID) = True Then
                     MessageSelect(tvwMessages.SelectedNode)
                  End If
               Else
                  MessageSelect(tvwMessages.SelectedNode)
               End If
            Else
               MsgBox("Selected tag is nothing", MsgBoxStyle.Exclamation, "frmsUAve::tvwMessages")
            End If
         Else
            MsgBox("Select node is nothing", MsgBoxStyle.Exclamation, "frmsUAve::tvwMessages")
         End If
      End If
   End Sub

   Private Sub tmrsUAve_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmrsUAve.Tick
      Dim bLoop As Boolean

      If Not Client Is Nothing Then
         If m_bTimer = False Then
            m_bTimer = True

            bLoop = Client.loop()

            If Not Client Is Nothing Then
               If Client.State() = CClient.OPEN Then
                  ShowTimeOn(True)
               End If
            End If

            m_bTimer = False
         Else
            'debugline("frmsUAve::Not calling timer")
         End If
      Else
         MsgBox("Timer failed", MsgBoxStyle.Exclamation, "frmsUAve::tmrsUAve")

         tmrsUAve.Enabled = False
      End If
   End Sub

   Private Sub mnuViewFixed_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuViewFixed.Click
      mnuViewFixed.Checked = Not mnuViewFixed.Checked

      If mnuViewFixed.Checked = True Then
         mnuViewUnicode.Checked = False

         rtbContent.Font = FixedFont()
      Else
         rtbContent.Font = Me.Font
      End If
   End Sub

   Private Sub mnuViewUnicode_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuViewUnicode.Click
      mnuViewUnicode.Checked = Not mnuViewUnicode.Checked

      If mnuViewUnicode.Checked = True Then
         mnuViewFixed.Checked = False

         rtbContent.Font = UnicodeFont()
      Else
         rtbContent.Font = Me.Font
      End If
   End Sub

   Private Sub mnuFileExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuFileExit.Click
      End
   End Sub

   Private Sub mnuFileClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuFileClose.Click
      Dim pInput As frmInput

      pInput = New frmInput("Logout", frmInput.TXT_INPUT, "Message", ua.UA_SHORTMSG_LEN)

      If pInput.ShowDialog() = DialogResult.OK Then
         disconnect(False, pInput.GetValue())
      End If
   End Sub

   Private Function RefreshMessage(ByVal iMessageID As Integer) As Boolean
      Dim iCurrID As Integer, iAccessLevel As Integer, iFolderID As Integer, iSubType As Integer, iReplyID As Integer, iFromID As Integer, iToID As Integer, iMsgPos As Integer, iNumMsgs As Integer
      Dim iAttachmentID As Integer, iMsgType As Integer, iLater As Integer, iNumReplies As Integer, iVoteType As Integer
      Dim bReturn As Boolean, bTemp As Boolean, bLoop As Boolean, bShow As Boolean = True
      Dim sFromName As String, sToName As String, sSubject As String, sText As String, sFolderName As String, sWrite As String, sUserName As String, sType As String, sMessage As String
      Dim sContentType As String
      Dim iMessageDate As Integer, iDate As Integer
      Dim pRequest As CEDF, pReply As CEDF
      Dim pFolder As MessageTreeLookup
      Dim pNode As TreeNode
      Dim pGraphics As Graphics

      iCurrID = Client.GetID()
      iAccessLevel = Client.GetAccessLevel()

      debugline("frmsUAve::RefreshMessage entry " & iMessageID)

      pRequest = New CEDF
      pRequest.AddChild("messageid", iMessageID)

      pReply = New CEDF
      If Client.request3(ua.MSG_MESSAGE_LIST, pRequest, pReply) = True Then
         'pReply.MsgPrint("RefreshMessage " & iMessageID)

         iNumMsgs = pReply.GetChildInt("nummsgs")

         iFolderID = pReply.GetChildInt("folderid")
         pFolder = FolderGet(iFolderID)
         If Not pFolder Is Nothing Then
            iSubType = pFolder.m_iSubType
         End If

         If iFolderID <> m_iCurrFolder Then
            FolderJump(pFolder)
         End If

         pNode = MessageFind(0, iMessageID)
         If Not pNode Is Nothing Then
            bTemp = m_bUserInput
            m_bUserInput = False
            tvwMessages.SelectedNode = pNode
            m_bUserInput = bTemp
         End If

         If pReply.Child("message") = True Then
            iMsgType = pReply.GetChildInt("msgtype")
            iFromID = pReply.GetChildInt("fromid")
            iToID = pReply.GetChildInt("toid")
            If mask(iMsgType, ua.MSGTYPE_DELETED) = True Then
               If MsgBox("Show deleted message", MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2) = MsgBoxResult.No Then
                  bShow = False
               End If
            ElseIf mask(pFolder.m_iAccessMode, ua.ACCMODE_PRIVATE) = True And iFromID <> iCurrID And iToID <> iCurrID Then
               If MsgBox("Show private message", MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2) = MsgBoxResult.No Then
                  bShow = False
               End If
            End If

            If bShow = True Then
               m_iCurrMessage = iMessageID

               sMessage = "Message: " & markup(iMessageID)
               iMsgPos = pReply.GetChildInt("msgpos")
               iNumReplies = pReply.GetChildInt("numreplies")
               If iMsgPos > 0 Or iNumReplies > 0 Then
                  sMessage &= " ("
                  If Client.version("2.6") >= 0 Then
                     sMessage &= markup(iMsgPos & NumPos(iMsgPos)) & " of " & markup(iNumMsgs)
                     If iNumReplies > 0 Then
                        sMessage &= ", "
                     End If
                  End If
                  If iNumReplies > 0 Then
                     sMessage &= plural(iNumReplies, "reply", "replies", True)
                  End If
                  sMessage &= ")"
               End If

               m_pCurrMessage = New CEDF
               m_pCurrMessage.Copy(pReply, True, True, True)

               iMsgType = pReply.GetChildInt("msgtype")
               If mask(iMsgType, ua.MSGTYPE_VOTE) = True Then
                  pnlVotes.Visible = True
                  If pReply.Child("votes") = True Then
                     iVoteType = pReply.GetChildInt("votetype")
                     pReply.Parent()
                  End If

                  If (Client.GetAccessLevel >= ua.LEVEL_WITNESS Or pFolder.m_iSubType = ua.SUBTYPE_EDITOR) And mask(iVoteType, ua.VOTE_CLOSED) = False Then
                     tbbMsgVoteClose.Enabled = True
                  Else
                     tbbMsgVoteClose.Enabled = False
                  End If
               Else
                  pnlVotes.Visible = False
                  tbbMsgVoteClose.Enabled = False
               End If

               If iAccessLevel >= ua.LEVEL_WITNESS Or iSubType = ua.SUBTYPE_EDITOR Or iFromID = iCurrID Or iToID = iCurrID Then
                  tbbMsgAnnotate.Enabled = True
               Else
                  tbbMsgAnnotate.Enabled = False
               End If

               mnuViewRefresh.Visible = True
               mnuViewFixed.Visible = True
               If Not UnicodeFont() Is Nothing Then
                  mnuViewUnicode.Visible = True
               Else
                  mnuViewUnicode.Visible = False
               End If
               mnuViewRaw.Visible = True
               mnuKeysReply.Enabled = True

               tbbMsgReply.Enabled = True

               rlbHeader.Enabled = True

               lblReplyTo.Enabled = True
               rlbReplyTo.Enabled = True
               lblReplyBy.Enabled = True
               rlbReplyBy.Enabled = True

               iMessageDate = pReply.GetChildInt("date")

               sFromName = pReply.GetChildStr("fromname")
               sToName = pReply.GetChildStr("toname")
               sSubject = TextDecode(pReply.GetChildStr("subject"))

               rlbHeader.Items.Clear()
               rlbHeader.Items.Add(sMessage)
               rlbHeader.Items.Add("Date: " & StrTime(STRTIME_LONG, iMessageDate, True))
               rlbHeader.Items.Add("From: " & markup(sFromName))
               If Not sToName Is Nothing Then
                  rlbHeader.Items.Add("To: " & markup(sToName))
               End If
               If Not sSubject Is Nothing Then
                  rlbHeader.Items.Add("Subject: " & markup(sSubject))
               End If

               If mask(iMsgType, ua.MSGTYPE_VOTE) = True Then
                  ShowMessageVotes(pReply)
               End If

               bLoop = pReply.Child()
               Do While bLoop = True
                  sType = pReply.GetName()
                  If sType = "delete" Or sType = "edit" Or sType = "move" Then
                     iDate = pReply.GetInt()
                     sUserName = pReply.GetChildStr("username")
                     sFolderName = pReply.GetChildStr("foldername")

                     sWrite = ""
                     If sType = "delete" Then
                        sWrite = "Deleted"
                     ElseIf sType = "edit" Then
                        sWrite = "Edited"
                     ElseIf sType = "move" Then
                        sWrite = "Moved-From"
                     End If

                     sWrite &= ": "

                     If Not sFolderName Is Nothing Then
                        sWrite &= markup(sFolderName) & ", "
                     End If

                     sWrite &= " " & StrTime(STRTIME_SHORT, iDate, True)

                     If Not sUserName Is Nothing Then
                        sWrite &= " (by " & markup(sUserName) & ")"
                     End If

                     rlbHeader.Items.Add(sWrite)
                  End If

                  bLoop = pReply.Next()
                  If bLoop = False Then
                     pReply.Parent()
                  End If
               Loop

               ShowMessageReply(pReply, "replyto")
               ShowMessageReply(pReply, "replyby")

               sText = TextDecode(pReply.GetChildStr("text"))
               'MsgBox("Text '" & sText & "'")
               rtbContent.Enabled = True
               TextShow(rtbContent, sText, mnuViewUnicode.Checked, mnuViewFixed.Checked, True, mnuViewEmphasis.Checked)

               pnlAttachments.Visible = False
               rtbAttachments.Text = ""
               bLoop = pReply.Child("attachment")
               Do While bLoop = True
                  sFromName = pReply.GetChildStr("fromname")
                  iDate = pReply.GetChildInt("date")
                  sContentType = pReply.GetChildStr("content-type")
                  'debugline("frmsUAve::RefreshMessage " & iAttachmentID & "," & sContentType)
                  If sContentType = ua.MSGATT_ANNOTATION Then
                     sText = TextDecode(pReply.GetChildStr("text"))

                     iLater = iDate - iMessageDate

                     'sWrite = "Annotated-By: " & markup(sFromName)

                     If pnlAttachments.Visible = False Then
                        pnlAttachments.Visible = True
                     End If

                     Dim pFont As Font = New Font(rtbAttachments.Font, FontStyle.Bold)
                     Dim pOldFont As Font = rtbAttachments.Font

                     sWrite = "Annotated-By: " & sFromName & " "

                     Dim iTimeLength = 0
                     If iLater > 0 Then
                        Dim sTime As String = StrValue(STRVALUE_TIME, iLater, 1, False)
                        iTimeLength = sTime.Length
                        sWrite &= " (" & sTime & " after message posted)"
                     End If

                     If rtbAttachments.Text <> "" Then
                        rtbAttachments.AppendText(vbCrLf)
                     End If

                     Dim iNameStart = rtbAttachments.TextLength
                     Dim iTimeStart = iNameStart + 14 + sFromName.Length + 3

                     rtbAttachments.AppendText(sWrite & vbCrLf & sText)

                     rtbAttachments.SelectionStart = iNameStart + 14
                     rtbAttachments.SelectionLength = sFromName.Length
                     rtbAttachments.SelectionFont = pFont

                     rtbAttachments.SelectionStart = iTimeStart
                     rtbAttachments.SelectionLength = iTimeLength
                     rtbAttachments.SelectionFont = pFont
                  End If

                  bLoop = pReply.Next("attachment")
                  If bLoop = False Then
                     pReply.Parent()
                  End If
               Loop
            End If

            pReply.Parent()

            tvwMessages.Focus()

            bReturn = True
         End If
      End If

      debugline("frmsUAve::RefreshMessage exit " & bReturn)
      Return bReturn
   End Function

   Private Sub ShowMessageReply(ByRef pReply As CEDF, ByVal sName As String)
      Dim iReplyID As Integer, iFolderID As Integer
      Dim bTemp As Boolean, bLoop As Boolean
      Dim sFromName As String, sFolderName As String, sWrite As String
      Dim pLookup As Lookup

      bTemp = m_bClearing
      m_bClearing = True
      If sName = "replyto" Then
         rlbReplyTo.Items.Clear()
      Else
         rlbReplyBy.Items.Clear()
      End If
      m_bClearing = bTemp

      bLoop = pReply.Child(sName)
      Do While bLoop = True
         iReplyID = pReply.GetInt()
         iFolderID = pReply.GetChildInt("folderid")
         sFolderName = pReply.GetChildStr("foldername")
         'If sName = "replyby" Then
         sFromName = pReply.GetChildStr("fromname")
         'End If

         sWrite = markup(iReplyID)
         If pReply.IsChild("exist") = False Then
            sWrite &= " by " & markup(sFromName)
            If Not sFolderName Is Nothing Then
               sWrite = sWrite & " in " & markup(sFolderName)
            End If

            pLookup = New Lookup(0, iReplyID, sWrite)

            If sName = "replyto" Then
               rlbReplyTo.Items.Add(pLookup)
            Else
               rlbReplyBy.Items.Add(pLookup)
            End If
         End If

         bLoop = pReply.Next(sName)
         If bLoop = False Then
            pReply.Parent()
         End If
      Loop
   End Sub

   Private Function RefreshUnread() As Boolean
      Dim bLoop As Boolean = True, bReturn As Boolean, bTemp As Boolean
      Dim pNode As TreeNode
      Dim pFolder As MessageTreeLookup

      debugline("frmsUAve::RefreshUnread entry " & m_iCurrFolder & " " & m_iCurrMessage)

      pNode = MessageFind(1, m_iCurrMessage)

      If Not pNode Is Nothing Then
         tvwMessages.SelectedNode = pNode
         bReturn = True
      Else
         If m_iCurrFolder <> -1 Then
            pFolder = FolderNext(m_iCurrFolder)
            'debugline("frmsUAve::RefreshUnread folder num " & iFolderNum)
            If pFolder Is Nothing Then
               debugline("frmsUAve::RefreshUnread lookup pre-loop warning 1")
               pFolder = FolderNext(-1)
            End If

         Else
            pFolder = FolderNext(-1)
            If pFolder Is Nothing Then
               debugline("frmsUAve::RefreshUnread lookup pre-loop warning 2")
            End If
         End If

         If pFolder Is Nothing Then
            debugline("frmsUAve::RefreshUnread lookup pre-loop warning 3")
         End If

         Do While bLoop = True
            If pFolder.m_iSubType > 0 And pFolder.m_iValue > 0 Then
               FolderJump(pFolder)

               pNode = MessageFind(1, -1)
               If Not pNode Is Nothing Then
                  tvwMessages.SelectedNode = pNode
               Else
                  debugline("frmsUAve::RefreshUnread message not found")
               End If

               bLoop = False
               bReturn = True
            Else
               pFolder = FolderNext(pFolder.m_iID)
               If pFolder Is Nothing Then
                  If m_iCurrFolder <> -1 Then
                     pFolder = FolderNext(-1)
                     If pFolder Is Nothing Then
                        debugline("frmsUAve::RefreshUnread lookup in-loop warning")
                     End If
                  Else
                     bLoop = False
                  End If
               ElseIf pFolder.m_iID = m_iCurrFolder Then
                  bLoop = False
               End If
            End If
         Loop

         If bReturn = False Then
            If m_iViewType = VT_FOLDERUSER Then
               rcbFolders.SelectedIndex = -1
            Else
               tvwFolders.SelectedNode = Nothing
               RefreshMessages(Nothing, True)
            End If
         End If
      End If

      debugline("frmsUAve::RefreshUnread exit " & bReturn & ", " & m_iCurrFolder & " " & m_iCurrMessage)
      Return bReturn
   End Function

   Private Sub RefreshMessages(ByRef pFolder As MessageTreeLookup, ByVal bUseCache As Boolean)
      Dim iItemNum As Integer, iNumUnread As Integer, iDiff As Integer, iNumMsgs As Integer, iNumReads As Integer, iResult As Integer = MsgBoxResult.Yes, iUserID As Integer
      Dim bTemp As Boolean, bFound As Boolean
      Dim pRequest As CEDF, pReply As CEDF
      Dim pNode As TreeNode
      Dim pNodes As TreeNodeCollection
      Dim pEntry As DateTime
      Dim pTimeDiff As TimeSpan

      pEntry = Now()

      If Not pFolder Is Nothing Then
         debugline("frmsUAve::RefreshMessages " & pFolder.m_iID)

         If pFolder.m_iSubType = 0 Then
            iResult = MsgBox("You are not subscribed. Subscribe now?", MsgBoxStyle.Question + MsgBoxStyle.YesNoCancel)

            If iResult = MsgBoxResult.Yes Then
               If FolderSubscribe(pFolder.m_iID, ua.SUBTYPE_SUB) = False Then
                  iResult = MsgBoxResult.Cancel
               End If
            End If
         End If

         If iResult <> MsgBoxResult.Cancel Then
            'Me.Cursor = Cursors.WaitCursor

            If bUseCache = False Or pFolder.m_pTree Is Nothing Or pFolder.m_bDirty = True Then
               pRequest = New CEDF
               pRequest.AddChild("folderid", pFolder.m_iID)
               If mask(pFolder.m_iAccessMode, ua.ACCMODE_PRIVATE) = True Then
                  iUserID = Client.GetID()

                  If Client.version("2.7") >= 0 Then
                     pRequest.Add("or")
                  End If
                  pRequest.AddChild("toid", iUserID)
                  pRequest.AddChild("fromid", iUserID)
                  If (Client.version("2.7") >= 0) Then
                     pRequest.Parent()
                  End If
               End If
               pReply = New CEDF
               Client.request3(ua.MSG_MESSAGE_LIST, pRequest, pReply)

               pFolder.m_pTree = Nothing
               pFolder.m_bDirty = False

               pTimeDiff = Now().Subtract(pEntry)
               debugline("frmsUAve::RefreshMessages got message list in " & pTimeDiff.TotalMilliseconds & " ms")

               m_iCurrFolder = pReply.GetChildInt("folderid")

               iNumMsgs = pReply.Children("message", True)
               iNumReads = pReply.Children("read", True)
            Else
               m_iCurrFolder = pFolder.m_iID

               iNumMsgs = pFolder.m_iNumMsgs
               iNumReads = pFolder.m_iNumMsgs - pFolder.m_iValue
            End If

            iNumUnread = iNumMsgs - iNumReads
            If pFolder.m_iValue <> iNumUnread Then
               debugline("frmsUAve::RefreshMessages unread count for " & pFolder.m_sValue & " is unsynced (" & iNumMsgs & " - " & iNumReads & " = " & iNumUnread & " reply, " & pFolder.m_iValue & " lookup)")
               iDiff = iNumUnread - pFolder.m_iValue

               ResetFolder(pFolder, pFolder.m_iValue + iDiff)

               ShowSystem()
            End If
         End If
      Else
         'Me.Cursor = Cursors.WaitCursor

         m_iCurrFolder = -1
      End If

      If iResult <> MsgBoxResult.Cancel Then
         m_iCurrMessage = -1

         mnuViewRefresh.Visible = False
         mnuViewFixed.Visible = False
         mnuViewUnicode.Visible = False
         mnuViewRaw.Visible = False
         mnuKeysReply.Enabled = False

         tbbMsgReply.Enabled = False
         tbbMsgAnnotate.Enabled = False
         tbbMsgVoteClose.Enabled = False
         pnlVotes.Visible = False

         If m_iCurrFolder <> -1 Then
            mnuFolderRefreshMessages.Visible = True

            If pFolder.m_iSubType > 0 Then
               mnuFolderUnsubscribe.Visible = True
            Else
               mnuFolderUnsubscribe.Visible = False
            End If

            tbbMsgThread.Enabled = True
         Else
            mnuFolderRefreshMessages.Visible = False

            mnuFolderUnsubscribe.Visible = False

            tbbMsgThread.Enabled = False
         End If

         rlbReplyTo.Items.Clear()
         rlbReplyBy.Items.Clear()

         rlbHeader.Items.Clear()
         rtbContent.Text = ""

         pnlAttachments.Visible = False

         tvwMessages.Enabled = True

         m_bClearing = True
         tvwMessages.BeginUpdate()
         tvwMessages.Nodes.Clear()
         tvwMessages.EndUpdate()
         m_bClearing = False

         'Console.WriteLine("RefreshMessages post-clear " & tvwMessages.GetNodeCount(True) & " nodes")

         If m_iCurrFolder <> -1 Then
            tvwMessages.BeginUpdate()

            'If pReply.Children("message") > 0 Then
            If iNumMsgs > 0 Then
               tvwMessages.ContextMenu = mnuMsgThread
            Else
               tvwMessages.ContextMenu = Nothing
            End If

            If m_iCaching >= 1 And Not pFolder.m_pTree Is Nothing Then
               For Each pNode In pFolder.m_pTree.Nodes
                  'MsgBox("Adding " & pNode.Tag & " to tree view from old cache with " & pNode.GetNodeCount(False) & " children", , "RefreshMessages")
                  tvwMessages.Nodes.Add(pNode)
               Next

               'Console.WriteLine("RefreshMessages post-cache " & tvwMessages.GetNodeCount(True) & " nodes")
            Else
               If m_iCaching >= 1 Then
                  pFolder.m_pTree = New TreeNode
                  pNodes = pFolder.m_pTree.Nodes

                  'Console.WriteLine("RefreshMessages pre-show " & pFolder.m_pNodes.GetNodeCount(True) & " nodes")
               Else
                  pNodes = tvwMessages.Nodes

                  'Console.WriteLine("RefreshMessages post-show " & tvwMessages.GetNodeCount(True) & " nodes")
               End If

               ShowMessages(pReply, pNodes)
               'Console.WriteLine("RefreshMessages post-show " & tvwMessages.GetNodeCount(True) & " nodes")

               If m_iCaching >= 1 Then
                  For Each pNode In pNodes
                     tvwMessages.Nodes.Add(pNode)
                  Next
               End If
            End If

            ExpandMessages(tvwMessages.Nodes)

            tvwMessages.EndUpdate()
         End If

         'Me.Cursor = Cursors.Default

         pTimeDiff = Now().Subtract(pEntry)
         debugline("frmsUAve::RefreshMessages exit " & pTimeDiff.TotalMilliseconds & " ms")

         'Console.WriteLine("RefreshMessages post-exit " & tvwMessages.GetNodeCount(True) & " nodes")
      End If
   End Sub

   Private Function ExpandMessages(ByRef pNodes As TreeNodeCollection) As Boolean
      Dim pNode As TreeNode

      For Each pNode In pNodes
         ExpandMessages(pNode.Nodes)

         pNode.Expand()
      Next
   End Function

   Private Sub ShowFolder(ByVal pNode As TreeNode, ByVal pFolder As MessageTreeLookup)
      pNode.Tag = pFolder

      'If pFolder.m_iSubType = 0 Or pFolder.m_iValue = 0 Then
      'pNode.NodeFont = New Font(tvwFolders.Font, FontStyle.Regular)
      'Else
      'pNode.NodeFont = New Font(tvwFolders.Font, FontStyle.Bold)
      'End If

      pNode.Text = pFolder.m_sValue
      If pFolder.m_iSubType > 0 Then
         pNode.NodeFont = New Font(tvwFolders.Font, FontStyle.Bold)
         If pFolder.m_iValue > 0 Then
            pNode.Text &= ", " & pFolder.m_iValue & " unread"
         End If
      Else
         pNode.NodeFont = New Font(tvwFolders.Font, FontStyle.Regular)
      End If
   End Sub

   Private Sub ShowFolders(ByRef pReply As CEDF, ByRef pParent As TreeNode)
      Dim iFolderID As Integer
      Dim bLoop As Boolean
      Dim pAdd As TreeNode = Nothing
      Dim pFolder As MessageTreeLookup

      bLoop = pReply.Child("folder")
      Do While bLoop = True
         iFolderID = pReply.GetInt()

         pFolder = FolderGet(iFolderID)

         pAdd = New TreeNode
         ShowFolder(pAdd, pFolder)

         If Not pParent Is Nothing Then
            pParent.Nodes.Add(pAdd)
         Else
            tvwFolders.Nodes.Add(pAdd)
         End If

         ShowFolders(pReply, pAdd)

         If Not pAdd Is Nothing Then
            pAdd.Expand()
         End If

         bLoop = pReply.Next("folder")
         If bLoop = False Then
            pReply.Parent()
         End If
      Loop
   End Sub

   Public Sub RefreshFolders(Optional ByVal bRequest As Boolean = True)
      Dim iFolderNum As Integer
      Dim bTemp As Boolean
      Dim pNode As TreeNode
      Dim pRequest As CEDF, pReply As CEDF
      Dim pFolders(FolderCount()) As MessageTreeLookup

      Me.Cursor = Cursors.WaitCursor
      Application.DoEvents()

      If bRequest = True Then
         pRequest = New CEDF
         pRequest.AddChild("searchtype", 3)
         pReply = New CEDF
         Client.request3(ua.MSG_FOLDER_LIST, pRequest, pReply)

         pReply.Sort("folder", "name", True)

         'pReply.MsgPrint("frmsUAve::RefreshFolders")

         Folders(pReply)
      End If

      m_bClearing = True

      rcbFolders.BeginUpdate()
      rcbFolders.Items.Clear()
      rcbFolders.EndUpdate()
      tvwFolders.BeginUpdate()
      tvwFolders.Nodes.Clear()
      tvwFolders.EndUpdate()

      tvwMessages.BeginUpdate()
      tvwMessages.Nodes.Clear()
      tvwMessages.EndUpdate()

      m_bClearing = False

      m_iCurrFolder = -1
      m_iCurrMessage = -1

      bTemp = m_bUserInput
      m_bUserInput = False
      If m_iViewType = VT_FOLDERUSER Then
         pFolders = FoldersCopy()

         Array.Sort(pFolders)

         For iFolderNum = 0 To FolderCount() - 1
            rcbFolders.Items.Add(pFolders(iFolderNum))
         Next
      Else
         tvwFolders.BeginUpdate()
         ShowFolders(pReply, Nothing)
         tvwFolders.EndUpdate()
      End If
      m_bUserInput = bTemp

      Me.Cursor = Cursors.Default

      ShowSystem()
   End Sub

   Private Sub RefreshChannels()
      Dim iChannelNum As Integer
      Dim bLoop As Boolean
      Dim pRequest As CEDF, pReply As CEDF

      'Me.Cursor = Cursors.WaitCursor

      pRequest = New CEDF
      pRequest.AddChild("searchtype", 3)
      pReply = New CEDF
      Client.request3(ua.MSG_CHANNEL_LIST, pRequest, pReply)

      pReply.Sort("channel", "name", True)

      Channels(pReply)

      ShowSystem()

      'Me.Cursor = Cursors.Default
   End Sub

   Private Sub RefreshServices()
      Dim iServiceID As Integer
      Dim bTemp As Boolean, bLoop As Boolean, bRefresh As Boolean
      Dim sName As String, sPassword As String
      Dim pRequest As CEDF, pReply As CEDF
      Dim pService As ServiceLookup

      Me.Cursor = Cursors.WaitCursor

      pReply = New CEDF
      pRequest = New CEDF
      If Client.request3(ua.MSG_SERVICE_LIST, pRequest, pReply) = True Then
         Services(pReply)

         m_pConfig.Root()

         bLoop = m_pConfig.Child("service")
         Do While bLoop = True
            iServiceID = m_pConfig.GetInt()

            sName = m_pConfig.GetChildStr("name")
            sPassword = m_pConfig.GetChildStr("password")

            pRequest = New CEDF
            pRequest.AddChild("serviceid", iServiceID)
            pRequest.AddChild("active", True)
            pRequest.AddChild("name", sName)
            pRequest.AddChild("password", sPassword)

            pService = ServiceGet(iServiceID)

            pReply = New CEDF

            If pService.m_bActive = True Then
               If Client.request3(ua.MSG_SERVICE_UNSUBSCRIBE, pRequest, pReply) = True Then
                  ServiceDeactivate(pService)
                  bRefresh = True
               End If
            End If

            If Client.request3(ua.MSG_SERVICE_SUBSCRIBE, pRequest, pReply) = True Then
               bRefresh = True
            End If

            bLoop = m_pConfig.Next("service")
            If bLoop = False Then
               m_pConfig.Parent()
            End If
         Loop

         If bRefresh = True Then
            ShowWholist()
            ShowSystem()
         End If
      End If

      Me.Cursor = Cursors.Default
   End Sub

   Private Sub RefreshSystem()
      Dim iAccessLevel As Integer
      Dim sName As String

      sName = Client.GetName()
      iAccessLevel = Client.GetAccessLevel()

      ShowTimeOn(False)

      stbsUAve.Panels(1).Text = sName & " (" & ua.AccessName(iAccessLevel, 0) & ")"

      'ShowSystem()
   End Sub

   Private Sub ShowSystem()
      Dim iNumActive As Integer, iNumUnread As Integer, iNumTalking As Integer
      Dim sUsers As String, sUnread As String

      iNumActive = UserCountActive()
      iNumTalking = UserCountTalking()

      If iNumActive > 0 Then
         sUsers &= plural(iNumActive, "active", "active")
         If iNumTalking > 0 Then
            sUsers &= ", "
         End If
      End If
      If iNumTalking > 0 Then
         sUsers &= plural(iNumTalking, "talking", "talking")
      End If
      If Not sUsers Is Nothing Then
         If sUsers.Length > 0 Then
            sUsers = " (" & sUsers & ")"
         End If
      End If

      iNumUnread = FoldersUnread()
      If iNumUnread > 0 Then
         tbbMsgNextUnread.Enabled = True

         If m_bSysTray = True Or Me.Visible = False Then
            ShowTray(iNumUnread)
            mnuTrayClose.Visible = Me.Visible
            nfisUAve.Visible = True
         End If

         sUnread = " ( " & plural(iNumUnread, "unread message") & ")"
      Else
         tbbMsgNextUnread.Enabled = False

         If Me.Visible = False Then
            ShowTray(0)
         Else
            nfisUAve.Visible = False
         End If
      End If

      stbsUAve.Panels(2).Text = plural(UserCountLogins(), "login") & sUsers & ", " & plural(FolderCount(), "folder") & sUnread
   End Sub

   Private Sub ShowTimeOn(ByVal bCheck As Boolean)
      Dim iTimeDiff As Int64, iTimeOn As Int64, iStatus As Integer = ua.LOGIN_OFF
      Dim sTimeOn As String
      Dim pNow As DateTime
      Dim pTimeDiff As TimeSpan

      If bCheck = True Then
         pNow = Now()
         pTimeDiff = pNow.Subtract(m_pTimeOn)
         iTimeDiff = pTimeDiff.TotalMilliseconds
         'MsgBox("Time diff " & iTimeOn)
      End If

      If bCheck = False Or iTimeDiff > m_iTimeUpdate + 1000 Then
         'MsgBox("Time diff " & iTimeOn)

         iTimeOn = iTimeDiff / 1000

         sTimeOn = " +"
         sTimeOn &= Microsoft.VisualBasic.Right("00" & iTimeOn \ 3600, 2)
         sTimeOn &= ":" & Microsoft.VisualBasic.Right("00" & iTimeOn \ 60 Mod 60, 2)
         'sTimeOn &= ":" & Microsoft.VisualBasic.Right("00" & iTimeOn Mod 60, 2)
         'sTimeOn &= iTimeOn

         iStatus = Client.GetStatus()

         If mask(iStatus, ua.LOGIN_BUSY) = True Then
            sTimeOn &= " (busy)"
         End If

         stbsUAve.Panels(0).Text = sTimeOn

         m_iTimeUpdate = iTimeOn
      End If

      If iTimeDiff > m_iWholistUpdate + 10000 Then
         'RefreshWholist()

         m_iWholistUpdate = iTimeDiff
      End If
   End Sub

   Private Sub RefreshWholist()
      Dim bLoop As Boolean
      Dim pRequest As CEDF, pReply As CEDF
      Dim pUser As UserLookup

      debugline("frmsUAve::RefreshWholist")

      pRequest = New CEDF
      pRequest.AddChild("searchtype", 1)

      pReply = New CEDF
      Client.request2(ua.MSG_USER_LIST, pReply)

      pReply.Sort("user", "name")

      ShowWholist()
   End Sub

   Private Sub RefreshUsers()
      Dim pRequest As CEDF, pReply As CEDF

      Me.Cursor = Cursors.WaitCursor
      Application.DoEvents()

      pReply = New CEDF
      pRequest = New CEDF
      If m_bThinPipe = True Then
         pRequest.AddChild("lowest", ua.LEVEL_MESSAGES)
      End If
      Client.request3(ua.MSG_USER_LIST, pRequest, pReply)

      Users(pReply)

      ShowWholist()
      ShowSystem()

      Me.Cursor = Cursors.Default
      Application.DoEvents()
   End Sub

   Private Sub AddMessage(ByRef pFolder As MessageTreeLookup, ByRef pMessage As CEDF)
      Dim iMessageID As Integer, iFromID As Integer
      Dim sToName As String, sSubject As String
      Dim pRequest As CEDF, pReply As CEDF
      Dim pDialog As frmMessage
      Dim pReplyFolder As MessageTreeLookup

      If Not pMessage Is Nothing And Not pFolder Is Nothing Then
         If pFolder.m_iReplyID > 0 Then
            pReplyFolder = FolderGet(pFolder.m_iReplyID)
         Else
            pReplyFolder = pFolder
         End If
      Else
         pReplyFolder = pFolder
      End If

      pDialog = New frmMessage(pReplyFolder, pMessage)

      If pDialog.ShowDialog() = DialogResult.OK Then
         pRequest = pDialog.GetRequest()

         pReply = New CEDF
         If Client.request3(ua.MSG_MESSAGE_ADD, pRequest, pReply) = False Then
            pReply.MsgPrint("AddMessage failed")
         End If
      End If
   End Sub

   Private Function ShowMessages(ByRef pReply As CEDF, ByRef pParent As TreeNodeCollection) As Boolean
      Dim iMessageID As Integer, iRead As Integer, iMsgType As Integer
      Dim bLoop As Boolean, bReturn As Boolean
      Dim sRead As String, sFromName As String, sSubject As String, sString As String
      Dim pNode As TreeNode
      Dim pMessage As MessageLookup

      bLoop = pReply.Child("message")
      Do While bLoop = True

         iMessageID = pReply.GetInt()
         iMsgType = pReply.GetChildInt("msgtype")
         sFromName = pReply.GetChildStr("fromname")
         sSubject = TextDecode(pReply.GetChildStr("subject"))
         If pReply.GetChildBool("read") = True Then
            iRead = 1
         Else
            iRead = 0
            bReturn = True
         End If

         'debugline("frmsUAve::ShowMessages message " & iMessageID & " " & sSubject)

         pMessage = New MessageLookup(iMessageID, Nothing, sFromName, sSubject, iRead)

         sString = pMessage.ToString()

         pNode = New TreeNode(sString)
         If mask(iMsgType, ua.MSGTYPE_VOTE) = True Then
            pNode.ImageIndex = ICO_BALLOT
         End If
         pNode.Tag = pMessage
         If pMessage.m_iValue = 1 Then
            pNode.NodeFont = New Font(tvwMessages.Font, FontStyle.Regular)
         End If

         'MsgBox("Adding node " & pMessage.m_iID & " to parent with " & pNode.GetNodeCount(False) & " children", , "ShowMessages")
         pParent.Add(pNode)

         ShowMessages(pReply, pNode.Nodes)

         pNode.Expand()

         bLoop = pReply.Next("message")
         If bLoop = False Then
            pReply.Parent()
         End If
      Loop

      'Return bReturn
      Return True
   End Function

   Private Sub ResetFolder(ByRef pFolder As MessageTreeLookup, ByVal iNumUnread As Integer, Optional ByVal iNumMsgs As Integer = -1)
      Dim iFolderNum As Integer
      Dim bFound As Boolean, bTemp As Boolean
      Dim pNode As TreeNode, pFind As TreeNode

      'pFolder = FolderGet(iFolderID, iFolderNum)

      'MsgBox("Reducing unread count from " & pFolder.m_iValue)
      pFolder.m_iValue = iNumUnread

      If iNumMsgs <> -1 Then
         pFolder.m_iNumMsgs = iNumMsgs
      End If

      bTemp = m_bUserInput
      m_bUserInput = False
      If m_iViewType = VT_FOLDERUSER Then
         Do While bFound = False And iFolderNum < rcbFolders.Items.Count
            If rcbFolders.Items(iFolderNum).m_iID = pFolder.m_iID Then
               rcbFolders.Items(iFolderNum) = pFolder
               bFound = True
            Else
               iFolderNum += 1
            End If
         Loop
      Else
         pNode = FolderFind(pFolder.m_iID)
         ShowFolder(pNode, pFolder)
      End If
      m_bUserInput = bTemp
   End Sub

   Private Function MessageFind(ByVal iType As Integer, Optional ByVal iID As Integer = 0) As TreeNode
      Dim bID As Boolean

      Return NodeFind(tvwMessages.Nodes, tvwMessages.GetNodeCount(False), iType, iID)
   End Function

   Private Function FolderFind(ByVal iID As Integer) As TreeNode
      Return NodeFind(tvwFolders.Nodes, tvwFolders.GetNodeCount(False), 0, iID)
   End Function

   Private Function NodeFind(ByRef pNodes As TreeNodeCollection, ByVal iNumItems As Integer, ByVal iType As Integer, ByVal iID As Integer) As TreeNode
      Dim bID As Boolean

      Return NodeFind(pNodes, iNumItems, iType, iID, bID)
   End Function

   Private Function NodeFind(ByRef pNodes As TreeNodeCollection, ByVal iNumItems As Integer, ByVal iType As Integer, ByVal iID As Integer, ByRef bID As Boolean) As TreeNode
      Dim iItemNum As Integer
      Dim bFound As Boolean
      Dim pNode As TreeNode
      Dim pLookup As Lookup

      'debugline("NodeFind entry " & iType & " " & iid & ", " & iNumItems & " items")

      Do While bFound = False And iItemNum < iNumItems
         pNode = pNodes(iItemNum)
         pLookup = pNode.Tag

         'debugline("NodeFind lookup " & pLookup.m_iID & " " & pLookup.m_iValue)

         If iID > 0 And iID = pLookup.m_iID Then
            bID = True
         End If

         If iType = 0 And iID = pLookup.m_iID Then
            'Found message
            bFound = True
         ElseIf iType = 1 And pLookup.m_iValue = 0 And (iID = -1 Or bID = True) Then
            'Found unread message
            bFound = True
         Else
            If pNode.GetNodeCount(False) > 0 Then
               pNode = NodeFind(pNode.Nodes, pNode.GetNodeCount(False), iType, iID, bID)
            Else
               pNode = Nothing
            End If

            If Not pNode Is Nothing Then
               bFound = True
            Else
               iItemNum += 1
            End If
         End If
      Loop

      If bFound = False Then
         'debugline("NodeFind exit Nothing")
         Return Nothing
      End If

      'debugline("NodeFind exit {TreeNode}")
      Return pNode
   End Function

   Private Sub mnuToolsRequest_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuToolsRequest.Click
      Dim pRequest As frmRequest

      If frmRequest.getForm() Is Nothing Then
         pRequest = New frmRequest
         pRequest.Show()
      End If
   End Sub

   Private Sub mnuViewRaw_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuViewRaw.Click
      m_pCurrMessage.MsgPrint("Current Message")
   End Sub

   Private Sub rtbContent_LinkClicked(ByVal sender As Object, ByVal e As System.Windows.Forms.LinkClickedEventArgs) Handles rtbContent.LinkClicked
      'debugline("frmsUAve::rtbContent link " + e.LinkText)

      System.Diagnostics.Process.Start(GetBrowser(), e.LinkText)
   End Sub

   Private Sub rlbReplyTo_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rlbReplyTo.SelectedIndexChanged
      MessageGoto(rlbReplyTo.SelectedItem)
   End Sub

   Private Sub mnuToolsRefreshAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuToolsRefreshAll.Click
      RefreshAll()
   End Sub

   Private Sub mnuViewRefreshFolders_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuFolderRefreshFolders.Click
      RefreshFolders()
   End Sub

   Private Sub AddAnnotation()
      Dim pInput As frmInput
      Dim pValue() As Byte
      Dim pRequest As CEDF, pReply As CEDF

      pInput = New frmInput("Annotation", frmInput.TXT_INPUT, "Text", ua.UA_SHORTMSG_LEN)

      If pInput.ShowDialog() = DialogResult.OK Then
         pRequest = New CEDF
         pRequest.AddChild("messageid", m_iCurrMessage)
         pRequest.Add("attachment", "add")
         pRequest.AddChild("content-type", ua.MSGATT_ANNOTATION)
         AddTextField(pRequest, "text", pInput.GetValue())
         pRequest.Parent()

         pReply = New CEDF

         If Client.request3(ua.MSG_MESSAGE_EDIT, pRequest, pReply) = False Then
            pReply.MsgPrint("frmsUAve::AddAnnotation request failed")
         End If
      End If
   End Sub

   Private Sub tlbsUAve_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles tlbsUAve.ButtonClick
      Dim iVoteType As Integer
      Dim pRequest As CEDF, pReply As CEDF
      Dim pPage As frmPage

      If e.Button Is tbbOpen Then
         mnuFileOpen_Click(sender, e)
      ElseIf e.Button Is tbbClose Then
         mnuFileClose_Click(sender, e)
      ElseIf e.Button Is tbbPage Then
         pPage = New frmPage(Nothing, Nothing)
         pPage.Show()
      ElseIf e.Button Is tbbWholist Then
         WholistWindow()
      ElseIf e.Button Is tbbTalk Then
         TalkJoin()
      ElseIf e.Button Is tbbMsgAdd Then
         AddMessage(FolderGet(m_iCurrFolder), Nothing)
      ElseIf e.Button Is tbbMsgAnnotate Then
         AddAnnotation()
      ElseIf e.Button Is tbbMsgReply Then
         AddMessage(FolderGet(m_iCurrFolder), m_pCurrMessage)
      ElseIf e.Button Is tbbMsgNextUnread Then
         mnuFolderNextUnread_Click(sender, e)
      ElseIf e.Button Is tbbMsgThread Then
         Select Case Client.GetClientInt("caching")
            Case 0
               MessageThread(ua.MSG_MESSAGE_MARK_READ, ua.THREAD_MSGCHILD, -1, False)

            Case 1
               CatchupWholeThread()

         End Select
      ElseIf e.Button Is tbbMsgVoteClose Then
         If MsgBox("Really close poll?", MsgBoxStyle.Question + MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2) = MsgBoxResult.Yes Then
            If m_pCurrMessage.Child("votes") = True Then
               iVoteType = m_pCurrMessage.GetChildInt("votetype")
               m_pCurrMessage.Parent()
            End If
            iVoteType = iVoteType Or ua.VOTE_CLOSED

            pRequest = New CEDF
            pRequest.AddChild("messageid", m_iCurrMessage)
            pRequest.AddChild("votetype", iVoteType)

            If Client.request3(ua.MSG_MESSAGE_EDIT, pRequest, pReply) = False Then
               pReply.MsgPrint("frmsUAve::tlbsUAve")
            End If
         End If
      End If
   End Sub

   Private Sub rlbReplyBy_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rlbReplyBy.SelectedIndexChanged
      MessageGoto(rlbReplyBy.SelectedItem)
   End Sub

   Public Function MessageGoto(ByRef pLookup As Lookup) As Boolean
      Return RefreshMessage(pLookup.m_iID)
   End Function

   Private Sub mnuKeysAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuKeysAdd.Click
      AddMessage(FolderGet(m_iCurrFolder), Nothing)
   End Sub

   Private Sub mnuKeysReply_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuKeysReply.Click
      AddMessage(FolderGet(m_iCurrFolder), m_pCurrMessage)
   End Sub

   Private Sub mnuToolsPager_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuToolsPager.Click
      Dim iStatus As Integer
      Dim sPager As String
      Dim pInput As frmInput
      Dim pRequest As CEDF, pReply As CEDF

      iStatus = Client.GetStatus()

      If mask(iStatus, ua.LOGIN_BUSY) = True Then
         sPager = "On"
         iStatus -= ua.LOGIN_BUSY
      Else
         sPager = "Off"
         iStatus += ua.LOGIN_BUSY
      End If

      pInput = New frmInput("Pager " & sPager, frmInput.TXT_INPUT, "Message", ua.UA_SHORTMSG_LEN)

      If pInput.ShowDialog() = DialogResult.OK Then
         pRequest = New CEDF
         pRequest.Add("login")
         pRequest.AddChild("status", iStatus)
         If pInput.GetValue() <> "" Then
            AddTextField(pRequest, "statusmsg", pInput.GetValue())
         Else
            pRequest.AddChild("statusmsg")
         End If
         pRequest.Parent()

         'pRequest.MsgPrint("frmsUAve::mnuToolsPager")

         If Client.RefreshUser(pRequest) = True Then
            ShowTimeOn(False)
         End If
      End If
   End Sub

   Private Sub mnuToolsSystem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuToolsSystem.Click
      Dim pSystem As frmSystem
      Dim pReply As CEDF

      pReply = New CEDF

      Client.request2(ua.MSG_SYSTEM_LIST, pReply)

      pSystem = New frmSystem(pReply)
      pSystem.ShowDialog()
   End Sub

   Private Function MessageThread(ByVal sRequest As String, ByVal iType As Integer, Optional ByVal iID As Integer = -1, Optional ByVal bDialog As Boolean = True) As Boolean
      Dim iFolderNum As Integer, iMoveID As Integer, iCurrID As Integer
      Dim bCrossFolder As Boolean, bMarkKeep As Boolean
      Dim sType As String
      Dim pRequest As CEDF, pReply As CEDF
      Dim pNode As TreeNode
      Dim pLookup As Lookup
      Dim pMessage As MessageLookup
      Dim pFolder As MessageTreeLookup
      Dim pInput As frmInput

      debugline("frmsUAve::MessageThread " & sRequest & " " & iType & " " & iID & " " & bDialog)

      If sRequest = ua.MSG_MESSAGE_MOVE Then
         pInput = New frmInput("Message Move", frmInput.RCB_INPUT, "Folder", ua.UA_NAME_LEN)

         pInput.BeginAddItems()
         For iFolderNum = 0 To FolderCount() - 1
            pFolder = FolderList(iFolderNum)
            pLookup = New Lookup(0, pFolder.m_iID, pFolder.m_sValue)
            pInput.AddItem(pLookup)
         Next
         pInput.EndAddItems()

         If pInput.ShowDialog() <> DialogResult.OK Then
            Return False
         End If

         pLookup = pInput.GetItem()
         If pLookup Is Nothing Then
            Return False
         End If

         iMoveID = pLookup.m_iID
      ElseIf sRequest = ua.MSG_MESSAGE_DELETE Then
         If MsgBox("Really delete messages?", MsgBoxStyle.Question + MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2) = MsgBoxResult.No Then
            Return False
         End If
      ElseIf sRequest = ua.MSG_MESSAGE_MARK_READ Or sRequest = ua.MSG_MESSAGE_MARK_UNREAD Then
         If bDialog = True And Client.version("2.6") >= 0 And sRequest = ua.MSG_MESSAGE_MARK_READ And (iType = 1 Or iType = 2) Then
            If MsgBox("Stay caught up?", MsgBoxStyle.Question + MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2) = MsgBoxResult.Yes Then
               bMarkKeep = True
            End If
         End If
      End If

      'MsgBox(sRequest & " " & iMessageID & " / " & iType, , "frmsUAve::messageThread")

      If iID = -1 Then
         iID = m_iCurrMessage
         debugline("frmsUAve::MessageThread ID " & iID)
         iCurrID = m_iCurrMessage
      End If

      pRequest = New CEDF
      pReply = New CEDF

      If iType = 3 Then
         pRequest.AddChild("folderid", iID)
      Else
         pRequest.AddChild("messageid", iID)
         If iType > 0 Then
            If sRequest.IndexOf("mark") > 0 Then
               sType = "mark"
            ElseIf sRequest.IndexOf("delete") > 0 Then
               sType = "delete"
            ElseIf sRequest.IndexOf("move") > 0 Then
               sType = "move"
            End If

            pRequest.AddChild(sType & "type", iType)
         End If
      End If

      If iMoveID > 0 Then
         pRequest.AddChild("moveid", iMoveID)
      End If

      If bMarkKeep = True Then
         pRequest.AddChild("markkeep", bMarkKeep)
      End If

      'pRequest.MsgPrint("frmsUAve::messageThread request")

      Client.request3(sRequest, pRequest, pReply)

      'pReply.MsgPrint("frmsUAve::messageThread reply")

      RefreshMessages(FolderGet(m_iCurrFolder), False)

      If Not m_pMessageContext Is Nothing Then
         iCurrID = m_pMessageContext.m_iID
         debugline("frmsUAve::MessageThread context ID " & iCurrID)

         m_pMessageContext = Nothing
      End If

      If iCurrID <> -1 Then
         pNode = MessageFind(0, iCurrID)
         If Not pNode Is Nothing Then
            tvwMessages.SelectedNode = pNode
         Else
            debugline("frmsUAve::MessageThread cannot find " & iCurrID)
         End If
      End If
   End Function

   Private Sub mnuViewRefresh_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuViewRefresh.Click
      RefreshMessage(m_iCurrMessage)
   End Sub

   Private Sub mnuViewRefreshMessages_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuFolderRefreshMessages.Click
      Dim iMessageID As Integer

      iMessageID = m_iCurrMessage

      RefreshMessages(FolderGet(m_iCurrFolder), False)

      If m_iCurrMessage <> -1 Then
         RefreshMessage(iMessageID)
      End If
   End Sub

   Private Sub mnuFolderNextUnread_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuFolderNextUnread.Click
      RefreshUnread()
   End Sub

   Private Sub mnuToolsWholist_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuToolsWholist.Click
      WholistWindow()
   End Sub

   Protected Overrides Sub Finalize()
      MyBase.Finalize()
   End Sub

   Private Sub mnuMsgCatchMsgChild_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuMsgCatchMsgChild.Click
      MessageThread(ua.MSG_MESSAGE_MARK_READ, ua.THREAD_MSGCHILD)
   End Sub

   Private Sub mnuMsgCatchChild_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuMsgCatchChild.Click
      MessageThread(ua.MSG_MESSAGE_MARK_READ, ua.THREAD_CHILD)
   End Sub

   Private Sub mnuMsgCatchWhole_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuMsgCatchWhole.Click
      CatchupWholeThread()
   End Sub

   Private Sub mnuMsgcatchAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuMsgCatchAll.Click
      If Not tvwMessages.SelectedNode Is Nothing Then
         m_pMessageContext = tvwMessages.SelectedNode.Tag
      End If

      MessageThread(ua.MSG_MESSAGE_MARK_READ, 3, m_iCurrFolder)
   End Sub

   Private Sub mnuToolsOptions_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuToolsOptions.Click
      Dim pRequest As CEDF, pTemp As CEDF
      Dim pOptions As frmOptions

      pOptions = New frmOptions

      If pOptions.ShowDialog() = DialogResult.OK Then
         pTemp = pOptions.GetRequest()

         If Not pTemp Is Nothing Then
            If pTemp.Children() > 0 Then
               'ptemp.MsgPrint("frmsUAve::mnuToolsOptions request")

               pRequest = New CEDF
               pRequest.Add("client", "edit")
               pRequest.Copy(pTemp, False, False, True)

               'pRequest.MsgPrint("frmsUAve::mnuToolsOptions temp request")

               Client.RefreshUser(pRequest)

               RefreshSettings()
            End If
         End If
      End If
   End Sub

   Private Sub rlbAnnounces_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rlbAnnounces.SelectedIndexChanged
      Dim bLoop As Boolean
      Dim pLookup As Lookup
      Dim pUser As UserLookup
      Dim pService As ServiceLookup
      Dim pPage As frmPage

      If m_bClearing = False And m_bUserInput = True Then
         pLookup = rlbAnnounces.SelectedItem()

         If pLookup.m_iType = Lookup.ANN_MESSAGE Then
            MessageGoto(pLookup)
         ElseIf pLookup.m_iType = Lookup.ANN_USER Then
            pUser = UserGet(pLookup.m_iID)

            pPage = PageFind(pUser)

            If Not pPage Is Nothing Then
               pPage.Focus()
            Else
               pPage = New frmPage(pUser, Nothing)
               pPage.Show()
            End If
         Else
            debugline("rlbAnnounces type " & pLookup.m_iType)
         End If
      End If
   End Sub

   Private Sub RefreshSettings()
      Dim iViewType As Integer

      iViewType = m_iViewType

      m_iViewType = Client.GetClientInt("viewtype", VT_FOLDERUSER)
      m_iExpansion = Client.GetClientInt("expansion")
      m_iCaching = Client.GetClientInt("caching")

      m_bSysTray = Client.GetClientBool("systray")
      m_bHide = Client.GetClientBool("hide")

      If m_iViewType <> iViewType Then
         If m_iViewType = VT_NONE Then
            pnlTop.Controls.Remove(pnlSelect)
         Else
            pnlTop.Controls.Add(pnlSelect)

            Do While pnlSelect.Controls.Count > 0
               pnlSelect.Controls.RemoveAt(0)
            Loop

            Do While pnlMessages.Controls.Count > 0
               pnlMessages.Controls.RemoveAt(0)
            Loop

            If m_iViewType = VT_FOLDERUSER Then
               Me.rcbWholist.Dock = DockStyle.Left
               Me.pnlSelect.Controls.AddRange(New System.Windows.Forms.Control() {Me.splSelect, Me.rcbFolders, Me.rcbWholist})

               Me.pnlMessages.Controls.Add(Me.tvwMessages)
            Else
               Me.rcbWholist.Dock = DockStyle.Fill
               Me.pnlSelect.Controls.Add(Me.rcbWholist)

               Me.pnlMessages.Controls.AddRange(New System.Windows.Forms.Control() {Me.tvwMessages, Me.splFolders, Me.pnlFolders})
            End If

            RefreshFolders()
            If Client.version("2.6") >= 0 Then
               RefreshChannels()
               Application.DoEvents()

               RefreshServices()
               Application.DoEvents()
            End If
         End If
      Else
         'MsgBox("Not refreshing folders")
      End If
   End Sub

   Private Sub tvwFolders_AfterSelect(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles tvwFolders.AfterSelect
      Dim pFolder As MessageTreeLookup

      If m_bClearing = False And m_bUserInput = True Then
         pFolder = tvwFolders.SelectedNode.Tag
         RefreshMessages(pFolder, True)
      End If
   End Sub

   Private Sub rcbFolders_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rcbFolders.SelectedIndexChanged
      If m_bClearing = False And m_bUserInput = True Then
         RefreshMessages(rcbFolders.SelectedItem, True)
      End If
   End Sub

   Private Sub mnuToolsLocations_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuAdminLocations.Click
      Dim pReply As CEDF
      Dim pLocations As frmLocations

      If frmLocations.getForm() Is Nothing Then
         pReply = New CEDF
         Client.request2(ua.MSG_LOCATION_LIST, pReply)

         pLocations = New frmLocations(pReply)
         pLocations.Show()
      End If
   End Sub

   Private Sub tvwMessages_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles tvwMessages.MouseDown
      Dim pNode As TreeNode

      pNode = tvwMessages.GetNodeAt(e.X, e.Y)
      If Not pNode Is Nothing Then
         m_pMessageContext = pNode.Tag

         debugline("frmsUAve::tvwMessages context message " & m_pMessageContext.m_iID)
      Else
         debugline("frmsUAve::tvwMessages no context node")
      End If
   End Sub

   Private Sub mnuMsgHoldMsg_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuMsgHoldMsg.Click
      MessageThread(ua.MSG_MESSAGE_MARK_UNREAD, 0)
   End Sub

   Private Sub mnuMsgHoldMsgChild_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuMsgHoldMsgChild.Click
      MessageThread(ua.MSG_MESSAGE_MARK_UNREAD, ua.THREAD_MSGCHILD)
   End Sub

   Private Sub mnuMsgHoldChild_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuMsgHoldChild.Click
      MessageThread(ua.MSG_MESSAGE_MARK_UNREAD, ua.THREAD_CHILD)
   End Sub

   Private Sub mnuMsgHoldWhole_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuMsgHoldWhole.Click
      Dim iMessageID As Integer = -1

      If Not m_pCurrMessage Is Nothing Then
         'm_pCurrMessage.MsgPrint("frmsUAve::mnuMsgCatchWhole")

         m_pCurrMessage.Root()

         'm_pCurrMessage.Child("message")

         If m_pCurrMessage.Children("replyto") > 0 Then
            iMessageID = m_pCurrMessage.GetChildInt("replyto", CEDF.LAST)
         End If

         'm_pcurrmessage.Parent()

         m_pMessageContext = tvwMessages.SelectedNode.Tag

         MessageThread(ua.MSG_MESSAGE_MARK_READ, ua.THREAD_MSGCHILD, iMessageID)
      End If
   End Sub

   Private Sub mnuMsgHoldAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuMsgHoldAll.Click
      If Not tvwMessages.SelectedNode Is Nothing Then
         m_pMessageContext = tvwMessages.SelectedNode.Tag
      End If

      MessageThread(ua.MSG_MESSAGE_MARK_UNREAD, 3, m_iCurrFolder)
   End Sub

   Private Sub mnuMsgMoveMsg_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuMsgMoveMsg.Click
      MessageThread(ua.MSG_MESSAGE_MOVE, 0)
   End Sub

   Private Sub mnuMsgMoveMsgChild_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuMsgMoveMsgChild.Click
      MessageThread(ua.MSG_MESSAGE_MOVE, ua.THREAD_MSGCHILD)
   End Sub

   Private Sub mnuMsgMoveChild_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuMsgMoveChild.Click
      MessageThread(ua.MSG_MESSAGE_MOVE, ua.THREAD_CHILD)
   End Sub

   Private Sub mnuMsgMoveWhole_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuMsgMoveWhole.Click
      Dim iMessageID As Integer = -1

      If Not m_pCurrMessage Is Nothing Then
         'm_pCurrMessage.MsgPrint("frmsUAve::mnuMsgCatchWhole")

         m_pCurrMessage.Root()

         'm_pCurrMessage.Child("message")

         If m_pCurrMessage.Children("replyto") > 0 Then
            iMessageID = m_pCurrMessage.GetChildInt("replyto", CEDF.LAST)
         End If

         'm_pcurrmessage.Parent()

         m_pMessageContext = tvwMessages.SelectedNode.Tag

         MessageThread(ua.MSG_MESSAGE_MOVE, ua.THREAD_MSGCHILD, iMessageID)
      End If
   End Sub

   Private Sub mnuMsgDelMsg_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuMsgDelMsg.Click
      MessageThread(ua.MSG_MESSAGE_DELETE, 0)
   End Sub

   Private Sub mnuMsgDelMsgChild_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuMsgDelMsgChild.Click
      MessageThread(ua.MSG_MESSAGE_DELETE, ua.THREAD_MSGCHILD)
   End Sub

   Private Sub mnuMsgDelChild_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuMsgDelChild.Click
      MessageThread(ua.MSG_MESSAGE_DELETE, ua.THREAD_CHILD)
   End Sub

   Private Sub mnuMsgDelWhole_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuMsgDelWhole.Click
      Dim iMessageID As Integer = -1

      If Not m_pCurrMessage Is Nothing Then
         'm_pCurrMessage.MsgPrint("frmsUAve::mnuMsgCatchWhole")

         m_pCurrMessage.Root()

         'm_pCurrMessage.Child("message")

         If m_pCurrMessage.Children("replyto") > 0 Then
            iMessageID = m_pCurrMessage.GetChildInt("replyto", CEDF.LAST)
         End If

         'm_pcurrmessage.Parent()

         m_pMessageContext = tvwMessages.SelectedNode.Tag

         MessageThread(ua.MSG_MESSAGE_DELETE, ua.THREAD_MSGCHILD, iMessageID)
      End If
   End Sub

   Private Sub nfisUAve_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles nfisUAve.DoubleClick
      If Me.Visible = False Then
         RestoreWindow()
      Else
         RefreshUnread()
      End If
   End Sub

   Private Function MessageInFolder(ByRef pEDF As CEDF, ByVal iMessageID As Integer) As Boolean
      Dim bLoop As Boolean, bReturn As Boolean
      Dim iMessageEDF As Integer

      pEDF.Root()

      bLoop = pEDF.Child("message")
      Do While bLoop = True
         iMessageEDF = pEDF.GetInt()
         If iMessageEDF = iMessageID Then
            bReturn = True
            bLoop = False
         Else
            bLoop = pEDF.Iterate("message")
         End If
      Loop

      Return bReturn
   End Function

   Private Sub mnuFolderUnsubscribe_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuFolderUnsubscribe.Click
      If MsgBox("Really unsubscribe?", MsgBoxStyle.Question + MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2) = MsgBoxResult.Yes Then
         FolderSubscribe(m_iCurrFolder, 0)

         RefreshMessages(Nothing, True)
      End If
   End Sub

   Private Sub mnuFolderJump_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuFolderJump.Click
      Dim iID As Integer
      Dim bTemp As Boolean
      Dim sValue As String
      Dim pInput As frmInput
      Dim pLookup As Lookup
      Dim pFolder As MessageTreeLookup
      Dim pNode As TreeNode

      pInput = New frmInput("Jump", frmInput.TXT_INPUT, "Name / ID")
      If pInput.ShowDialog() = DialogResult.OK And pInput.GetValue() <> "" Then
         sValue = pInput.GetValue()
         If Char.IsLetter(sValue.Substring(0, 1)) = True Then
            pFolder = FolderGet(sValue)

            If Not pFolder Is Nothing Then
               m_iCurrMessage = -1
               m_pCurrMessage = Nothing

               FolderJump(pFolder)
            Else
               MsgBox("No such folder", MsgBoxStyle.Exclamation)
            End If
         Else
            iID = sValue

            pFolder = FolderGet(iID)
            If Not pFolder Is Nothing Then
               FolderJump(pFolder)
            Else
               pLookup = New Lookup(0, iID, Nothing)
               If MessageGoto(pLookup) = False Then
                  MsgBox("No such message", MsgBoxStyle.Exclamation)
               End If
            End If
         End If
      End If
   End Sub

   Private Sub frmsUAve_SizeChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.SizeChanged
      Dim iNumUnread As Integer, iNumItems As Integer
      Dim pSettings As RegistryKey

      'MsgBox("frmsUAve::SizeChanged " & Me.WindowState)

      If m_bHide = True And Me.WindowState <> m_iWindowState Then
         'MsgBox("Now i is " & Me.WindowState)

         If Me.WindowState = FormWindowState.Minimized Then
            iNumUnread = FoldersUnread()

            'MsgBox("frmsUAve::SizeChanged hiding")
            Me.Visible = False

            mnuTrayShow.Visible = True
            mnuTraySep1.Visible = True

            ShowTray(iNumUnread)
            mnuTrayClose.Visible = Me.Visible
            nfisUAve.Visible = True
         Else
            'MsgBox("frmsUAve::SizeChanged showing")
            Me.Visible = True

            mnuTrayShow.Visible = False
            mnuTraySep1.Visible = False

            nfisUAve.Text = Nothing
            nfisUAve.Visible = False

            pSettings = GetRegSection()
            pSettings.SetValue("mainwindow", Me.Left & "," & Me.Top & "," & Me.ClientSize.Width & "," & Me.ClientSize.Height)
            iNumItems = rlbAnnounces.Height \ rlbAnnounces.ItemHeight
            pSettings.SetValue("announceitems", iNumItems)
         End If

         m_iWindowState = Me.WindowState
      End If
   End Sub

   Private Sub mnuTrayClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuTrayClose.Click
      mnuFileClose_Click(sender, e)
   End Sub

   Private Sub mnuTrayExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuTrayExit.Click
      nfisUAve.Visible = False

      End
   End Sub

   Private Sub mnuTrayShow_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuTrayShow.Click
      RestoreWindow()
   End Sub

   Private Sub RestoreWindow()
      nfisUAve.Visible = True

      Me.Visible = True
      mnuTrayClose.Visible = True

      Me.WindowState = FormWindowState.Normal

      Me.Focus()
   End Sub

   Private Sub TalkJoin()
      Dim iChannelNum As Integer
      Dim pInput As frmInput, pTalk As frmTalk
      Dim pChannel As MessageTreeLookup

      pInput = New frmInput("Talk Channel", frmInput.RCB_INPUT, "Channel", ua.UA_NAME_LEN)

      pInput.BeginAddItems()
      For iChannelNum = 0 To ChannelCount() - 1
         pChannel = ChannelList(iChannelNum)
         pInput.AddItem(pChannel)
      Next
      pInput.EndAddItems()

      If pInput.ShowDialog() = DialogResult.OK Then
         pChannel = pInput.GetItem()

         If Not pChannel Is Nothing Then
            pTalk = ChannelFind(pChannel.m_iID)
            If Not pTalk Is Nothing Then
               pTalk.Focus()
            Else
               If ChannelSubscribe(pChannel.m_iID, ua.SUBTYPE_SUB) = True Then
                  pTalk = New frmTalk(pChannel)
                  pTalk.Show()
               End If
            End If
         Else
            MsgBox("Nothing selected", "frmsUAve::TalkJoin")
         End If
      End If
   End Sub

   Private Sub rcbFolders_Resize(ByVal sender As Object, ByVal e As System.EventArgs) 'Handles rcbFolders.Resize
      pnlSelect.Refresh()

      If rcbFolders.Width > 0 Then
         rcbFolders.DropDownWidth = rcbFolders.Width
      End If
   End Sub

   Private Sub rcbWholist_Resize(ByVal sender As Object, ByVal e As System.EventArgs) 'Handles rcbWholist.Resize
      If rcbWholist.Width > 0 Then
         rcbWholist.DropDownWidth = rcbWholist.Width
      End If
   End Sub

   Private Sub ShowTray(ByVal iNumUnread As Integer)
      'MsgBox("" & iNumUnread & " messages", , "frmsUAve::ShowTray")

      If iNumUnread > 0 Then
         nfisUAve.Text = CLIENT_NAME & " - " & plural(iNumUnread, "unread message")
         'nfisUAve.Icon = sUAveHelper.m_pImageList.Images(ICO_SUAVE)
      Else
         nfisUAve.Text = CLIENT_NAME
         'nfisUAve.Icon = sUAveHelper.m_pImageList.Images(ICO_SUAVE2)
      End If
   End Sub

   Private Sub mnuTrayPage_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuTrayPage.Click
      Dim pPage As frmPage

      pPage = New frmPage(Nothing, Nothing)
      pPage.Show()
   End Sub

   Private Sub mnuToolsUsers_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuToolsUsers.Click
      Dim pUsers As frmUsers

      If frmUsers.getForm() Is Nothing Then
         pUsers = New frmUsers
         pUsers.Show()
      End If
   End Sub

   Private Sub WholistWindow()
      Dim pRequest As CEDF, pReply As CEDF
      Dim pWholist As frmWholist

      If frmWholist.getForm() Is Nothing Then
         Me.Cursor = Cursors.WaitCursor
         Application.DoEvents()

         pRequest = New CEDF
         pRequest.AddChild("searchtype", 1)

         pReply = New CEDF

         Client.request3(ua.MSG_USER_LIST, pRequest, pReply)

         pWholist = New frmWholist(pReply)
         pWholist.Show()

         Me.Cursor = Cursors.Default
         Application.DoEvents()
      End If
   End Sub

   Private Sub mnuAdminBanner_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuAdminBanner.Click
      Dim pText As frmText
      Dim pRequest As CEDF, pReply As CEDF

      pText = New frmText("Banner")
      If pText.ShowDialog() = DialogResult.OK Then
         pRequest = New CEDF
         pRequest.AddChild("banner", pText.txtText.Text)

         pReply = New CEDF

         Client.request3(ua.MSG_SYSTEM_EDIT, pRequest, pReply)
      End If
   End Sub

   Private Sub mnuAdminReload_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuAdminReload.Click
      Dim pInput As frmInput

      pInput = New frmInput("Reload Confirmation", frmInput.TXT_INPUT, Nothing)
      If pInput.ShowDialog() = DialogResult.OK And pInput.GetValue() = "YES" Then
         Client.edf("reload")
      End If
   End Sub

   Private Sub mnuAdminSysMsg_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuAdminSysMsg.Click
      Dim pValue() As Byte
      Dim pText As frmText
      Dim pRequest As CEDF, pReply As CEDF

      pText = New frmText("System Message")
      If pText.ShowDialog() = DialogResult.OK Then
         pRequest = New CEDF
         AddTextField(pRequest, "text", pText.txtText.Text)

         pReply = New CEDF

         Client.request3(ua.MSG_SYSTEM_MESSAGE, pRequest, pReply)
      End If
   End Sub

   Private Function PageRecieve(ByVal iAnnounceTime As Integer, ByRef pEDF As CEDF) As Boolean
      Dim bReturn As Boolean, bService As Boolean
      Dim iFromID As Integer, iServiceID As Integer, iStatus As Integer = -1, iGender As Integer, iImageIndex As Integer = ICO_USERS
      Dim sFromName As String, sService As String, sTitle As String, sServiceAction As String, sUsername As String
      Dim sStatusMsg As String, sStatus1 As String, sStatus2 As String, sAction As String
      Dim sWrite As String, sSubject As String
      Dim pPage As frmPage
      Dim pUser As UserLookup
      Dim pLookup As Lookup, pService As Lookup

      iServiceID = pEDF.GetChildInt("serviceid")
      sService = pEDF.GetChildStr("servicename")

      If pEDF.Child("serviceaction") = True Then
         sServiceAction = pEDF.GetStr()

         If Not sServiceAction Is Nothing Then
            pService = ServiceGet(iServiceID)

            If Not pService Is Nothing Then
               If sServiceAction = ua.ACTION_LOGIN Then
                  sWrite = "Service " & markup(sService) & " active"

                  ServiceActivate(pService, pEDF)
               ElseIf sServiceAction = ua.ACTION_LOGOUT Then
                  sWrite = "Service " & markup(sService) & " inactive"

                  ServiceDeactivate(pService)
               ElseIf sServiceAction = ua.ACTION_LIST Or sServiceAction = ua.ACTION_CONTACT_LOGIN Or sServiceAction = ua.ACTION_CONTACT_LOGOUT Or sServiceAction = ua.ACTION_CONTACT_STATUS Then
                  If sServiceAction = ua.ACTION_LIST Then
                     ServiceStatus(pService, -2, pEDF)
                  ElseIf sServiceAction = ua.ACTION_CONTACT_LOGIN Then
                     ServiceStatus(pService, ua.LOGIN_ON, pEDF)

                     sUsername = pEDF.GetChildStr("username")
                     sWrite = markup(sUsername) & " (" & markup(sService) & ") has logged in"
                  ElseIf sServiceAction = ua.ACTION_CONTACT_LOGOUT Then
                     ServiceStatus(pService, ua.LOGIN_OFF, pEDF)

                     sUsername = pEDF.GetChildStr("username")
                     sWrite = markup(sUsername) & " (" & markup(sService) & ") has logged out"
                  ElseIf sServiceAction = ua.ACTION_CONTACT_STATUS Then
                     ServiceStatus(pService, -1, pEDF)

                     If pEDF.IsChild("status") = True Then
                        iStatus = pEDF.GetChildInt("status")
                     End If
                     If mask(iStatus, ua.LOGIN_IDLE) = False Then
                        sUsername = pEDF.GetChildStr("username")
                        sStatusMsg = TextDecode(pEDF.GetChildStr("statusmsg"))
                        If iStatus <> -1 Then
                           If mask(iStatus, ua.LOGIN_BUSY) = True Then
                              sAction = "Busy"
                              iImageIndex = ICO_BULB_OFF
                           Else
                              sAction = "Active"
                              iImageIndex = ICO_BULB_ON
                           End If

                           sStatus1 = markup(sUsername) & " (" & markup(sService) & ") is " & markup(sAction.ToLower)
                           sStatus2 = markup(sAction) & ": " & markup(sUsername) & " (" & markup(sService) & ")"
                        Else
                           sStatus1 = markup(sUsername)
                           sStatus2 = sStatus1
                        End If

                        sWrite = UserEmote(sStatus1, sStatus2, sStatusMsg, True, True)
                     End If
                  End If

                  If sWrite <> "" Then
                     pLookup = New Lookup(Lookup.ANN_SERVICE, iServiceID, sWrite)
                     pLookup.ImageIndex = iImageIndex

                     sWrite = ""
                  End If
               Else
                  pEDF.MsgPrint("frmsUAve::PageRecieve unknown action " & sServiceAction, CEDF.EL_CURR)
               End If

               ShowWholist()
            Else
               sWrite &= "action " & markup(sServiceAction)
            End If
         Else
            debugline("frmsUAve::PageRecieve no section for service " & sService)
         End If

         'pEDF.MsgPrint("frmsUAve::PageRecieve", CEDF.EL_CURR)

         pEDF.Parent()
      End If

      If sWrite <> "" Then
         pLookup = New Lookup(sWrite)
         pLookup.ImageIndex = ICO_USERS
      End If
      If Not pLookup Is Nothing Then
         announce(iAnnounceTime, pLookup)
      End If

      If pEDF.IsChild("text") = True Or pEDF.IsChild("attachment") = True Then
         pPage = PageFind(Nothing, pEDF)

         If Not pPage Is Nothing Then
            pPage.AddPage(True, Nothing, Nothing, pEDF)

            bReturn = True
         Else
            iFromID = pEDF.GetChildInt("fromid")
            sFromName = pEDF.GetChildStr("fromname")

            If Not sFromName Is Nothing Then
               sTitle = sFromName
               If Not sService Is Nothing Then
                  sTitle &= " (" & sService & ")"
               End If
               sTitle &= " is paging you. Accept?"
            End If

            If MsgBox(sTitle, MsgBoxStyle.Question + MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton1) = MsgBoxResult.Yes Then
               If iFromID > 0 Then
                  pUser = UserGet(iFromID)
               End If
               If pUser Is Nothing Then
                  'pUser = New UserLookup(iFromID, 0, sFromName, 0, False, Nothing, 0, iServiceID)
               End If

               pPage = New frmPage(pUser, pEDF)
               pPage.Show()

               bReturn = True
            End If
         End If
      End If

      Return bReturn
   End Function

   Private Sub mnuFolderList_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuFolderList.Click
      Dim pFolders As frmMessageTrees

      pFolders = New frmMessageTrees("folder", m_iCurrFolder)
      pFolders.Show()
   End Sub

   Private Sub RefreshAll()
      RefreshUsers()
      Application.DoEvents()

      RefreshSettings()
      Application.DoEvents()

      'RefreshFolders()
      'Application.DoEvents()

      'If Client.version("2.6") >= 0 Then
      'RefreshChannels()
      'Application.DoEvents()

      'RefreshServices()
      'Application.DoEvents()
      'End If

      RefreshSystem()
      Application.DoEvents()
   End Sub

   Private Sub rlbAnnounces_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles rlbAnnounces.Resize
      'MsgBox("Height " & rlbAnnounces.Height, , "frmSuave::rlbAnnounces resize")
   End Sub

   Private Sub picVotes_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles picVotes.Paint
      ShowMessageVotePicture(e.Graphics)
   End Sub

   Private Sub ShowMessageVotes(ByRef pReply As CEDF)
      Dim iVoteType As Integer, iTotalVotes As Integer, iVoteID As Integer, iNumVotes As Integer
      Dim iMinValue As Integer, iMaxValue As Integer
      Dim bLoop As Boolean, bMinValue As Boolean, bMaxValue As Boolean
      Dim dMinValue As Double, dMaxValue As Double
      Dim sText As String
      Dim pLookup As Lookup

      'pReply.MsgPrint("frmsUAve::ShowMessageVotes")

      If pReply.Child("votes") = True Then
         rlbVotes.Items.Clear()

         iVoteType = pReply.GetChildInt("votetype")
         bMinValue = pReply.IsChild("minvalue")
         If bMinValue = True Then
            If mask(iVoteType, ua.VOTE_INTVALUES) = True Then
               iMinValue = pReply.GetChildInt("minvalue")
            ElseIf mask(iVoteType, ua.VOTE_FLOATVALUES) = True Then
               dMinValue = pReply.GetChildFloat("minvalue")
            End If
         End If
         bMaxValue = pReply.IsChild("maxvalue")
         If bMaxValue = True Then
            If mask(iVoteType, ua.VOTE_INTVALUES) = True Then
               iMaxValue = pReply.GetChildInt("maxvalue")
            ElseIf mask(iVoteType, ua.VOTE_FLOATVALUES) = True Then
               dMaxValue = pReply.GetChildFloat("maxvalue")
            End If
         End If

         lblVotes.Text = ""
         If mask(iVoteType, ua.VOTE_NAMED) = True Then
            lblVotes.Text &= ", name logged"
            If mask(iVoteType, ua.VOTE_CHANGE) = True Then
               lblVotes.Text &= "(changable)"
            End If
         Else
            lblVotes.Text &= ", anonymous"
         End If
         If mask(iVoteType, ua.VOTE_PUBLIC) = True Then
            lblVotes.Text &= ", public"
         ElseIf mask(iVoteType, ua.VOTE_PUBLIC_CLOSE) = True Then
            lblVotes.Text &= ", public when closed"
         End If
         If mask(iVoteType, ua.VOTE_CLOSED) = True Then
            lblVotes.Text &= ", closed"
         End If
         If mask(iVoteType, ua.VOTE_INTVALUES) = True Then
            lblVotes.Text &= ", integer"
            If bMinValue = True And bMaxValue = True Then
               lblVotes.Text &= "(" & iMinValue & " to " & iMaxValue & ")"
            ElseIf bMinValue = True Then
               lblVotes.Text &= "(" & iMinValue & " or more)"
            ElseIf bMaxValue = True Then
               lblVotes.Text &= "(up to " & iMaxValue & ")"
            End If
         ElseIf mask(iVoteType, ua.VOTE_PERCENT) = True Then
            lblVotes.Text &= ", percent"
         ElseIf mask(iVoteType, ua.VOTE_FLOATVALUES) = True Then
            lblVotes.Text &= ", float"
            If bMinValue = True And bMaxValue = True Then
               lblVotes.Text &= "(" & dMinValue & " to " & dMaxValue & ")"
            ElseIf bMinValue = True Then
               lblVotes.Text &= "(" & dMinValue & " or more)"
            ElseIf bMaxValue = True Then
               lblVotes.Text &= "(up to " & dMaxValue & ")"
            End If
         ElseIf mask(iVoteType, ua.VOTE_PERCENT) = True Then
            lblVotes.Text &= ", percent(float)"
         ElseIf mask(iVoteType, ua.VOTE_STRVALUES) = True Then
            lblVotes.Text &= ", string"
         End If

         If lblVotes.Text.Length >= 3 Then
            lblVotes.Text = lblVotes.Text.Substring(2, 1).ToUpper() & lblVotes.Text.Substring(3)
         End If

         iTotalVotes = pReply.GetChildInt("numvotes")

         If iTotalVotes > 0 Then
            If lblVotes.Text <> "" Then
               lblVotes.Text &= vbCrLf
            End If
            lblVotes.Text &= "Total votes: " & iTotalVotes
         End If

         bLoop = pReply.Child("vote")
         Do While bLoop = True
            iVoteID = pReply.GetInt()
            sText = TextDecode(pReply.GetChildStr("text"))
            iNumVotes = pReply.GetChildInt("numvotes")

            pLookup = New Lookup(0, iVoteID, sText)
            rlbVotes.Items.Add(pLookup)

            If iNumVotes > 0 And iTotalVotes > 0 Then
               rlbVotes.Items.Add("  - " & plural(iNumVotes, "vote") & ", " & markup(Format((100 * iNumVotes) / iTotalVotes, "0.0")) & "%")
            End If

            bLoop = pReply.Next("vote")
            If bLoop = False Then
               pReply.Parent()
            End If
         Loop

         'debugline("frmsUAve::ShowMessageVotes check type " & iVoteType)

         If mask(iVoteType, ua.VOTE_INTVALUES) = True Or mask(iVoteType, ua.VOTE_PERCENT) = True Or mask(iVoteType, ua.VOTE_FLOATVALUES) = True Or mask(iVoteType, ua.VOTE_FLOATPERCENT) = True Or mask(iVoteType, ua.VOTE_STRVALUES) = True Then
            'MsgBox("Adding own value", , "frmsUAve::ShowMEssageVotes")
            pLookup = New Lookup(0, 0, "Own value...")
            rlbVotes.Items.Add(pLookup)
         End If

         pReply.Parent()

         picVotes.Refresh()
      Else
         MsgBox("No votes section", , "frmsUAve::ShowMessageVotes")
      End If
   End Sub

   Private Sub ShowMessageVotePie(ByRef pEDF As CEDF, ByVal iXPos As Integer, ByVal iYPos As Integer, ByVal iRadius As Integer, ByRef pGraphics As Graphics)
      Dim iTotalVotes As Integer, iNumVotes As Integer, iAngle As Integer, iPie As Integer, iVoteID As Integer
      Dim fTextAngle As Single
      Dim pSize As SizeF
      Dim pBounds As RectangleF
      Dim bLoop As Boolean, bFill As Boolean
      Dim sText As String
      Dim pPen As Pen
      Dim pPieBrush As Brush, pTextBrush As Brush

      pGraphics.Clear(Me.BackColor)

      If Not pEDF Is Nothing Then
         If pEDF.Child("votes") = True Then
            iAngle = 270

            pPen = New Pen(Me.ForeColor)
            pPieBrush = New SolidBrush(Me.ForeColor)
            pTextBrush = New SolidBrush(Me.ForeColor)

            iTotalVotes = pEDF.GetChildInt("numvotes")

            If iTotalVotes > 0 Then
               bLoop = pEDF.Child("vote")
               Do While bLoop = True
                  iVoteID = pEDF.GetInt()
                  sText = TextDecode(pEDF.GetChildStr("text"))
                  iNumVotes = pEDF.GetChildInt("numvotes")

                  If iNumVotes > 0 Then
                     iPie = (360 * iNumVotes) / iTotalVotes

                     'debugline("frmVote::pPicture " & iNumVotes & " of " & iTotalVotes & ", " & iAngle & " -> " & iPie)
                     'e.Graphics.FillPie(pBrush, iXPos, iYPos, iRadius, iRadius, iAngle, iPie)

                     'debugline("frmsUAve::ShowMessageVotePie x=" & iXPos & " y=" & iYPos & " r=" & iRadius & " a=" & iAngle & " p=" & iPie)
                     If bFill = True Then
                        pGraphics.FillPie(pPieBrush, iXPos - iRadius, iYPos - iRadius, 2 * iRadius, 2 * iRadius, iAngle, iPie)
                     Else
                        pGraphics.DrawPie(pPen, iXPos - iRadius, iYPos - iRadius, 2 * iRadius, 2 * iRadius, iAngle, iPie)
                     End If
                     bFill = Not bFill

                     fTextAngle = (iAngle + iPie / 2) * (Math.PI / 180)
                     pSize = pGraphics.MeasureString(sText, sUAveFont())
                     pBounds.Width = pSize.Width
                     If pBounds.Width > 70 Then
                        pBounds.Width = 70
                     End If
                     pBounds.Height = pSize.Height
                     pBounds.X = iXPos + (iRadius + 10) * Math.Cos(fTextAngle) + (pBounds.Width / 2) * Math.Cos(fTextAngle) - pBounds.Width / 2
                     pBounds.Y = iYPos + (iRadius + 10) * Math.Sin(fTextAngle)
                     pGraphics.DrawString(sText, sUAveFont(), pTextBrush, pBounds)

                     iAngle += iPie
                     If iAngle >= 360 Then
                        iAngle -= 360
                     End If
                  End If

                  bLoop = pEDF.Next("vote")
                  If bLoop = False Then
                     pEDF.Parent()
                  End If
               Loop
            End If

            pEDF.Parent()
         End If
      End If
   End Sub

   Private Sub ShowMessageVoteBar(ByRef pEDF As CEDF, ByVal iWidth As Integer, ByVal iHeight As Integer, ByVal iGap As Integer, ByRef pGraphics As Graphics)
      Dim bLoop As Boolean, bVote As Boolean = False
      Dim iVoteType As Integer, iNumVotes As Integer, iMaxVotes As Integer
      Dim iXVal1 As Integer, iXVal2 As Integer, iYVal As Integer
      Dim dValue As Integer, dMinValue As Integer, dMaxValue As Integer
      Dim sValue As String
      Dim pPen As Pen

      pGraphics.Clear(Me.BackColor)

      If Not pEDF Is Nothing Then
         pPen = New Pen(Me.ForeColor)

         If pEDF.Child("votes") = True Then
            iVoteType = pEDF.GetChildInt("votetype")

            bLoop = pEDF.Child("vote")
            Do While bLoop = True
               iNumVotes = pEDF.GetChildInt("numvotes")
               sValue = pEDF.GetChildStr("text")
               dValue = sValue
               debugline("frmsUAve::ShowMessageVoteBar mumvotes=" & iNumVotes & ", value=" & sValue & "(" & dValue & ")")

               If iNumVotes > iMaxVotes Then
                  iMaxVotes = iNumVotes
               End If
               If bVote = False Then
                  dMinValue = dValue
                  dMaxValue = dValue
                  bVote = True
               Else
                  If dValue < dMinValue Then
                     dMinValue = dValue
                  End If
                  If dValue > dMaxValue Then
                     dMaxValue = dValue
                  End If
               End If

               bLoop = pEDF.Next("vote")
               If bLoop = False Then
                  pEDF.Parent()
               End If
            Loop

            debugline("frmsUAve::ShowMessageVoteBar maxvotes=" & iMaxVotes & ", minvalue=" & dMinValue & ", maxvalue=" & dMaxValue)

            If mask(iVoteType, ua.VOTE_INTVALUES) = True Or mask(iVoteType, ua.VOTE_PERCENT) = True Then
               dMaxValue += 1
            End If

            If bVote = True Then
               pGraphics.DrawLine(pPen, iGap, iHeight - iGap, iWidth - iGap, iHeight - iGap)

               bLoop = pEDF.Child("vote")
               Do While bLoop = True
                  iNumVotes = pEDF.GetChildInt("numvotes")
                  sValue = pEDF.GetChildStr("text")
                  dValue = sValue

                  iXVal1 = ((iWidth - 2 * iGap) * (dValue - dMinValue)) / (dMaxValue - dMinValue)
                  iYVal = ((iHeight - 2 * iGap) * iNumVotes) / iMaxVotes
                  debugline("frmSuave::ShowMessageVoteBar " & iNumVotes & " of " & dValue & " -> " & iXVal1 & "," & iYVal)

                  If mask(iVoteType, ua.VOTE_INTVALUES) = True Or mask(iVoteType, ua.VOTE_PERCENT) = True Then
                     iXVal2 = (iWidth - 2 * iGap) / (dMaxValue - dMinValue)
                     pGraphics.DrawRectangle(pPen, iGap + iXVal1, iHeight - iYVal - iGap, iXVal2, iYVal)
                  Else
                     pGraphics.DrawLine(pPen, iGap + iXVal1, iHeight - iGap, iGap + iXVal1, iHeight - iYVal)
                  End If

                  bLoop = pEDF.Next("vote")
                  If bLoop = False Then
                     pEDF.Parent()
                  End If
               Loop
            End If

            pEDF.Parent()
         End If
      End If
   End Sub

   Private Sub ShowMessageVotePicture(ByVal pGraphics As Graphics)
      Dim iXPos As Integer, iYPos As Integer, iRadius As Integer
      Dim iVoteType As Integer

      If Not m_pCurrMessage Is Nothing And Me.WindowState <> FormWindowState.Minimized Then

         If m_pCurrMessage.Child("votes") = True Then
            iVoteType = m_pCurrMessage.GetChildInt("votetype")
            m_pCurrMessage.Parent()
         End If

         If mask(iVoteType, ua.VOTE_INTVALUES) = True Or mask(iVoteType, ua.VOTE_PERCENT) = True Or mask(iVoteType, ua.VOTE_FLOATVALUES) = True Or mask(iVoteType, ua.VOTE_FLOATPERCENT) = True Then
            ShowMessageVoteBar(m_pCurrMessage, picVotes.Size.Width, picVotes.Size.Height, 8, pGraphics)
         Else
            'debugline("frmsUAve::ShowMessageVotePie width=" & pPicture.Size.Width & " height=" & pPicture.Size.Height)
            If picVotes.Size.Width < picVotes.Size.Height Then
               iRadius = picVotes.Size.Width / 2
            Else
               iRadius = picVotes.Size.Height / 2
            End If

            iXPos = iRadius
            iYPos = iRadius

            iRadius -= 30

            'MsgBox("x = " & iXPos & ", y = " & iYPos & ", r = " & iRadius)

            ShowMessageVotePie(m_pCurrMessage, iXPos, iYPos, iRadius, pGraphics)
         End If
      End If
   End Sub

   Private Sub rlbVotes_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rlbVotes.SelectedIndexChanged
      Dim iVoteType As Integer, iVoteValue As Integer
      Dim dVoteValue As Double
      Dim sVoteValue As String
      Dim pLookup As Lookup
      Dim pRequest As CEDF, pReply As CEDF
      Dim pInput As frmInput

      'Only try voting if the selected item is a vote object
      pLookup = New Lookup("")

      If rlbVotes.SelectedItem.GetType.Equals(pLookup.GetType()) Then
         pLookup = rlbVotes.SelectedItem

         pRequest = New CEDF
         pRequest.AddChild("messageid", m_pCurrMessage.GetInt())

         If pLookup.m_iID > 0 Then
            pRequest.AddChild("messageid", m_pCurrMessage.GetInt())
         Else
            pInput = New frmInput("Vote", frmInput.TXT_INPUT, "Value")
            If pInput.ShowDialog() = DialogResult.OK Then
               sVoteValue = pInput.GetValue()

               If m_pCurrMessage.Child("votes") = True Then
                  iVoteType = m_pCurrMessage.GetChildInt("votetype")
                  m_pCurrMessage.Parent()
               End If

               If mask(iVoteType, ua.VOTE_INTVALUES) = True Or mask(iVoteType, ua.VOTE_PERCENT) = True Then
                  iVoteValue = sVoteValue
                  pRequest.AddChild("votevalue", iVoteValue)
               ElseIf mask(iVoteType, ua.VOTE_FLOATVALUES) = True Or mask(iVoteType, ua.VOTE_FLOATPERCENT) = True Then
                  dVoteValue = sVoteValue
                  pRequest.AddChild("votevalue", dVoteValue)
               Else
                  pRequest.AddChild("votevalue", sVoteValue)
               End If
            End If
         End If

         pReply = New CEDF

         Client.request3(ua.MSG_MESSAGE_VOTE, pRequest, pReply)

         pReply.MsgPrint("frmsUAve::rlbVotes")
      End If
   End Sub
   Friend WithEvents splVotes As System.Windows.Forms.Splitter

   Private Sub picVotes_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles picVotes.Resize
      Dim pGraphics As Graphics

      pGraphics = picVotes.CreateGraphics()
      If Not pGraphics Is Nothing Then
         ShowMessageVotePicture(pGraphics)
         pGraphics.Dispose()
      End If
   End Sub

   Private Sub mnuFolderSearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuFolderSearch.Click
      Dim bFreeForm As Boolean
      Dim pSearch As frmMessageSearch

      bFreeForm = Client.GetClientBool("freeformsearch")

      If frmMessageSearch.getForm() Is Nothing Then
         pSearch = New frmMessageSearch(m_iCurrFolder, bFreeForm)
         pSearch.Show()
      End If
   End Sub

   Friend WithEvents mnuFolderSearch As System.Windows.Forms.MenuItem

   Public Shared Function getForm() As frmsUAve
      Return m_pForm
   End Function

   Private Sub mnuHelpAbout_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuHelpAbout.Click
      Dim pAbout As frmAbout

      pAbout = New frmAbout

      pAbout.ShowDialog()
   End Sub

   Private Sub FolderJump(ByVal pFolder As MessageTreeLookup)
      Dim bTemp As Boolean
      Dim pNode As TreeNode

      bTemp = m_bUserInput
      m_bUserInput = True
      If m_iViewType = VT_FOLDERUSER Then
         rcbFolders.SelectedItem = pFolder
      Else
         pNode = FolderFind(pFolder.m_iID)
         tvwFolders.SelectedNode = pNode
      End If
      m_bUserInput = bTemp
   End Sub

   Private Sub ShowWholist()
      Dim bTemp As Boolean

      bTemp = m_bUserInput
      m_bUserInput = False

      sUAveHelper.ShowUsers(rcbWholist, True, True)

      m_bUserInput = True
   End Sub

   Private Sub CatchupWholeThread()
      Dim iMessageID As Integer = -1

      If Not m_pCurrMessage Is Nothing Then
         'm_pCurrMessage.MsgPrint("frmsUAve::mnuMsgCatchWhole")

         m_pCurrMessage.Root()

         'm_pCurrMessage.Child("message")

         If m_pCurrMessage.Children("replyto") > 0 Then
            iMessageID = m_pCurrMessage.GetChildInt("replyto", CEDF.LAST)
         End If

         'm_pcurrmessage.Parent()

         m_pMessageContext = tvwMessages.SelectedNode.Tag

         MessageThread(ua.MSG_MESSAGE_MARK_READ, ua.THREAD_MSGCHILD, iMessageID)
      End If
   End Sub

   Private Function FolderNext(ByVal iFolderID As Integer) As MessageTreeLookup
      Dim iEDF As Integer, iLookupID As Integer
      Dim bLoop As Boolean

      m_pFolderTree.Root()
      If iFolderID = -1 Then
         If m_pFolderTree.Child("folder") = True Then
            iLookupID = m_pFolderTree.GetInt()
         End If
      Else
         bLoop = m_pFolderTree.Child("folder")
         Do While bLoop = True
            iEDF = m_pFolderTree.GetInt()
            bLoop = m_pFolderTree.Iterate("folder")
            If iEDF = iFolderID Then
               If bLoop = True Then
                  iLookupID = m_pFolderTree.GetInt()
                  bLoop = False
               Else
                  iLookupID = -1
               End If
            End If
         Loop
      End If

      Return FolderGet(iLookupID)
   End Function
   Friend WithEvents mnuToolsStatus As System.Windows.Forms.MenuItem

   Private Sub mnuToolsStatus_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuToolsStatus.Click
      Dim pRequest As CEDF, pReply As CEDF
      Dim pInput As frmInput

      pInput = New frmInput("Status", frmInput.TXT_INPUT, "Message", ua.UA_SHORTMSG_LEN)

      If pInput.ShowDialog() = DialogResult.OK Then
         pRequest = New CEDF
         pRequest.Add("login")
         If pInput.GetValue() <> "" Then
            AddTextField(pRequest, "statusmsg", pInput.GetValue())
         Else
            pRequest.AddChild("statusmsg")
         End If
         pRequest.Parent()

         'pRequest.MsgPrint("frmsUAve::mnuToolsPager")

         pReply = New CEDF

         Client.request3(ua.MSG_USER_EDIT, pRequest, pReply)
      End If
   End Sub

   Private Sub mnuToolsRefreshServices_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuToolsRefreshServices.Click
      RefreshServices()
      Application.DoEvents()
   End Sub

   Private Sub rtbContent_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles rtbContent.KeyUp
      Dim sText As String

      If e.KeyCode = Keys.C And e.Control = True And e.Shift = True Then
         sText = rtbContent.SelectedText

         sText = sText.Replace(vbCr, "")
         sText = sText.Replace(vbLf, "")

         Clipboard.SetDataObject(sText)
      End If
   End Sub
End Class
