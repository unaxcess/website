Imports org.ua2

Public Class sUAveClient
   Inherits CClient

   Public Sub New(ByVal sDebugFile As String)
      MyBase.New()
   End Sub

   Protected Overrides Function CLIENT_NAME() As String
      Return sUAveHelper.CLIENT_NAME
   End Function

   Public Overrides Function connected() As Boolean
      frmsUAve.getForm().connected()
   End Function

   Public Overrides Function disconnected() As Boolean
      frmsUAve.getForm().disconnected()
   End Function

   Public Overrides Function loggedIn() As Boolean
      frmsUAve.getForm().loggedIn()
   End Function

   Public Overrides Function reply(ByVal sReply As String, ByVal pReply As CEDF) As Boolean
      Return frmsUAve.getForm().reply(sReply, pReply)
   End Function

   Public Overrides Function announce(ByVal sAnnounce As String, ByVal pAnnounce As CEDF) As Boolean
      Return frmsUAve.getForm().announce(sAnnounce, pAnnounce)
   End Function

   Public Function RefreshUser(Optional ByRef pRequest As CEDF = Nothing) As Boolean
      Dim bReturn As Boolean
      Dim pReply As CEDF, pTemp As CEDF

      If Not pRequest Is Nothing Then
         pReply = New CEDF()

         request3(ua.MSG_USER_EDIT, pRequest, pReply)
      End If

      pTemp = New CEDF()
      pTemp.AddChild("searchtype", 4)

      pReply = New CEDF()

      If request3(ua.MSG_USER_LIST, pTemp, pReply) = True Then
         If pReply.Child("user") = True Then
            m_pUser = New CEDF()

            m_pUser.Copy(pReply, True, True, True)

            pReply.Parent()
         End If

         bReturn = True
      End If

      Return bReturn
   End Function

   Public Function GetID() As Integer
      Return m_pUser.GetInt()
   End Function

   Public Function GetName() As String
      Return m_pUser.GetChildStr("name")
   End Function

   Public Function GetAccessLevel() As Integer
      Return m_pUser.GetChildInt("accesslevel")
   End Function

   Public Function GetStatus() As Integer
      Dim iReturn As Integer

      If m_pUser.Child("login") = True Then
         iReturn = m_pUser.GetChildInt("status")

         m_pUser.Parent()
      End If

      Return iReturn
   End Function

   Public Function GetClientInt(ByVal sName As String, Optional ByVal iDefault As Integer = 0) As Integer
      Dim iReturn As Integer = iDefault

      If m_pUser.Child("client", CLIENT_NAME()) = True Then
         iReturn = m_pUser.GetChildInt(sName)

         m_pUser.Parent()
      End If

      Return iReturn
   End Function

   Public Function GetClientBool(ByVal sName As String, Optional ByVal bDefault As Boolean = False) As Boolean
      Dim bReturn As Boolean = bDefault

      If m_pUser.Child("client", CLIENT_NAME()) = True Then
         bReturn = m_pUser.GetChildBool(sName)

         m_pUser.Parent()
      End If

      Return bReturn
   End Function
End Class
