Imports Microsoft.Win32
Imports Microsoft.VisualBasic
Imports System.IO
Imports System.Text
Imports System.Drawing.Imaging

Imports org.ua2

Module sUAveHelper
   Private Class CompareID
      Implements IComparer

      Public Function Compare(ByVal a As Object, ByVal b As Object) As Integer Implements IComparer.Compare
         Dim pLookup1 As Lookup, pLookup2 As Lookup

         pLookup1 = a
         pLookup2 = b

         If pLookup1.m_iID < pLookup2.m_iID Then
            Return -1
         ElseIf pLookup1.m_iID > pLookup2.m_iID Then
            Return 1
         End If

         Return 0
      End Function
   End Class

   Public Const CLIENT_NAME = "sUAve v0.70"

   Public Const ICO_SUAVE = 0, ICO_SUAVE2 = 1, ICO_FOLDER_CLOSE = 2, ICO_FOLDER_OPEN = 3, ICO_MSG_CLOSE = 4, ICO_MSG_OPEN = 5, ICO_MSG_ACTION = 6, ICO_USERS = 7, ICO_BULB_ON = 8, ICO_BULB_OFF = 9, ICO_LOCK = 10, ICO_BALLOT = 11

   Public Const STRTIME_TIME = 1, STRTIME_DATE = 2, STRTIME_SHORT = 3, STRTIME_MEDIUM = 4, STRTIME_LONG = 5, STRTIME_HM = 6
   Public Const STRVALUE_TIME = 1, STRVALUE_BYTE = 2

   Public Const CRLF = Chr(13) & Chr(10)

   Private m_pClient As sUAveClient
   Private m_pUserList() As UserLookup = Nothing
   Private m_pFolderList() As MessageTreeLookup = Nothing, m_pChannelList() As MessageTreeLookup = Nothing
   Public m_pServiceList() As ServiceLookup = Nothing
   Public m_pFolderTree As CEDF
   Public m_iCurrFolder As Integer = -1
   Public m_iCurrMessage As Integer = -1
   Public m_pCurrMessage As CEDF
   Public m_pImageList As ImageList
   Private m_pForms As Collection
   Private m_iServerDiff As Integer
   Private m_pFont As Font, m_pFixedFont As Font, m_pUnicodeFont As Font
   Private m_pComparer As CompareID = New CompareID()
   Private m_sBrowser As String

   Public Sub LoggedIn()
      m_pForms = New Collection()
   End Sub

   Public Sub Disconnect()
      Dim pForm As Form

      If Not m_pClient Is Nothing Then
         m_pClient = Nothing
      End If

      If Not m_pForms Is Nothing Then
         For Each pForm In m_pForms
            If pForm.GetType Is GetType(frmPage) Or pForm.GetType Is GetType(frmTalk) Then
               pForm.Dispose()
            End If
         Next
      End If
   End Sub

   Public Property Client() As sUAveClient
      Get
         Return m_pClient
      End Get
      Set(ByVal pClient As sUAveClient)
         m_pClient = pClient
      End Set
   End Property

   Private Function SubRequest(ByRef pInput As frmInput, ByVal sTitle As String, ByVal sInput As String, ByVal sType As String) As CEDF
      Dim iItemNum As Integer, iNumItems As Integer
      Dim pItem As Lookup, pLookup As Lookup
      Dim pUser As UserLookup
      Dim pReturn As CEDF

      If pInput Is Nothing Then
         pInput = New frmInput(sTitle, frmInput.RCB_INPUT + frmInput.CMB_TYPE, sInput, ua.UA_NAME_LEN)

         If sType = "folder" Then
            iNumItems = FolderCount()
         ElseIf sType = "channel" Then
            iNumItems = ChannelCount()
         ElseIf sType = "user" Then
            iNumItems = UserCount()
         End If

         pInput.BeginAddItems()
         For iItemNum = 0 To (iNumItems - 1)
            If sType = "folder" Then
               pItem = FolderList(iItemNum)
            ElseIf sType = "channel" Then
               pItem = ChannelList(iItemNum)
            ElseIf sType = "user" Then
               pUser = UserList(iItemNum)
               If pUser.m_iAccessLevel >= ua.LEVEL_MESSAGES Then
                  pItem = pUser
               Else
                  pItem = Nothing
               End If
            End If

            If Not pItem Is Nothing Then
               pLookup = New Lookup(0, pItem.m_iID, pItem.m_sValue)

               pInput.AddItem(pLookup)
            End If
         Next
         pInput.EndAddItems()

         pInput.AddType("Subscriber")
         pInput.AddType("Member")
         If Client.GetAccessLevel() >= ua.LEVEL_WITNESS Then
            pInput.AddType("Editor")
         End If
      Else
         pInput.Text = sTitle
         pInput.lblInput.Text = sInput
      End If

      If pInput.ShowDialog() = DialogResult.OK Then
         pLookup = pInput.GetItem()

         If Not pLookup Is Nothing Then
            pReturn = New CEDF()
            pReturn.AddChild(sType & "id", pLookup.m_iID)

            If pInput.GetTypeIndex() = 1 Then
               pReturn.AddChild("subtype", ua.SUBTYPE_MEMBER)
            ElseIf pInput.GetTypeIndex() = 2 Then
               pReturn.AddChild("subtype", ua.SUBTYPE_EDITOR)
            End If
         End If
      End If

      Return pReturn
   End Function

   Public Function UserGet(ByVal iUserID As Integer) As UserLookup
      Dim iTemp As Integer

      Return LookupFind(m_pUserList, iUserID, iTemp)
   End Function

   Public Function UserGet(ByVal iUserID As Integer, ByVal iUserNum As Integer) As UserLookup
      Return LookupFind(m_pUserList, iUserID, iUserNum)
   End Function

   Public Function UserGet(ByVal sUserName As String) As UserLookup
      Dim iUserNum As Integer
      Dim bFound As Boolean
      Dim pReturn As UserLookup

      If m_pUserList Is Nothing Then
         Return Nothing
      End If

      Do While bFound = False And iUserNum < m_pUserList.Length
         If m_pUserList(iUserNum).m_sValue.ToLower() = sUserName.ToLower() Then
            pReturn = m_pUserList(iUserNum)
            bFound = True
         Else
            iUserNum += 1
         End If
      Loop

      Return pReturn
   End Function

   Public Function UserList(ByVal iUserNum As Integer) As UserLookup
      If m_pUserList Is Nothing Then
         Return Nothing
      End If

      If iUserNum < 0 Or iUserNum >= m_pUserList.Length Then
         Return Nothing
      End If

      Return m_pUserList(iUserNum)
   End Function

   Public Function UserCount() As Integer
      If m_pUserList Is Nothing Then
         Return 0
      End If

      Return m_pUserList.Length
   End Function

   Public Function UserCountLogins() As Integer
      Dim iReturn As Integer
      Dim pUser As UserLookup

      If m_pUserList Is Nothing Then
         Return 0
      End If

      For Each pUser In m_pUserList
         If pUser.m_iValue > 0 Then
            iReturn += 1
         End If
      Next

      Return iReturn
   End Function

   Public Function UserCountActive() As Integer
      Dim iReturn As Integer
      Dim pUser As UserLookup

      If m_pUserList Is Nothing Then
         Return 0
      End If

      For Each pUser In m_pUserList
         If isActive(pUser.m_iValue) = True Then
            iReturn += 1
         End If
      Next

      Return iReturn
   End Function

   Public Function UserCountTalking() As Integer
      Dim iReturn As Integer
      Dim pUser As UserLookup

      If m_pUserList Is Nothing Then
         Return 0
      End If

      For Each pUser In m_pUserList
         If mask(pUser.m_iValue, ua.LOGIN_TALKING) = True Then
            iReturn += 1
         End If
      Next

      Return iReturn
   End Function

   Public Function UsersCopy() As UserLookup()
      Dim pReturn(m_pUserList.Length - 1) As UserLookup

      Array.Copy(m_pUserList, pReturn, m_pUserList.Length)

      Return pReturn
   End Function

   Private Sub UserChange(ByRef pUser As UserLookup, ByVal bStatus As Boolean, ByVal iStatus As Integer, ByVal sStatusMsg As String)
      Dim iUserNum As Integer
      Dim pForm As Form
      Dim pPage As frmPage
      Dim pRequest As CEDF, pReply As CEDF
      Dim pWholist As frmWholist

      If bStatus = True Then
         pUser.m_iValue = iStatus
      End If
      pUser.m_sStatusMsg = sStatusMsg

      For Each pForm In m_pForms
         If pForm.GetType Is GetType(frmPage) Then
            pPage = pForm
            If pPage.GetFromID() = pUser.m_iID Then
               If isActive(pUser.m_iValue) = True And pPage.cmbContact.SelectedIndex = 2 Then
                  pPage.cmbContact.SelectedIndex = 0
                  pPage.chkReturnSend.Checked = pPage.m_bReturnSend
               ElseIf isActive(pUser.m_iValue) = False And pPage.cmbContact.SelectedIndex = 0 Then
                  pPage.cmbContact.SelectedIndex = 2
                  pPage.m_bReturnSend = pPage.chkReturnSend.Checked
                  pPage.chkReturnSend.Checked = False
               End If
            End If
         End If
      Next

      If Not frmWholist.getForm() Is Nothing Then
         pRequest = New CEDF()
         pRequest.AddChild("searchtype", 1)

         pReply = New CEDF()

         Client.request3(ua.MSG_USER_LIST, pRequest, pReply)

         pWholist = frmWholist.getForm()
         pWholist.SetData(pReply)
      End If
   End Sub

   Private Function UserNew(ByRef pUser As CEDF) As UserLookup
      Dim iUserID As Integer, iUserType As Integer, iAccessLevel As Integer, iStatus As Integer, iNumShadows As Integer
      Dim bSecure As Boolean
      Dim sName As String, sStatusMsg As String
      Dim pReturn As UserLookup

      iUserID = pUser.GetInt()
      iUserType = pUser.GetChildInt("usertype")
      sName = pUser.GetChildStr("name")
      iAccessLevel = pUser.GetChildInt("accesslevel")

      If pUser.Child("login") = True Then
         iStatus = pUser.GetChildInt("status")
         sStatusMsg = pUser.GetChildStr("statusmsg")
         bSecure = pUser.GetChildBool("secure")

         pUser.Parent()
      Else
         iStatus = pUser.GetChildInt("status")
         sStatusMsg = pUser.GetChildStr("statusmsg")
      End If

      iNumShadows = pUser.GetChildInt("numshadows")

      pReturn = New UserLookup(iUserID, iUserType, sName, iAccessLevel, iStatus, bSecure, sStatusMsg, iNumShadows, False, Nothing)

      Return pReturn
   End Function

   Public Sub UserAdd(ByRef pUser As CEDF)
      If pUser.Child("user") = True Then
         ReDim Preserve m_pUserList(m_pUserList.Length)

         m_pUserList(m_pUserList.Length - 1) = UserNew(pUser)

         Array.Sort(m_pUserList, m_pComparer)

         pUser.Parent()
      End If
   End Sub

   Public Sub UserLogin(ByVal iUserID As Integer, ByVal iStatus As Integer, ByVal sStatusMsg As String)
      Dim iUserNum As Integer
      Dim pUser As UserLookup

      pUser = LookupFind(m_pUserList, iUserID, iUserNum)

      If Not pUser Is Nothing Then
         If mask(iStatus, ua.LOGIN_SHADOW) = False Then
            UserChange(pUser, True, iStatus, sStatusMsg)
         Else
            pUser.m_iNumShadows += 1
         End If
      End If
   End Sub

   Public Sub UserLogout(ByVal iUserID As Integer, ByVal iStatus As Integer, ByVal sStatusMsg As String)
      Dim iUserNum As Integer
      Dim pUser As UserLookup

      pUser = LookupFind(m_pUserList, iUserID, iUserNum)

      If Not pUser Is Nothing Then
         If mask(iStatus, ua.LOGIN_SHADOW) = False Then
            UserChange(pUser, True, ua.LOGIN_OFF, sStatusMsg)
         Else
            pUser.m_iNumShadows -= 1
         End If
      End If
   End Sub

   Public Sub UserStatus(ByVal iUserID As Integer, ByVal bStatus As Boolean, ByVal iStatus As Integer, ByVal sStatusMsg As String, ByVal iConnID As Integer)
      Dim iUserNum As Integer
      Dim pUser As UserLookup

      If iConnID <= 0 Then
         pUser = LookupFind(m_pUserList, iUserID, iUserNum)

         If Not pUser Is Nothing Then
            UserChange(pUser, bStatus, iStatus, sStatusMsg)
         End If
      End If
   End Sub

   Public Sub UserEmote(ByRef pControl As RichTextBox, ByVal sPrefix As String, ByVal sText As String, ByVal cColour As Color)
      Dim bSet As Boolean

      pControl.Select()
      pControl.SelectionColor = cColour
      pControl.SelectionFont = New Font(pControl.Font, FontStyle.Bold)

      If Not sText Is Nothing Then
         If sText.StartsWith(":'s ") = True Then
            pControl.AppendText(sPrefix & "'s")
            sText = sText.Substring(4)

            bSet = True
         ElseIf sText.StartsWith(":") = True And IsSmiley(sText) = False Then
            pControl.AppendText(sPrefix)
            sText = sText.Substring(1)

            bSet = True
         End If
      End If

      If bSet = False Then
         pControl.AppendText("(" & sPrefix & ")")
      End If

      pControl.Select()
      pControl.SelectionColor = pControl.ForeColor
      pControl.SelectionFont = pControl.Font

      pControl.AppendText(" " & sText)

      'TextEmphasis(pControl, " " & sText)
   End Sub

   Public Function UserEmote(ByVal sPrefix1 As String, ByVal sPrefix2 As String, ByVal sText As String, ByVal bDot As Boolean, ByVal bMarkup As Boolean) As String
      Dim bSet As Boolean
      Dim sReturn As String

      If sText Is Nothing Then
         Return sPrefix1
      End If

      If sText.Length = 0 Then
         Return sPrefix1
      End If

      If sText.Length > 2 Then
         If sText.Substring(0, 1) = ":" Then
            If sText.Substring(1, 2) = "'s " Then
               sReturn = sPrefix2
               If bMarkup = True Then
                  sReturn &= markup("'s")
               Else
                  sReturn &= "'s"
               End If
               sReturn &= sText.Substring(3)

               bSet = True
            ElseIf IsSmiley(sText) = False Then
               sReturn = sPrefix2 & " " & sText.Substring(1)

               bSet = True
            End If
         End If
      End If

      If bSet = False Then
         sReturn = sPrefix1
         If bDot = True Then
            sReturn &= "."
         End If
         sReturn &= " " & sText
      End If

      Return sReturn
   End Function

   Public Sub Users(ByRef pUsers As CEDF)
      Dim iUserNum As Integer, iNumUsers As Integer
      Dim bLoop As Boolean

      iNumUsers = pUsers.Children("user", True)
      If iNumUsers > 0 Then
         ReDim m_pUserList(iNumUsers - 1)

         bLoop = pUsers.Child("user")
         Do While bLoop = True
            m_pUserList(iUserNum) = UserNew(pUsers)

            bLoop = pUsers.Next("user")
            If bLoop = True Then
               iUserNum += 1
            Else
               pUsers.Parent()
            End If
         Loop

         Array.Sort(m_pUserList, m_pComparer)
      Else
         m_pUserList = Nothing
      End If
   End Sub

   Public Function FolderGet(ByVal iFolderID As Integer) As MessageTreeLookup
      Dim iTemp As Integer

      Return LookupFind(m_pFolderList, iFolderID, iTemp)
   End Function

   Public Function FolderGet(ByVal sFolderName As String) As MessageTreeLookup
      Dim iFolderNum As Integer
      Dim bFound As Boolean
      Dim pReturn As MessageTreeLookup

      If m_pFolderList Is Nothing Then
         Return Nothing
      End If

      Do While bFound = False And iFolderNum < m_pFolderList.Length
         If m_pFolderList(iFolderNum).m_sValue.ToLower() = sFolderName.ToLower() Then
            pReturn = m_pFolderList(iFolderNum)
            bFound = True
         Else
            iFolderNum += 1
         End If
      Loop

      Return pReturn
   End Function

   Public Function FolderGet(ByVal iFolderID As Integer, ByRef iFolderNum As Integer) As MessageTreeLookup
      Return LookupFind(m_pFolderList, iFolderID, iFolderNum)
   End Function

   Public Function FolderList(ByVal iFolderNum As Integer) As MessageTreeLookup
      If m_pFolderList Is Nothing Then
         Return Nothing
      End If

      If iFolderNum < 0 Or iFolderNum >= m_pFolderList.Length Then
         Return Nothing
      End If

      Return m_pFolderList(iFolderNum)
   End Function

   Public Function FolderCount() As Integer
      If m_pFolderList Is Nothing Then
         Return 0
      End If

      Return m_pFolderList.Length
   End Function

   Private Function FolderNew(ByRef pFolder As CEDF) As MessageTreeLookup
      Dim iFolderID As Integer, iSubType As Integer, iNumUnread As Integer, iNumMessages As Integer, iAccessMode As Integer, iReplyID As Integer
      Dim sName As String
      Dim pReturn As MessageTreeLookup

      iFolderID = m_pFolderTree.GetInt()
      sName = m_pFolderTree.GetChildStr("name")
      iSubType = m_pFolderTree.GetChildInt("subtype")

      iNumUnread = m_pFolderTree.GetChildInt("unread")
      iNumMessages = m_pFolderTree.GetChildInt("nummsgs")
      iAccessMode = m_pFolderTree.GetChildInt("accessmode")
      iReplyID = m_pFolderTree.GetChildInt("replyid")

      pReturn = New MessageTreeLookup(iFolderID, sName, iSubType, iNumMessages, iNumUnread, iReplyID, iAccessMode)

      If mask(iAccessMode, ua.ACCMODE_SUB_READ) = False Then
         pReturn.ImageIndex = ICO_LOCK
      Else
         pReturn.ImageIndex = -1
      End If

      Return pReturn
   End Function

   Public Sub FolderAdd(ByRef pFolder As CEDF)
      If pFolder.Child("folder") = True Then
         ReDim Preserve m_pFolderList(m_pFolderList.Length)

         m_pFolderList(m_pFolderList.Length - 1) = FolderNew(pFolder)

         Array.Sort(m_pFolderList, m_pComparer)

         pFolder.Parent()
      End If
   End Sub

   Public Function FoldersCopy() As MessageTreeLookup()
      Dim pReturn() As MessageTreeLookup

      If Not m_pFolderList Is Nothing Then
         If m_pFolderList.Length > 0 Then
            ReDim pReturn(m_pFolderList.Length - 1)

            Array.Copy(m_pFolderList, pReturn, m_pFolderList.Length)
         Else
            ReDim pReturn(0)
         End If
      Else
         ReDim pReturn(0)
      End If

      Return pReturn
   End Function

   Public Function FoldersUnread() As Integer
      Dim iReturn As Integer
      Dim pFolder As MessageTreeLookup

      If m_pFolderList Is Nothing Then
         Return 0
      End If

      For Each pFolder In m_pFolderList
         If pFolder.m_iSubType > 0 Then
            iReturn += pFolder.m_iValue
         End If
      Next

      Return iReturn
   End Function

   Public Function FolderSubscribe(ByVal iFolderID As Integer, ByVal iSubType As Integer) As Boolean
      Dim bReturn As Boolean
      Dim sRequest As String
      Dim pRequest As CEDF, pReply As CEDF
      Dim pFolder As MessageTreeLookup

      If iSubType > 0 Then
         sRequest = ua.MSG_FOLDER_SUBSCRIBE
      Else
         sRequest = ua.MSG_FOLDER_UNSUBSCRIBE
      End If

      pRequest = New CEDF()
      pRequest.AddChild("folderid", iFolderID)
      If iSubType > 0 Then
         pRequest.AddChild("subtype", iSubType)
      End If

      pReply = New CEDF()

      bReturn = m_pClient.request3(sRequest, pRequest, pReply)

      If bReturn = True Then
         pFolder = FolderGet(iFolderID)
         pFolder.m_iSubType = iSubType
      Else
         pReply.MsgPrint("sUAverHelper::FolderSubscribe " & sRequest & " request failed")
      End If

      Return bReturn
   End Function

   Public Sub Folders(ByRef pFolders As CEDF)
      Dim iFolderNum As Integer, iNumFolders As Integer
      Dim bLoop As Boolean

      iNumFolders = pFolders.Children("folder", True)
      If iNumFolders > 0 Then
         m_pFolderTree = New CEDF()
         m_pFolderTree.Copy(pFolders, True, True, True)
         m_pFolderTree.Sort("folder", "name", True)

         ReDim m_pFolderList(iNumFolders - 1)

         bLoop = m_pFolderTree.Child("folder")
         Do While bLoop = True
            m_pFolderList(iFolderNum) = FolderNew(m_pFolderTree)

            bLoop = m_pFolderTree.Iterate("folder")
            If bLoop = True Then
               iFolderNum += 1
            End If
         Loop

         Array.Sort(m_pFolderList, m_pComparer)
      Else
         m_pFolderList = Nothing
         m_pFolderTree = Nothing
      End If
   End Sub

   Public Function ChannelGet(ByVal iChannelID As Integer) As MessageTreeLookup
      Dim iTemp As Integer

      Return LookupFind(m_pChannelList, iChannelID, iTemp)
   End Function

   Public Function ChannelGet(ByVal iChannelID As Integer, ByRef iChannelNum As Integer) As MessageTreeLookup
      Return LookupFind(m_pChannelList, iChannelID, iChannelNum)
   End Function

   Public Function ChannelList(ByVal iChannelNum As Integer) As MessageTreeLookup
      If m_pChannelList Is Nothing Then
         Return Nothing
      End If

      If iChannelNum < 0 Or iChannelNum >= m_pChannelList.Length Then
         Return Nothing
      End If

      Return m_pChannelList(iChannelNum)
   End Function

   Public Function ChannelCount() As Integer
      If m_pChannelList Is Nothing Then
         Return 0
      End If

      Return m_pChannelList.Length
   End Function

   Public Function ChannelSubscribe(ByVal iChannelID As Integer, ByVal iSubType As Integer) As Boolean
      Dim bReturn As Boolean
      Dim sRequest As String
      Dim pRequest As CEDF, pReply As CEDF
      Dim pChannel As MessageTreeLookup

      If m_pClient Is Nothing Then
         Return False
      End If

      pChannel = ChannelGet(iChannelID)

      pRequest = New CEDF()
      pRequest.AddChild("channelid", iChannelID)
      If iSubType = 0 And pChannel.m_iSubType >= ua.SUBTYPE_MEMBER Then
         sRequest = ua.MSG_CHANNEL_SUBSCRIBE

         pRequest.AddChild("subtype", pChannel.m_iSubType)
         pRequest.AddChild("active", False)
      Else
         If iSubType > 0 Then
            sRequest = ua.MSG_CHANNEL_SUBSCRIBE

            pRequest.AddChild("subtype", iSubType)
            pRequest.AddChild("active", True)
         Else
            sRequest = ua.MSG_CHANNEL_UNSUBSCRIBE
         End If
      End If

      pReply = New CEDF()

      bReturn = m_pClient.request3(sRequest, pRequest, pReply)

      If bReturn = True Then
         pChannel.m_iSubType = iSubType
      Else
         pReply.MsgPrint("sUAverHelper::ChannelSubscribe " & sRequest & " request failed")
      End If

      Return bReturn
   End Function

   Public Function ChannelFind(ByVal iChannelID As Integer, Optional ByRef pAnnounce As CEDF = Nothing) As frmTalk
      Dim iChannelNum As Integer = 1
      Dim bFound As Boolean
      Dim pForm As Form
      Dim pChannel As frmTalk

      If Not pAnnounce Is Nothing Then
         iChannelID = pAnnounce.GetChildInt("channelid")
      End If

      debugline("ChannelFind entry " & iChannelID)

      Do While bFound = False And iChannelNum <= m_pForms.Count()
         pForm = m_pForms.Item(iChannelNum)
         If pForm.GetType() Is GetType(frmTalk) Then
            pChannel = pForm
            debugline("ChannelFind check " & pChannel.GetChannelID())
            If pChannel.GetChannelID() = iChannelID Then
               bFound = True
            End If
         End If

         If bFound = False Then
            iChannelNum += 1
         End If
      Loop

      debugline("ChannelFind found " & bFound)

      If bFound = True Then
         Return pForm
      End If

      Return Nothing
   End Function

   Public Sub Channels(ByRef pChannels As CEDF)
      Dim iChannelNum As Integer, iNumChannels As Integer
      Dim iChannelID As Integer, iSubType As Integer, iAccessMode As Integer
      Dim sName As String
      Dim bLoop As Boolean

      'pChannels.MsgPrint("Channels data")

      iNumChannels = pChannels.Children("channel", True)
      If iNumChannels > 0 Then
         ReDim m_pChannelList(iNumChannels - 1)

         bLoop = pChannels.Child("channel")
         Do While bLoop = True
            iChannelID = pChannels.GetInt()
            sName = pChannels.GetChildStr("name")
            iSubType = pChannels.GetChildInt("subtype")

            iAccessMode = pChannels.GetChildInt("accessmode")

            m_pChannelList(iChannelNum) = New MessageTreeLookup(iChannelID, sName, iSubType, 0, 0, 0, iAccessMode)

            If mask(iAccessMode, ua.ACCMODE_SUB_READ) = False Then
               m_pChannelList(iChannelNum).ImageIndex = ICO_LOCK
            Else
               m_pChannelList(iChannelNum).ImageIndex = -1
            End If

            bLoop = pChannels.Iterate("channel")
            If bLoop = True Then
               iChannelNum += 1
            End If
         Loop

         Array.Sort(m_pChannelList, m_pComparer)
      Else
         m_pChannelList = Nothing
      End If
   End Sub

   Public Function ServiceGet(ByVal iServiceID As Integer) As ServiceLookup
      Dim iTemp As Integer

      Return LookupFind(m_pServiceList, iServiceID, iTemp)
   End Function

   Public Function ServiceCount() As Integer
      If m_pServiceList Is Nothing Then
         Return 0
      End If

      Return m_pServiceList.Length
   End Function

   Public Function ServiceList(ByVal iServiceNum As Integer) As ServiceLookup
      If m_pServiceList Is Nothing Then
         Return Nothing
      End If

      If iServiceNum < 0 Or iServiceNum >= m_pServiceList.Length Then
         Return Nothing
      End If

      Return m_pServiceList(iServiceNum)
   End Function

   Public Sub ServiceActivate(ByRef pService As ServiceLookup, ByRef pEDF As CEDF)
      pService.m_bActive = True

      pService.m_pEDF = New CEDF()
      pService.m_pEDF.Copy(pEDF, True, True, True)
   End Sub

   Public Sub ServiceDeactivate(ByRef pService As ServiceLookup)
      pService.m_bActive = False
      pService.m_pEDF = Nothing
   End Sub

   Public Sub ServiceStatus(ByRef pService As ServiceLookup, ByVal iType As Integer, ByRef pEDF As CEDF)
      Dim iStatus As Integer
      Dim bLoop As Boolean
      Dim sUsername As String, sStatusMsg As String

      'pEDF.MsgPrint("ServiceStatus")

      'pService.m_pEDF.MsgPrint("ServiceStatus pre-edit data", CEDF.EL_CURR)

      If iType = -2 Then
         Do While pService.m_pEDF.DeleteChild("username") = True
         Loop

         bLoop = pEDF.Child("username")
         Do While bLoop = True
            sUsername = pEDF.GetStr()
            ServiceStatusUser(pService, pEDF, sUsername, -1)

            bLoop = pEDF.Next("username")
         Loop
      Else
         sUsername = pEDF.GetChildStr("username")
         ServiceStatusUser(pService, pEDF, sUsername, iType)
      End If

      'pService.m_pEDF.MsgPrint("ServiceStatus post-edit data", CEDF.EL_CURR)
   End Sub

   Private Sub ServiceStatusUser(ByRef pService As ServiceLookup, ByRef pEDF As CEDF, ByVal sUsername As String, ByVal iType As Integer)
      Dim iStatus As Integer
      Dim sStatusMsg As String

      If pService.m_pEDF.Child("username", sUsername) = False Then
         pService.m_pEDF.Add("username", sUsername)
      End If

      If iType <> -1 Then
         pService.m_pEDF.SetChild("status", iType)
      ElseIf pEDF.IsChild("status") = True Then
         iStatus = pEDF.GetChildInt("status")
         pService.m_pEDF.SetChild("status", iStatus)
      End If

      sStatusMsg = TextDecode(pEDF.GetChildStr("statusmsg"))
      If Not sStatusMsg Is Nothing Then
         pService.m_pEDF.SetChild("statusmsg", sStatusMsg)
      Else
         pService.m_pEDF.DeleteChild("statusmsg")
      End If

      pService.m_pEDF.Parent()
   End Sub

   Public Sub Services(ByRef pServices As CEDF)
      Dim iServiceNum As Integer, iNumServices As Integer
      Dim iServiceID As Integer, iServiceType As Integer
      Dim bActive As Boolean
      Dim sName As String
      Dim bLoop As Boolean

      'pServices.MsgPrint("sUAveHelper::Services")

      iNumServices = pServices.Children("service")
      If iNumServices > 0 Then
         ReDim m_pServiceList(iNumServices - 1)

         bLoop = pServices.Child("service")
         Do While bLoop = True
            iServiceID = pServices.GetInt()
            sName = pServices.GetChildStr("name")
            iServiceType = pServices.GetChildInt("servicetype")
            bActive = pServices.GetChildBool("active")

            m_pServiceList(iServiceNum) = New ServiceLookup(iServiceID, sName, iServiceType, bActive, Nothing)

            bLoop = pServices.Next("service")
            If bLoop = True Then
               iServiceNum += 1
            Else
               pServices.Parent()
            End If
         Loop
      Else
         m_pServiceList = Nothing
      End If
   End Sub

   Public Function PageFind(ByRef pUser As UserLookup, Optional ByRef pAnnounce As CEDF = Nothing) As frmPage
      Dim iUserID As Integer, iServiceID As Integer, iPageNum As Integer = 1
      Dim bFound As Boolean
      Dim sUserName As String, sText As String
      Dim pForm As Form
      Dim pPage As frmPage

      If Not pAnnounce Is Nothing Then
         iUserID = pAnnounce.GetChildInt("fromid")
         sUserName = pAnnounce.GetChildStr("fromname")
         iServiceID = pAnnounce.GetChildInt("serviceid")
      ElseIf Not pUser Is Nothing Then
         iUserID = pUser.m_iID
         iServiceID = pUser.m_iServiceID
      End If

      debugline("PageFind entry " & iUserID & " " & sUserName & " / service " & iServiceID)

      Do While bFound = False And iPageNum <= m_pForms.Count()
         pForm = m_pForms.Item(iPageNum)
         If pForm.GetType() Is GetType(frmPage) Then
            pPage = pForm

            If pPage.GetServiceID() > 0 Then
               If pPage.GetServiceID() = iServiceID Then
                  If pPage.GetFromName() = sUserName Then
                     bFound = True
                  End If
               End If
            Else
               If pPage.GetFromID() = iUserID Then
                  bFound = True
               End If
            End If
         End If

         If bFound = False Then
            iPageNum += 1
         End If
      Loop

      debugline("PageFind found " & bFound)

      If bFound = True Then
         Return pForm
      End If

      Return Nothing
   End Function

   Private Function LookupFind(ByRef pLookupList() As Lookup, ByVal iID As Integer, ByRef iLookupNum As Integer) As Lookup
      Dim iMin As Integer, iMax As Integer, iMid As Integer
      Dim pReturn As Lookup

      If pLookupList.Length = 0 Or iID <= 0 Then
         iLookupNum = 0

         Return Nothing
      End If

      'debugline("LookupFind entry " & iID & ", " & pLookupList.Length)

      iMax = pLookupList.Length - 1

      Do
         iMid = (iMin + iMax) \ 2
         'debugline("LookupFind compare at " & iMid & ": value " & pLookupList(iMid).m_iID)
         If pLookupList(iMid).m_iID = iID Then
            pReturn = pLookupList(iMid)
         ElseIf pLookupList(iMid).m_iID < iID Then
            iMin = iMid + 1
         Else
            iMax = iMid - 1
         End If
      Loop While pReturn Is Nothing And iMin <= iMax

      iLookupNum = iMid

      If Not pReturn Is Nothing Then
         'debugline("LookupFind exit " & pReturn.m_iID & ", " & iMid)
      Else
         'debugline("LookupFind exit NULL, " & iMid)
      End If

      Return pReturn
   End Function

   Public Function markup(ByVal sString As Object, Optional ByVal sMarkup As String = "B") As String
      Return Chr(31) & sMarkup & sString & Chr(31) & "0"
   End Function

   Public Function plural(ByVal sValue As String, ByVal sSingular As String, ByVal sPlural As String, Optional ByVal bMarkup As Boolean = False) As String
      Dim sReturn As String

      If bMarkup = True Then
         sReturn = markup(sValue)
      Else
         sReturn = sValue
      End If

      sReturn &= " "
      If sValue = "1" Then
         sReturn &= sSingular
      Else
         If Not sPlural Is Nothing Then
            sReturn &= sPlural
         Else
            sReturn &= sSingular & "s"
         End If
      End If

      Return sReturn
   End Function

   Public Function plural(ByVal iValue As Integer, ByVal sSingular As String, Optional ByVal bMarkup As Boolean = False)

      Return plural(iValue, sSingular, Nothing, bMarkup)
   End Function

   Public Function plural(ByVal iValue As Integer, ByVal sSingular As String, ByVal sPlural As String, Optional ByVal bMarkup As Boolean = False)
      Dim sValue As String

      sValue = iValue

      Return plural(sValue, sSingular, sPlural, bMarkup)
   End Function

   Public Function AbortEdit() As Boolean
      If MsgBox("Really abort edit?", MsgBoxStyle.Question + MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2) = MsgBoxResult.Yes Then
         Return True
      End If

      Return False
   End Function

   Public Sub TextShow(ByRef pControl As RichTextBox, ByVal sString As String, ByVal bUnicode As Boolean, ByVal bFixed As Boolean, ByVal bReset As Boolean, ByVal bEmphasis As Boolean)
      Dim iStringPos As Integer, iNumTextChars As Integer, iNumPicChars As Integer, iFound As Integer
      Dim iDataPos As Integer, iDataLen As Integer, iSlash As Integer, iAsterisk As Integer, iUnderscore As Integer, iNext As Integer, iSpace As Integer
      Dim sTemp As String
      Dim sChar As Char
      Dim pFont As Font
      Dim iFontStyle As FontStyle = FontStyle.Regular

      If Not sString Is Nothing Then
         If bUnicode = False And bFixed = False Then
            If sString.Length > 0 Then
               If sString.IndexOf("^^^") > 0 Or sString.IndexOf("---") > 0 Then
                  bFixed = True
               Else
                  For iStringPos = 0 To sString.Length - 1
                     sChar = sString.Substring(iStringPos, 1)
                     If Char.IsLetterOrDigit(sChar) = True Then
                        iNumTextChars += 1
                     ElseIf sChar <> " " And sChar <> vbCr And sChar <> vbLf Then
                        iNumPicChars += 1
                     End If
                  Next

                  debugline("sUAveHelper::TextShow " & iNumTextChars & " text, " & iNumPicChars & " pic, " & sString.Length & " total")

                  If iNumPicChars > 50 Or (100 * iNumPicChars) / sString.Length > 20 Then
                     bFixed = True
                  End If
               End If
            End If
         Else
            'MsgBox("Unicode " & bUnicode & ", fixed " & bFixed, , "TextShow")
         End If

         If bFixed = True Then
            pControl.Font = FixedFont()
            'MsgBox("Using fixed font")
         ElseIf bUnicode = True Then
            pControl.Font = UnicodeFont()
            'MsgBox("Using unicode font")
         Else
            pControl.Font = sUAveFont()
         End If
      End If

      If bReset = True Then
         pControl.Text = ""
      End If

      If Not sString Is Nothing Then
         'If bEmphasis = True Then
         'TextEmphasis(pControl, sString)
         'Else
         pControl.AppendText(sString)
         'End If
      End If

      If bFixed = True Or bUnicode = True Then
         'MsgBox("Control font " & pControl.Font.Name)
      End If
   End Sub

   Public Sub TextEmphasis(ByVal pControl As RichTextBox, ByVal sString As String)
      Dim iDataLen As Integer, iAsterisk As Integer, iSlash As Integer, iUnderscore As Integer, iDataPos As Integer
      Dim iNext As Integer, iSpace As Integer, iFontStyle As Integer, iFound As Integer
      Dim sTemp As String
      Dim pFont As Font

      pFont = pControl.Font

      iDataLen = sString.Length()
      iAsterisk = sString.IndexOf("*")
      iSlash = sString.IndexOf("/")
      iUnderscore = sString.IndexOf("_")

      Do While iDataPos < iDataLen
         If iAsterisk >= 0 Or iSlash >= 0 Or iUnderscore >= 0 Then
            If iAsterisk >= 0 And (iSlash < 0 Or iAsterisk < iSlash) And (iUnderscore < 0 Or iAsterisk < iUnderscore) Then
               If iAsterisk = 0 Or (iAsterisk > 0 And sString.Substring(iAsterisk - 1, 1) = " ") Then
                  iNext = sString.IndexOf("*", iAsterisk + 1)
                  iSpace = sString.IndexOf(" ", iAsterisk + 1)
                  If iNext >= 0 And (iSpace < 0 Or iNext < iSpace) Then
                     iFontStyle = FontStyle.Bold
                     iFound = iAsterisk
                     iAsterisk = sString.IndexOf("*", iNext + 1)
                  End If
               End If
            ElseIf iSlash >= 0 And (iUnderscore < 0 Or iSlash < iUnderscore) Then
               If iSlash = 0 Or (iSlash > 0 And sString.Substring(iSlash - 1, 1) = " ") Then
                  iNext = sString.IndexOf("/", iSlash + 1)
                  iSpace = sString.IndexOf(" ", iSlash + 1)
                  If iNext >= 0 And (iSpace < 0 Or iNext < iSpace) Then
                     iFontStyle = FontStyle.Italic
                     iFound = iSlash
                     iSlash = sString.IndexOf("/", iNext + 1)
                  End If
               End If
            Else
               If iUnderscore = 0 Or (iUnderscore > 0 And sString.Substring(iUnderscore - 1, 1) = " ") Then
                  iNext = sString.IndexOf("_", iUnderscore + 1)
                  iSpace = sString.IndexOf(" ", iUnderscore + 1)
                  If iNext >= 0 And (iSpace < 0 Or iNext < iSpace) Then
                     iFontStyle = FontStyle.Bold
                     iFound = iUnderscore
                     iUnderscore = sString.IndexOf("*", iNext + 1)
                  End If
               End If
            End If

            If iFontStyle <> FontStyle.Regular Then
               sTemp = sString.Substring(iDataPos, iFound - iDataPos)
               Debug.WriteLine("TextShow appending normal '" & sTemp & "'")
               pControl.AppendText(sTemp)

               pControl.Select()
               pControl.SelectionFont = New Font(pFont, iFontStyle)
               sTemp = sString.Substring(iFound + 1, iNext - iFound - 1)
               Debug.WriteLine("TextShow appending special '" & sTemp & "'")
               pControl.AppendText(sTemp)
               pControl.Select()
               pControl.SelectionFont = pFont

               iFontStyle = FontStyle.Regular

               iDataPos = iNext + 1
            Else
               If iSpace - iDataPos > 0 Then
                  sTemp = sString.Substring(iDataPos, iSpace - iDataPos)
                  Debug.WriteLine("TextShow appending normal '" & sTemp & "'")
                  pControl.AppendText(sTemp)
               End If

               iDataPos = iSpace + 1
            End If
         Else
            sTemp = sString.Substring(iDataPos)
            Debug.WriteLine("TextShow ending with '" & sTemp & "'")
            pControl.AppendText(sTemp)
            iDataPos = iDataLen
         End If
      Loop
   End Sub

   Public Function TextDecode(ByVal sString As String) As String
      Dim iByteNum As Integer
      Dim pBytes() As Byte
      Dim pEncoder As UTF8Encoding

      If sString Is Nothing Then
         Return Nothing
      End If

      'Do UTF-8 decoding
      ReDim pBytes(sString.Length - 1)
      pEncoder = New UTF8Encoding()
      For iByteNum = 0 To sString.Length - 1
         pBytes(iByteNum) = Asc(sString.Chars(iByteNum))
      Next
      sString = pEncoder.GetString(pBytes)

      'Replace CF/LFs with LFs (so all lines LFs only) then put the CRs back
      sString = sString.Replace(CRLF, Chr(10))
      sString = sString.Replace(Chr(10), CRLF)

      Return sString
   End Function

   Public Function AddTextField(ByVal pEDF As CEDF, ByVal sField As String, ByVal sValue As String, Optional ByVal sDefault As String = "")
      Dim pValue() As Byte
      Dim pEncoder As UTF8Encoding

      If sValue <> "" Then
         pEncoder = New UTF8Encoding()
         pValue = pEncoder.GetBytes(sValue)
         pEDF.AddChild(sField, pValue, pValue.Length)
      ElseIf sDefault <> "" Then
         pEDF.AddChild(sField, sDefault)
      End If
   End Function

   Public Function TimeHM() As String
      Dim sReturn As String
      Dim pNow As DateTime

      pNow = Now()

      sReturn = Microsoft.VisualBasic.Right("00" & pNow.Hour, 2)
      sReturn &= ":" & Microsoft.VisualBasic.Right("00" & pNow.Minute, 2)

      Return sReturn
   End Function

   Public Function SecsToHM(ByVal iSeconds As Integer) As String
      Dim iHours As Integer
      Dim sReturn As String

      iHours = iSeconds \ 3600
      If iHours >= 100 Then
         sReturn = iHours
      Else
         sReturn = Microsoft.VisualBasic.Right("00" & iHours, 2)
      End If
      sReturn &= ":" & Microsoft.VisualBasic.Right("00" & (iSeconds \ 60) Mod 60, 2)

      Return sReturn
   End Function

   Public Function mask(ByVal iValue As Integer, ByVal iMask As Integer) As Boolean
      If iValue And iMask Then
         Return True
      End If

      Return False
   End Function

   Private Function StrValueUnit(ByRef iValue As Integer, ByVal iDivider As Integer, ByVal sUnit As String, ByVal sUnits As String, ByRef iNumFields As Integer, ByVal bMarkup As Boolean, ByRef bFirst As Boolean) As String
      Dim iUnit As Integer
      Dim dValue As Double, dDivider As Double, dUnit As Double
      Dim sValue As String, sReturn As String = ""

      debugline("StrValueUnit entry v=" & iValue & " d=" & iDivider & " u=" & sUnit & " f=" & iNumFields & " f=" & bFirst)

      If iValue >= iDivider And iNumFields <> 0 And iNumFields <> -3 Then
         If iNumFields = -2 Then
            dValue = iValue
            dDivider = iDivider
            dUnit = dValue / dDivider
            sValue = Format(dUnit, "0.00")
            If sValue.EndsWith(".00") = True Then
               sValue = sValue.Substring(0, sValue.Length - 3)
            End If

            iValue = 0
         Else
            If iDivider <> 1 Then
               iUnit = iValue \ iDivider
               iValue = iValue Mod iDivider
            Else
               iUnit = iValue
               iValue = 0
            End If
            sValue = iUnit
         End If

         debugline("StrValueUnit v=" & iValue & " d=" & iDivider & " -> u=" & dUnit & " v=" & sValue)

         If bFirst = False Then
            sReturn &= ", "
         End If

         sReturn &= plural(sValue, sUnit, sUnits, bMarkup)

         If iNumFields > 0 Then
            iNumFields -= 1
         ElseIf iNumFields = -2 Then
            iNumFields = -3
         End If

         bFirst = False
      End If

      debugline("StrValueUnit exit " & sReturn & ", v=" & iValue & " f=" & iNumFields & " f=" & bFirst)
      Return sReturn
   End Function

   Private Function StrValueUnit(ByRef iValue As Integer, ByVal iDivider As Integer, ByVal sUnit As String, ByRef iNumFields As Integer, ByVal bMarkup As Boolean, ByRef bFirst As Boolean) As String
      Return StrValueUnit(iValue, iDivider, sUnit, Nothing, iNumFields, bMarkup, bFirst)
   End Function

   Private Function StrValueUnit(ByRef iValue As Integer, ByVal sUnit As String, ByRef iNumFields As Integer, ByVal bMarkup As Boolean, ByRef bFirst As Boolean) As String
      Return StrValueUnit(iValue, 1, sUnit, Nothing, iNumFields, bMarkup, bFirst)
   End Function

   Public Function StrValue(ByVal iType As Integer, ByVal iValue As Integer, ByVal iNumFields As Integer, Optional ByVal bMarkup As Boolean = False) As String
      Dim bFirst As Boolean = True
      Dim sReturn As String = ""

      debugline("StrValue entry t=" & iType & " v=" & iValue & " f=" & iNumFields)

      If iType = STRVALUE_TIME Then
         sReturn &= StrValueUnit(iValue, 604800, "week", iNumFields, bMarkup, bFirst)
         sReturn &= StrValueUnit(iValue, 86400, "day", iNumFields, bMarkup, bFirst)
         sReturn &= StrValueUnit(iValue, 3600, "hour", iNumFields, bMarkup, bFirst)
         sReturn &= StrValueUnit(iValue, 60, "minute", iNumFields, bMarkup, bFirst)
         sReturn &= StrValueUnit(iValue, "second", iNumFields, bMarkup, bFirst)
      ElseIf iType = STRVALUE_BYTE Then
         sReturn &= StrValueUnit(iValue, 1000000000, "Gb", "Gb", iNumFields, bMarkup, bFirst)
         sReturn &= StrValueUnit(iValue, 1000000, "Mb", "Mb", iNumFields, bMarkup, bFirst)
         sReturn &= StrValueUnit(iValue, 1000, "Kb", "Kb", iNumFields, bMarkup, bFirst)
         sReturn &= StrValueUnit(iValue, "byte", iNumFields, bMarkup, bFirst)
      End If

      debugline("StrValue exit " & sReturn)
      Return sReturn
   End Function

   Public Function StrValue(ByVal iType As Integer, ByVal iValue As Integer, Optional ByVal bMarkup As Boolean = False) As String
      Dim iNumFields As Integer = -1

      If iType = STRVALUE_BYTE Then
         iNumFields = -2
      End If

      Return StrValue(iType, iValue, iNumFields, bMarkup)
   End Function

   Public Function StrTime(ByVal iType As Integer, ByVal iTime As Integer, Optional ByVal bMarkup As Boolean = False) As String
      Dim sFormat As String
      Dim dTime As DateTime, dNow As DateTime
      Dim pTimeZone As TimeZone
      Dim pDaylightTime As Globalization.DaylightTime

      dNow = Now()
      pTimeZone = TimeZone.CurrentTimeZone

      dTime = New DateTime(1970, 1, 1)
      dTime = dTime.AddSeconds(iTime)
      If pTimeZone.IsDaylightSavingTime(dTime) = True Then
         pDaylightTime = pTimeZone.GetDaylightChanges(dTime.Year)
         dTime = dTime.AddSeconds(pDaylightTime.Delta.TotalSeconds)
      End If

      If iType = STRTIME_TIME Then
         sFormat = "HH:mm:ss"
      ElseIf iType = STRTIME_HM Then
         sFormat = "HH:mm"
      ElseIf iType = STRTIME_DATE Then
         sFormat = "dd/MM/yy"
      ElseIf iType = STRTIME_SHORT Then
         sFormat = "HH:mm:ss dd/MM/yy"
      ElseIf iType = STRTIME_MEDIUM Then
         If dNow.Year <> dTime.Year Then
            sFormat = "HH:mm, dddd dd/MM/yy"
         Else
            sFormat = "HH:mm, dddd dd/MM"
         End If
      ElseIf iType = STRTIME_LONG Then
         sFormat = "dddd, dd MMMM yyyy - HH:mm"
      End If

      If bMarkup = True Then
         Return markup(dTime.ToString(sFormat))
      Else
         Return dTime.ToString(sFormat)
      End If

      Return ""
   End Function

   Public Function isLoggedIn(ByRef pUser As UserLookup) As Boolean
      If mask(pUser.m_iValue, ua.LOGIN_ON) = True Or pUser.m_iNumShadows > 0 Then
         Return True
      End If

      Return False
   End Function

   Public Function isActive(ByVal iStatus As Integer) As Boolean
      If iStatus > 0 And mask(iStatus, ua.LOGIN_BUSY) = False And mask(iStatus, ua.LOGIN_NOCONTACT) = False And mask(iStatus, ua.LOGIN_SHADOW) = False Then
         Return True
      End If

      Return False
   End Function

   Public Function debugline(ByVal sString As String) As Integer
      If Not m_pClient Is Nothing Then
         Return CClient.debugline(sString)
      Else
         Console.WriteLine(sString)
         Return sString.Length
      End If
   End Function

   Public Function FormAdd(ByRef pForm As Form) As Form
      If m_pForms Is Nothing Then
         Return Nothing
      End If

      m_pForms.Add(pForm)

      Return pForm
   End Function

   Public Function FormRemove(ByRef pForm As Form) As Boolean
      Dim iFormNum As Integer = 1
      Dim bFound As Boolean

      If m_pForms Is Nothing Then
         Return False
      End If

      Do While bFound = False And iFormNum <= m_pForms.Count
         If m_pForms.Item(iFormNum) Is pForm Then
            m_pForms.Remove(iFormNum)

            bFound = True
         Else
            iFormNum += 1
         End If
      Loop

      Return bFound
   End Function

   Public Function FormFocus() As Form
      Dim iFormNum As Integer = 1
      Dim pReturn As Form

      Do While pReturn Is Nothing And iFormNum <= m_pForms.Count
         If m_pForms.Item(iFormNum).containsfocus Then
            pReturn = m_pForms.Item(iFormNum)
         Else
            iFormNum += 1
         End If
      Loop

      Return pReturn
   End Function

   Public Sub FormDispose(ByRef pMiss As Form)
      Dim iFormNum As Integer = 1
      Dim pForm As Form

      If Not m_pForms Is Nothing Then
         For Each pForm In m_pForms
            If Not pForm Is pMiss Then
               pForm.Dispose()
            End If
         Next
      End If
   End Sub

   Public Sub SetServerTime(ByRef pSystem As CEDF)
      Dim iServerTime As Integer, iClientTime As Integer
      Dim pTimeDiff As TimeSpan

      iServerTime = pSystem.GetChildInt("systemtime")

      pTimeDiff = Now().Subtract(New DateTime(1970, 1, 1))
      iClientTime = pTimeDiff.TotalSeconds

      m_iServerDiff = iClientTime - iServerTime

      'MsgBox("Server time " & iServerTime & ", client time " & iClientTime & ". Diff " & m_iServerDiff)
   End Sub

   Public Function GetServerTime() As Integer
      Dim iClientTime As Integer
      Dim pTimeDiff As TimeSpan

      pTimeDiff = Now().Subtract(New DateTime(1970, 1, 1))
      iClientTime = pTimeDiff.TotalSeconds

      Return iClientTime - m_iServerDiff
   End Function

   Public Function AccessColour(ByVal bCustom As Boolean, ByVal iAccessLevel As Integer, ByVal iUserType As Integer) As Color
      If bCustom = True Then
         If mask(iUserType, ua.USERTYPE_AGENT) = True Then
            Return Color.Blue
         End If

         Select Case iAccessLevel
            Case ua.LEVEL_NONE
               Return Color.FromArgb(192, 192, 192)

            Case ua.LEVEL_GUEST
               Return Color.FromArgb(0, 255, 0)

            Case ua.LEVEL_MESSAGES
               Return Color.FromArgb(0, 255, 0)

            Case ua.LEVEL_EDITOR
               Return Color.Magenta

            Case ua.LEVEL_WITNESS
               Return Color.Yellow

            Case ua.LEVEL_SYSOP
               Return Color.Red
         End Select
      Else
         If iAccessLevel = ua.LEVEL_MESSAGES Or iAccessLevel = ua.LEVEL_EDITOR Then
            Return SystemColors.ActiveCaption
         End If

         Return SystemColors.WindowText
      End If
   End Function

   Public Function AccessStyle(ByVal bCustom As Boolean, ByVal iAccessLevel As Integer, ByVal iUserType As Integer) As FontStyle
      If bCustom = True Then
         Return FontStyle.Bold
      Else
         If mask(iUserType, ua.USERTYPE_AGENT) = True Or iAccessLevel = ua.LEVEL_NONE Or iAccessLevel = ua.LEVEL_GUEST Or iAccessLevel = ua.LEVEL_MESSAGES Then
            Return FontStyle.Regular
         End If

         Return FontStyle.Bold
      End If
   End Function

   Public Function FixedFont() As Font
      Dim sName As String
      Dim iSize As Integer
      Dim pSettings As RegistryKey

      If m_pFixedFont Is Nothing Then
         pSettings = GetRegSection()
         sName = pSettings.GetValue("fixedfontname", "Courier New")
         iSize = pSettings.GetValue("fixedfontsize", 8)
         m_pFixedFont = New Font(sName, iSize, FontStyle.Regular)
      End If

      Return m_pFixedFont
   End Function

   Public Sub FixedFont(ByRef pFont As Font)
      m_pFixedFont = pFont
   End Sub

   Public Function UnicodeFont() As Font
      Dim sName As String
      Dim iSize As Integer
      Dim pSettings As RegistryKey

      If m_pUnicodeFont Is Nothing Then
         pSettings = GetRegSection()
         sName = pSettings.GetValue("unicodefontname", Nothing)
         iSize = pSettings.GetValue("unicodefontsize", 0)
         If Not sName Is Nothing And iSize > 0 Then
            m_pUnicodeFont = New Font(sName, iSize, FontStyle.Regular)
         End If
      End If

      Return m_pUnicodeFont
   End Function

   Public Sub UnicodeFont(ByRef pFont As Font)
      m_pUnicodeFont = pFont
   End Sub

   Public Function sUAveFont() As Font
      Return m_pFont
   End Function

   Public Sub sUAveFont(ByRef pForm As Form)
      If m_pFont Is Nothing Then
         m_pFont = New Font("Tahoma", 8, FontStyle.Regular)
      End If

      pForm.SuspendLayout()
      pForm.Font = m_pFont
      pForm.ResumeLayout()
   End Sub

   Public Function GetRegSection() As RegistryKey
      Dim pReturn As RegistryKey, pChild As RegistryKey

      pReturn = Registry.CurrentUser
      'ShowKeys(pSettings)

      pReturn = pReturn.OpenSubKey("Software", True)
      'ShowKeys(pSettings)

      pChild = pReturn.OpenSubKey("UNaXcess", True)
      If pChild Is Nothing Then
         'Console.Write("mnuFileOpen no UNaXcess key")
         pChild = pReturn.CreateSubKey("UNaXcess")
      End If
      pReturn = pChild

      pChild = pReturn.OpenSubKey("sUAve", True)
      If pChild Is Nothing Then
         'Console.Write("mnuFileOpen no sUAve key")
         pChild = pReturn.CreateSubKey("sUAve")
      End If
      pReturn = pChild

      Return pReturn
   End Function

   Public Function EDFFind(ByRef pEDF As CEDF, ByVal sName As String, ByVal iID As Integer, Optional ByVal bRecurse As Boolean = False) As Boolean
      Dim bLoop As Boolean

      bLoop = pEDF.Child(sName)
      Do While bLoop = False
         If pEDF.GetValType() = CEDF.EL_INT And pEDF.GetInt() = iID Then
            Return True
         End If

         If bRecurse = True Then
            If EDFFind(pEDF, sName, iID, True) = True Then
               Return True
            End If
         End If

         bLoop = pEDF.Next(sName)
         If bLoop = False Then
            pEDF.Parent()
         End If
      Loop

      Return False
   End Function

   Public Function IsXP() As Boolean
      Dim pVersion As OperatingSystem

      pVersion = Environment.OSVersion()

      'debugline("frmsUAve::frmsUAve OS version " & pVersion.Version.Major & "." & pVersion.Version.Minor)

      If pVersion.Version.Major > 5 Or (pVersion.Version.Major = 5 And pVersion.Version.Minor >= 1) Then
         Return True
      End If

      Return False
   End Function

   Public Function NumPos(ByVal iValue As Integer) As String
      If iValue Mod 10 = 1 And iValue Mod 100 <> 11 Then
         Return "st"
      ElseIf iValue Mod 10 = 2 And iValue Mod 100 <> 12 Then
         Return "nd"
      ElseIf iValue Mod 10 = 3 And iValue Mod 100 <> 13 Then
         Return "rd"
      End If

      Return "th"
   End Function

   Public Function FilenameToMIME(ByVal sFilename As String) As String
      Dim iTemp As Integer = 0, iExtPos As Integer, iKeyNum As Integer
      Dim sExt As String, sReturn As String
      Dim pKey As RegistryKey, pChild As RegistryKey
      Dim sKeys As String()

      iExtPos = sFilename.Length - 1
      Do While iExtPos >= 0 And sFilename.Chars(iExtPos) <> "."
         iExtPos -= 1
      Loop

      If iExtPos < 0 Then
         Return Nothing
      End If

      sExt = sFilename.Substring(iExtPos)

      If sExt.ToLower() = ".edf" Then
         Return ua.MSGATT_EDF
      End If

      pKey = Registry.ClassesRoot

      sKeys = pKey.GetSubKeyNames()

      Do While sReturn Is Nothing And iKeyNum < sKeys.Length
         If sKeys(iKeyNum).ToLower() = sExt.ToLower() Then
            pChild = pKey.OpenSubKey(sKeys(iKeyNum))
            If Not pChild Is Nothing Then
               sReturn = pChild.GetValue("Content Type")
            End If
         End If

         If sReturn Is Nothing Then
            iKeyNum += 1
         End If
      Loop

      Return sReturn
   End Function

   Public Function OpenAttachments(ByRef pEDF As CEDF) As Boolean
      Dim iReadPos As Integer, iReadLen As Integer, iFilePos As Integer, iCharNum As Integer
      Dim bReturn As Boolean
      Dim sFilename As String, sContentType As String, sData As String
      Dim pData() As Byte
      Dim pOpen As OpenFileDialog
      Dim pFile As FileStream
      'Dim pConverter As ASCIIEncoding

      pOpen = New OpenFileDialog()
      pOpen.CheckFileExists = True
      pOpen.Multiselect = True

      If pOpen.ShowDialog() = DialogResult.OK Then
         'pConverter = New ASCIIEncoding()

         pEDF = New CEDF()

         For Each sFilename In pOpen.FileNames

            'sFilename = pFileForm.FileName()
            sContentType = FilenameToMIME(sFilename)
            If sContentType Is Nothing Then
               sContentType = "application/octet-stream"
            End If

            pFile = pOpen.OpenFile()
            If Not pFile Is Nothing Then
               ReDim pData(pFile.Length - 1)
               iReadLen = pFile.Read(pData, 0, pFile.Length)

               pFile.Close()

               iFilePos = sFilename.Length - 1
               Do While iFilePos >= 0 And sFilename.Chars(iFilePos) <> "\"
                  iFilePos -= 1
               Loop

               If iFilePos >= 0 Then
                  sFilename = sFilename.Substring(iFilePos + 1)
               End If

               'sData = BytesToString(pData)

               pEDF.Add("attachment")
               pEDF.AddChild("content-type", sContentType)
               pEDF.AddChild("filename", sFilename)
               'pEDF.AddChild("data", pConverter.GetChars(pData))
               'pEDF.AddChild("data", sData)
               pEDF.AddChild("data", pData, pData.Length)
               pEDF.Parent()

               bReturn = True
            Else
               MsgBox("Unable to open " & sFilename & ". " & Err.Description, MsgBoxStyle.Exclamation)
            End If
         Next
      End If

      Return bReturn
   End Function

   Public Function SaveAttachments(ByRef pEDF As CEDF) As Boolean
      Dim bLoop As Boolean, bReturn As Boolean
      Dim sFilename As String, sData As String
      Dim pFile As FileStream
      Dim pBytes() As Byte
      'Dim pConverter As ASCIIEncoding
      Dim pSave As SaveFileDialog

      If Not pEDF Is Nothing Then
         If pEDF.IsChild("attachment") = True Then
            If MsgBox("Save attachments?", MsgBoxStyle.Question + MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
               'pConverter = New ASCIIEncoding()

               bLoop = pEDF.Child("attachment")
               Do While bLoop = True
                  sFilename = pEDF.GetChildStr("filename")
                  sData = pEDF.GetChildStr("data")

                  debugline("SaveAttachments data " & sData.Length & " bytes long")

                  pSave = New SaveFileDialog()
                  pSave.FileName = sFilename

                  If pSave.ShowDialog() = DialogResult.OK Then
                     'debugline("SaveAttachments converting to bytes")
                     'pBytes = StringToBytes(sData)

                     'debugline("SaveAttachments writing bytes")
                     'pFile = New FileStream(pSave.FileName, FileMode.Create)
                     'pFile.Write(pBytes, 0, sData.Length)
                     'pFile.Close()

                     CClient.FileWrite(pSave.FileName, sData)

                     bReturn = True
                  End If

                  bLoop = pEDF.Next("attachment")
                  If bLoop = False Then
                     pEDF.Parent()
                  End If
               Loop
            End If
         End If
      End If

      Return bReturn
   End Function

   Private Sub debugmem(ByVal sTitle As String, ByRef sData As String, ByRef pData() As Byte)
      Dim iPos As Integer, iLen As Integer
      Dim cSingle As Char
      Dim sDebug As String

      If Not pData Is Nothing Then
         iLen = pData.Length
      Else
         iLen = sData.Length
      End If

      sDebug = sTitle & ", " & iLen & " bytes: "
      For iPos = 0 To iLen - 1
         If Not pData Is Nothing Then
            cSingle = Chr(pData(iPos))
         Else
            cSingle = sData.Chars(iPos)
         End If

         If False And Char.IsLetterOrDigit(cSingle) Then
            sDebug &= cSingle
         Else
            sDebug &= "[" & Asc(cSingle) & "]"
         End If
      Next

      debugline(sDebug)
   End Sub

   Public Function StringToBytes(ByRef sData As String) As Byte()
      Dim iByteNum As Integer
      Dim pReturn() As Byte

      If sData Is Nothing Then
         Return Nothing
      End If

      debugmem("StringToBytes source", sData, Nothing)

      ReDim pReturn(sData.Length - 1)
      For iByteNum = 0 To sData.Length - 1
         pReturn(iByteNum) = Asc(sData.Chars(iByteNum))
      Next

      'debugmem("StringToBytes dest", Nothing, pReturn)

      Return pReturn
   End Function

   Private Function IsSmiley(ByVal sText As String) As Boolean
      If sText.StartsWith(":)") = True Or sText.StartsWith(":(") = True Then
         Return True
      End If

      If sText.StartsWith(":-)") = True Or sText.StartsWith(":-(") = True Or sText.StartsWith(":-/") = True Then
         Return True
      End If

      Return False
   End Function

   Public Function gettick() As DateTime
      Return Now()
   End Function

   Public Function tickdiff(ByVal dTick As DateTime) As Double
      Dim pDiff As TimeSpan

      pDiff = dTick.Subtract(Now)

      Return Math.Abs(pDiff.TotalMilliseconds())
   End Function

   Public Function SpellCheck(ByVal sString As String) As String
      Dim pSpeller As Object
      Dim sReturn As String

      Try
         pSpeller = CreateObject("Word.Basic")

         pSpeller.FileNew()
         pSpeller.Insert(sString)
         pSpeller.ToolsSpelling()
         pSpeller.AppShow()
         pSpeller.EditSelectAll()
         pSpeller.AppHide()
         sReturn = pSpeller.Selection()
         pSpeller.FileClose(2)

         Do While sReturn.EndsWith(vbCr)
            sReturn = sReturn.Substring(0, sReturn.Length - 1)
         Loop

         sReturn = sReturn.Replace(vbCr, vbCrLf)
      Catch e As Exception
         MsgBox("Exception " & e.Message, , "SpellCheck")
      End Try

      Return sReturn
   End Function

   Public Sub ShowUsers(ByVal rcbControl As RichControl.RichComboBox, ByVal bMarkup As Boolean, ByVal bLoginsOnly As Boolean)
      Dim iUserNum As Integer, iStatus As Integer
      Dim bLoop As Boolean, bAdd As Boolean
      Dim sUsername As String, sStatusMsg As String
      Dim pEDF As CEDF
      Dim pService As ServiceLookup
      Dim pLookup As Lookup
      Dim pUser As UserLookup
      Dim pList As ArrayList

      pList = New ArrayList()

      For iUserNum = 0 To UserCount() - 1
         pUser = UserList(iUserNum)

         If isLoggedIn(pUser) = True Then
            If isActive(pUser.m_iValue) = True Then
               pUser.ImageIndex = ICO_BULB_ON
            Else
               pUser.ImageIndex = ICO_BULB_OFF
            End If

            bAdd = True
         Else
            pUser.ImageIndex = -1

            If bLoginsOnly = False Then
               bAdd = True
            Else
               bAdd = False
            End If
         End If

         If bAdd = True Then
            If bMarkup = False Then
               pLookup = New Lookup(0, pUser.m_iID, 0, pUser.m_sValue, pUser.ImageIndex)
            Else
               pLookup = pUser
            End If

            pList.Add(pLookup)
         End If
      Next

      debugline("frmsUAve::ShowWholist " & ServiceCount() & " services")

      For iUserNum = 0 To ServiceCount() - 1
         pService = ServiceList(iUserNum)

         pEDF = pService.m_pEDF
         If Not pEDF Is Nothing Then

            'pEDF.MsgPrint("sUAveHelper::ShowUsers service")

            bLoop = pEDF.Child("username")
            Do While bLoop = True
               sUsername = pEDF.GetStr()
               iStatus = ua.LOGIN_OFF

               If pEDF.IsChild("status") = True Then
                  iStatus = pEDF.GetChildInt("status")
               ElseIf pEDF.GetChildBool("active") = True Then
                  iStatus = ua.LOGIN_ON
               End If
               sStatusMsg = pEDF.GetChildStr("statusmsg")

               pUser = New UserLookup(0, 0, sUsername, 0, iStatus, False, sStatusMsg, 0, pService.m_iID, pService.m_sValue)
               If isLoggedIn(pUser) = True Then
                  If isActive(pUser.m_iValue) = True Then
                     pUser.ImageIndex = ICO_BULB_ON
                  Else
                     pUser.ImageIndex = ICO_BULB_OFF
                  End If

                  bAdd = True
               Else
                  pUser.ImageIndex = -1
               End If

               pList.Add(pUser)

               bLoop = pEDF.Next("username")
               If bLoop = False Then
                  pEDF.Parent()
               End If
            Loop
         End If
      Next

      rcbControl.BeginUpdate()
      rcbControl.Items.Clear()

      pList.Sort()

      For iUserNum = 0 To pList.Count - 1
         pLookup = pList.Item(iUserNum)

         rcbControl.Items.Add(pLookup)
      Next

      rcbControl.EndUpdate()
   End Sub

   Private Sub MatchAdd(ByRef pEDF As CEDF, ByRef bNot As Boolean, ByVal sCommand As String, ByVal sValue As String)
      Dim pLookup As Lookup

      debugline("MatchAdd entry " & bNot & " " & sCommand & "/" & sValue)

      If sCommand = "and" Or sCommand = "or" Then
         debugline("MatchAdd boolean")
         pEDF.Set(sCommand)
      ElseIf sCommand = "not" Then
         bNot = Not bNot
      ElseIf sValue.Length > 0 Then
         If bNot = True Then
            pEDF.Add("not")
         End If

         If sCommand = "folder" Then
            pLookup = FolderGet(sValue)
            If Not pLookup Is Nothing Then
               pEDF.AddChild("folderid", pLookup.m_iID)
            Else
               debugline("MatchAdd invalid folder " & sValue)
            End If
         ElseIf sCommand = "from" Or sCommand = "to" Or sCommand = "user" Then
            pLookup = UserGet(sValue)
            If Not pLookup Is Nothing Then
               If sCommand = "user" Then
                  pEDF.Add("or")
                  pEDF.AddChild("fromid", pLookup.m_iID)
                  pEDF.AddChild("toid", pLookup.m_iID)
                  pEDF.Parent()
               Else
                  pEDF.AddChild(sCommand & "id", pLookup.m_iID)
               End If
            Else
               debugline("MatchAdd invalid user " & sValue)
            End If
         ElseIf sCommand = "text" Or sCommand = "subject" Or sCommand = "keyword" Then
            pEDF.AddChild(sCommand, sValue)
         Else
            pEDF.AddChild("keyword", sValue)
         End If

         If bNot = True Then
            pEDF.Parent()

            bNot = False
         End If
      Else
         debugline("MatchAdd doing nothing")
      End If

      debugline("MatchAdd exit")
   End Sub

   Private Sub MatchClose(ByRef pEDF As CEDF)
      Dim sName As String
      Dim pTemp As CEDF

      pEDF.debugPrint("MatchClose entry", CEDF.EL_CURR + CEDF.PR_SPACE)

      If pEDF.Children() = 0 Then
         debugline("MatchClose delete element")
         pEDF.Delete()
      ElseIf pEDF.Children() = 1 Then
         debugline("MatchClose consolidate element")
         pEDF.Child()

         pTemp = New CEDF()
         pTemp.Copy(pEDF, True, True, True)
         pTemp.debugPrint("MatchClose temp")

         pEDF.Delete()
         pEDF.Delete()

         pEDF.Copy(pTemp, True, False, True)
      Else
         debugline("MatchClose move to parent")
         pEDF.Parent()
      End If

      If pEDF.GetName() = "not" Then
         debugline("MatchClose move not to parent")
         pEDF.Parent()
      End If

      pEDF.debugPrint("MatchClose exit ", CEDF.EL_CURR + CEDF.PR_SPACE)
   End Sub

   Public Function MatchToEDF(ByVal sMatch As String) As CEDF
      Dim iMatchPos As Integer = 0, iValue As Integer, iStartPos As Integer, iCommandPos As Integer, iValueLen As Integer
      Dim bNot As Boolean = False, bLoop As Boolean
      Dim pMatch As Char()
      Dim sValue As String, sToken As String, sCommand As String, sQuote As String
      Dim pReturn As CEDF
      Dim pLookup As Lookup

      debugline("MatchToEDF entry " & sMatch)

      pReturn = New CEDF()
      pReturn.Add("and")

      pMatch = sMatch.ToCharArray()
      Do While iMatchPos < pMatch.Length
         bLoop = True
         Do While bLoop = True
            If iMatchPos = pMatch.Length Then
               bLoop = False
            ElseIf Char.IsWhiteSpace(pMatch(iMatchPos)) = False Then
               bLoop = False
            Else
               iMatchPos += 1
            End If
         Loop

         If iMatchPos < pMatch.Length Then
            debugline("MatchToEDF match point " & sMatch.Substring(iMatchPos))

            If pMatch(iMatchPos) = "(" Then
               debugline("MatchToEDF open bracket")

               If bNot = True Then
                  pReturn.Add("not")
                  bNot = False
               End If

               pReturn.Add("and")

               iMatchPos += 1
            ElseIf pMatch(iMatchPos) = ")" Then
               debugline("MatchToEDF close bracket")

               MatchClose(pReturn)

               iMatchPos += 1
            Else
               debugline("MatchToEDF token")
               iStartPos = iMatchPos

               If pMatch(iMatchPos) = Chr(34) Or pMatch(iMatchPos) = Chr(39) Then
                  sQuote = pMatch(iMatchPos)

                  iStartPos += 1

                  bLoop = True
                  Do While bLoop = True
                     iMatchPos += 1
                     If iMatchPos = pMatch.Length Then
                        bLoop = False
                     ElseIf pMatch(iMatchPos) = sQuote Then
                        bLoop = False
                     End If
                  Loop

                  sValue = sMatch.Substring(iStartPos, iMatchPos - iStartPos)
                  debugline("MatchToEDF value " & sValue)

                  MatchAdd(pReturn, bNot, "", sValue)
               Else
                  bLoop = True
                  Do While bLoop = True
                     iMatchPos += 1
                     If iMatchPos = pMatch.Length Then
                        bLoop = False
                     ElseIf Char.IsWhiteSpace(pMatch(iMatchPos)) = True Then
                        bLoop = False
                     ElseIf pMatch(iMatchPos) = "(" Or pMatch(iMatchPos) = ")" Or pMatch(iMatchPos) = ":" Then
                        bLoop = False
                     End If
                  Loop

                  If iMatchPos < pMatch.Length Then
                     If pMatch(iMatchPos) = ":" Then
                        debugline("MatchToEDF command")

                        sCommand = sMatch.Substring(iStartPos, iMatchPos - iStartPos)

                        iStartPos = iMatchPos + 1
                        If pMatch(iStartPos) = Chr(34) Or pMatch(iStartPos) = Chr(39) Then
                           debugline("MatchToEDF quote " & pMatch(iStartPos))
                           sQuote = pMatch(iStartPos)

                           iStartPos += 1
                           iMatchPos = iStartPos
                           bLoop = True
                           Do While bLoop = True
                              iMatchPos += 1
                              If iMatchPos = pMatch.Length Then
                                 bLoop = False
                              ElseIf pMatch(iMatchPos) = sQuote Then
                                 bLoop = False
                              End If
                           Loop

                           sValue = sMatch.Substring(iStartPos, iMatchPos - iStartPos)

                           If iMatchPos < pMatch.Length Then
                              iMatchPos += 1
                           End If
                        Else
                           bLoop = True
                           Do While bLoop = True
                              iMatchPos += 1
                              If iMatchPos = pMatch.Length Then
                                 bLoop = False
                              ElseIf Char.IsWhiteSpace(pMatch(iMatchPos)) = True Then
                                 bLoop = False
                              ElseIf pMatch(iMatchPos) = "(" Or pMatch(iMatchPos) = ")" Or pMatch(iMatchPos) = ":" Then
                                 bLoop = False
                              End If

                              sValue = sMatch.Substring(iStartPos, iMatchPos - iStartPos)
                           Loop
                        End If

                        debugline("MatchToEDF command " & sCommand & "/" & sValue)

                        MatchAdd(pReturn, bNot, sCommand, sValue)
                     Else
                        sValue = sMatch.Substring(iStartPos, iMatchPos - iStartPos)
                        debugline("MatchToEDF value " & sValue)

                        MatchAdd(pReturn, bNot, sValue, sValue)
                     End If
                  Else
                     sValue = sMatch.Substring(iStartPos, iMatchPos - iStartPos)
                     debugline("MatchToEDF value " & sValue)

                     MatchAdd(pReturn, bNot, sValue, sValue)
                  End If
               End If
            End If
         End If
      Loop

      MatchClose(pReturn)

      pReturn.Root()

      pReturn.debugPrint("MatchToEDF exit")

      Return pReturn
   End Function

   Public Sub AddSubToList(ByVal sType As String, ByVal sRequestType As String, ByVal sItemType As String, ByRef pItem As Lookup, ByRef pList As ListBox)
      Dim iLookupNum As Integer, iNumLookups As Integer, iID As Integer, iSubType As Integer
      Dim sName As String
      Dim pRequest As CEDF, pReply As CEDF
      Dim pLookup As Lookup, pTemp As Lookup
      Dim pUser As UserLookup
      Dim pInput As frmInput

      debugline("AddSubToList t=" & sType & " r=" & sRequestType & " i=" & sItemType & "/" & pItem.m_iID)

      pInput = New frmInput("Add Subscription", frmInput.RCB_INPUT + frmInput.CMB_TYPE, "Name", ua.UA_NAME_LEN)

      If sType = "folder" Then
         iNumLookups = FolderCount()
      ElseIf sType = "channel" Then
         iNumLookups = ChannelCount()
      ElseIf sType = "user" Then
         iNumLookups = UserCount()
      End If

      pInput.BeginAddItems()
      For iLookupNum = 0 To (iNumLookups - 1)
         If sType = "folder" Then
            pLookup = FolderList(iLookupNum)
         ElseIf sType = "channel" Then
            pLookup = ChannelList(iLookupNum)
         ElseIf sType = "user" Then
            pUser = UserList(iLookupNum)
            If pUser.m_iAccessLevel >= ua.LEVEL_MESSAGES Then
               pLookup = pUser
            Else
               pLookup = Nothing
            End If
         End If

         If Not pLookup Is Nothing Then
            pTemp = New Lookup(0, pLookup.m_iID, pLookup.m_sValue)

            pInput.AddItem(pTemp)
         End If
      Next
      pInput.EndAddItems()

      pInput.AddType("Subscriber")
      pInput.AddType("Member")
      If Client.GetAccessLevel() >= ua.LEVEL_WITNESS Then
         pInput.AddType("Editor")
      End If

      If pInput.ShowDialog() = DialogResult.OK Then
         pLookup = pInput.GetItem()

         If Not pLookup Is Nothing Then
            debugline("AddSubToList lookup " & pLookup.m_iID & " " & pLookup.m_sValue)

            pRequest = New CEDF()
            pRequest.AddChild(sType & "id", pLookup.m_iID)

            If pInput.GetTypeIndex() = 1 Then
               pRequest.AddChild("subtype", ua.SUBTYPE_MEMBER)
            ElseIf pInput.GetTypeIndex() = 2 Then
               pRequest.AddChild("subtype", ua.SUBTYPE_EDITOR)
            End If

            pRequest.AddChild(sItemType & "id", pItem.m_iID)

            pReply = New CEDF()

            If Client.request3(sRequestType & "_subscribe", pRequest, pReply) = True Then
               iID = pReply.GetChildStr(sType & "id")
               sName = pReply.GetChildStr(sType & "name")
               iSubType = pReply.GetChildInt("subtype")

               pLookup = New Lookup(Lookup.FOLDER_SUB, iID, iSubType, sName, -1)
               pList.Items.Add(pLookup)
            Else
               pReply.MsgPrint("AddSubToList request failed")
            End If
         End If
      End If
   End Sub

   Public Sub RemoveSubFromList(ByVal sType As String, ByVal sRequestType As String, ByVal sItemType As String, ByVal pItem As Lookup, ByRef pList As ListBox)
      Dim pLookup As Lookup
      Dim pRequest As CEDF, pReply As CEDF

      debugline("RemoveSubFromList t=" & sType & " r=" & sRequestType & " i=" & sItemType & "/" & pItem.m_iID)

      pLookup = pList.SelectedItem

      If Not pLookup Is Nothing Then
         debugline("RemoveSubFromList lookup " & pLookup.m_iID & " " & pLookup.m_sValue)

         If MsgBox("Really remove " & pLookup.m_sValue & " from " & pItem.m_sValue & "?", MsgBoxStyle.Question + MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2) = MsgBoxResult.Yes Then
            pRequest = New CEDF()
            pRequest.AddChild(sType & "id", pLookup.m_iID)
            pRequest.AddChild(sItemType & "id", pItem.m_iID)

            pReply = New CEDF()

            If Client.request3(sRequestType & "_unsubscribe", pRequest, pReply) = True Then
               pList.Items.Remove(pLookup)
            Else
               pReply.MsgPrint("RemoveSubFromList request failed")
            End If
         End If
      End If
   End Sub

   Public Sub SetBrowser()
      Dim sFileType As String, sCommandLine As String
      Dim pKey As RegistryKey

      pKey = Registry.ClassesRoot

      pKey = pKey.OpenSubKey(".htm", False)
      'MsgBox(".htm key " & pKey.ToString(), , "SetBrowser")

      sFileType = pKey.GetValue(Nothing)

      pKey = Registry.ClassesRoot

      pKey = pKey.OpenSubKey(sFileType & "\\shell\\open\\command", False)
      'MsgBox(sFileType & " key " & pKey.ToString(), , "SetBrowser")

      sCommandLine = pKey.GetValue(Nothing)
      'MsgBox("Command line " & sCommandLine, , "SetBrowser")

      If sCommandLine.StartsWith("""") = True Then
         sCommandLine = sCommandLine.Substring(1)
         m_sBrowser = sCommandLine.Substring(0, sCommandLine.IndexOf(""""))
      Else
         m_sBrowser = sCommandLine
      End If

      'MsgBox("Browser " & m_sBrowser, , "SetBrowser")
   End Sub

   Public Function GetBrowser() As String
      Return m_sBrowser
   End Function
End Module
