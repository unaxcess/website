Public Class ua

   'Protocol
   Public Const PROTOCOL = "2.7-beta8"

   'String lengths (UA_ prefix introduced in v2.4-beta8 due to conflicts with MySQL)
   Public Const UA_NAME_LEN = 20
   Public Const UA_SHORTMSG_LEN = 100
   Public Const UA_ACCESSNAME_LEN = 10

   'User types
   Public Const USERTYPE_NONE = 0
   Public Const USERTYPE_DELETED = 2
   Public Const USERTYPE_AGENT = 1
   Public Const USERTYPE_TEMP = 4

   'Access levels
   Public Const LEVEL_NONE = 0
   Public Const LEVEL_GUEST = 1
   Public Const LEVEL_MESSAGES = 2
   Public Const LEVEL_EDITOR = 3
   Public Const LEVEL_WITNESS = 4
   Public Const LEVEL_SYSOP = 5

   'Gender types
   Public Const GENDER_PERSON = 0
   Public Const GENDER_MALE = 1
   Public Const GENDER_FEMALE = 2
   Public Const GENDER_NONE = 3

   'Login status code flags
   Public Const LOGIN_OFF = 0
   Public Const LOGIN_ON = 1
   Public Const LOGIN_BUSY = 2
   Public Const LOGIN_IDLE = 4
   Public Const LOGIN_TALKING = 8
   Public Const LOGIN_AGENT = 16 'Deprecated in v2.2a
   Public Const LOGIN_GONE = 32 'Deprecated in v2.0
   Public Const LOGIN_SILENT = 64
   Public Const LOGIN_NOCONTACT = 128 'Added in v2.5-alpha, mapped to LOGIN_SHADOW in v2.6-beta3
   Public Const LOGIN_SHADOW = 256 'Added in v2.5-alpha
   Public Const LOGIN_BUSYFRIENDS = 512 'Added in v2.6-beta4

   'Detail types
   Public Const DETAIL_PUBLIC = 1
   Public Const DETAIL_VALID = 2
   Public Const DETAIL_OWNER = 4
   Public Const DETAIL_PROXY = 8

   'Access rights (expanded from folder-only rights in v2.5-beta5)
   Public Const ACCMODE_SUB_READ = 1
   Public Const ACCMODE_SUB_WRITE = 2
   Public Const ACCMODE_MEM_READ = 16
   Public Const ACCMODE_MEM_WRITE = 32
   Public Const ACCMODE_PRIVATE = 256

   Public Const ACCMODE_READONLY = ACCMODE_SUB_READ

   'Folder specific, changed in v2.6-beta6
   Public Const FOLDERMODE_SUB_SDEL = 4
   Public Const FOLDERMODE_SUB_ADEL = 8
   Public Const FOLDERMODE_SUB_MOVE = 512
   Public Const FOLDERMODE_MEM_SDEL = 64
   Public Const FOLDERMODE_MEM_ADEL = 128
   Public Const FOLDERMODE_MEM_MOVE = 1024
   Public Const FOLDERMODE_CONTENT = 2048 'Added in v2.7-alpha
   Public Const FOLDERMODE_PERSIST = 4096 'Added in v2.7-alpha

   Public Const FOLDERMODE_NORMAL = ACCMODE_SUB_READ + ACCMODE_SUB_WRITE + FOLDERMODE_SUB_SDEL
   Public Const FOLDERMODE_RESTRICTED = ACCMODE_MEM_READ + ACCMODE_MEM_WRITE + FOLDERMODE_MEM_SDEL

   '#define ACCMODE_NORMAL FOLDERMODE_NORMAL // Deprecated in v2.6-alpha, use FOLDERMODE_NORMAL
   '#define ACCMODE_RESTRICTED FOLDERMODE_RESTRICTED // Deprecated in v2.6-alpha, use FOLDERMODE_RESTRICTED

   'Channel specific (added in v2.6-alpha)
   Public Const CHANNELMODE_PERMANENT = 512
   Public Const CHANNELMODE_LOGGED = 1024
   Public Const CHANNELMODE_LOGIN = 2048

   Public Const CHANNELMODE_NORMAL = ACCMODE_SUB_READ + ACCMODE_SUB_WRITE
   Public Const CHANNELMODE_RESTRICTED = ACCMODE_MEM_READ + ACCMODE_MEM_WRITE
   Public Const CHANNELMODE_DEBATE = ACCMODE_MEM_READ + ACCMODE_MEM_WRITE + ACCMODE_SUB_READ

   'Message types (expanded v2.5-beta6)
   Public Const MSGTYPE_NONE = 0
   Public Const MSGTYPE_DELETED = 1
   Public Const MSGTYPE_VOTE = 2
   Public Const MSGTYPE_ARCHIVE = 4

   'Marking types
   Public Const MARKING_ADD_PRIVATE = 1
   Public Const MARKING_ADD_PUBLIC = 2
   Public Const MARKING_EDIT_PRIVATE = 4
   Public Const MARKING_EDIT_PUBLIC = 8

   Public Const MARKED_READ = 1
   Public Const MARKED_UNREAD = 2

   'Subscription types (expanded from folder-only types v2.4-beta5)
   Public Const SUBTYPE_SUB = 1
   Public Const SUBTYPE_MEMBER = 2
   Public Const SUBTYPE_EDITOR = 3
   Public Const SUBTYPE_ACTIVE = 4 'Deprecated in v2.6-alpha

   'Folder subscription types for backwards compatiblity (deprecated in v2.4-beta5)
   '#define FOLDER_SUBTYPE_SUB SUBTYPE_SUB
   '#define FOLDER_SUBTYPE_MEMBER SUBTYPE_MEMBER
   '#define FOLDER_SUBTYPE_EDITOR SUBTYPE_EDITOR

   Public Const SUBNAME_SUB = "subscriber"
   Public Const SUBNAME_MEMBER = "member"
   Public Const SUBNAME_EDITOR = "editor"

   'Backwards compatiblity (deprecated in v2.4-beta5)
   '#define FOLDER_SUBNAME_SUB SUBNAME_SUB
   '#define FOLDER_SUBNAME_MEMBER SUBNAME_MEMBER
   '#define FOLDER_SUBNAME_EDITOR SUBNAME_EDITOR

   'Voting types
   Public Const VOTE_SIMPLE = 1 'Deprecated in v2.2a
   Public Const VOTE_COMPLEX = 2 'Deprecated in v2.2a
   Public Const VOTE_NAMED = 1
   '#define VOTE_CHOICE 2 // Deprecated in v2.6-beta6
   Public Const VOTE_CHANGE = 4
   Public Const VOTE_MULTI = 64 'Added in v2.6-beta4
   Public Const VOTE_PUBLIC = 8
   Public Const VOTE_PUBLIC_CLOSE = 16
   Public Const VOTE_CLOSED = 32
   Public Const VOTE_INTVALUES = 128 'Added in v2.6-beta16
   Public Const VOTE_PERCENT = 256 'Added in v2.6-beta16
   Public Const VOTE_STRVALUES = 512 'Added in v2.6-beta16
   Public Const VOTE_FLOATVALUES = 1024 'Added in v2.7-beta8
   Public Const VOTE_FLOATPERCENT = 2048 'Added in v2.7-beta8

   'Message attachment types
   Public Const MSGATT_EDF = "text/x-edf"
   Public Const MSGATT_ANNOTATION = "text/x-ua-annotation"
   Public Const MSGATT_LINK = "text/x-ua-link"

   Public Const MSGATT_FAILED = 1
   Public Const MSGATT_TOOBIG = 2
   Public Const MSGATT_MIMETYPE = 3

   'Message thread operation (mark_read, mark_unread, move, delete) types - added v2.6-beta5
   Public Const THREAD_MSGCHILD = 1
   Public Const THREAD_CHILD = 2

   'Channel types (deprecated in v2.4-beta5, see access rights)
   '#define CHANNEL_PUBLIC 1
   '#define CHANNEL_PRIVATE 2
   '#define CHANNEL_PERMANENT 4
   '#define CHANNEL_PEER 8

   'Channel subscription types (deprecated in v2.4-beta5, see subscription types)
   '#define CHANNEL_MEMBER 1
   '#define CHANNEL_MODERATOR 2
   '#define CHANNEL_OWNER 4
   '#define CHANNEL_ACTIVE 8

   'Contact types (deprecated in v2.6-alpha - use services)
   Public Const CONTACT_PAGE = 0
   Public Const CONTACT_EMAIL = 1
   Public Const CONTACT_SMS = 2
   Public Const CONTACT_POST = 3 'Use divert flag

   'Service types (added in v2.6-alpha)
   Public Const SERVICE_CONTACT = 1
   Public Const SERVICE_LOGIN = 2
   Public Const SERVICE_TONAME = 4

   'Task repeat times
   Public Const TASK_DAILY = 1
   Public Const TASK_WEEKDAY = 2
   Public Const TASK_WEEKEND = 3
   Public Const TASK_WEEKLY = 4

   'Message archiving (added in v2.7-beta7)
   Public Const ARCHIVE_PUBLIC = 1
   Public Const ARCHIVE_PRIVATE = 2

   'Service actions (added in v2.6-beta2)
   Public Const ACTION_LIST = "list"
   Public Const ACTION_LOGIN = "login"
   Public Const ACTION_LOGOUT = "logout"
   Public Const ACTION_LOGIN_INVALID = "login_invalid"
   Public Const ACTION_CONTACT_INVALID = "contact_invalid"
   Public Const ACTION_CONTACT_NOT_EXIST = "contact_not_exist"
   Public Const ACTION_CONTACT_NOT_ON = "contact_not_on"
   Public Const ACTION_CONTACT_LOGIN = "contact_login"
   Public Const ACTION_CONTACT_LOGOUT = "contact_logout"
   Public Const ACTION_CONTACT_STATUS = "contact_status"



   'Request / reply / announce messages
   Public Const MSG_SYSTEM_EDIT = "system_edit"
   Public Const MSG_SYSTEM_LIST = "system_list"
   Public Const MSG_SYSTEM_WRITE = "system_write"
   Public Const MSG_SYSTEM_MESSAGE = "system_message"
   Public Const MSG_SYSTEM_SHUTDOWN = "system_shutdown"
   Public Const MSG_SYSTEM_MAINTENANCE = "system_maintenance"
   Public Const MSG_SYSTEM_CONTACT = "system_contact" 'Added in v2.6-alpha

   Public Const MSG_CONNECTION_CLOSE = "connection_close"
   Public Const MSG_CONNECTION_DROP = "connection_drop" 'Deprecated in v2.5-beta4, use MSG_CONNECTION_CLOSE

   Public Const MSG_BULLETIN_ADD = "bulletin_add"
   Public Const MSG_BULLETIN_DELETE = "bulletin_delete"
   Public Const MSG_BULLETIN_EDIT = "bulletin_edit"
   Public Const MSG_BULLETIN_LIST = "bulletin_list"

   'Added in v2.6-beta11
   Public Const MSG_SERVICE_ADD = "service_add"
   Public Const MSG_SERVICE_DELETE = "service_delete"
   Public Const MSG_SERVICE_EDIT = "service_edit"
   Public Const MSG_SERVICE_LIST = "service_list"
   Public Const MSG_SERVICE_SUBSCRIBE = "service_subscribe"
   Public Const MSG_SERVICE_UNSUBSCRIBE = "service_unsubscribe"

   Public Const MSG_LOCATION_ADD = "location_add"
   Public Const MSG_LOCATION_DELETE = "location_delete"
   Public Const MSG_LOCATION_EDIT = "location_edit"
   Public Const MSG_LOCATION_LIST = "location_list"
   Public Const MSG_LOCATION_SORT = "location_sort" 'Added in v2.5-beta7
   Public Const MSG_LOCATION_LOOKUP = "location_lookup" 'Added in v2.5-beta8

   Public Const MSG_HELP_ADD = "help_add"
   Public Const MSG_HELP_DELETE = "help_delete"
   Public Const MSG_HELP_EDIT = "help_edit"
   Public Const MSG_HELP_LIST = "help_list"

   'Task scheduling (added in v2.5-beta2)
   Public Const MSG_TASK_ADD = "task_add"
   Public Const MSG_TASK_DELETE = "task_delete"
   Public Const MSG_TASK_EDIT = "task_edit"
   Public Const MSG_TASK_LIST = "task_list"

   Public Const MSG_FOLDER_ADD = "folder_add"
   Public Const MSG_FOLDER_DELETE = "folder_delete"
   Public Const MSG_FOLDER_EDIT = "folder_edit"
   Public Const MSG_FOLDER_LIST = "folder_list"
   Public Const MSG_FOLDER_SUBSCRIBE = "folder_subscribe"
   Public Const MSG_FOLDER_UNSUBSCRIBE = "folder_unsubscribe"
   Public Const MSG_FOLDER_ACTIVATE = "folder_activate"
   Public Const MSG_FOLDER_DEACTIVATE = "folder_deactivate"
   Public Const MSG_MESSAGE_ADD = "message_add"
   Public Const MSG_MESSAGE_DELETE = "message_delete"
   Public Const MSG_MESSAGE_EDIT = "message_edit"
   Public Const MSG_MESSAGE_LIST = "message_list"
   Public Const MSG_MESSAGE_MOVE = "message_move"
   Public Const MSG_MESSAGE_MARK_READ = "message_mark_read"
   Public Const MSG_MESSAGE_MARK_UNREAD = "message_mark_unread"
   Public Const MSG_MESSAGE_VOTE = "message_vote"
   Public Const MSG_CONTENT_ADD = "content_add" 'dded in v2.7-alpha
   Public Const MSG_CONTENT_DELETE = "content_delete" 'Added in v2.7-alpha
   Public Const MSG_CONTENT_EDIT = "content_edit" 'Added in v2.7-alpha
   Public Const MSG_CONTENT_LIST = "content_list" 'Added in v2.7-alpha

   Public Const MSG_CHANNEL_ADD = "channel_add"
   Public Const MSG_CHANNEL_DELETE = "channel_delete"
   Public Const MSG_CHANNEL_EDIT = "channel_edit"
   Public Const MSG_CHANNEL_LIST = "channel_list"
   Public Const MSG_CHANNEL_SUBSCRIBE = "channel_subscribe"
   Public Const MSG_CHANNEL_UNSUBSCRIBE = "channel_unsubscribe"
   Public Const MSG_CHANNEL_SEND = "channel_send"

   Public Const MSG_USER_ADD = "user_add"
   Public Const MSG_USER_DELETE = "user_delete"
   Public Const MSG_USER_EDIT = "user_edit"
   Public Const MSG_USER_LIST = "user_list"
   Public Const MSG_USER_STATS = "user_stats" 'Deprecated in v2.0, use MSG_SYSTEM_LIST
   Public Const MSG_USER_LOGIN = "user_login"
   Public Const MSG_USER_LOGIN_QUERY = "user_login_query" 'Added in v2.6-beta13
   Public Const MSG_USER_LOGOUT = "user_logout"
   Public Const MSG_USER_PAGE = "user_page" 'Deprecated in v2.6-beta11, use MSG_USER_CONTACT
   Public Const MSG_USER_AGENT = "user_agent" 'Deprecated in v2.6-beta11, use MSG_USER_CONTACT
   Public Const MSG_USER_CONTACT = "user_contact"
   Public Const MSG_USER_SYSOP = "user_sysop"
   Public Const MSG_USER_LOGOUT_LIST = "user_logout_list"

   'Error messages
   Public Const MSG_ACCESS_INVALID = "access_invalid"

   Public Const MSG_SYSTEM_CONTACT_INVALID = "system_contact_invalid" 'Added in v2.6-alpha

   Public Const MSG_CONNECTION_NOT_EXIST = "connection_not_exist"

   Public Const MSG_TASK_NOT_EXIST = "task_not_exist" 'Added in v2.5-beta2

   Public Const MSG_BULLETIN_NOT_EXIST = "bulletin_not_exist"
   Public Const MSG_BULLETIN_ACCESS_INVALID = "bulletin_access_invalid" 'Added in v2.6-alpha

   Public Const MSG_SERVICE_ACCESS_INVALID = "folder_access_invalid"
   Public Const MSG_SERVICE_NOT_EXIST = "service_not_exist"
   Public Const MSG_SERVICE_INVALID = "service_invalid"

   Public Const MSG_LOCATION_NOT_EXIST = "location_not_exist"
   Public Const MSG_LOCATION_INVALID = "location_invalid"

   Public Const MSG_HELP_NOT_EXIST = "help_not_exist"

   Public Const MSG_FOLDER_NOT_EXIST = "folder_not_exist"
   Public Const MSG_FOLDER_EXIST = "folder_exist" 'Deprecated in v2.5-beta3
   Public Const MSG_FOLDER_SUBSCRIBED = "folder_subscribed" 'Deprecated in v2.5-alpha, use MSG_FOLDER_SUBSCRIBE
   Public Const MSG_FOLDER_UNSUBSCRIBED = "folder_unsubscribed" 'Deprecated in v2.5-alpha, use MSG_FOLDER_SUBSCRIBE
   Public Const MSG_FOLDER_ACCESS_INVALID = "folder_access_invalid"
   Public Const MSG_FOLDER_INVALID = "folder_invalid"

   Public Const MSG_MESSAGE_NOT_EXIST = "message_not_exist"
   '#define MSG_MESSAGE_REPLIES_EXCEEDED "message_replies_exceeded" // Deprecated in v2.5-beta3, use MSG_MESSAGE_ACCESS_INVALID
   Public Const MSG_MESSAGE_MOVE_INVALID = "message_move_invalid" 'Deprecated in v2.5-beta3, use MSG_MESSAGE_ACCESS_INVALID
   '#define MSG_MESSAGE_VOTE_INVALID "message_vote_invalid" // Deprecated in v2.5-beta3, use MSG_MESSAGE_ACCESS_INVALID
   Public Const MSG_MESSAGE_ACCESS_INVALID = "message_access_invalid"

   Public Const MSG_CONTENT_NOT_EXIST = "content_not_exist" 'Added in v2.7-alpha
   Public Const MSG_CONTENT_ACCESS_INVALID = "content_access_invalid" 'Added in v2.7-alpha

   Public Const MSG_CHANNEL_NOT_EXIST = "channel_not_exist"
   Public Const MSG_CHANNEL_EXIST = "channel_exist"
   '#define MSG_CHANNEL_INVALID "channel_invalid" // Deprecated in v2.5-alpha
   Public Const MSG_CHANNEL_ACCESS_INVALID = "channel_access_invalid" 'Added in v2.6-alpha

   Public Const MSG_USER_NOT_EXIST = "user_not_exist"
   Public Const MSG_USER_EXIST = "user_exist"
   Public Const MSG_USER_NOT_ON = "user_not_on"
   Public Const MSG_USER_BUSY = "user_busy"
   Public Const MSG_USER_CONTACT_NOCONTACT = "user_contact_nocontact"
   Public Const MSG_USER_LOGIN_INVALID = "user_login_invalid"
   Public Const MSG_USER_LOGIN_ALREADY_ON = "user_login_already_on"
   Public Const MSG_USER_CONTACT_INVALID = "user_contact_invalid"
   Public Const MSG_USER_INVALID = "user_invalid"

   'Announce messages
   Public Const MSG_CONNECTION_OPEN = "connection_open"
   Public Const MSG_CONNECTION_DENIED = "connection_denied"

   Public Const MSG_SYSTEM_RELOAD = "system_reload"

   '#define MSG_CHANNEL_JOIN "channel_join" Deprecated in v2.5-alpha

   Public Const MSG_USER_STATUS = "user_status"
   Public Const MSG_USER_LOGIN_DENIED = "user_login_denied"

   Public Shared Function AccessName(ByVal iLevel As Integer, ByVal iType As Integer) As String
      If iType <> -1 And iType = USERTYPE_AGENT Then
         Return "Agent"
      End If

      Select Case iLevel
         Case LEVEL_NONE
            Return "None"

         Case LEVEL_GUEST
            Return "Guest"

         Case LEVEL_MESSAGES
            Return "Messages"

         Case LEVEL_EDITOR
            Return "Editor"

         Case LEVEL_WITNESS
            Return "Witness"

         Case LEVEL_SYSOP
            Return "SysOp"
      End Select

      Return ""
   End Function

   Public Shared Function gender(ByVal iGender As Integer)
      Select Case iGender
         Case GENDER_MALE
            Return "his"

         Case GENDER_FEMALE
            Return "her"

         Case GENDER_PERSON
            Return "their"

         Case GENDER_NONE
            Return "its"
      End Select

      Return ""
   End Function
End Class
