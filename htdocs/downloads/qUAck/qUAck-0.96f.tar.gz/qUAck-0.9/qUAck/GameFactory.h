#ifndef _GAME_FACTORY_H_
#define _GAME_FACTORY_H_

#include "Game.h"

Game *FindGame(char *szContentType);

#endif
